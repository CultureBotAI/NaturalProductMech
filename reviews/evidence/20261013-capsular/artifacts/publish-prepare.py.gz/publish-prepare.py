import csv
import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml
from naturalproductmech.curate.structure_corrections import row_digest

W = Path(__file__).parent
OLD = Path('/private/tmp/npmech-capsular-review-UUGHOQ')
RUN = Path('/private/tmp/npmech-capsular-resume-6vn9Sp')
ARCHIVE = Path('reviews/evidence/20261013-capsular')
BASE = 'b87e2fa3e2acc7896755a7c4eaa09d48fe0159e8'
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
digest = lambda raw: hashlib.sha256(raw).hexdigest()
raw = json.loads((OLD / 'structured-inspection.json').read_text())
seqs = {r['accession']: r for r in raw['sequences']}
source = list(csv.DictReader(Path('data/raw/mibig_compounds.tsv').open(), delimiter='\t'))
matrix = []
for m in raw['mibig']:
    r, = [r for r in source if r['mibig_accession'] == m['accession']]
    locus, = m['loci']
    s = seqs[locus['accession']]
    q = s['source'][0]['qualifiers']
    strain = q.get('strain', q.get('isolate'))[0]
    if 'isolate' in q:
        strain = 'isolate ' + strain
    assert m['status'] == 'active' and not locus['evidence'] and not m['compounds'][0]['evidence']
    assert r['entry_version'] == str(m['version'])
    matrix.append(dict(source_id=m['accession'] + ':' + r['compound_index'],
        source_row_sha256=row_digest(r), entry_version=m['version'],
        accession=s['accession'], strain=strain, serotype=q['serotype'][0],
        taxon_id=q['db_xref'][0], standard_inchi_key=r['standard_inchi_key'],
        qualifier_kind='isolate' if 'isolate' in q else 'strain'))
assert len(matrix) == 17
(W / 'matrix.json').write_text(json.dumps(matrix, indent=2) + '\n')

specs = [
    dict(slug='capsular-polysaccharide-2', cid=3083199, taxon='Klebsiella', pmid='17599305',
         serotypes='K5, K20 and K54', registry='K15',
         concern='Five deposited K5/K20/K54 loci share one finite, stereochemically undefined six-ring graph. PubChem names that graph as K15. The inspected study abstract concerns genotyping and clinical/serum-resistance comparisons, not exact product structural assignment.'),
    dict(slug='capsular-polysaccharide-3', cid=3083207, taxon='Streptococcus agalactiae', pmid='11773119',
         serotypes='Ia, III and VI', registry='type V',
         concern='Nine deposited Ia/III/VI loci share one stereospecified seven-ring graph whose PubChem record title is group B type V. The cited study abstract concerns PCR/sequencing serotyping, not proof that these loci synthesize this exact graph. An earlier type II research lead was incorrect and is discarded.'),
    dict(slug='capsular-polysaccharide', cid=195740, taxon='Actinobacillus', pmid='18215476',
         serotypes='12, 6 and 7', registry='type 7',
         concern='Three serotype 12/6/7 loci share one finite type-7-labelled graph. Its n-propoxy substituent, geminal ring diol and phosphate monoester require adjudication against capsule chemistry. The accessible 2024 study describes a glycosylglycerol-phosphate polymer backbone, not this finite graph, and its AP76 enzyme context is not the imported isolate 72-14676. A. lignieresii occurrence support remains unknown because the cited full paper is inaccessible; absence from its abstract is not refutation.'),
]
for spec in specs:
    inspection = json.loads((RUN / (spec['slug'] + '-inspect.json')).read_text())
    spec['target'] = inspection['targets'][0]
    spec['key'] = yaml.safe_load(Path(spec['target']['path']).read_text())['chemical_structure']['standard_inchi_key']
    rows = [r for r in matrix if r['standard_inchi_key'] == spec['key']]
    spec['matrix'] = rows
    spec['description'] = spec['concern'] + ' Registry names/MeSH associations are name-based and are not independent chemical certification. Exact PubChem graph agreement is verified; deleting its xref alone would not repair the biological assignment. The confirmed defect is unsupported exact-product assignment across the recorded contexts, not an experimentally established replacement structure.'
    body = f"""## Finding
Scientific identity blocker in `{spec['target']['path']}` at `{BASE}`.

{spec['description']}

## Inspected evidence
- Version-pinned MIBiG rows and GenBank source qualifiers: {', '.join(r['accession'] for r in rows)}.
- [PubChem {spec['cid']}](https://pubchem.ncbi.nlm.nih.gov/compound/{spec['cid']}): registry context {spec['registry']}; all stored InChI/keys reproduce with RDKit 2026.03.5.
- [PMID {spec['pmid']}](https://pubmed.ncbi.nlm.nih.gov/{spec['pmid']}/): metadata/abstract inspected; full text unavailable after access denial.

## Bounded remediation
Add a cited OPEN identity qualification and retain SEEDED status. Preserve source assertions and all exact keys pending product-specific adjudication. Do not rename every source to the registry serotype, guess stereochemistry, merge/split owners, or promote evidence grades.

## Acceptance for full resolution
Identify the actual product form for every retained locus and occurrence using inspected primary chemistry. Choose a supported individual-structure representation and maintained migration/exclusion path; regenerate and run strict validation, reproduction and full QC. A warning is mitigation, not closure.
"""
    if spec['cid'] == 195740:
        body += '\nAdditional inspected full text: https://doi.org/10.1038/s41589-024-01664-8, Results (Cps7D polymerization) and cloning methods; backbone and recombinant context only.\n'
    (W / (spec['slug'] + '-issue.md')).write_text(body)
(W / 'specs.json').write_text(json.dumps(specs, indent=2) + '\n')
(W / 'strains-issue.md').write_text('''## Finding
Three capsular owners omit explicit deposited strain/isolate context on 17 MIBiG producer claims. GenBank source qualifiers distinguish K5/K20/K54, GBS Ia/III/VI and Actinobacillus 12/6/7 contexts. Femo is already present in its taxon label but lacks an explicit strain field.

## Repair
Add exactly 17 complete-row-pinned qualifications to `curation/mibig_producer_strains.tsv`, citing the exact versioned GenBank accession. Preserve literal strain spelling; store `isolate 72-14676` explicitly as isolate context, not WF83 or AP76. Put serotype in the evidence rationale, not in taxon identity. Preserve all database assertions and SOURCE_ASSERTION / CLUSTER_UNSTATED grades.

## Acceptance
Compare the 17 rows against source qualifiers and expected raw-row hashes. Reseed only the three owners, verify all other source-owned fields are unchanged, append native history, regenerate pages/queue, and pass focused regression tests, strict validation, reproduction and full QC. This issue does not resolve the three chemical identity blockers.
''')
print(json.dumps(matrix, indent=2))
