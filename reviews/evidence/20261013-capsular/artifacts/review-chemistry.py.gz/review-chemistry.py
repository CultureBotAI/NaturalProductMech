import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, rdMolDescriptors, Draw

W = Path(__file__).parent
OLD = Path('/private/tmp/npmech-capsular-review-UUGHOQ')
capture = json.loads((W / 'capture.json').read_text())
patterns = {
    'n_propoxy_on_ring': '[CH3]-[CH2]-[CH2]-[O]-[C;R]',
    'geminal_ring_diol': '[C;R]([O;H1])([O;H1])',
    'phosphate_monoester': '[P](=[O])([O;H1])([O;H1])[O][C]',
    'carboxylic_acid': '[C](=[O])[O;H1]',
    'acetamide': '[CH3][C](=[O])[N]',
}
out, molecules, legends = [], [], []
for path, cid in zip(capture['selected'], [3083199, 3083207, 195740], strict=True):
    doc = json.loads((W / (Path(path).stem + '-resolved.json')).read_text())
    cs = doc['chemical_structure']
    mol = Chem.MolFromSmiles(cs['smiles'])
    assert mol is not None
    inchi = Chem.MolToInchi(mol)
    key = Chem.InchiToInchiKey(inchi)
    assert key == cs['standard_inchi_key'] and inchi == cs['standard_inchi']
    pcpath = OLD / f'pubchem{cid}.json'
    receipt = json.loads(pcpath.with_suffix('.json.receipt.json').read_text())
    assert hashlib.sha256(pcpath.read_bytes()).hexdigest() == receipt['sha256']
    prop, = json.loads(pcpath.read_text())['PropertyTable']['Properties']
    assert prop['CID'] == cid and prop['InChIKey'] == key
    assert Chem.MolToInchiKey(Chem.MolFromSmiles(prop['SMILES'])) == key
    formula = rdMolDescriptors.CalcMolFormula(mol)
    assert prop['MolecularFormula'] == formula
    centers = Chem.FindMolChiralCenters(mol, includeUnassigned=True, useLegacyImplementation=False)
    matches = {name: mol.GetSubstructMatches(Chem.MolFromSmarts(smarts)) for name, smarts in patterns.items()}
    out.append(dict(path=path, target_id=doc['identifier'], standard_inchi_key=key,
        formula=formula, formal_charge=Chem.GetFormalCharge(mol), exact_mass=Descriptors.ExactMolWt(mol),
        exact_mass_units='Da', connected_components=len(Chem.GetMolFrags(mol)),
        ring_sizes=[len(r) for r in mol.GetRingInfo().AtomRings()],
        assigned_centers=sum(label != '?' for _, label in centers),
        unassigned_centers=sum(label == '?' for _, label in centers),
        reported_stereo_complete=cs['stereo_complete'],
        dummy_atoms=sum(a.GetAtomicNum() == 0 for a in mol.GetAtoms()),
        pubchem_cid=cid, pubchem_inchikey_exact=True, motifs=matches,
        interpretation='Finite explicit molecular graph, not an encoded variable-degree polymer. Exact registry agreement does not validate a BGC-to-compound assignment.'))
    molecules.append(mol)
    legends.append(f'{Path(path).stem}: {formula}')
result = dict(rdkit_version=rdBase.rdkitVersion, inspected_at=datetime.now(timezone.utc).isoformat(),
    atom_indices='zero-based RDKit atom indices in each owner SMILES', smarts=patterns, records=out)
with (W / 'chemistry.json').open('x') as handle:
    json.dump(result, handle, indent=2)
Draw.MolsToGridImage(molecules, molsPerRow=1, subImgSize=(1300, 650), legends=legends).save(W / 'structures.png')
print(json.dumps(result, indent=2))
