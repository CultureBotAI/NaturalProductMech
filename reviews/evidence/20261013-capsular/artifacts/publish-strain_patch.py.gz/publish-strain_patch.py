import csv
import io
import json
from pathlib import Path

specs = json.loads((Path(__file__).parent / 'specs.json').read_text())
path = Path('curation/mibig_producer_strains.tsv')
existing = path.read_text()
headers = existing.splitlines()[0].split('\t')
rows = list(csv.DictReader(io.StringIO(existing), delimiter='\t'))
new = []
for spec, issue in zip(specs, (935, 936, 937), strict=True):
    for r in spec['matrix']:
        assert not any(old['source_id'] == r['source_id'] for old in rows)
        item = dict(source_id=r['source_id'], expected_source_row_sha256=r['source_row_sha256'],
            strain=r['strain'], reference='https://www.ncbi.nlm.nih.gov/nuccore/' + r['accession'],
            curator='codex', date='2026-10-13',
            rationale=f"GenBank {r['accession']} source feature identifies {r['qualifier_kind']} {r['strain'].removeprefix('isolate ')} and serotype {r['serotype']}. This qualifies the deposited locus, not exact capsule-product identity, which remains open in issue #{issue}. No taxon, structure or evidence-grade change. See issue #938.")
        new.append('\t'.join(item[h] for h in headers))
print('*** Begin Patch\n*** Update File: ' + str(path) + '\n@@\n ' + existing.splitlines()[-1])
print('\n'.join('+' + line for line in new))
print('*** End Patch')
