import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
prior = json.loads(Path('/private/tmp/npmech-vibrioferrin-publish-PRF5Nf/review-campaign-checkpoint-final.json').read_text())
selected = {s['target']['path'] for s in json.loads((W / 'specs.json').read_text())}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed = []
components = 0
for row in prior['records']:
    if sha(row['path']) != row['sha256']:
        assert row['path'] in selected
        before = yaml.safe_load(subprocess.check_output(['git', 'show', prior['base'] + ':' + row['path']]))
        after = yaml.safe_load(Path(row['path']).read_text())
        for old, new in zip(before['producer_organisms'], after['producer_organisms'], strict=True):
            assert new.pop('strain')
            ev = new['evidence'].pop()
            assert ev['evidence_type'] == 'CURATOR_INFERENCE' and '#938' in ev['notes']
            assert old == new
        discussion = after['discussions'].pop()
        assert discussion['discussion_id'] == 'curator-capsule-exact-product-assignment'
        assert discussion['status'] == 'OPEN'
        assert after['curation_history'][:len(before['curation_history'])] == before['curation_history']
        assert len(after['curation_history']) == len(before['curation_history']) + 2
        after['curation_history'] = before['curation_history']
        assert before == after
        changed.append(row['path'])
    for component in row['graph_components']:
        assert sha(component['path']) == component['sha256']
        components += 1
assert set(changed) == selected and len(prior['records']) == 3115 and components == 243
for r in prior['all_review_observations']:
    assert sha(r['yaml']) == r['yaml_sha256'] and sha(r['markdown']) == r['markdown_sha256']
assert not subprocess.check_output(['git', 'diff', prior['base'], '--', 'data/raw', 'data/natural_products/PATHS.tsv', 'data/causal_graphs'])
result = dict(checked_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    base=prior['base'], owners=3115, components=243, changed=changed, unchanged=3112,
    previous_review_pairs_unchanged=42, preserved='All chemistry, taxa, imported assertions, evidence grades, occurrences, source rows, statuses and preexisting history; only 17 deposited qualifiers, three OPEN discussions and append-only history changed.')
(W / 'scope-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
