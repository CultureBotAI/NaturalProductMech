import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

path = Path(sys.argv[1])
root = ET.parse(path).getroot()
text = lambda e: ' '.join(''.join(e.itertext()).split())
items = []
for tag in ['article-title', 'article-id', 'abstract', 'sec', 'fig']:
    for node in root.findall('.//' + tag):
        if tag == 'sec':
            for child in node:
                if child.tag in ('title', 'p', 'table-wrap'):
                    items.append(dict(tag=child.tag, section=node.get('id'), text=text(child)))
        else:
            items.append(dict(tag=tag, id=node.get('id'), attributes=node.attrib,
                text=text(node), graphics=[g.attrib for g in node.findall('.//graphic')]))
out = path.with_suffix('.read.json')
with out.open('x') as handle:
    json.dump(items, handle, indent=2)
for index, row in enumerate(items):
    print(f'[{index}] {row.get("tag")} {row.get("id", row.get("section", ""))}: {row["text"]}')
    if row.get('graphics'):
        print(json.dumps(row['graphics']))
