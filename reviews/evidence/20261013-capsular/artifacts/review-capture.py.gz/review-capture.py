import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml
from naturalproductmech.graph_components import read_natural_product
from naturalproductmech.curate.structure_corrections import row_digest

W = Path(__file__).parent
OLD = Path('/private/tmp/npmech-capsular-review-UUGHOQ')
P = Path('/private/tmp/npmech-vibrioferrin-publish-PRF5Nf/review-campaign-checkpoint-final.json')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
started = now()
assert sha(P) == '461f55ce82a7826cbd938c3726a2d8ffc520fbf4cbca738c9e7e7ca7cbfcefbc'
prior = json.loads(P.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == prior['base'] == 'b87e2fa3e2acc7896755a7c4eaa09d48fe0159e8'
assert not subprocess.check_output(['git', 'status', '--porcelain'])
owners = {r['path']: r for r in prior['records']}
components = {c['path']: c for r in owners.values() for c in r['graph_components']}
assert len(owners) == 3115 and len(components) == 243
actual = {str(p) for root in ['data/natural_products', 'data/causal_graphs'] for p in Path(root).rglob('*.yaml')}
assert actual == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(path) == row['sha256'], path
reviews = prior['all_review_observations']
assert len(reviews) == 42
assert {str(p) for p in Path('reviews/structured').rglob('review.yaml')} == {r['yaml'] for r in reviews}
for row in reviews:
    assert sha(row['yaml']) == row['yaml_sha256']
    assert sha(row['markdown']) == row['markdown_sha256']
selected = prior['pending_in_priority_order'][:3]
assert [Path(p).stem for p in selected] == ['capsular-polysaccharide-2', 'capsular-polysaccharide-3', 'capsular-polysaccharide']
old_inspect = json.loads((OLD / 'capsular-polysaccharide-2-inspect.json').read_text())
inputs = {r['path'] for r in old_inspect['source']['inputs']}
inputs.update(['curation/mibig_claim_references.tsv', 'src/naturalproductmech/curate/claim_references.py'])
changed_context = [r['path'] for r in old_inspect['source']['inputs'] if sha(r['path']) != r['sha256']]
keys = set()
for path in selected:
    slug = Path(path).stem
    target = json.loads((OLD / (slug + '-targets.json')).read_text())
    target['targets'][0]['owner_paths'].append(dict(repository='CultureBotAI/NaturalProductMech',
        path='curation/mibig_claim_references.tsv', role='Implemented pinned claim-specific citation routing'))
    doc = read_natural_product(Path(path))
    assert doc == yaml.safe_load(Path(path).read_text()) and not owners[path]['graph_components']
    assert doc['identifier'] == target['targets'][0]['target_id']
    keys.add(doc['chemical_structure']['standard_inchi_key'])
    for suffix, payload in [('targets', target), ('resolved', doc)]:
        with (W / (slug + '-' + suffix + '.json')).open('x') as handle:
            json.dump(payload, handle, indent=2)
    cmd = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(W / (slug + '-targets.json'))]
    for item in sorted(inputs):
        cmd.extend(['--input', item])
    receipt = dict(command=cmd, started_at=now())
    result = subprocess.run(cmd, text=True, capture_output=True, check=True)
    captured = json.loads(result.stdout)
    for item in captured['source']['inputs']:
        assert hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + item['path']])).hexdigest() == item['sha256']
    out = W / (slug + '-inspect.json')
    with out.open('x') as handle:
        handle.write(result.stdout)
    receipt.update(finished_at=now(), exit_code=0, log=str(out), log_sha256=sha(out))
    with (W / (slug + '-inspect.receipt.json')).open('x') as handle:
        json.dump(receipt, handle, indent=2)
rows = {}
for name in ['mibig_compounds', 'npclassifier', 'lotus_occurrences', 'chebi_structures', 'chebi_origins', 'antibioticmech_inchikeys', 'pubchem_bioassay']:
    with Path('data/raw', name + '.tsv').open() as handle:
        rows[name] = [dict(line=i, source_row_sha256=row_digest(row), **row)
            for i, row in enumerate(csv.DictReader(handle, delimiter='\t'), 2)
            if row.get('standard_inchi_key') in keys or 'capsular polysaccharide' in ' '.join(row.values()).lower()]
assert rows == json.loads((OLD / 'source-rows.json').read_text())
with (W / 'source-rows.json').open('x') as handle:
    json.dump(rows, handle, indent=2)
report = dict(started_at=started, finished_at=now(), review_started_at='2026-10-13T20:50:38Z',
    base=base, prior_checkpoint=str(P), prior_checkpoint_sha256=sha(P), owners_verified=3115,
    components_verified=243, immutable_reviews_verified=42, selected=selected,
    prior_changed_context=changed_context, source_rows_unchanged=True,
    previous_turn_classification='Progress: protected merge of reviewed vibrioferrin corrections, four resolved issues, immutable successors and durable audit; full all-record goal remains incomplete.',
    access_ledger_entries=len(prior['access_stops_no_alternate_retrieval']),
    native_gate_reuse='Final PR and merge-group QC tested the exact current domain tree; fresh scoped strict validation, corpus and labels will supplement those explicit historical receipts. New review bundles require fresh canonical and contract checks.')
with (W / 'capture.json').open('x') as handle:
    json.dump(report, handle, indent=2)
print(json.dumps(report, indent=2))
