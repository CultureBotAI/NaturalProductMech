import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

W = Path(__file__).parent
RUN = Path('/private/tmp/npmech-capsular-resume-6vn9Sp')
for s in json.loads((W / 'specs.json').read_text()):
    old = json.loads((RUN / (s['slug'] + '-inspect.json')).read_text())
    started = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    command = ['uv', 'run', 'python', 'scripts/record_review.py', 'inspect', '--targets', str(RUN / (s['slug'] + '-targets.json'))]
    for row in old['source']['inputs']:
        command.extend(['--input', row['path']])
    command.extend(['--input', 'tests/test_capsular_curation.py'])
    result = subprocess.run(command, capture_output=True, check=True)
    path = W / (s['slug'] + '-successor-inspect.json')
    path.write_bytes(result.stdout)
    source = json.loads(result.stdout)['source']
    for row in source['inputs']:
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
    path.with_suffix('.receipt.json').write_text(json.dumps(dict(started_at=started,
        finished_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'), command=command, exit_code=0), indent=2))
    print(path)
