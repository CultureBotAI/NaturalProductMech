import hashlib
import json
import shlex
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
OLD = Path('/private/tmp/npmech-capsular-review-UUGHOQ')
RUN = Path('/private/tmp/npmech-capsular-resume-6vn9Sp')
REPO = 'CultureBotAI/NaturalProductMech'
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
specs = json.loads((W / 'specs.json').read_text())
chem = json.loads((RUN / 'chemistry.json').read_text())
observations = []

for s, issue in zip(specs, (935, 936, 937), strict=True):
    t = s['target']
    tid = t['target_id']
    doc = yaml.safe_load(Path(t['path']).read_text())
    inspected = json.loads((RUN / (s['slug'] + '-inspect.json')).read_text())
    source = inspected['source']
    for entry in source['inputs']:
        raw = subprocess.check_output(['git', 'show', source['git_revision'] + ':' + entry['path']])
        assert hashlib.sha256(raw).hexdigest() == entry['sha256']
    source['state'] = 'git_commit'
    c, = [c for c in chem['records'] if c['path'] == t['path']]
    evidence = []
    def ev(eid, kind, reference, summary, path=None, support='context_only', locator=None):
        e = dict(evidence_id=eid, kind=kind, reference=reference, accessed_at=now(),
                 support=support, summary=summary)
        if path:
            e['snapshot_sha256'] = sha(path)
            receipt = path.with_name(path.name + '.receipt.json')
            if receipt.exists():
                r = json.loads(receipt.read_text())
                assert r.get('sha256', sha(path)) == sha(path)
                e['accessed_at'] = r['finished_at']
        if locator:
            e['locator'] = locator
        evidence.append(e)
    ev('E-owner', 'record_content', t['path'], 'Entire owner read, with all source concepts, producer/cluster/occurrence claims, history and discussions; no attached graph components.', Path(t['path']), 'supports', source['git_revision'])
    ev('E-mibig', 'database', 'https://mibig.secondarymetabolites.org/',
       'Inspected exact-version MIBiG payloads for ' + ', '.join(r['source_id'] + ' version ' + str(r['entry_version']) for r in s['matrix']) + '. All active, generic capsule label, empty compound and locus-method evidence. These support a database assertion, not experimentally established exact-product equivalence.',
       OLD / 'structured-inspection.json', 'partial', 'mibig array; accession/version selectors in E-matrix')
    ev('E-genbank', 'database', 'https://www.ncbi.nlm.nih.gov/nuccore/',
       '; '.join(r['accession'] + ': ' + r['strain'] + ', serotype ' + r['serotype'] for r in s['matrix']),
       OLD / 'sequences.xml', 'supports', 'GBSeq accession-version; source feature strain/isolate, serotype and db_xref qualifiers')
    ev('E-matrix', 'validation', 'reviews/evidence/20261013-capsular/manifest.json',
       'Exact-source mapping, complete raw-row SHA256 pins and deposited context; no taxon or product inference.', W / 'matrix.json', 'supports', 'matrix.json')
    ev('E-taxonomy', 'authority', 'https://www.ncbi.nlm.nih.gov/taxonomy',
       'Six source taxon IDs resolve with the retained labels/ranks: 573 species, 574 subspecies, 1311 species, 715 species, 720 species, 754256 strain. No species-to-strain remapping inferred.', OLD / 'taxonomy.xml', 'supports')
    ev('E-pubchem', 'database', f'https://pubchem.ncbi.nlm.nih.gov/compound/{s["cid"]}',
       f'Names and Identifiers record title associates this graph with {s["registry"]}; MeSH names explicitly use name-based association, not chemical equivalence certification.',
       RUN / f'pubchem{s["cid"]}-view.json', 'context_only', 'RecordTitle and MeSH/Synonyms; no identity inferred from names alone')
    ev('E-chemistry', 'validation', 'reviews/evidence/20261013-capsular/manifest.json',
       f'RDKit 2026.03.5 reproduces stored Standard InChI and key and matches PubChem. Formula {c["formula"]}; {c["assigned_centers"]} assigned and {c["unassigned_centers"]} undefined centers; stereo_complete flag is computationally consistent. Finite graph, not a variable-degree polymer; this does not validate its biological assignment.', RUN / 'chemistry.json', 'supports', t['path'])
    ev('E-literature', 'primary_source', 'PMID:' + s['pmid'],
       s['concern'] + ' Metadata and abstract only for this cited paper; full text was denied and was not retrieved through an alternate route.', OLD / 'metadata.json', 'partial', 'Europe PMC result id ' + s['pmid'])
    ev('E-sources', 'record_content', 'data/raw/mibig_compounds.tsv',
       'Structured full-inventory joins retain imported rows, LOTUS references and NPClassifier pin. No exact-key ChEBI grounding row or sibling link; 21 capsule-context ChEBI rows are not exact identity candidates. Initial name-only Chebi-origin zero was not exhaustive; exact-ID context origins were separately checked.', RUN / 'source-rows.json', 'supports')
    ev('E-search', 'search', 'reviews/evidence/20261013-capsular/manifest.json',
       'Ignored-inclusive local search found the three owners and queue/lock references, not additional matching maintained corrections or components in the declared scope.', RUN / 'local-search.log', 'context_only')
    evidence[-1]['search_scope'] = 'rg --no-ignore --hidden over data/natural_products, data/causal_graphs, curation, src, scripts and .claude using all three identifiers/keys, capsule label and 17 BGC IDs; raw inventory joins use CSV parsing separately.'
    if s['cid'] == 195740:
        ev('E-primary-backbone', 'primary_source', 'DOI:10.1038/s41589-024-01664-8',
           'Full text Results Cps7D polymerization and cloning methods inspected. Cps7D builds a galactosylglycerol-phosphate backbone; Cps7A/C experiments include AP76, not imported isolate 72-14676. This does not certify the complete modified native capsule or upgrade the imported loci.', RUN / 'app-transition.xml', 'partial', 'PMC11666461 Sec6 and cloning methods')
    checks = []
    for name in ('strict', 'labels', 'corpus', 'chemistry-pinned', 'local-search'):
        r = json.loads((RUN / (name + '.receipt.json')).read_text())
        log = Path(r['log'])
        assert sha(log) == r['log_sha256'] and r['exit_code'] == 0
        eid = 'E-check-' + name
        ev(eid, 'validation', 'reviews/evidence/20261013-capsular/manifest.json',
           f'Actual execution {r["started_at"]} through {r["finished_at"]}; exit 0. ' + ('Label check retains 499 warnings and 4649 adapter skips; not all identifier classes remotely resolved.' if name == 'labels' else 'This deterministic check is not scientific certification.'), log, 'supports', log.name)
        checks.append(dict(check_id='C-' + name, name=name, status='passed', required=True,
            summary=evidence[-1]['summary'], command=shlex.join(r['command']), exit_code=0,
            target_ids=[tid], evidence_ids=[eid]))
    checks += [dict(check_id='C-primary', name='Exact-product primary evidence and LOTUS origin trace', status='unavailable', required=True,
        summary='The cited primary full text and applicable Wikidata origin endpoints encountered HTTP403/access challenges. Abstracts and database payloads do not resolve exact-product identity; no bypass attempted.', target_ids=[tid], evidence_ids=['E-literature']),
        dict(check_id='C-imodulondb', name='Structured expression dataset applicability search', status='passed', required=False,
        summary='Installed sibling kg-microbe-sources imodulondb datasets ran successfully; no covered target organism dataset. Not negative biological evidence. Earlier missing runner/dependency attempts failed and were superseded.',
        command='../../culturebotai-claw/.venv/bin/kg-microbe-sources imodulondb datasets', exit_code=0, target_ids=[tid]),
        dict(check_id='C-prior-qc', name='Exact-base historical native QC', status='passed', required=True,
        summary='Historical merge-group run 38464138422 on b87e2fa3 passed native QC and reproduction (786 passed, 4 skipped). All current domain input hashes matched that base at capture; not a fresh full QC run for these review bundles.',
        target_ids=[tid], scope_note='https://github.com/CultureBotAI/NaturalProductMech/actions/runs/38464138422')]
    assessments = []
    def assess(aid, area, topic, outcome, summary, eids):
        assessments.append(dict(assessment_id=aid, area=area, topic=topic, outcome=outcome,
            summary=summary, target_ids=[tid], evidence_ids=eids))
    assess('A-identity', 'identity', 'Exact product versus capsule/serotype concept', 'concern', s['description'], ['E-owner', 'E-mibig', 'E-genbank', 'E-pubchem', 'E-literature'])
    assess('A-structure', 'representation', 'Internal chemical encoding and exact registry xref', 'supported', evidence[6]['summary'] + ' Keep the exact PubChem xref; it is not a mismatching-key case.', ['E-chemistry', 'E-pubchem'])
    if s['cid'] == 195740:
        assessments[-1]['details'] = 'n-propoxy-on-ring, geminal-ring-diol and phosphate-monoester SMARTS matches are persisted with atom indices. Their biological assignment remains unresolved; no replacement graph inferred.'
    assess('A-grounding', 'grounding', 'Minted identity and exact joins', 'supported', 'MINTED rationale agrees with pinned exact-key inventory joins. Broader capsule ontology terms cannot serve as exact structure replacements.', ['E-sources'])
    assess('A-class', 'consistency', 'Computed filing, asserted class, taxonomy and origin facets', 'supported', f'Filing {doc["np_pathway"]} follows the pinned NPClassifier output; SACCHARIDE remains an asserted BGC class. NATURAL_PRODUCT is source-asserted, not predicted. OTHER_BACTERIAL taxonomy is separate from natural/engineered origin. This is metadata consistency, not validation of the disputed graph assignment.', ['E-owner', 'E-sources', 'E-taxonomy'])
    assess('A-producer', 'provenance', 'Producer and locus evidence scope', 'concern', f'{len(s["matrix"])} deposited strain/isolate qualifiers are missing from explicit producer context. SOURCE_ASSERTION and CLUSTER_UNSTATED correctly reflect empty MIBiG method lists; no characterization upgrade justified.', ['E-owner', 'E-mibig', 'E-genbank'])
    assessments[-1]['dimensions'] = [dict(name='deposited_context', value='; '.join(r['accession'] + ': ' + r['strain'] + ' / ' + r['serotype'] for r in s['matrix']), definition='Exact GenBank source strain/isolate and serotype qualifiers, not experimental proof of the assigned finite compound.', evidence_ids=['E-genbank'])]
    if doc.get('occurrences'):
        assess('A-occurrence', 'evidence', 'Occurrence versus production and publication independence', 'unknown', 'LOTUS occurrences remain DATABASE_ASSERTION, never promoted to production. Their DOI is the same publication as the PMID on the MIBiG entries, not independent evidence. Exact structure and Wikidata provenance remain unresolved.' + (' A. lignieresii support is unknown, not disproved by absence from the abstract.' if s['cid'] == 195740 else ''), ['E-owner', 'E-sources', 'E-literature'])
    else:
        assess('A-occurrence', 'evidence', 'Occurrence claims', 'not_applicable', 'No occurrence assertions on this owner.', ['E-owner'])
    assess('A-optional', 'completeness', 'Graphs, pathway, activities, targets, clinical status and sibling links', 'not_applicable', 'Full owner has no graph components, curated mechanism, assay, molecular target, clinical status or related sibling link. These optional absences are not fabricated defects; clinical/genotype studies are not pure-compound bioactivity assays.', ['E-owner', 'E-search', 'E-sources'])
    assess('A-history', 'ownership', 'Generated boundaries and scientific status', 'supported', 'SEEDED remains appropriate. Existing shared-structure discussion is OPEN; no REVIEWED promotion. Generated changes belong in implemented curation tables or source transforms, not reserved unconsumed decisions.tsv.', ['E-owner'])
    fowners = [p for p in t['owner_paths'] if p['path'] in ('data/raw/mibig_compounds.tsv', 'scripts/seed_from_sources.py', 'curation/mibig_structure_corrections.tsv')]
    sowners = [p for p in t['owner_paths'] if p['path'] == 'curation/mibig_producer_strains.tsv']
    findings = [dict(finding_id='F1', issue_key=s['slug'] + '-exact-product-assignment', category='identity', severity='blocker', status='open', certainty='confirmed',
        title='Exact capsule-product assignment is unsupported across deposited serotypes', description=s['description'], target_ids=[tid], field_paths=['chemical_structure', 'producer_organisms', 'biosynthetic_gene_clusters'], evidence_ids=['E-mibig', 'E-genbank', 'E-pubchem', 'E-chemistry', 'E-literature'],
        rule_id='CLAUDE.md: A record is a structure; review-checklist: Identity and Gene clusters', native_severity='blocker', normalization_reason='The compound identity assigned to biological source claims is not established; a valid graph and generic capsule name do not prove equivalence.', owner_paths=fowners, external_issues=[f'https://github.com/{REPO}/issues/{issue}']),
        dict(finding_id='F2', issue_key=s['slug'] + '-deposited-strain-context', category='provenance', severity='minor', status='open', certainty='confirmed', title='Deposited strain and serotype qualifications are missing',
        description=f'{len(s["matrix"])} source qualifiers are available but not explicitly carried into producer strain/evidence context.' + (' Femo is already in the taxon label; isolate 72-14676 must not become WF83 or AP76.' if s['cid'] == 195740 else ''),
        target_ids=[tid], field_paths=['producer_organisms[].strain', 'producer_organisms[].evidence'], evidence_ids=['E-owner', 'E-genbank', 'E-matrix'], rule_id='review-checklist: Producer organisms', native_severity='minor', normalization_reason='Bounded provenance repair that can be made without deciding chemical identity or evidence grade.', owner_paths=sowners, external_issues=[f'https://github.com/{REPO}/issues/938'])]
    if s['cid'] == 195740:
        findings[0]['evidence_ids'].append('E-primary-backbone')
    actions = [dict(action_id='A1', description='Preserve an OPEN identity qualification, then adjudicate exact locus-to-product and occurrence assignments from accessible primary chemistry before migration; do not rename all entries to the registry serotype.', finding_ids=['F1'], target_ids=[tid], owner_paths=fowners,
        acceptance_checks=['Per-source structure and polymer/form boundary justified by inspected primary chemistry.', 'Use a supported maintained migration/exclusion path, preserve provenance, and pass strict validation, reproduction and full QC.'], generator='scripts/seed_from_sources.py'),
        dict(action_id='A2', description='Add complete-row-pinned strain qualifications with versioned GenBank references and serotype rationale; no taxon or evidence-grade changes.', finding_ids=['F2'], target_ids=[tid], owner_paths=sowners,
        acceptance_checks=['All deposited qualifiers match source; isolate remains labelled as isolate.', 'Canary, scoped reseeding, invariant regression tests and byte-identical reproduction pass.'], generator='scripts/seed_from_sources.py')]
    finished = now()
    rid = finished[:19].replace('-', '').replace(':', '') + 'Z-' + s['slug']
    review = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=REPO,
        title='Capsular product scientific review: ' + s['taxon'], started_at='2026-10-13T20:50:38Z', finished_at=finished,
        reviewer=dict(identity='Codex', kind='agent', independence='self_review', independence_basis='Same assistant conducting the campaign and follow-up; not independent human sign-off.'),
        skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial', verdict='needs_curation', scientific_review=True,
        native_verdict='SEEDED retained; exact identity not adjudicated', summary='One identity blocker and one minor deposited-context finding; primary access gaps prevent full assessment.', source=source,
        scope=dict(description='One exact capsule owner and all attached components (none).', selection='Next exact owner in the exhaustive 3115-owner campaign checkpoint; no cohort extrapolation.', coverage='partial', population_size=1, reviewed_target_ids=[tid], exclusions=[dict(target='Other 3114 owners and their components', reason='Not assessed in this observation.')]),
        targets=[t], checks=checks, evidence=evidence, assessments=assessments, findings=findings, actions=actions,
        limitations=['The three cited primary full texts encountered HTTP403; applicable Wikidata organism endpoints also denied access. Later structural leads with access challenges were not pursued through alternate routes.',
        'Default Python lacked RDKit; uv chemistry-extra resolution lacked an Intel Mac wheel. Exact pinned RDKit 2026.03.5 in an existing environment succeeded. Earlier CLI dependency failures were superseded by the installed sibling runner.',
        'PubChem naming is not exact-product proof. No replacement structure, all-serotype equivalence, experimental strain equivalence or complete native polymer modification set established.',
        'Deterministic QC is not a completed scientific review. Full campaign remains incomplete; this assesses historical base b87e2fa3 before curation.'],
        notes=['Evidence manifest retains source captures, derived chemistry, source matrix and execution receipts; publication metadata/full article content is reference-only where redistribution is not established.', 'Prior GBS type II lead discarded: current registry label is type V.'], tags=['capsular', 'scientific-review', 'partial'])
    out = W / (s['slug'] + '-initial.yaml')
    out.write_text(yaml.safe_dump(json.loads(json.dumps(review)), sort_keys=False, allow_unicode=False))
    subprocess.run(['uv', 'run', 'python', 'scripts/record_review.py', 'validate', str(out)], check=True)
    subprocess.run(['uv', 'run', 'python', 'scripts/record_review.py', 'save', '--content', str(out)], check=True)
    observations.append(dict(slug=s['slug'], review_id=rid, yaml=f'reviews/structured/{rid}/review.yaml', markdown=f'reviews/structured/{rid}/review.md'))
(W / 'initials.json').write_text(json.dumps(observations, indent=2) + '\n')
