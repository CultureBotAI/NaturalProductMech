import json
from pathlib import Path

import yaml
from naturalproductmech.curate.curation_event import record_curation_event
from naturalproductmech.validation.write_validated import write_validated_natural_product

specs = json.loads((Path(__file__).parent / 'specs.json').read_text())
for s, issue in zip(specs, (935, 936, 937), strict=True):
    path = Path(s['target']['path'])
    doc = yaml.safe_load(path.read_text())
    assert doc['identifier'] == s['target']['target_id']
    assert doc['chemical_structure']['standard_inchi_key'] == s['key']
    did = 'curator-capsule-exact-product-assignment'
    assert not any(d['discussion_id'] == did for d in doc.get('discussions', []))
    evidence = [dict(reference=f'https://github.com/CultureBotAI/NaturalProductMech/issues/{issue}',
        explanation='Open exact-product adjudication; qualification is mitigation, not resolution.'),
        dict(reference=f'https://pubchem.ncbi.nlm.nih.gov/compound/{s["cid"]}', evidence_source='database',
             explanation=f'Registry title uses {s["registry"]}; exact graph/key agrees, but name-based MeSH association is not biological identity certification.'),
        dict(reference='PMID:' + s['pmid'], evidence_source='abstract',
             explanation='Metadata and abstract inspected; full text denied. No exact-product equivalence inferred from genotyping or capsule-gene comparisons.')]
    evidence += [dict(reference='https://www.ncbi.nlm.nih.gov/nuccore/' + r['accession'], evidence_source='database',
        explanation=f"Deposited {r['qualifier_kind']} context {r['strain']}, serotype {r['serotype']}; not exact molecular-product proof.") for r in s['matrix']]
    if issue == 937:
        evidence.append(dict(reference='DOI:10.1038/s41589-024-01664-8', evidence_source='full_text',
            explanation='Cps7D backbone polymerization and cloning methods inspected; AP76 experimental context is not imported isolate 72-14676, and backbone synthesis does not specify all native capsule modifications.'))
    history = doc.pop('curation_history')
    doc['discussions'].append(dict(discussion_id=did, kind='CURATION_TODO', status='OPEN', posed_by='codex',
        prompt='Which exact chemical product does each deposited capsule locus support?',
        rationale=s['description'] + ' Preserve existing keys, source assertions and SEEDED status pending primary-chemistry adjudication; no automatic split, merge, stereochemical completion or registry-serotype rename.', evidence=evidence))
    doc['curation_history'] = history
    record_curation_event(doc, curator='codex', action='RECORD_CURATED',
        changes=f'Add cited OPEN capsule-product identity qualification for issue #{issue}; no chemical, taxonomic, evidence-grade or scientific-status changes.', llm_assisted=True)
    write_validated_natural_product(doc, path)
    print(path)
