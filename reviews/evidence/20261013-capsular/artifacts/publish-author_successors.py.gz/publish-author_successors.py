import hashlib
import json
import shlex
import subprocess
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
RUN = Path('/private/tmp/npmech-capsular-resume-6vn9Sp')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
rows = []
for original in json.loads((W / 'initials.json').read_text()):
    old = yaml.safe_load(Path(original['yaml']).read_text())
    inspection = W / (original['slug'] + '-successor-inspect.json')
    captured = json.loads(inspection.read_text())
    receipt = json.loads(inspection.with_suffix('.receipt.json').read_text())
    for entry in captured['source']['inputs']:
        assert sha(entry['path']) == entry['sha256']
    tid = old['targets'][0]['target_id']
    evidence = deepcopy([e for e in old['evidence'] if e['evidence_id'] in ('E-genbank', 'E-matrix', 'E-chemistry', 'E-pubchem', 'E-literature', 'E-primary-backbone')])
    def ev(eid, kind, path, summary):
        evidence.append(dict(evidence_id=eid, kind=kind, reference=str(path), accessed_at=now(), support='supports', summary=summary, snapshot_sha256=sha(path)))
    ev('E-current', 'record_content', old['targets'][0]['path'], 'Entire current owner reread: exact deposited qualifiers and cited OPEN identity discussion added; original source assertions, keys, grades and SEEDED status unchanged.')
    ev('E-prior', 'prior_review', original['yaml'], 'Immutable partial full-owner assessment, including scientific findings and unavailable source checks.')
    ev('E-strains', 'record_content', 'curation/mibig_producer_strains.tsv', 'Seventeen exact-row-pinned GenBank qualifications, with serotypes in rationale and isolate 72-14676 explicitly marked as isolate; no taxon-ID reassignment.')
    ev('E-scope', 'validation', W / 'scope-audit.json', 'All 3115 owners, 243 components and 42 preexisting pairs checked: only three selected owners changed, with limited qualifiers, OPEN discussions and appended history.')
    checks = []
    for label in ('publish-focused', 'publish-strict', 'publish-scope'):
        r = json.loads((RUN / (label + '.receipt.json')).read_text())
        assert r['exit_code'] == 0 and sha(r['log']) == r['log_sha256']
        ev('E-' + label, 'validation', r['log'], f'Actual execution {r["started_at"]} to {r["finished_at"]}, exit 0. Full QC is deterministic validation, not scientific completion.')
        checks.append(dict(check_id=label, name=label, required=True, status='passed', command=shlex.join(r['command']), exit_code=0,
            target_ids=[tid], evidence_ids=['E-' + label], summary=evidence[-1]['summary']))
    checks.append(dict(check_id='primary-remaining', name='Outstanding exact-product primary evidence', status='unavailable', required=True, target_ids=[tid], summary='All predecessor access limitations remain; no new retrieval or exact-product adjudication in this disposition.'))
    findings = deepcopy(old['findings'])
    for f in findings:
        f['previous_occurrences'] = [dict(repository=old['repository'], review_id=old['review_id'], finding_id=f['finding_id'])]
        f['evidence_ids'] = ['E-current', 'E-prior', 'E-genbank', 'E-matrix', 'E-strains', 'E-scope', 'E-publish-focused']
        if f['finding_id'] == 'F2':
            f['status'] = 'resolved'
            f['disposition_reason'] = 'Exact deposited strain/isolate qualifiers and serotype rationale are now preserved through pinned curation rows and guarded generation; all narrow invariants pass. This resolves only missing context, not chemical identity.'
        else:
            f['status'] = 'open'
            f['disposition_reason'] = 'Mitigated by a cited OPEN discussion. The per-locus exact chemical product and representation boundary remain unadjudicated; no replacement structure or broader equivalence is inferred.'
            f['evidence_ids'] += ['E-chemistry', 'E-pubchem', 'E-literature']
    finished = now()
    rid = finished[:19].replace('-', '').replace(':', '') + 'Z-' + original['slug'] + '-scoped-disposition'
    review = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=old['repository'],
        title=original['slug'] + ': deposited-context disposition', started_at=receipt['started_at'], finished_at=finished,
        reviewer=dict(identity='Codex', kind='agent', independence='self_review', independence_basis='Implementing assistant performing a separate adversarial pass; not independent human sign-off.'),
        skill=old['skill'], completion='partial', verdict='needs_curation', scientific_review=True,
        summary='Missing deposited context resolved; exact-product identity remains open and visibly qualified.', source=captured['source'], targets=captured['targets'],
        scope=dict(description='One exact owner; scoped finding disposition, not a second full assessment.', selection='User-authorized issue remediation and publication.', coverage='partial', population_size=1, reviewed_target_ids=[tid]),
        checks=checks, evidence=evidence, findings=findings,
        assessments=[dict(assessment_id='fixed-context', area='provenance', topic='Deposited strain/isolate and serotype scope', outcome='supported', target_ids=[tid], evidence_ids=['E-current', 'E-strains', 'E-genbank', 'E-matrix', 'E-scope'], summary='Exact qualifiers agree with the deposited source context; no biological scope or evidence-grade change.'),
            dict(assessment_id='identity-open', area='identity', topic='Remaining exact-product uncertainty', outcome='concern', target_ids=[tid], evidence_ids=['E-current', 'E-prior', 'E-chemistry', 'E-pubchem', 'E-literature'], summary='OPEN qualification is mitigation, not identity adjudication. Full-owner assessment and primary access limits remain partial.')],
        actions=[deepcopy(old['actions'][0])], limitations=['Scoped disposition only; no new owner coverage or native REVIEWED promotion.', 'All predecessor primary and authority access limits persist. No additional primary retrieval or access bypass.', 'Source state is working_tree: current input bytes were inspected and archived, not claimed to exist at the base commit.', 'Full QC is still running at authoring; canonical checks and final CI follow. An initial local QC lint failure was corrected before restarting. Only the recorded focused tests, strict validation and object-level scope audit are claimed here.'],
        related_reviews=[dict(repository=old['repository'], review_id=old['review_id'], relationship='Exact predecessor disposition; preserve immutable full-owner partial assessment.')])
    out = W / (original['slug'] + '-successor.yaml')
    out.write_text(yaml.safe_dump(json.loads(json.dumps(review)), sort_keys=False, allow_unicode=False))
    subprocess.run(['uv', 'run', 'python', 'scripts/record_review.py', 'validate', str(out)], check=True)
    subprocess.run(['uv', 'run', 'python', 'scripts/record_review.py', 'save', '--content', str(out)], check=True)
    rows.append(dict(slug=original['slug'], review_id=rid, yaml=f'reviews/structured/{rid}/review.yaml', markdown=f'reviews/structured/{rid}/review.md'))
(W / 'successors.json').write_text(json.dumps(rows, indent=2) + '\n')
