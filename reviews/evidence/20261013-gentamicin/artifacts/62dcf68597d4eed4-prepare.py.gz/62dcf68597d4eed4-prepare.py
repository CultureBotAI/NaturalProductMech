import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
prior = Path('/private/tmp/npmech-capsular-publish-7cKqTV/review-campaign-checkpoint-final.json')
checkpoint = json.loads(prior.read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == checkpoint['base']
for r in checkpoint['records']:
    assert sha(r['path']) == r['sha256']
    for c in r['graph_components']:
        assert sha(c['path']) == c['sha256']
for r in checkpoint['all_review_observations']:
    assert sha(r['yaml']) == r['yaml_sha256']
    assert sha(r['markdown']) == r['markdown_sha256']
inputs = [x['path'] for x in yaml.safe_load(Path('reviews/structured/20261013T193947Z-vibrioferrin/review.yaml').read_text())['source']['inputs'] if 'vibrioferrin' not in x['path']]
inputs += ['data/natural_products/carbohydrates/gentamicin-2.yaml', 'data/natural_products/carbohydrates/gentamicin.yaml', 'scripts/extract_pubchem_bioassay.py', 'curation/mibig_claim_references.tsv']
owners = yaml.safe_load(Path('reviews/structured/20261013T193947Z-vibrioferrin/review.yaml').read_text())['targets'][0]['owner_paths']
owners += [dict(repository='CultureBotAI/NaturalProductMech', path='data/raw/pubchem_bioassay.tsv', role='Imported compound-specific assay observations'), dict(repository='CultureBotAI/NaturalProductMech', path='scripts/extract_pubchem_bioassay.py', role='BioAssay extraction')]
capture = dict(started_at=now(), prior_checkpoint=str(prior), prior_checkpoint_sha256=sha(prior), base=checkpoint['base'], owners=3115, components=243, immutable_observations=48, targets=[])
for slug in ('gentamicin-2', 'gentamicin'):
    path = f'data/natural_products/carbohydrates/{slug}.yaml'
    d = yaml.safe_load(Path(path).read_text())
    target = dict(target_id=d['identifier'], path=path, label=d['label'], record_class='NaturalProductRecord', kind='generated', owner_paths=owners)
    target_path = W / f'{slug}-targets.json'
    target_path.write_text(json.dumps(dict(targets=[target]), indent=2))
    command = ['uv', 'run', 'python', 'scripts/record_review.py', 'inspect', '--targets', str(target_path)]
    for p in sorted(set(inputs)):
        command += ['--input', p]
    receipt = dict(command=command, started_at=now())
    run = subprocess.run(command, text=True, capture_output=True)
    out = W / f'{slug}-inspect.json'
    out.write_text(run.stdout)
    receipt.update(finished_at=now(), exit_code=run.returncode, log=str(out), log_sha256=sha(out), stderr=run.stderr)
    (W / f'{slug}-inspect.receipt.json').write_text(json.dumps(receipt, indent=2))
    assert run.returncode == 0, run.stderr
    capture['targets'].append(target)
(W / 'capture.json').write_text(json.dumps(capture, indent=2))
print(json.dumps(capture, indent=2))
