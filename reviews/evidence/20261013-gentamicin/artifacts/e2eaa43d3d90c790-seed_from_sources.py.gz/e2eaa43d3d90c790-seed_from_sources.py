#!/usr/bin/env python3
"""Harmonize the committed inventories into one NaturalProductRecord per structure.

**M1 skeleton.** The identity model, the write path and the safety rails are
implemented and tested here; the extractors that produce `data/raw/` are M2, so
with no inventories on disk this reports an empty plan and writes nothing. That
is the intended state, not a stub to be quietly replaced: the rules below are
the contract M2's extractors have to satisfy.

    just seed                       # dry run: per-pathway counts, nothing written
    just seed-canary CHEBI:42355    # write exactly one record and validate it
    just seed-apply                 # write the whole corpus

Identity
--------
A record is ONE chemical structure. Resolution, in order:

1. A source concept whose ChEBI entry has a default structure grounds to that
   ChEBI CURIE (`grounding_status: EXACT`).
2. Otherwise the concept keeps a content-hashed
   `naturalproductmech:<source>-<hash>` CURIE (`grounding_status: MINTED`).
   The hash covers (source, source_id) and never the label, so an upstream
   label correction does not move the key that curation decisions are written
   against.
3. Concepts resolving to the same Standard InChIKey merge into one record
   carrying every source concept. That merge is the product.

A concept with no structure is NOT written: without an InChIKey there is
nothing to assert identity on, and a name is not a structure. MIBiG ships
SMILES and never an InChIKey, so keys are generated locally with the pinned
RDKit; 1,042 of its 5,443 compound records have no structure at all.

Origin
------
`producer_organisms` and `occurrences` are separate fields with separate
evidence bars, and **the seeder never promotes one to the other**. A MIBiG
locus grades a producer claim through `conf/producer_evidence.tsv`; a LOTUS
triple is an occurrence, whatever taxon it names.

Filing
------
`np_pathway` comes from the committed NPClassifier inventory, not a live call.
A multi-label or empty result files UNCLASSIFIED and queues the record rather
than resolving to a winner by array order — see PLAN.md 3.4.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from naturalproductmech.curate.claim_references import (  # noqa: E402
    correct_claim_reference,
    load_claim_references,
)
from naturalproductmech.curate.curation_event import record_curation_event  # noqa: E402
from naturalproductmech.curate.producer_strains import (  # noqa: E402
    load_producer_strains,
    qualify_producer,
)
from naturalproductmech.curate.structure_corrections import apply_structure_corrections  # noqa: E402
from naturalproductmech.curate.xref_exclusions import (  # noqa: E402
    exclusion_discussion,
    load_xref_exclusions,
)
from naturalproductmech.grading import (  # noqa: E402
    grade_cluster_link,
    grade_production,
    load_evidence_map,
)
from naturalproductmech.validation.write_validated import (  # noqa: E402
    ValidationFailedError,
    write_validated_natural_product,
)

REPO_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = REPO_ROOT / "data" / "raw"
CURATION_DIR = REPO_ROOT / "curation"
CORPUS_DIR = REPO_ROOT / "data" / "natural_products"
PATHS_FILE = CORPUS_DIR / "PATHS.tsv"
CONF_PATH = REPO_ROOT / "conf" / "sources.yaml"
MIBIG_LOCUS_EVIDENCE_OVERRIDES = CURATION_DIR / "mibig_locus_evidence_overrides.tsv"
MIBIG_STRUCTURE_CORRECTIONS = CURATION_DIR / "mibig_structure_corrections.tsv"
MIBIG_PRODUCER_STRAINS = CURATION_DIR / "mibig_producer_strains.tsv"
MIBIG_XREF_EXCLUSIONS = CURATION_DIR / "mibig_xref_exclusions.tsv"
MIBIG_CLAIM_REFERENCES = CURATION_DIR / "mibig_claim_references.tsv"

# MIBiG's cluster vocabulary -> the schema enum. Six values in 4.0; `alkaloid`
# was removed when compound classification was split from cluster
# classification. An unmapped value is dropped rather than guessed.
BGC_CLASS_MAP = {
    "PKS": "PKS",
    "NRPS": "NRPS",
    "ribosomal": "RIBOSOMAL",
    "terpene": "TERPENE",
    "saccharide": "SACCHARIDE",
    "other": "OTHER",
}

# Assay-name patterns that name an activity class unambiguously. Deliberately
# narrow: an unset class is honest, a guessed one is "computed presented as
# asserted" in a new place (#39).
ACTIVITY_CLASS_PATTERNS = [
    (re.compile(r"antibacterial|anti-bacterial|\bE\. ?coli\b|staphylococc|"
                r"antibiotic", re.I), "ANTIBACTERIAL"),
    (re.compile(r"antifungal|anti-fungal|candida|aspergillus", re.I), "ANTIFUNGAL"),
    (re.compile(r"antivir|anti-viral|hiv|influenza", re.I), "ANTIVIRAL"),
    (re.compile(r"antimalarial|plasmodium|trypanosom|leishman", re.I), "ANTIPARASITIC"),
    (re.compile(r"cytotox|tumor|tumour|cancer|nci-?60|growth inhibition|"
                r"antiproliferat", re.I), "CYTOTOXIC"),
    (re.compile(r"mutagen|carcinogen|ccris|genotox", re.I), "TOXIN"),
    (re.compile(r"inhibitors? of|inhibition of|\bIC50\b|\bKi\b|binding", re.I),
     "ENZYME_INHIBITOR"),
]


# AntibioticMech's filing class to this corpus's activity vocabulary. The
# mapping is deliberately lossless in both directions that matter: an
# unspecified antimicrobial stays unspecified rather than becoming
# antibacterial, and a mycobacterial claim keeps its own value rather than
# being widened. Anything unmapped is dropped rather than guessed.
SIBLING_ACTIVITY_CLASSES = {
    "ANTIBACTERIAL": "ANTIBACTERIAL",
    "ANTIFUNGAL": "ANTIFUNGAL",
    "ANTIMYCOBACTERIAL": "ANTIMYCOBACTERIAL",
    "ANTIVIRAL": "ANTIVIRAL",
    "ANTIPROTOZOAL": "ANTIPARASITIC",
    "ANTIMICROBIAL_UNSPECIFIED": "ANTIMICROBIAL_UNSPECIFIED",
}


def classify_activity(assay_name: str, *, aid: str = "") -> str | None:
    """A BioactivityClassEnum value when the assay name says one plainly."""
    # AID1650 is mock-infected Vero E6 viability, not antiviral efficacy (#877).
    # Pin the inspected title so a changed source is not silently reclassified.
    # https://pubchem.ncbi.nlm.nih.gov/rest/pug/assay/aid/1650/description/JSON
    if aid == "1650" and assay_name == (
        "A Cell Based Secondary Assay To Explore Cytotoxicity of West Nile Virus "
        "Anti-Viral Hit Compounds"
    ):
        return "CYTOTOXIC"
    classes = set()
    for pattern, label in ACTIVITY_CLASS_PATTERNS:
        if pattern.search(assay_name or ""):
            classes.add(label)
    # Generic inhibition wording is a fallback, not a competing activity.
    specific = classes - {"ENZYME_INHIBITOR"}
    if specific:
        return next(iter(specific)) if len(specific) == 1 else None
    return "ENZYME_INHIBITOR" if classes else None


# Unmapped names (including generic Potency, CC50 and AC50) retain their exact
# source spelling alongside OTHER, never an assumed IC50/EC50 equivalent.
MEASUREMENT_TYPES = {
    "IC50": "IC50", "EC50": "EC50", "KI": "KI", "KD": "KD",
    "MIC": "MIC", "GI50": "GI50", "LD50": "LD50",
}

# Only cross-references whose prefix this corpus declares are carried through.
DB_ID_RE = re.compile(r"^(npatlas|pubchem|chembl|chebi|cyanometdb|lotus):[A-Za-z0-9._-]+$")

#: Prefixes rewritten to the spelling this corpus mints identifiers in.
#:
#: MIBiG's `database_ids` are lowercase throughout, and for npatlas, pubchem,
#: chembl, lotus and cyanometdb that is left alone: this corpus never mints an
#: identifier in those namespaces, so there is no join to preserve and the
#: source's spelling is the honest record. ChEBI is different — `CHEBI:2766`
#: is a record identifier here — so `chebi:2766` in an xref is the same
#: structure written in a way that will not match it. An xref means the same
#: structure (CLAUDE.md), which is only useful if it resolves (#61).
XREF_PREFIX_CANON = {"chebi": "CHEBI"}


def canonical_xref(value: str) -> str:
    prefix, _, local = value.partition(":")
    return f"{XREF_PREFIX_CANON.get(prefix, prefix)}:{local}"


# PubChem's "Target Accession" is a depositor-controlled field. It can hold
# UniProtKB accessions, RefSeq proteins, GenPept proteins, or PDB chains such
# as 2HDS_A; only the first can be carried into a UniProtKB CURIE.
UNIPROT_ACCESSION_RE = re.compile(
    r"^(?:[OPQ][0-9][A-Z0-9]{3}[0-9]|[A-NR-Z][0-9][A-Z][A-Z0-9]{2}[0-9]"
    r"(?:[A-Z][A-Z0-9]{2}[0-9])?)$"
)

# How many occurrences reach a record. The INVENTORY keeps all of them, so
# nothing is lost and the corpus still reproduces; this bounds what a curator
# has to read. Without it lupeol carried 925 occurrences in a 397 KB file,
# while the median record has one — and `curate-yaml-record` instructs a
# curator to read the entire YAML (#28).
MAX_OCCURRENCES_PER_RECORD = 25

# The same reasoning as occurrences, and the distribution is worse: one
# structure carries 960 assay rows while the median carries 11. The inventory
# keeps them all; a record keeps the ones a curator can read.
MAX_BIOACTIVITIES_PER_RECORD = 25

# The same cap for BindingDB rows. Promiscuous kinase probes can carry dozens
# of exact affinity rows, and the raw inventory is the complete view.
MAX_MOLECULAR_TARGETS_PER_RECORD = 25

# One directory per NPClassifier pathway. UNCLASSIFIED is a real bucket, not an
# error state: it is where a multi-label result lands until a curator files it.
PATHWAY_DIRS = {
    "ALKALOIDS": "alkaloids",
    "AMINO_ACIDS_AND_PEPTIDES": "amino_acids_and_peptides",
    "CARBOHYDRATES": "carbohydrates",
    "FATTY_ACIDS": "fatty_acids",
    "POLYKETIDES": "polyketides",
    "SHIKIMATES_AND_PHENYLPROPANOIDS": "shikimates_and_phenylpropanoids",
    "TERPENOIDS": "terpenoids",
    "UNCLASSIFIED": "unclassified",
}

TAXON_GROUPS = [
    "ACTINOBACTERIAL",
    "CYANOBACTERIAL",
    "MYXOBACTERIAL",
    "OTHER_BACTERIAL",
    "ARCHAEAL",
    "FUNGAL",
    "DIATOM",
    "GREEN_ALGAL",
    "RED_ALGAL",
    "HAPTOPHYTE",
    "ALVEOLATE",
    "OTHER_STRAMENOPILE",
    "LAND_PLANT",
    "SPONGE",
    "CNIDARIAN",
    "MOLLUSK",
    "BRYOZOAN",
    "CHORDATE",
    "OTHER_ANIMAL",
    "OTHER_EUKARYOTIC",
    "OTHER",
]
TAXON_GROUP_ORDER = {group: index for index, group in enumerate(TAXON_GROUPS)}


def taxon_groups_for(
    items: list[dict[str, Any]],
    taxon_groups: dict[str, str],
) -> list[str]:
    """Record-level lineage facets derived from nested NCBITaxon ids."""
    found = {
        taxon_groups[taxon_id]
        for item in items
        if (taxon_id := item.get("taxon_id")) in taxon_groups
    }
    return sorted(found, key=lambda group: TAXON_GROUP_ORDER.get(group, len(TAXON_GROUP_ORDER)))


def mint_identifier(source: str, source_id: str) -> str:
    """Content-hashed CURIE for one source concept.

    Hashes (source, source_id) and never the label: an upstream label
    correction must not move the key `curation/decisions.tsv` rows are written
    against.
    """
    digest = hashlib.sha256(f"{source}\x00{source_id}".encode()).hexdigest()[:10]
    return f"naturalproductmech:{source.lower()}-{digest}"


def choose_pathway(pathway_results: list[str]) -> str:
    """The filing pathway, from NPClassifier's result array.

    One result files the record. Several or none files it UNCLASSIFIED, because
    picking by array order is how a corpus ends up asserting a classification
    nothing decided — AntibioticMech leaves its structural class empty for the
    same reason. Every returned label is still kept in `np_classification`.
    """
    if len(pathway_results) == 1:
        value = pathway_results[0].strip().upper().replace(" ", "_").replace("-", "_")
        return value if value in PATHWAY_DIRS else "UNCLASSIFIED"
    return "UNCLASSIFIED"


# Keys the seeder uses internally and strips before writing. A record's YAML
# must contain only schema fields, and closed validation would reject the rest.
INTERNAL_PREFIX = "_"

CURATOR_OWNED_CARRIED_FIELDS = (
    "biosynthetic_pathway",
    "causal_graphs",
    "causal_graph_refs",
)

# Reserved for whole threads raised by curators, not source-generated questions.
CURATOR_DISCUSSION_PREFIX = "curator-"

#: Slots on a Discussion that belong to whoever worked it, not to the seeder.
#: For source-generated threads it owns `discussion_id`, `kind` and `prompt` — it raises the
#: question and rewrites it each run — and everything else is the answer.
CURATOR_OWNED_DISCUSSION_FIELDS = (
    "status",
    "resolved_date",
    "resolution_note",
    "posed_by",
    "posed_date",
    "rationale",
    "attaches_to",
    "proposed_experiments",
    "evidence",
    "notes",
)


def record_path(pathway: str, slug: str) -> Path:
    """Where a record lives. The directory IS the filing decision."""
    return CORPUS_DIR / PATHWAY_DIRS.get(pathway, "unclassified") / f"{slug}.yaml"


def _standard_inchi_key(doc: dict[str, Any]) -> str | None:
    chemical_structure = doc.get("chemical_structure") or {}
    if not isinstance(chemical_structure, dict):
        return None
    value = chemical_structure.get("standard_inchi_key")
    return value if isinstance(value, str) else None


def carry_curator_owned_fields(payload: dict[str, Any], existing: dict[str, Any]) -> None:
    """Carry record curation across a re-seed of the same chemical structure."""
    standard_inchi_key = _standard_inchi_key(payload)
    if not standard_inchi_key or standard_inchi_key != _standard_inchi_key(existing):
        return

    # Copy once to preserve YAML anchors shared across curator-owned sections.
    existing = deepcopy(existing)
    curator_discussions = {}
    for discussion in existing.get("discussions") or []:
        if not isinstance(discussion, dict):
            continue
        discussion_id = discussion.get("discussion_id")
        if (isinstance(discussion_id, str)
                and discussion_id.startswith(CURATOR_DISCUSSION_PREFIX)
                and discussion_id != CURATOR_DISCUSSION_PREFIX):
            if discussion_id in curator_discussions:
                raise ValueError(f"duplicate curator discussion_id: {discussion_id}")
            curator_discussions[discussion_id] = discussion

    # Imported targets are rebuilt; only explicitly curator-owned items survive.
    curator_targets = [target for target in existing.get("molecular_targets") or []
                       if isinstance(target, dict) and target.get("source") == "CURATOR"]
    if curator_targets:
        payload["molecular_targets"] = [
            target for target in payload.get("molecular_targets") or []
            if target.get("source") != "CURATOR"
        ] + curator_targets

    for field in CURATOR_OWNED_CARRIED_FIELDS:
        if field in existing:
            payload[field] = existing[field]

    # A curator can only ever move a record OFF `SEEDED`, so a status that is
    # not `SEEDED` is a decision somebody made and the seeder must not undo it.
    # This is the first thing `curate-yaml-record` tells a curator to do, and
    # before this the next re-seed silently put it back (#79).
    status = existing.get("curation_status")
    if status and status != "SEEDED":
        payload["curation_status"] = status

    # The seeder raises a discussion; a curator answers it. Carry the answer
    # onto the question the seeder just re-raised, matched on discussion_id.
    # A discussion the seeder no longer raises is dropped with its answer,
    # which is right: the condition that prompted it is gone.
    answered = {d.get("discussion_id"): d for d in existing.get("discussions") or []
                if isinstance(d, dict) and d.get("discussion_id")}
    for index, discussion in enumerate(payload.get("discussions") or []):
        if discussion.get("discussion_id") in curator_discussions:
            payload["discussions"][index] = curator_discussions[discussion["discussion_id"]]
            continue
        # This adjudication is owned by the pinned curation table, not the YAML.
        if (discussion.get("discussion_id") == "source-structure-correction"
                or discussion.get("discussion_id", "").startswith("source-xref-exclusion-")):
            continue
        previous_discussion = answered.get(discussion.get("discussion_id"))
        if not previous_discussion:
            continue
        for field in CURATOR_OWNED_DISCUSSION_FIELDS:
            if field in previous_discussion:
                discussion[field] = previous_discussion[field]

    present = {d.get("discussion_id") for d in payload.get("discussions") or []}
    for discussion_id, discussion in curator_discussions.items():
        if discussion_id not in present:
            payload.setdefault("discussions", []).append(discussion)
    # A curator-only discussion section must be emitted before the audit trail.
    if "curation_history" in existing:
        payload["curation_history"] = existing["curation_history"]


def carry_existing_curator_owned_fields(payload: dict[str, Any], path: Path) -> None:
    if not path.exists():
        return
    existing = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if isinstance(existing, dict):
        carry_curator_owned_fields(payload, existing)


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def read_inventories() -> dict[str, list[dict[str, str]]]:
    """Every committed source inventory and curation override, keyed by file stem.

    The pipeline reads only committed TSVs and never the network, which is what
    makes `just verify-corpus` and the offline test suite mean anything.
    """
    inventories: dict[str, list[dict[str, str]]] = {}
    for path in sorted(RAW_DIR.glob("*.tsv")):
        inventories[path.stem] = read_tsv(path)
    if MIBIG_LOCUS_EVIDENCE_OVERRIDES.exists():
        inventories[MIBIG_LOCUS_EVIDENCE_OVERRIDES.stem] = read_tsv(
            MIBIG_LOCUS_EVIDENCE_OVERRIDES)
    if MIBIG_STRUCTURE_CORRECTIONS.exists():
        inventories[MIBIG_STRUCTURE_CORRECTIONS.stem] = read_tsv(MIBIG_STRUCTURE_CORRECTIONS)
    if MIBIG_PRODUCER_STRAINS.exists():
        inventories[MIBIG_PRODUCER_STRAINS.stem] = read_tsv(MIBIG_PRODUCER_STRAINS)
    if MIBIG_XREF_EXCLUSIONS.exists():
        inventories[MIBIG_XREF_EXCLUSIONS.stem] = read_tsv(MIBIG_XREF_EXCLUSIONS)
    if MIBIG_CLAIM_REFERENCES.exists():
        inventories[MIBIG_CLAIM_REFERENCES.stem] = read_tsv(MIBIG_CLAIM_REFERENCES)
    return inventories


MIBIG_WITHDRAWAL_CONTEXT = (
    "entry_version", "taxon_id", "genome_accession", "locus_from", "locus_to",
    "standard_inchi_key", "locus_evidence_methods",
)


def load_mibig_locus_evidence_overrides(
    rows: list[dict[str, str]],
) -> dict[str, dict[str, str]]:
    evidence_map = load_evidence_map()
    overrides: dict[str, dict[str, str]] = {}
    for row in rows:
        identifier = row["minted_identifier"]
        if identifier in overrides:
            raise ValueError(f"duplicate MIBiG locus evidence override for {identifier}")
        action = row.get("action", "REPLACE")
        if action not in {"REPLACE", "WITHDRAW"}:
            raise ValueError(f"{identifier} has invalid MIBiG evidence action {action!r}")
        methods = [m for m in row["locus_evidence_methods"].split("|") if m]
        if action == "REPLACE" and not methods:
            raise ValueError(
                f"{identifier} has a MIBiG locus evidence override with no methods")
        unknown = [m for m in methods if m not in evidence_map]
        if unknown:
            raise ValueError(
                f"{identifier} has unknown MIBiG locus evidence method(s): "
                + ", ".join(unknown)
            )
        override = {
            "locus_evidence_methods": "|".join(methods),
            "producer_evidence_basis": grade_production(methods, evidence_map),
            "cluster_link_evidence_basis": grade_cluster_link(methods, evidence_map),
        }
        if action == "WITHDRAW":
            if row["locus_evidence_methods"]:
                raise ValueError(f"{identifier} WITHDRAW must have empty replacement methods")
            required = ("source_id", "reference", "rationale", "curator", "date") + tuple(
                "expected_" + field for field in MIBIG_WITHDRAWAL_CONTEXT
                if field not in {"locus_from", "locus_to"})
            if row.get("source") != "MIBIG" or any(
                not isinstance(row.get(field), str) or not row[field].strip()
                for field in required
            ):
                raise ValueError(
                    f"{identifier} WITHDRAW requires source, citation, rationale and pinned context")
            for field in ("expected_locus_from", "expected_locus_to"):
                value = row.get(field)
                if not isinstance(value, str) or (value and not re.fullmatch(r"[0-9]+", value)):
                    raise ValueError(f"{identifier} WITHDRAW requires explicit pinned bounds: {field}")
            reference = row["reference"]
            url = urlsplit(reference)
            if not (re.fullmatch(r"(?:DOI:10\.\d{4,9}/\S+|PMID:\d+)", reference) or (
                url.scheme == "https" and url.hostname and not re.search(r"\s", reference)
            )):
                raise ValueError(f"{identifier} WITHDRAW requires a stable DOI, PMID or HTTPS reference")
            original_methods = row["expected_locus_evidence_methods"].split("|")
            if any(method not in evidence_map for method in original_methods):
                raise ValueError(f"{identifier} WITHDRAW has unknown expected source methods")
            override.update({
                "action": action,
                "source_id": row["source_id"],
                "qualification_reference": reference,
                "qualification_note": (
                    f"Curated exclusion of source locus methods from this taxon/locus claim: "
                    f"{row['expected_locus_evidence_methods']}. {row['rationale']} "
                    f"Curator: {row['curator']}; date: {row['date']}."
                ),
                **{"expected_" + field: row["expected_" + field]
                   for field in MIBIG_WITHDRAWAL_CONTEXT},
            })
        overrides[identifier] = override
    return overrides


def apply_mibig_locus_evidence_override(
    row: dict[str, str],
    overrides: dict[str, dict[str, str]],
    *,
    source_row: dict[str, str] | None = None,
) -> dict[str, str]:
    source_concept_identifier = mint_identifier(
        "MIBIG", row["mibig_accession"] + ":" + row["compound_index"])
    override = overrides.get(source_concept_identifier)
    if not override:
        return row
    if override.get("action") == "WITHDRAW":
        context = row if source_row is None else source_row
        expected = {field: override["expected_" + field]
                    for field in MIBIG_WITHDRAWAL_CONTEXT}
        expected["mibig_accession"] = override["source_id"]
        for field, value in expected.items():
            if context.get(field) != value:
                raise ValueError(
                    f"{source_concept_identifier} WITHDRAW source context changed: {field}")
        return {
            **row,
            **{field: override[field] for field in (
                "locus_evidence_methods", "producer_evidence_basis", "cluster_link_evidence_basis")},
            "locus_evidence_qualification": override["qualification_note"],
            "locus_evidence_qualification_reference": override["qualification_reference"],
            "excluded_locus_evidence_methods": context["locus_evidence_methods"],
        }
    return {**row, **override}


def slugify(label: str, identifier: str) -> str:
    """A filesystem- and URL-safe slug for a record.

    Falls back to the identifier when a label slugifies to nothing, which
    happens for compounds named only with brackets or Greek letters. A slug is
    a published URL, so it is assigned once and locked in PATHS.tsv.
    """
    text = unicodedata.normalize("NFKD", label.lower())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    slug = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    if not slug:
        slug = re.sub(r"[^a-z0-9]+", "-", identifier.lower()).strip("-")
    return slug[:80]


# A name from a paper's own numbering, not a compound name. Narrow on purpose:
# anything broader starts flagging real names such as "A-74528" or "BAA".
PAPER_INTERNAL_NAME = re.compile(r"(?i)^(compound|metabolite|unnamed|unknown)?\s*\d+[a-z]?$")


# A chemical name extends its parent with punctuation far more often than with
# a space: `tirucalla-7,24-dien-3β-ol`, `spirangien A1`, `xiamycin A`. Matching
# only on a space left the vague name winning, which is the defect #16 fixed
# for one delimiter and #22 found for the rest.
EXTENSION_CHARS = (" ", "-", ",", "(")


def _extends(longer: str, shorter: str) -> bool:
    """True when `longer` is `shorter` plus a specifying suffix."""
    a, b = longer.lower(), shorter.lower()
    return a != b and a.startswith(b) and a[len(b):len(b) + 1] in EXTENSION_CHARS


def choose_label(names: list[str], authoritative: str | None = None) -> tuple[str, list[str]]:
    """The record's label, and every other source name as a synonym.

    Chosen separately from the lead row, because the lead row is picked by
    producer-evidence strength and has nothing to say about naming.

    Three rules, in order:

    1. **Specificity wins.** Drop any candidate that another candidate extends:
       `erythromycin` loses to `erythromycin A`, and `tirucalla` loses to
       `tirucalla-7,24-dien-3β-ol`. The record is one structure and the bare
       name is the family.
    2. **The identity authority wins.** Among what survives, prefer
       `authoritative` — ChEBI's name, for a record grounded to a ChEBI term.
       Without this, a deterministic sort chose MIBiG's `β-carotein` over
       ChEBI's `β-carotene` because `i` sorts before `n` (#22).
    3. **Deterministic case.** Otherwise collapse case variants and sort, so
       `Aflatoxin B1` and `aflatoxin B1` do not depend on entry order.

    Every discarded name is returned as a synonym rather than thrown away.
    """
    unique = sorted({n.strip() for n in names if n and n.strip()})
    if not unique:
        return "", []

    specific = [
        name for name in unique
        if not any(_extends(other, name) for other in unique)
    ]
    candidates = specific or unique

    if authoritative and authoritative.strip() in candidates:
        label = authoritative.strip()
    else:
        by_lower: dict[str, list[str]] = defaultdict(list)
        for name in candidates:
            by_lower[name.lower()].append(name)
        label = sorted(by_lower[sorted(by_lower)[0]])[0]

    return label, [name for name in unique if name != label]


# Typographic variants that are not disagreements: a Unicode minus against a
# hyphen, a Greek Tau against a Latin T, and a leading stereo or positional
# descriptor. Each produced false controversies (#24).
# Applied AFTER lowercasing, so the Greek letters here are the lowercase
# codepoints: an uppercase Tau has already become a lowercase tau by then, and
# mapping only the uppercase form silently did nothing.
_NAME_NOISE = str.maketrans({
    "\u2212": "-", "\u2013": "-", "\u2014": "-",
    "\u03c4": "t", "\u03b1": "a", "\u03b2": "b", "\u03b3": "g",
})
# Only descriptors that do NOT change which compound is meant: optical
# rotation, absolute configuration, cis/trans. A Greek letter or a numeric
# locant is NOT stripped — alpha-amyrin and beta-amyrin are different
# compounds, and two sources disagreeing about that on one InChIKey is
# precisely the upstream error this check exists to surface.
_LEADING_DESCRIPTOR = re.compile(
    r"^(\([+\-\u2212\u00b1]\)-|\([0-9rszeRSZE'`,\- ]+\)-|[+\-\u2212\u00b1]-|cis-|trans-|rel-)+",
    re.IGNORECASE,
)


def _name_core(value: str) -> str:
    """A name reduced to what a disagreement would have to be about."""
    text = value.strip().lower().translate(_NAME_NOISE)
    text = " ".join(text.split())
    return _LEADING_DESCRIPTOR.sub("", text) or text


def names_disagree(label: str, other: str) -> bool:
    """True when two names for one structure differ substantively.

    Case, whitespace and the discarded-synonym cases are not disagreements. A
    grounded record whose sources call it two genuinely different things is,
    because one of the two upstream records then has the wrong structure —
    `astaxanthin` and `(2R,3S,3'S)-2-hydroxyastaxanthin` share an InChIKey in
    the committed inventories and are not the same compound.
    """
    a, b = _name_core(label), _name_core(other)
    if a == b or not a or not b:
        return False
    return not (_extends(a, b) or _extends(b, a))


def mibig_evidence(row: dict[str, str]) -> list[dict[str, str]]:
    """Claim-level evidence for one MIBiG row.

    Original source evidence is always DATABASE_ASSERTION, whatever the reference
    points at. The corpus
    relays what MIBiG asserts; nobody here has read the paper, and
    docs/CURATION.md is explicit that a database assertion does not become the
    primary report merely because the database cites one. A separately cited
    curator exclusion is CURATOR_INFERENCE, not a primary experiment. The level the
    citation came from travels in the note, so a curator can tell a
    compound-specific structure report from the entry's general reference.

    Returns a fresh list per call. Sharing one object between the producer and
    the gene cluster made PyYAML emit anchors and aliases, which no reader of a
    record should have to resolve.
    """
    level = row["reference_basis"].lower().replace("_", " ")
    evidence = [{
        "reference": row["primary_reference"],
        "evidence_type": "DATABASE_ASSERTION",
        "notes": (f"MIBiG {row['mibig_accession']} entry version "
                  f"{row['entry_version']}; citation taken from the {level} level"),
    }]
    if row.get("locus_evidence_qualification"):
        evidence.append({
            "reference": row["locus_evidence_qualification_reference"],
            "evidence_type": "CURATOR_INFERENCE",
            "notes": row["locus_evidence_qualification"],
        })
    if row.get("structure_correction_note"):
        evidence.append({
            "reference": row["structure_correction_reference"],
            "evidence_type": "CURATOR_INFERENCE",
            "notes": row["structure_correction_note"],
        })
    return evidence


def group_by_structure(rows: list[dict[str, str]]) -> dict[str, list[dict[str, str]]]:
    """Group source rows by Standard InChIKey. That merge is the product."""
    grouped: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        key = row.get("standard_inchi_key")
        if key:
            grouped[key].append(row)
    return grouped


def mibig_cluster(row: dict[str, str], accession: str, *, host: str | None) -> dict[str, Any]:
    """The cluster a MIBiG row describes, with its host only when it is named.

    ``organism_taxon_id`` is optional in the schema, which is what lets a
    cluster from a metagenome or an unplaced isolate stay in the corpus
    without inventing a host for it (#62, #68).
    """
    cluster: dict[str, Any] = {
        "accession": f"mibig:{accession}",
        "entry_version": row["entry_version"],
        "entry_status": row["entry_status"],
    }
    # Key order is the emission contract: `evidence` goes last, so the organism
    # keys are inserted before it rather than appended after. Appending them
    # reordered the cluster block in all 3,115 records and buried the real
    # changes in cosmetic churn.
    if host:
        cluster["organism_taxon_id"] = host
        cluster["organism_label"] = row["taxon_label"]
    cluster["evidence"] = mibig_evidence(row)
    return cluster


def rewrite_merged_taxon(
    item: dict[str, Any], key: str, merges: dict[str, str], rewrites: Counter, source: str,
    *, note: bool,
) -> None:
    """Replace a taxon id NCBI has merged with the current one, and say so.

    The source's id stays in the inventory as provenance; the record carries
    the id that joins (#63). A merged id still denotes the organism, so the
    label is left as the source wrote it — it is now a synonym of the current
    node's name, which is what the id-label gate accepts.
    """
    old = item.get(key)
    if not old or old not in merges:
        return
    item[key] = merges[old]
    rewrites[source] += 1
    if note:
        text = (f"Taxon id {old}, as given by {source}, was merged into {merges[old]} "
                f"by NCBI Taxonomy; rewritten at seed time.")
        item["notes"] = f"{item['notes']} {text}" if item.get("notes") else text


def build_records(inventories: dict[str, list[dict[str, str]]]) -> list[dict[str, Any]]:
    """Harmonize the committed inventories into one record per structure.

    M2 covers MIBiG plus the NPClassifier filing inventory. ChEBI grounding,
    LOTUS occurrences and PubChem structures join here in later milestones; the
    shape below is what they slot into.

    Every record produced is MINTED, because MIBiG carries no ChEBI
    cross-reference for most compounds and this milestone does not yet read
    ChEBI. Grounding those is exactly what the next milestone is for, and
    `just worklist` ranks them.
    """
    raw_mibig_rows = inventories.get("mibig_compounds") or []
    claim_references = load_claim_references(
        raw_mibig_rows, inventories.get("mibig_claim_references") or [])
    applied_references: set[str] = set()
    producer_strains = load_producer_strains(
        raw_mibig_rows, inventories.get("mibig_producer_strains") or [])
    applied_strains: set[str] = set()
    xref_exclusions = load_xref_exclusions(
        raw_mibig_rows, inventories.get("mibig_xref_exclusions") or [])
    applied_exclusions: set[str] = set()
    mibig_rows = apply_structure_corrections(
        raw_mibig_rows,
        inventories.get("mibig_structure_corrections") or [],
        inventories.get("chebi_structures") or [],
    )
    mibig_locus_overrides = load_mibig_locus_evidence_overrides(
        inventories.get("mibig_locus_evidence_overrides") or [])
    source_counts = Counter(mint_identifier("MIBIG", row["mibig_accession"] + ":" + row["compound_index"])
                            for row in mibig_rows)
    for identifier, override in mibig_locus_overrides.items():
        if override.get("action") == "WITHDRAW" and source_counts[identifier] != 1:
            raise ValueError(f"{identifier} WITHDRAW requires exactly one matching source row")
    if not mibig_rows:
        return []
    mibig_rows = [
        apply_mibig_locus_evidence_override(row, mibig_locus_overrides, source_row=raw)
        for row, raw in zip(mibig_rows, raw_mibig_rows, strict=True)
    ]

    classification = {
        row["standard_inchi_key"]: row
        for row in inventories.get("npclassifier") or []
    }

    # Old NCBI taxid -> current, from the taxonomy extractor's merged.dmp
    # inventory. Applied wherever a source-supplied id is written (#63).
    merges = {row["old_taxon_id"]: row["new_taxon_id"]
              for row in inventories.get("taxon_merged") or []}
    taxon_rewrites: Counter[str] = Counter()

    # Taxa that do not denote a single organism — NCBI's bins for unplaced
    # sequences, whole metagenomes, and the two generic `uncultured` nodes that
    # every unplaced organism shares. A producer claim on one of these asserts
    # a producer while naming none, and no other gate can see it: the CURIE is
    # valid and the label is non-empty (#62, #68). Derived from the taxdump by
    # the taxonomy extractor, so it is a committed decision, not a literal here.
    non_organism = {row["taxon_id"]: row["reason"]
                    for row in inventories.get("taxon_non_organism") or []}
    if not non_organism:
        print("taxon_non_organism.tsv: ABSENT — producer claims will be written for "
              "taxa that name no organism. Run `just extract-taxonomy` first if this "
              "was not intended.", file=sys.stderr)
    withheld_producers: Counter[str] = Counter()

    # Current NCBITaxon CURIE -> broad display group, derived from the NCBI
    # parent tree in the taxonomy extractor. Missing rows withhold a facet,
    # never the underlying producer or occurrence claim.
    taxon_groups = {row["taxon_id"]: row["taxon_group"]
                    for row in inventories.get("taxon_groups") or []}
    if not taxon_groups:
        print("taxon_groups.tsv: ABSENT — producer and occurrence lineage facets "
              "will be omitted. Run `just extract-taxonomy` first if this was not "
              "intended.", file=sys.stderr)

    # Organism name -> current NCBITaxon CURIE. Built by the taxonomy extractor
    # from names.dmp, which carries only live nodes, so these ids need no
    # merge rewriting — unlike the ones sources supply directly (#63).
    taxon_by_name = {row["organism_name"].lower(): row["taxon_id"]
                     for row in inventories.get("taxon_names") or []}
    unresolved_target_organisms: Counter[str] = Counter()

    # ChEBI, keyed by structure. A key matching more than one 3-star entry is
    # NOT a resolution failure: ChEBI keeps a compound and its zwitterion as
    # separate entries sharing an InChIKey, deliberately. Picking one would
    # overrule the people who own the identifiers, so the record stays minted
    # and says the identity needs adjudicating.
    chebi_by_key: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in inventories.get("chebi_structures") or []:
        chebi_by_key[row["standard_inchi_key"]].append(row)

    # The same entries by identifier, so an xref asserting "this compound is
    # CHEBI:X" can be checked against the structure ChEBI holds for X. When
    # they disagree, one of the two databases has the wrong structure, and
    # neither the InChIKey merge nor any gate would say so (#77).
    chebi_by_id = {row["chebi_id"]: row for row in inventories.get("chebi_structures") or []}

    origins_by_chebi: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in inventories.get("chebi_origins") or []:
        origins_by_chebi[row["chebi_id"]].append(row)

    # LOTUS: structure-organism-reference triples. Occurrences, never
    # producers — LOTUS reports that a compound was found in an organism and
    # does not say whether the organism makes it.
    lotus_by_key: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in inventories.get("lotus_occurrences") or []:
        lotus_by_key[row["standard_inchi_key"]].append(row)

    # CyanoMetDB isolation reports. Occurrences, not producers: a strain
    # designation says the compound was FOUND in material from that strain, not
    # that anyone showed the strain makes it.
    cyano_by_key: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in inventories.get("cyanometdb_occurrences") or []:
        cyano_by_key[row["standard_inchi_key"]].append(row)

    # BindingDB's own-curated affinities. Only rows its Curation/DataSource
    # column marks as BindingDB's own reach this inventory; the ChEMBL-derived
    # rows in the same file are share-alike and were filtered at extraction.
    targets_by_key: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in inventories.get("bindingdb_targets") or []:
        targets_by_key[row["standard_inchi_key"]].append(row)

    # PubChem BioAssay, already filtered at extraction to measurements and
    # positive calls, with ChEMBL-deposited rows excluded on licence.
    assays_by_key: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in inventories.get("pubchem_bioassay") or []:
        if row.get("aid"):
            assays_by_key[row["standard_inchi_key"]].append(row)

    # The sibling corpus, pinned. A compound in both keeps its antimicrobial
    # mechanism there and is linked from here, never copied.
    sibling_by_key: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in inventories.get("antibioticmech_inchikeys") or []:
        sibling_by_key[row["standard_inchi_key"]].append(row)

    pathway_by_key: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in inventories.get("pathwaymech_products") or []:
        pathway_by_key[row["standard_inchi_key"]].append(row)

    records: list[dict[str, Any]] = []
    for key, rows in sorted(group_by_structure(mibig_rows).items()):
        # Prefer the row with the strongest producer evidence as the record's
        # spokesman for label and structure: same structure either way, but a
        # characterized entry is the better-curated one.
        rows = sorted(rows, key=lambda r: (
            0 if r["producer_evidence_basis"] == "BGC_CHARACTERIZED" else
            1 if r["producer_evidence_basis"] == "BGC_CORRELATED" else 2,
            r["mibig_accession"],
        ))
        lead = rows[0]
        structure_corrected = any(row.get("structure_correction_note") for row in rows)
        minted = mint_identifier("MIBIG", lead["mibig_accession"] + ":" + lead["compound_index"])

        chebi_matches = chebi_by_key.get(key) or []
        name_candidates = [r["compound_name"] for r in rows]
        authoritative = chebi_matches[0]["name"] if len(chebi_matches) == 1 else None
        if authoritative:
            name_candidates.append(authoritative)
        label, synonyms = choose_label(name_candidates, authoritative=authoritative)
        label = label or key

        if len(chebi_matches) == 1:
            identifier = chebi_matches[0]["chebi_id"]
            grounding = "EXACT"
            grounding_notes = ""
        elif len(chebi_matches) > 1:
            identifier = minted
            grounding = "REVIEW_NEEDED"
            grounding_notes = (
                "This structure matches more than one 3-star ChEBI entry: "
                + ", ".join(m["chebi_id"] for m in chebi_matches)
                + ". ChEBI keeps such entries separate on purpose — a compound and "
                "its zwitterion share an InChIKey — so the identity is not picked "
                "here. A curator decides which term this record is."
            )
        else:
            identifier = minted
            grounding = "MINTED"
            grounding_notes = (
                "No 3-star ChEBI entry shares this structure, so the record keeps a "
                "content-hashed identifier."
            )

        classified = classification.get(key)
        pathway_results = [
            x for x in (classified["pathway_results"].split("|") if classified else []) if x
        ]
        pathway = choose_pathway(pathway_results)

        doc: dict[str, Any] = {
            "identifier": identifier,
            "label": label,
            "chemical_structure": {
                "smiles": lead["smiles"],
                "standard_inchi": lead["standard_inchi"],
                "standard_inchi_key": key,
                "stereo_complete": lead["stereo_complete"] == "true",
                "structure_source": lead.get("structure_source", "MIBIG"),
                "structure_source_id": lead.get(
                    "structure_source_id", f"mibig:{lead['mibig_accession']}"),
            },
            "np_pathway": pathway,
            "biosynthesis_origin": "NATURAL_PRODUCT",
        }
        if len(chebi_matches) == 1 and chebi_matches[0]["definition"]:
            doc["definition"] = chebi_matches[0]["definition"]
            doc["definition_source"] = chebi_matches[0]["chebi_id"]
        if synonyms:
            doc["synonyms"] = [{"value": value, "synonym_type": "RELATED_SYNONYM",
                                "source": "mibig:" + lead["mibig_accession"]}
                               for value in synonyms]

        if classified:
            doc["np_classification"] = {
                "tool": "NPClassifier",
                "tool_version": classified["model_version"],
                "pathway_results": pathway_results,
                "superclass_results": [x for x in classified["superclass_results"].split("|") if x],
                "class_results": [x for x in classified["class_results"].split("|") if x],
                "is_glycoside": classified["is_glycoside"] == "true",
            }

        bgc_classes, compound_classes, xrefs = [], [], []
        unnamed_producer_clusters: list[tuple[str, str, str]] = []
        producers: list[dict[str, Any]] = []
        clusters: list[dict[str, Any]] = []
        source_concepts: list[dict[str, Any]] = []
        excluded_xrefs: list[dict[str, str]] = []

        for row in rows:
            accession = row["mibig_accession"]
            source_concept_identifier = mint_identifier(
                "MIBIG", accession + ":" + row["compound_index"])

            source_concepts.append({
                "source": "MIBIG",
                "source_id": accession,
                "source_label": row["compound_name"] or label,
                "source_version": row["entry_version"],
                "minted_identifier": source_concept_identifier,
            })

            for value in row["bgc_classes"].split("|"):
                mapped = BGC_CLASS_MAP.get(value.strip())
                if mapped and mapped not in bgc_classes:
                    bgc_classes.append(mapped)
            for value in row["compound_classes"].split("|"):
                if value and value not in compound_classes:
                    compound_classes.append(value)
            source_id = f"{accession}:{row['compound_index']}"
            exclusions = xref_exclusions.get(source_id, [])
            if exclusions:
                if row.get("structure_correction_note"):
                    raise ValueError(f"{source_id}: xref exclusions need review after structure correction")
                applied_exclusions.add(source_id)
                excluded_xrefs.extend(exclusions)
            for value in row["database_ids"].split("|"):
                if any(value == decision["xref"] for decision in exclusions):
                    continue
                if value and DB_ID_RE.match(value):
                    canonical = canonical_xref(value)
                    if canonical not in xrefs:
                        xrefs.append(canonical)

            # Unconditional wherever MIBiG names an organism, and that is the
            # point: MIBiG asserting a compound-organism pair IS an assertion
            # of production. What varies is how well supported it is, which is
            # what evidence_basis says. grade_production has no withholding
            # case for the same reason — the one that used to exist,
            # homology-based prediction, now lands on the CLUSTER grade where
            # it belongs (#20).
            #
            # The one case that withholds is an entry whose taxonomy is a
            # non-organism node: the extractor blanks it, and a producer needs
            # a taxon to be a claim about one (#62). The compound and its
            # cluster stay; only the producer is not written.
            # The claim is judged on the id the record would carry, which is
            # the merged-forward one: an id NCBI retired into a bin must be
            # caught as a bin, not as whatever the source happened to send.
            host = merges.get(row["taxon_id"], row["taxon_id"])
            reason = non_organism.get(host)
            if reason:
                unnamed_producer_clusters.append((accession, host, reason))
                withheld_producers[host] += 1
                host = None

            reference_correction = claim_references.get(source_id)
            if reference_correction and not host:
                raise ValueError(f"{source_id}: claim references require an emitted producer")

            if host:
                producers.append({
                    "taxon_id": row["taxon_id"],
                    "taxon_label": row["taxon_label"],
                    "evidence_basis": row["producer_evidence_basis"],
                    "biosynthetic_gene_cluster": f"mibig:{accession}",
                    "source": "MIBIG",
                    "source_version": row["entry_version"],
                    "notes": (
                        (f"Source locus methods excluded as inapplicable: "
                         f"{row['excluded_locus_evidence_methods']}. No applicable locus methods remain. "
                         if row.get("locus_evidence_qualification") else
                         f"Locus evidence: {row['locus_evidence_methods'] or 'none stated'}. ") +
                        f"That evidence grades the LOCUS as "
                        f"{row.get('cluster_link_evidence_basis', 'CLUSTER_UNSTATED')}; this "
                        f"field grades the taxon claim, which is a different question."
                    ),
                    "evidence": mibig_evidence(row),
                })
                rewrite_merged_taxon(
                    producers[-1], "taxon_id", merges, taxon_rewrites, "MIBiG", note=True)
                if reference_correction:
                    correct_claim_reference(
                        producers[-1], row, reference_correction, field="producer_reference")
                qualification = producer_strains.get(f"{accession}:{row['compound_index']}")
                if qualification:
                    if row.get("structure_correction_note"):
                        raise ValueError(
                            f"{accession}: strain context needs review after structure correction")
                    qualify_producer(producers[-1], qualification)
                    applied_strains.add(qualification["source_id"])

            cluster = mibig_cluster(row, accession, host=host)
            if reference_correction:
                correct_claim_reference(cluster, row, reference_correction, field="locus_reference")
                applied_references.add(source_id)
            rewrite_merged_taxon(cluster, "organism_taxon_id", merges, taxon_rewrites, "MIBiG", note=True)
            if row["genome_accession"]:
                cluster["genome_accession"] = f"genbank:{row['genome_accession']}"
            for field, column in (("locus_from", "locus_from"), ("locus_to", "locus_to")):
                if row[column] and row[column].isdigit() and int(row[column]) > 0:
                    cluster[field] = int(row[column])
            if bgc_classes:
                cluster["bgc_class"] = list(bgc_classes)
            methods = [m for m in row["locus_evidence_methods"].split("|") if m]
            if methods:
                cluster["locus_evidence_methods"] = methods
            if row.get("cluster_link_evidence_basis"):
                cluster["link_evidence_basis"] = row["cluster_link_evidence_basis"]
            clusters.append(cluster)

        for match in chebi_matches:
            source_concepts.append({
                "source": "CHEBI",
                "source_id": match["chebi_id"],
                "source_label": match["name"],
                "source_version": f"{match['stars']}-star",
                "minted_identifier": mint_identifier("CHEBI", match["chebi_id"]),
            })

        # ChEBI's compound_origins records where a compound was FOUND. That is
        # an occurrence and never a producer claim: ChEBI is not asserting that
        # the organism biosynthesizes it, and the seeder does not promote.
        occurrences: list[dict[str, Any]] = []
        for match in chebi_matches:
            for origin in origins_by_chebi.get(match["chebi_id"]) or []:
                occurrence: dict[str, Any] = {
                    "taxon_label": origin["species_text"],
                    "source": "CHEBI",
                    "evidence": [{
                        "reference": f"PMID:{origin['source_accession']}"
                        if origin["source_accession"].isdigit() else origin["source_accession"],
                        "evidence_type": "DATABASE_ASSERTION",
                        "notes": f"ChEBI compound origin for {match['chebi_id']}",
                    }],
                }
                if structure_corrected and not re.match(
                    r"^(?:\d+$|PMID:|DOI:|https://)", origin["source_accession"]
                ):
                    occurrence["evidence"][0].update({
                        "reference": f"https://www.ebi.ac.uk/chebi/{match['chebi_id']}",
                        "notes": (f"ChEBI compound origin for {match['chebi_id']}; "
                                  f"source bibliography: {origin['source_accession']}"),
                    })
                if origin["species_accession"].isdigit():
                    occurrence["taxon_id"] = f"NCBITaxon:{origin['species_accession']}"
                    occurrence["taxon_source"] = "NCBITaxon"
                    rewrite_merged_taxon(occurrence, "taxon_id", merges, taxon_rewrites, "ChEBI", note=True)
                if origin["strain_text"]:
                    occurrence["detection_context"] = origin["strain_text"]
                context = " ".join(x for x in (origin["component_text"], origin["comments"]) if x)
                if context:
                    occurrence["notes"] = context[:400]
                occurrences.append(occurrence)
        for row in lotus_by_key.get(key) or []:
            occurrence = {
                "taxon_id": row["taxon_id"],
                "taxon_label": row["organism_name"],
                "taxon_source": "NCBITaxon",
                "source": "LOTUS",
                "evidence": [{
                    "reference": f"DOI:{row['reference_doi']}",
                    "evidence_type": "DATABASE_ASSERTION",
                    "notes": (
                        "LOTUS structure-organism-reference triple. LOTUS reports that "
                        "the compound was found in the organism; it does not assert that "
                        "the organism produces it."
                    ),
                }],
            }
            if row["organism_wikidata"]:
                occurrence["notes"] = f"Wikidata organism {row['organism_wikidata']}"
            rewrite_merged_taxon(occurrence, "taxon_id", merges, taxon_rewrites, "LOTUS", note=True)
            occurrences.append(occurrence)

        for row in cyano_by_key.get(key) or []:
            occurrence: dict[str, Any] = {
                "taxon_id": row["taxon_id"],
                "taxon_label": row["taxon_label"],
                "taxon_source": "NCBITaxon",
                "source": "CYANOMETDB",
                "evidence": [{
                    "reference": row["reference"],
                    "evidence_type": "DATABASE_ASSERTION",
                    "notes": (
                        "CyanoMetDB isolation report, manually curated from the primary "
                        "literature"
                        + (f"; structure confirmed by {row['nmr_used']}" if row["nmr_used"] else "")
                        + "."
                    ),
                }],
            }
            context = " ".join(
                x for x in (
                    f"strain {row['strain']}" if row["strain"] else "",
                    row["field_sample"] if row["field_sample"] else "",
                ) if x
            )
            if context:
                occurrence["detection_context"] = context[:200]
            rewrite_merged_taxon(occurrence, "taxon_id", merges, taxon_rewrites, "CyanoMetDB", note=True)
            occurrences.append(occurrence)

        # De-duplicate on (taxon, reference). Two routes produce exact
        # duplicates: a REVIEW_NEEDED record pulling origins from several ChEBI
        # entries that share one, and ChEBI and LOTUS citing the same paper
        # (#26). Distinct reference strings remain separate; DOI/PMID aliases
        # are not resolved here and do not establish independent publications.
        deduped: list[dict[str, Any]] = []
        seen_occurrence: set[tuple[str, str]] = set()
        for occurrence in occurrences:
            signature = (
                occurrence.get("taxon_id") or occurrence["taxon_label"],
                occurrence["evidence"][0]["reference"],
            )
            if signature in seen_occurrence:
                continue
            seen_occurrence.add(signature)
            deduped.append(occurrence)

        # Preserve the distinct claims without inferring publication independence
        # from taxon overlap or different citation identifiers (#891).
        producer_taxa = {p["taxon_id"] for p in producers}
        for occurrence in deduped:
            if occurrence.get("taxon_id") in producer_taxa:
                note = ("This taxon is also recorded as a producer. Production and occurrence "
                        "are distinct claims; their citations may refer to the same publication. "
                        "Publication independence has not been established.")
                occurrence["notes"] = (
                    f"{occurrence['notes']} {note}" if occurrence.get("notes") else note
                )

        if deduped:
            # Prefer occurrences that ADD something: a taxon not already
            # asserted as a producer carries information the record does not
            # otherwise have. Ordering is otherwise stable so the cap is
            # deterministic rather than dependent on source order.
            deduped.sort(key=lambda o: (
                o.get("taxon_id") in producer_taxa,
                o.get("taxon_id") or "",
                o["evidence"][0]["reference"],
            ))
            omitted = len(deduped) - MAX_OCCURRENCES_PER_RECORD
            if omitted > 0:
                kept_occurrences = deduped[:MAX_OCCURRENCES_PER_RECORD]
                note = (
                    f"{omitted} further cited occurrences are recorded in "
                    f"data/raw/lotus_occurrences.tsv and data/raw/chebi_origins.tsv "
                    f"but not written here: a record carrying hundreds of them cannot "
                    f"be reviewed. The inventories are the complete record."
                )
                kept_occurrences[-1]["notes"] = (
                    f"{kept_occurrences[-1]['notes']} {note}"
                    if kept_occurrences[-1].get("notes") else note
                )
                deduped = kept_occurrences
            occurrence_groups = taxon_groups_for(deduped, taxon_groups)
            if occurrence_groups:
                doc["occurrence_taxon_groups"] = occurrence_groups
            doc["occurrences"] = deduped

        summary_classes: set[str] = set()
        bioactivities: list[dict[str, Any]] = []
        for row in assays_by_key.get(key) or []:
            observation: dict[str, Any] = {
                "assay": row["assay_name"] or f"PubChem AID {row['aid']}",
                "evidence": [{
                    "reference": row["reference"] or f"pubchem.aid:{row['aid']}",
                    "evidence_type": "DATABASE_ASSERTION",
                    "notes": (
                        f"PubChem BioAssay AID {row['aid']}"
                        + (f", deposited by {row['depositor']}" if row["depositor"] else "")
                        + (f"; assay type {row['assay_type']}" if row["assay_type"] else "")
                        + "."
                    ),
                }],
            }
            outcome = row["activity_outcome"].strip()
            observation["call"] = {
                "active": "ACTIVE", "inactive": "INACTIVE",
            }.get(outcome.lower(), "NOT_DETERMINED")
            if observation["call"] == "NOT_DETERMINED":
                observation["evidence"][0]["notes"] += (
                    f" Source outcome: {outcome or '(missing)'}."
                )
            if row["activity_value_um"] and row["activity_name"]:
                measurement = MEASUREMENT_TYPES.get(row["activity_name"].strip().upper(), "OTHER")
                observation["measurement_type"] = measurement
                if measurement == "OTHER":
                    observation["evidence"][0]["notes"] += (
                        f" Source endpoint: {row['activity_name']}."
                    )
                observation["value"] = float(row["activity_value_um"])
                observation["units"] = "uM"
            target_accession = row["target_accession"].strip()
            if target_accession and UNIPROT_ACCESSION_RE.fullmatch(target_accession):
                observation["target_enzyme"] = f"UniProtKB:{target_accession}"
            elif target_accession:
                observation["evidence"][0]["notes"] += (
                    f" Target accession {target_accession} was left ungrounded because "
                    "PubChem did not provide a UniProtKB accession."
                )
            activity_class = classify_activity(row["assay_name"], aid=row["aid"])
            if activity_class and observation["call"] == "ACTIVE":
                observation["activity_class"] = activity_class
            bioactivities.append(observation)

        if bioactivities:
            # Measurements before bare calls: a number with units is worth more
            # to a curator than a hit, and the cap should not spend itself on
            # the latter.
            bioactivities.sort(key=lambda b: (0 if "value" in b else 1, b["assay"]))
            omitted = len(bioactivities) - MAX_BIOACTIVITIES_PER_RECORD
            if omitted > 0:
                bioactivities = bioactivities[:MAX_BIOACTIVITIES_PER_RECORD]
                bioactivities[-1]["notes"] = (
                    f"{omitted} further PubChem assay results are in "
                    f"data/raw/pubchem_bioassay.tsv but not written here."
                )
            doc["bioactivities"] = bioactivities

            # bioactivity_summary is derived and must never float: PLAN.md 3.5
            # accepts a bioactivities item as backing, and there are now
            # classified items to derive from. Only explicitly active written
            # observations back positive activity summaries.
            summary_classes.update(b["activity_class"] for b in bioactivities
                                   if b.get("activity_class") and b.get("call") == "ACTIVE")

        targets: list[dict[str, Any]] = []
        for row in targets_by_key.get(key) or []:
            context = ", ".join(
                part for part in (
                    f"pH {row['ph']}" if row["ph"] else "",
                    f"{row['temperature_c']} C" if row["temperature_c"] else "",
                ) if part
            )
            target: dict[str, Any] = {
                "target_label": row["target_name"] or "unnamed target",
                "target_type": "PROTEIN",
                "relation": "BINDS",
                "measurement_type": row["measurement_type"],
                "measurement_value": float(row["measurement_value_nm"]),
                "measurement_units": "nM",
                "source": "BINDINGDB",
                "evidence": [{
                    "reference": row["reference"],
                    "evidence_type": "DATABASE_ASSERTION",
                    "notes": (
                        "BindingDB own-curated affinity"
                        + (f"; measured at {context}" if context else "")
                        + f"; qualifier {row['measurement_qualifier']}."
                    ),
                }],
            }
            if row["uniprot"]:
                # An organism-specific accession is an EXAMPLE of a target, not
                # a target identity — docs/CURATION.md is explicit about it.
                target["protein_examples"] = [f"UniProtKB:{row['uniprot']}"]
            if row["target_organism"]:
                # The assay organism is which organism's protein was assayed,
                # and a name with no identifier joins to nothing — the rule
                # docs/HARMONIZATION.md states for occurrences (#67). Exact
                # match only, and no genus fallback, for the same reason
                # taxonomy.resolve_name has none: a species id under a strain
                # label is an id and a label denoting different things.
                organism = " ".join(row["target_organism"].split())
                resolved = taxon_by_name.get(organism.lower())
                if resolved:
                    target["taxon_id"] = resolved
                else:
                    unresolved_target_organisms[organism] += 1
                target["taxon_label"] = row["target_organism"]
            targets.append(target)
        if targets:
            omitted = len(targets) - MAX_MOLECULAR_TARGETS_PER_RECORD
            if omitted > 0:
                targets = targets[:MAX_MOLECULAR_TARGETS_PER_RECORD]
                targets[-1]["notes"] = (
                    f"{omitted} further BindingDB target rows are in "
                    f"data/raw/bindingdb_targets.tsv but not written here."
                )
            doc["molecular_targets"] = targets

        links = [{
            "corpus": "AntibioticMech",
            "identifier": sibling["identifier"],
            "relation": "SAME_STRUCTURE",
            "basis": "SAME_INCHIKEY",
            "source_version": (sibling["corpus_commit"] if structure_corrected
                               else sibling["corpus_commit"][:12]),
        } for sibling in sibling_by_key.get(key) or []]
        links.extend({
            "corpus": "PathwayMech",
            "identifier": pathway["identifier"],
            "relation": "BIOSYNTHESIZED_BY",
            "basis": pathway["basis"],
            "source_version": pathway["corpus_commit"],
        } for pathway in pathway_by_key.get(key) or [])
        if links:
            doc["related_records"] = links

        # A shared structure's antimicrobial class comes from the sibling that
        # owns that claim, and ONLY the class: no targets, no resistance
        # determinants, no MIC spectra. PLAN.md 4.1 says the corpora join
        # rather than duplicate, and 3.5 accepts a sibling link as backing for
        # exactly this. The alternative was leaving 205 shared compounds
        # unclassified while the fleet already knew what they do.
        for sibling in sibling_by_key.get(key) or []:
            mapped = SIBLING_ACTIVITY_CLASSES.get(sibling.get("antimicrobial_class", ""))
            if mapped:
                summary_classes.add(mapped)

        if summary_classes:
            doc["bioactivity_summary"] = sorted(summary_classes)

        if bgc_classes:
            doc["bgc_class"] = bgc_classes
        if compound_classes:
            doc["compound_classes"] = compound_classes
        # An xref pointing at this record's own identifier is not a cross
        # reference to anything. 20 records carried one, because MIBiG cites
        # the ChEBI id the record is already grounded to and the two spellings
        # hid it (#61).
        xrefs = [x for x in xrefs if x != doc["identifier"]]
        if any(decision["xref"] in xrefs for decision in excluded_xrefs):
            raise ValueError("excluded xref reintroduced by another source row; adjudicate all assertions")
        if xrefs:
            doc["xrefs"] = xrefs
        if producers:
            producer_groups = taxon_groups_for(producers, taxon_groups)
            if producer_groups:
                doc["producer_taxon_groups"] = producer_groups
            doc["producer_organisms"] = producers
        if clusters:
            doc["biosynthetic_gene_clusters"] = clusters

        doc["source_concepts"] = source_concepts
        doc["grounding_status"] = grounding
        if grounding_notes:
            doc["grounding_notes"] = grounding_notes
        doc["curation_status"] = "SEEDED"

        discussions: list[dict[str, Any]] = [exclusion_discussion(d) for d in excluded_xrefs]
        for row in rows:
            if row.get("structure_correction_note"):
                discussions.append({
                    "discussion_id": "source-structure-correction",
                    "kind": "CONTROVERSY",
                    "status": "RESOLVED",
                    "prompt": "Which structure represents the source compound?",
                    "resolution_note": row["structure_correction_note"],
                    "evidence": [{
                        "reference": row["structure_correction_reference"],
                        "evidence_source": "figure; curator interpretation",
                        "notes": row["structure_correction_note"],
                    }],
                })

        # A paper-internal label identifies a structure only relative to one
        # paper's numbering. The name is not invented here — MIBiG's is kept —
        # but the record says it needs one, so it lands on the worklist rather
        # than being found by someone browsing (#17).
        if PAPER_INTERNAL_NAME.match(label):
            discussions.append({
                "discussion_id": "needs-a-name",
                "kind": "CURATION_TODO",
                "status": "OPEN",
                "prompt": (
                    f"This record is labelled {label!r}, which is a label from the "
                    f"cited paper's own numbering rather than a compound name. "
                    f"Resolve a name from the literature or a structure registry."
                ),
            })

        # One structure, two sources calling it genuinely different things:
        # somebody's structure is wrong upstream, and no naming rule should
        # quietly decide which (#22).
        if authoritative:
            # Sorted, and every disagreeing name rather than the first: this
            # iterated a set and broke on the first match, so a structure with
            # two disagreeing MIBiG names quoted one of them at random — set
            # order varies per process, and three records re-emitted
            # differently on a coin flip (#75). Naphthalene-1,3,6,8-tetrol has
            # both `1,3,6,8-tetrahydroxynaphthalene` and the typo
            # `1,3,5,8-tetrahydroxynapthalene`, so half the time the curator
            # was shown the correct name as the conflict.
            disagreeing = sorted(
                other for other in {r["compound_name"] for r in rows if r["compound_name"]}
                if names_disagree(label, other)
            )
            if disagreeing:
                quoted = ", ".join(repr(name) for name in disagreeing)
                discussions.append({
                    "discussion_id": "name-disagreement",
                    "kind": "CONTROVERSY",
                    "status": "OPEN",
                    "prompt": (
                        f"ChEBI calls this structure {authoritative!r} and MIBiG calls "
                        f"it {quoted}. They share a Standard InChIKey, so if the "
                        f"names denote different compounds then one upstream record has "
                        f"the wrong structure. Check which."
                    ),
                })

        # A collision that survives must be visible, not silent.
        if len(rows) > 1 and len({r["mibig_accession"] for r in rows}) > 1:
            discussions.append({
                "discussion_id": "shared-structure",
                "kind": "CURATION_TODO",
                "status": "OPEN",
                "prompt": (
                    "This structure is reported by more than one MIBiG entry: "
                    + ", ".join(sorted({r["mibig_accession"] for r in rows}))
                    + ". Confirm they describe the same compound rather than an "
                    "upstream cross-reference error."
                ),
            })

        if unnamed_producer_clusters:
            detail = "; ".join(
                f"{acc}, which gives {taxon} ({reason})"
                for acc, taxon, reason in sorted(set(unnamed_producer_clusters))
            )
            discussions.append({
                "discussion_id": "unnamed-producer",
                "kind": "CURATION_TODO",
                "status": "OPEN",
                "prompt": (
                    f"No producer claim is written from {detail}, because the "
                    "taxon names no single organism. The cluster is kept: a "
                    "characterized locus is an origin assertion whether or not "
                    "its host has a name, and for a compound from an uncultured "
                    "symbiont that is the honest state. Name the producer if the "
                    "primary literature does."
                ),
            })

        # An xref asserts the same structure. When it names a ChEBI entry this
        # corpus holds under a DIFFERENT Standard InChIKey, that assertion and
        # the identity rule contradict each other, and one of the two upstream
        # records has the wrong structure. Refusing to merge is right and is
        # what the InChIKey rule already does; saying nothing is not (#77).
        for xref in xrefs:
            entry = chebi_by_id.get(xref)
            if entry is None or not entry["standard_inchi_key"]:
                continue
            their_key = entry["standard_inchi_key"]
            if their_key == key:
                continue
            same_skeleton = their_key.split("-")[0] == key.split("-")[0]
            discussions.append({
                "discussion_id": "structure-disagreement",
                "kind": "CURATION_TODO",
                "status": "OPEN",
                "prompt": (
                    f"MIBiG cross-references this compound to {xref}, but ChEBI holds "
                    f"{xref} with Standard InChIKey {their_key} and this record's "
                    f"structure is {key}. "
                    + (
                        "The skeleton blocks match, so the two disagree about "
                        "stereochemistry: check which configuration the primary "
                        "literature supports."
                        if same_skeleton else
                        "The skeleton blocks differ, so these are not the same "
                        "molecule: one of the two databases has the wrong structure "
                        "for this name. Check which, and report it upstream."
                    )
                ),
            })

        if discussions:
            doc["discussions"] = discussions

        doc["_slug"] = slugify(label, identifier)
        if structure_corrected:
            doc["_previous_standard_inchi_key"] = lead["structure_correction_old_key"]
        records.append(doc)

    # Slugs are published URLs and must be unique. A clash is resolved
    # deterministically rather than by whichever record was built first.
    seen: Counter[str] = Counter()
    for doc in sorted(records, key=lambda d: d["identifier"]):
        base = doc["_slug"]
        seen[base] += 1
        if seen[base] > 1:
            doc["_slug"] = f"{base}-{seen[base]}"
    # Said out loud, like the taxonomy table: a run with the merged inventory
    # absent rewrites nothing and passes every gate, which is the silent
    # shrinkage #35 was about.
    if unresolved_target_organisms:
        total = sum(unresolved_target_organisms.values())
        names = ", ".join(n for n, _ in unresolved_target_organisms.most_common(4))
        print(f"molecular targets whose assay organism did not resolve: {total} "
              f"({len(unresolved_target_organisms)} distinct: {names}…)", file=sys.stderr)

    if withheld_producers:
        total = sum(withheld_producers.values())
        detail = ", ".join(f"{t} {n}" for t, n in withheld_producers.most_common())
        print(f"producer claims withheld — taxon names no single organism: {total} "
              f"({detail})", file=sys.stderr)

    if merges:
        total = sum(taxon_rewrites.values())
        detail = ", ".join(f"{s} {n}" for s, n in sorted(taxon_rewrites.items()))
        print(f"taxon ids rewritten through taxon_merged.tsv: {total}"
              + (f" ({detail})" if detail else ""), file=sys.stderr)
    else:
        print("taxon_merged.tsv: ABSENT — merged ids left as the sources gave them. "
              "Run `just extract-taxonomy` first if this was not intended.", file=sys.stderr)
    if xref_exclusions.keys() - applied_exclusions:
        raise ValueError("xref exclusions did not reach a record: "
                         + ", ".join(sorted(xref_exclusions.keys() - applied_exclusions)))
    if producer_strains.keys() - applied_strains:
        raise ValueError("strain qualifications did not reach a producer: "
                         + ", ".join(sorted(producer_strains.keys() - applied_strains)))
    if claim_references.keys() - applied_references:
        raise ValueError("claim references did not reach a record: "
                         + ", ".join(sorted(claim_references.keys() - applied_references)))
    return records


def read_record(path: Path) -> dict[str, Any] | None:
    """The record already on disk, or None when there is not one yet."""
    if not path.exists():
        return None
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError:
        # A record too broken to parse is a record to rewrite, not to crash on.
        return None


def seeder_owned(record: dict[str, Any]) -> dict[str, Any]:
    """``record`` without the trail the seeder is deciding whether to add."""
    return {k: v for k, v in record.items() if k != "curation_history"}


def write_records(records: list[dict[str, Any]], *, only: str | None = None,
                  limit: int | None = None) -> int:
    selected = [doc for doc in records if not only or doc["identifier"] == only]
    if limit is not None:
        selected = selected[:max(0, limit)]
    replaced_keys = {doc["_previous_standard_inchi_key"] for doc in selected
                     if doc.get("_previous_standard_inchi_key")}
    if replaced_keys:
        for existing_path in CORPUS_DIR.rglob("*.yaml"):
            existing = read_record(existing_path)
            if existing and _standard_inchi_key(existing) in replaced_keys:
                raise ValueError(
                    f"{existing_path}: old structure owner remains; explicit curation migration required")
    # Refuse identity changes before ANY writes, including an apparently
    # uncurated owner's history. A reviewed migration must move it explicitly.
    for doc in selected:
        path = record_path(doc["np_pathway"], doc["_slug"])
        previous = read_record(path)
        if previous is not None and _standard_inchi_key(previous) != _standard_inchi_key(doc):
            raise ValueError(f"{path}: structure changed; explicit curation migration required")
    written = 0
    unchanged = 0
    rows: list[dict[str, str]] = []
    for doc in selected:
        slug = doc["_slug"]
        pathway = doc["np_pathway"]
        path = record_path(pathway, slug)
        payload = {k: v for k, v in doc.items() if not k.startswith(INTERNAL_PREFIX)}
        carry_existing_curator_owned_fields(payload, path)

        # Stamp a curation event only when the seeder-owned content actually
        # changed. The seeder rebuilds every record from scratch, so the
        # history was recreated with a fresh timestamp on every run and all
        # 3,115 records re-emitted differently — a corpus PR that changed
        # three records still showed 3,115 changed files, which is not a diff
        # anyone can review (#69). The timestamp now means what it says: when
        # this content was last produced, not when the seeder last ran.
        previous = read_record(path)
        if previous is not None and seeder_owned(previous) == seeder_owned(payload):
            payload["curation_history"] = previous.get("curation_history", [])
            unchanged += 1
        else:
            record_curation_event(
                payload,
                curator="seed_from_sources",
                action="SEEDED_FROM_SOURCES",
                changes="Seeded from the committed inventories and curation tables.",
            )
        try:
            write_validated_natural_product(payload, path)
        except ValidationFailedError as exc:
            print(exc.summary(), file=sys.stderr)
            raise
        rows.append({
            "identifier": doc["identifier"],
            "np_pathway": pathway,
            "slug": slug,
            "path": str(path.relative_to(REPO_ROOT)),
        })
        written += 1
    # A partial run must not rewrite the whole lockfile: it would drop every
    # record the run did not touch. `--prune` is already refused on a partial
    # run for the same reason.
    print(f"records written: {written} ({unchanged} unchanged, so their curation "
          f"timestamp is left alone)", file=sys.stderr)
    if rows and only is None and limit is None:
        write_lockfile(rows)
    elif rows:
        print(f"partial run: wrote {len(rows)} record(s) but left PATHS.tsv alone",
              file=sys.stderr)
    return written


def write_lockfile(rows: list[dict[str, str]]) -> None:
    """PATHS.tsv locks identifier, filing pathway and slug together.

    The pathway lives here, not only in the record, because it is the pin that
    stops a later NPClassifier release moving a published URL. A disagreement
    between this file and the current inventory is a `pathway-drift` worklist
    entry for a curator, never an automatic move.
    """
    columns = ["identifier", "np_pathway", "slug", "path"]
    with PATHS_FILE.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(sorted(rows, key=lambda r: r["identifier"]))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true", help="write records (default: dry run)")
    parser.add_argument("--only", help="seed exactly one identifier — the canary")
    parser.add_argument("--limit", type=int, help="stop after this many records")
    parser.add_argument("--prune", action="store_true",
                        help="delete records the run did not rebuild")
    args = parser.parse_args()

    # A partial run must never prune: --prune with --only or --limit would
    # delete records the run never built.
    if args.prune and (args.only or args.limit):
        print("refusing --prune on a partial run (--only/--limit)", file=sys.stderr)
        return 2

    conf = yaml.safe_load(CONF_PATH.read_text(encoding="utf-8"))
    budget = conf.get("record_budget")
    inventories = read_inventories()
    records = build_records(inventories)

    if budget and len(records) > budget:
        print(f"refusing to seed {len(records)} records over the budget of {budget} "
              f"in conf/sources.yaml — widening scope is a recorded decision",
              file=sys.stderr)
        return 2

    if not records:
        print("no inventories in data/raw/, so nothing to seed.")
        print("This is the expected M1 state: the extractors are M2 (PLAN.md section 7).")
        loaded = load_evidence_map()
        print(f"evidence methods loaded: {len(loaded)}; producer grades "
              f"{sorted({v['producer_basis'] for v in loaded.values() if v['producer_basis']})}; "
              f"cluster grades {sorted({v['cluster_basis'] for v in loaded.values()})}")
        return 0

    counts = Counter(doc["np_pathway"] for doc in records)
    for pathway, count in sorted(counts.items()):
        print(f"  {pathway:<34} {count:>6}")

    if not args.apply:
        print(f"dry run: {len(records)} records would be written")
        return 0

    written = write_records(records, only=args.only, limit=args.limit)
    print(f"wrote {written} records")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
