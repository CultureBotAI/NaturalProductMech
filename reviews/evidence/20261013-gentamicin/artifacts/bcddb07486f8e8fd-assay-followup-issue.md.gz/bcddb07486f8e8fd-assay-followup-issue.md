## Adversarial Follow-Up to PR #940

The pinned `data/raw/pubchem_bioassay.tsv` contains 24 AID1195 rows on 24 structure keys. The two-owner gentamicin remediation addresses only the BDTQ/CID72396 row; the other 23 owners are not scientifically reviewed by that change.

The inspected official protocol assigns Active to all substances with recommended-dose data. `rows_from_summary` currently admits positive summary flags without protocol adjudication, and `cid_to_key` trusts owner xrefs without exact-structure verification.

Source: https://pubchem.ncbi.nlm.nih.gov/rest/pug/assay/aid/1195/description/JSON

## Acceptance

- Inspect and account for the remaining AID1195 cohort, preserving original source rows and exact owner identities.
- Add source-version-aware protocol handling and an explicit policy for non-assay administrative outcomes; do not ban all `Other` assays.
- Validate exact CID-to-structure joins before future assay ingestion and define handling of identity conflicts and shared CIDs.
- Keep compound-specific review coverage honest; parser validation is not a scientific whole-record review.
- Test refresh/source-drift behavior, skipped/error reporting and retention of real experimental measurements.

This broader importer/cohort issue remains open; the narrowly pinned correction in #943 does not resolve it.
