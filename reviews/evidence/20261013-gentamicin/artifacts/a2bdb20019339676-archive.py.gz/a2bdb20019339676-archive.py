import gzip
import hashlib
import json
import subprocess
from pathlib import Path

import yaml

W = Path(__file__).parent
RUN = Path('/private/tmp/npmech-gentamicin-review-c2YN3q')
ARCHIVE = Path('reviews/evidence/20261013-gentamicin')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
artifacts, refs = {}, {}
(ARCHIVE / 'artifacts').mkdir(parents=True, exist_ok=True)
previous = json.loads((ARCHIVE/'manifest.json').read_text()) if (ARCHIVE/'manifest.json').exists() else {'artifacts': []}

def add(original, raw):
    original = str(original)
    if original in artifacts:
        assert artifacts[original]['sha256'] == sha(raw)
        return
    stored = gzip.compress(raw, mtime=0)
    basename = Path(original).name.replace(':', '-')
    path = 'artifacts/' + sha(original.encode())[:16] + '-' + basename + '.gz'
    (ARCHIVE / path).write_bytes(stored)
    artifacts[original] = dict(original_path=original, path=path, sha256=sha(raw), bytes=len(raw),
                               stored_sha256=sha(stored), stored_bytes=len(stored))

for p in sorted(RUN.iterdir()):
    if not p.is_file() or p.name.startswith(('bry', 'BGC0000174', 'BGC0000205', 'capture-bry', 'prepare_bry')):
        continue
    if p.name.startswith('primary2004') and not p.name.endswith('.receipt.json'):
        refs[str(p)] = dict(original_path=str(p), sha256=sha(p.read_bytes()), bytes=p.stat().st_size,
            source_url='https://www.jstage.jst.go.jp/article/antibiotics1968/57/7/57_7_436/_pdf/-char/en',
            reason='Inspected primary article and derivatives retained locally; citation and hashes only, no redistribution permission assumed.')
        continue
    if p.name.startswith('wikidata') and not p.name.endswith('.receipt.json'):
        refs[str(p)] = dict(original_path=str(p), sha256=sha(p.read_bytes()), bytes=p.stat().st_size,
            source_url=json.loads(p.with_name(p.name+'.receipt.json').read_text())['url'], reason='Denied response, not scientific evidence.')
        continue
    if p.suffix == '.log' and not p.with_suffix('.receipt.json').exists():
        continue
    if p.name in ('publish-qc.log','publish-qc.receipt.json') and not (RUN/'publish-qc.receipt.json').exists():
        continue
    add(p, p.read_bytes())
for p in sorted(W.iterdir()):
    if p.is_file() and p.name != 'review-campaign-checkpoint-final.json':
        add(p, p.read_bytes())
prior = Path('/private/tmp/npmech-capsular-publish-7cKqTV/review-campaign-checkpoint-final.json')
add(prior, prior.read_bytes())
reviews = []
for label in ('initials','successors'):
    for row in json.loads((W / (label+'.json')).read_text()):
        d = yaml.safe_load(Path(row['yaml']).read_text())
        add(row['yaml'], Path(row['yaml']).read_bytes())
        for i in d['source']['inputs']:
            if d['source']['state'] == 'git_commit':
                original = d['source']['git_revision'] + ':' + i['path']
                raw = subprocess.check_output(['git','show',original])
            else:
                original, raw = i['path'], Path(i['path']).read_bytes()
            assert sha(raw) == i['sha256'], i['path']
            add(original, raw)
        snapshots = []
        for e in d['evidence']:
            if 'snapshot_sha256' not in e:
                continue
            matches = [a for a in list(artifacts.values())+list(refs.values()) if a['sha256'] == e['snapshot_sha256']]
            assert matches, (row['yaml'],e['evidence_id'])
            snapshots.append(dict(evidence_id=e['evidence_id'], sha256=e['snapshot_sha256'], original_path=matches[0]['original_path']))
        reviews.append(dict(path=row['yaml'], sha256=sha(Path(row['yaml']).read_bytes()), markdown=row['markdown'],
            markdown_sha256=sha(Path(row['markdown']).read_bytes()), evidence_snapshots=snapshots))
manifest = dict(format_version=1, artifacts=list(artifacts.values()), reference_only_sources=list(refs.values()), reviews=reviews,
    checkpoint=str(W/'checkpoint.json'), note='Hash-addressed captures and validation receipts, not new scientific assertions. Primary text and access denials are reference-only. Exact old/current inputs retained separately; local runtime binaries are not redistributed.')
if (RUN/'publish-qc.receipt.json').exists():
    manifest['final_qc'] = str(RUN/'publish-qc.receipt.json')
current_paths = {r['path'] for r in artifacts.values()}
for old in previous['artifacts']:
    if old['path'] in current_paths:
        continue
    path = ARCHIVE / old['path']
    assert path.resolve().is_relative_to((ARCHIVE/'artifacts').resolve())
    assert sha(path.read_bytes()) == old['stored_sha256']
    path.unlink()
(ARCHIVE/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(artifacts=len(artifacts), references=len(refs), reviews=len(reviews))))
