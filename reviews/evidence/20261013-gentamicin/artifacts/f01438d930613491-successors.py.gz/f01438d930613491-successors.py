import hashlib
import json
import shlex
import subprocess
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
RUN = Path('/private/tmp/npmech-gentamicin-review-c2YN3q')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
rows = []
for item in json.loads((W / 'initials.json').read_text()):
    old = yaml.safe_load(Path(item['yaml']).read_text())
    target = deepcopy(old['targets'][0])
    extra = ['curation/pubchem_bioassay_exclusions.tsv', 'src/naturalproductmech/curate/bioassay_exclusions.py',
             'tests/test_bioassay_exclusions.py', 'tests/test_gentamicin_curation.py']
    target['owner_paths'] += [dict(repository=old['repository'], path=p, role='Scoped assay remediation input or regression') for p in extra]
    targets = W / (item['slug'] + '-successor-targets.json')
    targets.write_text(json.dumps(dict(targets=[target]), indent=2))
    command = ['uv', 'run', 'python', 'scripts/record_review.py', 'inspect', '--targets', str(targets)]
    for path in sorted({i['path'] for i in old['source']['inputs']} | set(extra) | {item['yaml']}):
        command += ['--input', path]
    receipt = dict(command=command, started_at=now())
    run = subprocess.run(command, text=True, capture_output=True)
    inspected = W / (item['slug'] + '-successor-inspect.json')
    inspected.write_text(run.stdout)
    receipt.update(finished_at=now(), exit_code=run.returncode, log=str(inspected), log_sha256=sha(inspected), stderr=run.stderr)
    inspected.with_suffix('.receipt.json').write_text(json.dumps(receipt, indent=2))
    assert run.returncode == 0, run.stderr
    captured = json.loads(run.stdout)
    for entry in captured['source']['inputs']:
        assert sha(entry['path']) == entry['sha256']
    tid = target['target_id']
    evidence = deepcopy([e for e in old['evidence'] if e['evidence_id'] in
        ('chemistry', 'pubchem', 'pubchem-a3', 'np-atlas', 'sequences', 'dsmz', 'assay', 'primary2004', 'primary2015-abstract')])
    def ev(eid, kind, path, summary):
        evidence.append(dict(evidence_id=eid, kind=kind, reference=str(path), accessed_at=now(),
                             support='supports', summary=summary, snapshot_sha256=sha(path)))
    ev('current', 'record_content', target['path'], 'Complete current owner and diff inspected: deposited context and OPEN product qualification; BDTQ also withholds nonexact CID72396 and AID1195. No chemistry, grade or status promotion.')
    ev('prior', 'prior_review', item['yaml'], 'Immutable full-owner partial assessment; source limitations and original findings remain historical evidence.')
    ev('strains', 'record_content', 'curation/mibig_producer_strains.tsv', 'Two exact source-row-pinned deposited qualifiers; no experiment or product assertion inferred from a sequence feature.')
    ev('xrefs', 'record_content', 'curation/mibig_xref_exclusions.tsv', 'Only CID72396 is excluded from the BDTQ owner; exact NPAtlas equivalence retained.')
    ev('assay-decision', 'record_content', 'curation/pubchem_bioassay_exclusions.tsv', 'One complete historical row is withheld with protocol citation and independent CID mismatch rationale. The other 23 AID1195 rows and future importer policy are separate issue945.')
    ev('scope', 'validation', W / 'scope-audit.json', 'All3115owners,243components and48prior review pairs verified; only two owners changed within authorized fields.')
    checks = []
    for label in ('publish-focused', 'publish-strict', 'publish-scope'):
        r = json.loads((RUN / (label + '.receipt.json')).read_text())
        assert r['exit_code'] == 0 and sha(r['log']) == r['log_sha256']
        ev(label, 'validation', r['log'], f'Actual execution {r["started_at"]} to {r["finished_at"]}, exit0. Deterministic check, not scientific completion.')
        checks.append(dict(check_id=label, name=label, status='passed', required=True, command=shlex.join(r['command']),
            exit_code=0, target_ids=[tid], evidence_ids=[label], summary=evidence[-1]['summary']))
    checks.append(dict(check_id='primary-remaining', name='Exact-product primary-source closure', status='unavailable', required=True,
        target_ids=[tid], summary='All predecessor access limitations persist. No new retrieval or exact-congener adjudication in this scoped disposition.'))
    findings = deepcopy(old['findings'])
    for f in findings:
        f['previous_occurrences'] = [dict(repository=old['repository'], review_id=old['review_id'], finding_id=f['finding_id'])]
        f['evidence_ids'] = ['current', 'prior', 'scope', 'publish-focused']
        if f['finding_id'] == 'F1':
            f['status'] = 'open'
            f['evidence_ids'] += ['chemistry', 'pubchem', 'primary2004']
            f['disposition_reason'] = 'Cited OPEN discussion mitigates the ambiguity. Exact product/congener and stereochemical assignment remain unresolved under issue941; no structure migration, merge or REVIEWED promotion.'
        else:
            f['status'] = 'resolved'
            if f['issue_key'].endswith('deposited-strain-context'):
                f['evidence_ids'] += ['sequences', 'strains', 'dsmz']
                f['disposition_reason'] = 'Deposited literal strain is preserved through complete-row-pinned qualification and guarded seeding. Original species and database tier remain unchanged. Resolves only missing context (issue944).'
            elif 'pubchem72396' in f['issue_key']:
                f['evidence_ids'] += ['pubchem', 'np-atlas', 'xrefs']
                f['disposition_reason'] = 'Nonexact CID72396 withheld through pinned MIBiG xref exclusion; exact NPAtlas xref and owner chemistry unchanged. No replacement CID inferred (issue942).'
            else:
                f['evidence_ids'] += ['assay', 'assay-decision', 'pubchem']
                f['owner_paths'] += [dict(repository=old['repository'], path=p, role='Implemented scoped historical assay-row exclusion') for p in extra[:2]]
                f['disposition_reason'] = 'Exact historical BDTQ/CID72396/AID1195 row withheld before observations and summaries; raw provenance retained in table-owned discussion. Regression tests reject drift and ambiguity and preserve other rows. Resolves this owner claim (issue943), not the broader importer/cohort issue945.'
    finished = now()
    rid = finished[:19].replace('-', '').replace(':', '') + 'Z-' + item['slug'] + '-scoped-disposition'
    review = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=old['repository'],
        title=item['slug'] + ': scoped source-defect disposition', started_at=receipt['started_at'], finished_at=finished,
        reviewer=dict(identity='Codex', kind='agent', independence='self_review', independence_basis='Implementing assistant performing a separate adversarial pass; not independent human approval.'),
        skill=old['skill'], completion='partial', verdict='needs_curation', scientific_review=True,
        summary='Confirmed source defects resolved within exact scope; product-identity assignment remains open.', source=captured['source'], targets=captured['targets'],
        scope=dict(description='One exact owner; scoped finding disposition, not another full-owner assessment.', selection='User-authorized issue remediation and PR publication.', coverage='partial', population_size=1, reviewed_target_ids=[tid]),
        checks=checks, evidence=evidence, findings=findings,
        assessments=[dict(assessment_id='fixed', area='provenance', topic='Scoped maintained-input corrections', outcome='supported', target_ids=[tid],
            evidence_ids=['current','strains','xrefs','assay-decision','scope','publish-focused'], summary='Guarded regeneration preserves exact identities, original assertions and grades while correcting reviewed context and nonexact source claims.'),
            dict(assessment_id='identity-open', area='identity', topic='Unresolved exact-product assignment', outcome='concern', target_ids=[tid],
                evidence_ids=['current','prior','chemistry','primary2004'], summary='OPEN qualification is not identity adjudication. Native SEEDED and all original source-access limits remain.')],
        actions=[deepcopy(old['actions'][0])],
        limitations=['Scoped disposition only; no additional owner coverage or native REVIEWED promotion.',
            'No new primary retrieval. All predecessor source-access limitations remain; no access bypass.',
            'Current working-tree input hashes are attestations, not a claim these bytes existed at the base commit.',
            'Only recorded focused/strict/scope checks are asserted here. Final full QC, review contract checks and CI follow before merge.',
            'Initial draft serialization/search-scope/check-status errors and two test-fixture failures were corrected before this observation; failed test receipts are retained.'],
        related_reviews=[dict(repository=old['repository'], review_id=old['review_id'], relationship='Exact predecessor; scoped findings disposition.')])
    out = W / (item['slug'] + '-successor.yaml')
    out.write_text(yaml.safe_dump(json.loads(json.dumps(review)), sort_keys=False, allow_unicode=False))
    subprocess.run(['uv','run','python','scripts/record_review.py','validate',str(out)], check=True)
    subprocess.run(['uv','run','python','scripts/record_review.py','save','--content',str(out)], check=True)
    rows.append(dict(slug=item['slug'], review_id=rid, yaml=f'reviews/structured/{rid}/review.yaml', markdown=f'reviews/structured/{rid}/review.md'))
(W / 'successors.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
