import copy
import hashlib
import json
import shlex
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
REPO = 'CultureBotAI/NaturalProductMech'
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
capture = json.loads((W/'capture.json').read_text())
facts = json.loads((W/'inspection.json').read_text())
base = capture['base']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == base


def owner(path, role):
    return dict(repository=REPO,path=path,role=role)


def evidence(eid, kind, reference, summary, locator, path=None, support='supports'):
    d = dict(evidence_id=eid,kind=kind,reference=reference,locator=locator,accessed_at=now(),support=support,summary=summary)
    if path:
        d['snapshot_sha256'] = sha(path)
    if kind == 'search':
        d['search_scope'] = 'Entire repository, including ignored and hidden files, except .git metadata; terms gentamicin, HFLKNINDVFJPQT, BDTQHFBWYNCGHN, BGC0000696 and BGC0001603. Compressed content is not claimed text-exhaustive.'
    return d


def fetched(eid, name, kind, summary, locator, support='supports'):
    r = json.loads((W/(name+'.receipt.json')).read_text())
    return evidence(eid,kind,r['url'],summary,
        f"{locator}; original retrieval {r['started_at']}..{r['finished_at']}, HTTP {r['status']}; payload {W/name}; receipt SHA256 {sha(W/(name+'.receipt.json'))}. accessed_at records local reinspection.", W/name,support)


def command_check(label, tid, summary, required=True, status=None):
    r = json.loads((W/(label+'.receipt.json')).read_text())
    assert sha(r['log']) == r['log_sha256']
    return dict(check_id=label,name=label,status=status or ('passed' if r['exit_code']==0 else 'failed'),required=required,command=shlex.join(r['command']),exit_code=r['exit_code'],expected_exit_code=0,target_ids=[tid],summary=summary,scope_note=f"Actual run {r['started_at']}..{r['finished_at']}; log {r['log']}; SHA256 {r['log_sha256']}")


common_evidence = [
    evidence('rules','record_content','docs/HARMONIZATION.md','One owner denotes one chemical structure, not a mixture or generic class. Computed filing, taxonomy, natural origin and BGC evidence are separate axes.','Unit of corpus, exact identity, producer/occurrence and filing sections','docs/HARMONIZATION.md'),
    evidence('ownership','record_content','docs/CURATION.md','Generated claims require maintained input changes. The strain and xref tables are implemented and complete-row pinned. decisions.tsv is unconsumed; existing structure replacement only supports an unoccupied exact ChEBI destination.','Implemented corrections and REVIEWED gate','docs/CURATION.md'),
    evidence('inventories','record_content','data/raw/mibig_compounds.tsv','Both exact source rows, classifier rows, all matching LOTUS/assay/sibling rows and absence of exact-key ChEBI grounding were inspected with structured TSV parsers. No exact-key AntibioticMech join is present; connectivity-only gentamicin X is not equivalent.','inspection.json source_rows per owner; source input hashes retained',W/'inspection.json'),
    evidence('chemistry','validation',str(W/'inspection.json'),'Pinned RDKit2026.03.5 roundtrips both SMILES to their recorded InChI and key. HFLKNINDVFJPQT has C19H38N4O10 and14 unassigned centers; BDTQHFBWYNCGHN has C18H36N4O10 and14 assigned centers. Both neutral. Internal agreement does not establish biological identity.','records chemistry; structures.png visually inspected',W/'inspection.json'),
    fetched('pubchem','pubchem.json','authority','CID72396 is VEGXETMJINRLTH-BOZYPMBZSA-N/C19H39N5O7, not the BDTQ owner. CID15574862 is HFLKNINDVFJPQT-ZFAMMYHGSA-N/C19H38N4O10; it shares connectivity, not stereochemical identity, with the HFLK owner.','Official properties for both CIDs'),
    fetched('pubchem-a3','pubchem-A3.json','authority','CID86490 has BDTQHFBWYNCGHN-UHFFFAOYSA-N: connectivity matches the BDTQ owner but stereo does not. It is a candidate for identity research, not an exact replacement xref.','CID86490 properties'),
    fetched('names','synonyms.json','authority','Registry synonyms name CID72396 gentamicin C1a, CID15574862 gentamicin X2 and CID86490 gentamicin A3. These are database names, not independent experimental structure determination.','CID-specific depositor synonyms'),
    fetched('taxonomy','taxonomy.xml','authority','NCBITaxon1873 resolves to genus Micromonospora and1877 to species Micromonospora echinospora; both are within Actinomycetota. This supports the taxonomic grouping, not the exact-product attribution.','TaxId, ScientificName, Rank and Lineage'),
    fetched('sequences','sequences.xml','authority','AJ628149.4 is deposited with strain DSM43036; KY971520.1 with ATCC15835 and culture_collection ATCC:15835. Both use taxon1877 and have unpublished/direct-submission references. The deposits establish sequence context, not the experimental identity of a product.','Source features and references of both exact accession versions'),
    fetched('primary2004','primary2004.pdf','primary_source','Unwin et al. study the gentamicin C complex in ATCC15835 using a gntB insertion and an immunoassay. The deposited sequence named in Methods is AY524043. Figure3 distinguishes A/A2/X2 intermediates from C congeners; it presents predicted enzyme assignments. This does not identify the BDTQ graph as their measured product.','DOI10.7164/antibiotics.57.436, all ten pages text inspected; Table1 p437, Figure2 p442 and Figure3 p443 visually inspected'),
    evidence('dsmz','authority','https://webshop.dsmz.de/en/bacteria/Micromonospora-echinospora-subsp-echinospora-oxid-2.html','DSMZ explicitly lists ATCC15835 among the equivalent collection numbers for DSM43036. Different collection labels therefore do not prove different strains. Different sequence deposits still need exact locus mapping.','DSM No. and Other collection no.; official web page inspected during this review; accessed_at is reinspection of returned source text'),
    evidence('np-atlas','database','https://www.npatlas.org/api/v1/compound/NPA009026?include=classifications','NPA009026 (resolving the shorter NPA09026 alias) exactly matches BDTQHFBWYNCGHN-CUYCKOLISA-N and its molecular formula. The origin is Micromonospora sp. and DOI10.1021/jm00340a034. Exact database agreement is retained; it does not validate the historical assignment to the complex.','Official export linked from compound page; inchikey/inchi/smiles/formula, origin and mol_structures; version2024_09. Returned API text reinspected; not redistributed.'),
    evidence('primary2015-abstract','primary_source','https://hero.epa.gov/reference/7214436/','The reproduced primary abstract identifies gentamicin X2 as a precursor of the C complex and reports native mutations plus enzyme reconstitution. Only that abstract was inspected; the paper, figures, supplements and exact experimental strain were not verified.','Huang et al., PMID25641167, DOI10.1016/j.chembiol.2014.12.012; primary abstract reproduced by EPA HERO. PubMed page displayed reCAPTCHA; no challenge bypass or full-paper retrieval.',support='partial'),
    fetched('imodulondb','imodulondb-datasets.json','database','Official inventory contains20 organism entries and no Micromonospora dataset. Native transcriptomic cross-check is not applicable; E.coli cloning-host data are not evidence for this producer. Adapter failed on missing dotenv, so the official dataset API was inspected.','Complete /api/datasets response'),
    evidence('local-search','search',str(W/'local-search.log'),'Ignored/hidden-inclusive repository search found the two owners, source rows and derived/historical coverage references. Both complete resolved records have no inline or referenced graphs. No prior canonical review targets these two owner IDs in the validated48-observation checkpoint.','Full recorded command and log; .git metadata excluded, ignored source files included; compressed files not claimed to be text-exhaustive',W/'local-search.log'),
    evidence('baseline','validation',str(W/'capture.json'),'The prior checkpoint was revalidated against all3115owner files,243components and48immutable YAML/Markdown pairs before this assessment. Same-label candidate selection does not prejudge equivalence.','prepare.py assertions, base commit and exact-target inspections',W/'capture.json'),
    fetched('assay','assay1195-cid72396.json','database','AID1195 assigns Active to every substance with a reported maximum recommended daily dose. The CID72396 query returns SID48416051 and dose metadata, not a pure-BDTQ-compound assay. This administrative outcome is not positive biological activity.','PC_AssaySubmit.assay.descr.protocol/results and data[0]; original dose units retained in source, not converted to MIC'),
    evidence('assay-owner','record_content','scripts/extract_pubchem_bioassay.py','cid_to_key trusts owner xrefs and associates a CID with an owner key without chemical revalidation. rows_from_summary admits a named positive call without protocol-level meaning. The seeder then emits ACTIVE from the stored outcome.','cid_to_key; rows_from_summary; scripts/seed_from_sources.py bioactivities loop','scripts/extract_pubchem_bioassay.py'),
]


def assess(aid, area, topic, outcome, summary, tid, refs):
    return dict(assessment_id=aid,area=area,topic=topic,outcome=outcome,summary=summary,target_ids=[tid],evidence_ids=refs)


saved = []
for slug in ('gentamicin-2','gentamicin'):
    inspect = json.loads((W/f'{slug}-inspect.json').read_text())
    target = inspect['targets'][0]
    tid = target['target_id']
    d = json.loads((W/f'{slug}-resolved.json').read_text())
    is_x = slug == 'gentamicin-2'
    bgc, version = ('BGC0001603',3) if is_x else ('BGC0000696',5)
    source = copy.deepcopy(inspect['source'])
    for i in source['inputs']:
        assert sha(i['path']) == i['sha256']
        assert hashlib.sha256(subprocess.check_output(['git','show',f"{base}:{i['path']}"])).hexdigest() == i['sha256']
    source['state'] = 'git_commit'
    ev = copy.deepcopy(common_evidence)
    ev += [evidence('owner','record_content',target['path'],'The entire owner, every nested claim, history and complete resolved view were read. Target selection is by exact path and identifier; the sibling is context only.','Complete raw YAML and read_natural_product result',target['path']),
        fetched('mibig',f'{bgc}.{version}.json','database',f'{bgc} version{version} is active and matches the imported chemical graph, taxon, saccharide class and genome accession. Locus evidence methods are empty; SOURCE_ASSERTION and CLUSTER_UNSTATED accurately preserve that database tier. Quality/reviewer placeholders are not truth signals.','Full exact version JSON, including all compound evidence and legacy references')]
    checks = [command_check(slug+'-inspect',tid,'Canonical input inspection before assessment.'),
        command_check('strict',tid,'Both exact owners and any referenced components validated with zero errors.'),
        command_check('resolved',tid,'Full native read succeeded; neither owner has a graph component.'),
        command_check('chemistry',tid,'Pinned RDKit roundtrips and source table/sequence/taxonomy inspection succeeded.'),
        command_check('labels',tid,'Full-corpus label gate exited0:13434canonical,646synonym,35exception;499nonblocking mismatches and4649skipped adapters. Not a full scientific identity pass.'),
        command_check('local-search',tid,'Ignored-inclusive source/reference search completed.',False),
        command_check('queue',tid,'Full queue computed to temporary output:8930diagnostic rows covering3115owners. No status or committed queue change.',False),
        command_check('sources',tid,'Initial chemistry helper unavailable in the project environment (RDKit missing); recovered with pinned isolated runtime and separate native resolved read.',False),
        command_check('sources-pinned',tid,'First isolated-runtime attempt lacked project import path; no scientific conclusion taken from failure.',False),
        command_check('sources-pinned-resolved',tid,'Cross-environment native import failed on sysconfig; separated native and chemistry phases, both then succeeded.',False),
        command_check('imodulondb',tid,'Adapter execution failed: missing dotenv. Official dataset API fallback inspected and no applicable native producer found.',False,'failed')]
    if (W/'qc.receipt.json').exists():
        checks.append(command_check('qc',tid,'Fresh full native QC, including corpus shape, history/reference tests, inventory provenance and reproduction. Read the complete receipt/log; deterministic gates are not scientific sign-off.'))
    else:
        raise RuntimeError('Wait for live QC6827; do not save an invented result.')
    checks.append(dict(check_id='required-literature',name='Exact compound and strain evidence',status='unavailable',required=True,target_ids=[tid],summary='Full source closure remains incomplete. PubMed25641167 and19362651 challenged; 1963 ACS paper denied403;1975A3 paper tool-inaccessible. No alternate full-paper retrieval. Wikidata organism IDs were denied403. These limits preclude completed status.'))
    assessments = [
        assess('identity','identity','Individual compound versus complex/congener','concern',
            'The generic gentamicin label hides an X2-connectivity record with all14tetrahedral centers unspecified. It is not the gentamicin C mixture. The cited2015abstract is X2-specific, but exact experimental assignment to this stereo-unspecified owner remains partial. Do not merge it with the BDTQ owner or install CID15574862 as exact identity.' if is_x else
            'The generic label is attached to a fully specified BDTQ graph. NPAtlas agrees, but inspected registry data point to gentamicin-A3 connectivity while the cited2004study assays the C complex. The1963origin report and1975A3 structural paper remain unread. Exact natural-product assignment is unresolved, not proved false solely from inaccessible text.',tid,['owner','chemistry','mibig','np-atlas','names','pubchem-a3','primary2004','primary2015-abstract']),
        assess('structure','consistency','Encoded chemistry and stereochemical resolution','supported',
            'SMILES, InChI and InChIKey are internally consistent. stereo_complete:false correctly exposes14unassigned centers; no automatic completion is justified.' if is_x else
            'SMILES, InChI and InChIKey are internally consistent with14assigned centers and stereo_complete:true. That flag describes the graph, not independent verification of its experimental stereochemistry.',tid,['owner','chemistry']),
        assess('grounding','grounding','ChEBI, exact xrefs and sibling boundaries','concern' if not is_x else 'supported',
            'Pinned ChEBI inventory has no exact-key match; minted identity is faithful to source resolution. No xrefs, parent, congener or related_records are asserted. A stereo-resolved X2 registry or sibling record cannot be adopted as an exact match to this key.' if is_x else
            'No exact-key ChEBI match; minted resolution is faithful. NPA09026 resolves to NPA009026 and matches exactly, so it should not be discarded. PubChem72396 is nonexact (F2). CID86490 is only a connectivity lead, not a validated replacement. No exact sibling link is present.',tid,['owner','inventories','np-atlas','pubchem','pubchem-a3']),
        assess('facets','representation','Filing, chemistry, taxonomy and origin axes','supported','CARBOHYDRATES, Polyols and glycoside=true reproduce the pinned NPClassifier version; SACCHARIDE is a separate MIBiG biosynthetic class. ACTINOBACTERIAL follows Micromonospora taxonomy. These axes neither identify a congener nor independently prove natural origin.',tid,['owner','inventories','mibig','taxonomy','rules']),
        assess('origin','scope','Natural origin and producer evidence','concern','A natural gentamicin-family origin is consistent with the sources, but exact compound assignment is limited as detailed in F1. SOURCE_ASSERTION is not inflated to direct experimental proof. Deposited strain context is missing (F2).' if is_x else 'The natural gentamicin-family origin is plausible and occurrence is not promoted to production. SOURCE_ASSERTION remains honest database attribution; native knockout results for the complex do not by themselves justify an exact-BDTQ grade upgrade. Deposited strain context is missing (F4).',tid,['owner','primary2004','primary2015-abstract','mibig','sequences']),
        assess('cluster','provenance','Exact active BGC and sequence versions','supported',f'{bgc}v{version} is active, names gentamicin, and supplies the exact imported structure and locus. Zero/unstated source bounds remain unstated. CLUSTER_UNSTATED matches empty methods. DSM43036 andATCC15835 are equivalent collection designations, not a strain conflict; AY524043/AJ628149/KY971520 are distinct deposits and are not asserted to be experimentally interchangeable.',tid,['mibig','sequences','dsmz','primary2004']),
        assess('occurrences','evidence','Claim-level occurrence citations','not_applicable' if is_x else 'concern','No occurrence object is asserted; no absence of literature evidence is inferred.' if is_x else 'Both LOTUS rows and taxon IDs reproduce. The1963DOI is a complex-discovery report whose text is inaccessible; the2004DOI is the same publication as producer PMID15376556, not independent corroboration. That paper does not resolve the exact BDTQ compound. Current Wikidata mappings remain unverified after403.',tid,['owner','inventories','primary2004','taxonomy']),
        assess('activity','evidence','Pure-compound bioactivity and summaries','not_applicable' if is_x else 'concern','No activity, summary or molecular target is asserted.' if is_x else 'The sole ACTIVE call is AID1195 dose-database metadata for CID72396, whose structure is not this owner. Even with a repaired CID mapping, this protocol is not an activity assay (F3). No potency, units, target, activity class or summary is invented by the current YAML, which limits but does not remove the misleading assertion.',tid,['owner','assay','assay-owner','pubchem']),
        assess('mechanism','graph','Complete mechanism and protein examples','not_applicable','No inline graph, graph ref, pathway step or protein example is present in the full resolved owner. Native absence of optional graphs is not a finding, and not a claim that literature lacks mechanisms. No homolog, cloning host or expression module is treated as native mechanistic proof.',tid,['owner','local-search','imodulondb']),
        assess('optional','completeness','Clinical assertions, datasets and other optional fields','not_applicable','No clinical-status object, dataset, parent-compound or congener relationship is asserted. Optional omissions alone are not defects. The clinical-dose deposit is not a licence to add a regulatory approval claim.',tid,['owner']),
        assess('history','provenance','Status, audit trail and maintained ownership','supported','SEEDED is retained. Seed events describe generated inputs; no saved review promotes status. Corrections belong in implemented input tables or reviewed extractor/seeder behavior, never direct edits of the generated owner or page.',tid,['owner','ownership','baseline']),
    ]
    assessments[3]['dimensions'] = [dict(name='taxonomy',value='NCBITaxon1877 species Micromonospora echinospora',definition='Producer taxonomic resolution, independent of chemical origin',evidence_ids=['taxonomy']),dict(name='stereochemical_resolution',value='14unassigned centers' if is_x else '14assigned centers',definition='Encoded tetrahedral centers calculated with pinned RDKit, not experimental proof',evidence_ids=['chemistry']),dict(name='evidence_tier',value='SOURCE_ASSERTION / CLUSTER_UNSTATED',definition='Separate native producer and locus grades',evidence_ids=['owner','mibig'])]
    findings, actions = [], []

    def add(fid,key,category,severity,title,description,fields,refs,paths,action,acceptance,certainty='confirmed'):
        own = [owner(p,role) for p,role in paths]
        findings.append(dict(finding_id=fid,issue_key=key,category=category,severity=severity,status='open',certainty=certainty,title=title,description=description,target_ids=[tid],field_paths=fields,evidence_ids=refs,rule_id='NaturalProductRecord checklist: '+category,native_severity=severity,normalization_reason={'blocker':'Unresolved product identity prevents sign-off that this owner denotes the named natural product.','major':'A materially ambiguous or unsupported identity/evidence claim requires correction before scientific sign-off.','minor':'Bounded provenance loss; repairing it does not resolve the independent exact-product question.'}[severity],owner_paths=own))
        actions.append(dict(action_id='A'+fid[1:],description=action,finding_ids=[fid],target_ids=[tid],owner_paths=own,acceptance_checks=acceptance,generator='Authorized curation only: maintained input change, canary seeding and guarded writer with history; then just verify-reproduction, just render and just qc. No changes made by this review.'))

    add('F1',slug+'-exact-product-assignment','identity','major' if is_x else 'blocker',
        'Generic gentamicin name obscures the X2 precursor and unresolved stereochemical scope' if is_x else 'Generic gentamicin grouping does not establish this exact A3-like structure',
        'HFLK connectivity matches the X2 candidate, not the clinically used C complex. Both the2015cited abstract and2004Figure3 distinguish that precursor. No specific congener label or qualification is present. Exact stereochemical and experimental strain attribution remain incomplete; this is not a demand to invent stereo or evidence grades.' if is_x else
        'The fully specified BDTQ graph is treated as gentamicin by MIBiG/NPAtlas and used to collect complex-level occurrence/producer assertions. The inspected2004paper measures C congeners and does not establish this graph; a separate registry associates its connectivity with A3. The1963and1975papers are uninspected. This is an unresolved exact-product boundary, not proof that A3 cannot be produced by this strain.',
        ['label','chemical_structure','producer_organisms','biosynthetic_gene_clusters']+([] if is_x else ['occurrences']),
        ['owner','mibig','primary2004','primary2015-abstract','chemistry','pubchem','pubchem-a3','names','np-atlas'],
        [('scripts/extract_mibig.py','Source-specific compound naming and structure extraction'),('scripts/seed_from_sources.py','Exact-key grouping and generated identity'),('data/raw/mibig_compounds.tsv','Pinned source assertion; do not rewrite without reviewed provenance')],
        'Adjudicate the exact congener against primary structure evidence and source-version provenance. Preserve the raw generic label, then implement a tested maintained qualification or correction path for the reviewed product. Do not merge the two owners, transfer mixture claims, replace with a stereo-different CID, or use reserved decisions.tsv. A source correction requiring a non-ChEBI destination needs separately implemented ownership/migration logic.',
        ['Primary evidence resolves named congener and supported stereochemical resolution.','Every producer, occurrence, xref and assay is re-audited for the selected exact structure.','Future tests prove no silent same-name merge or transfer between BDTQ and HFLK; reproduction and native gates pass.'],
        certainty='confirmed' if is_x else 'provisional')
    if not is_x:
        add('F2','gentamicin-pubchem72396-nonexact','grounding','major','PubChem72396 names gentamicin C1a, not the owner structure',
            'Owner BDTQHFBWYNCGHN-CUYCKOLISA-N/C18H36N4O10 and current CID72396 VEGXETMJINRLTH-BOZYPMBZSA-N/C19H39N5O7 differ in connectivity and elemental composition. NPA009026 is exact and must be assessed separately. CID86490 has only connectivity equivalence, so it is not a supported replacement.',
            ['xrefs[pubchem:72396]'],['owner','pubchem','names','chemistry','np-atlas','pubchem-a3'],
            [('curation/mibig_xref_exclusions.tsv','Implemented full-row-pinned chemical xref exclusion'),('scripts/seed_from_sources.py','Rebuild xrefs without manual owner edits')],
            'Withhold the confirmed nonexact PubChem xref through a complete-row-pinned BGC0000696:1 exclusion with inspected citation. Preserve raw source and valid NPAtlas xref. Re-audit the previously imported CID-derived assay independently: xref exclusion alone does not remove the historical key-indexed row.',
            ['Exact BGC0000696:1 row digest and xref are pinned.','Only pubchem:72396 is withheld; NPA09026 and owner chemistry remain unchanged unless separately adjudicated.','Former CID-derived bioactivity is explicitly remediated under F3; reproduction/native gates pass.'])
        add('F3','gentamicin-aid1195-not-bioactivity','evidence','major','Recommended-dose metadata is represented as a positive bioactivity call',
            'AID1195 protocol says Active is assigned to all substances because dose data are reported. Its CID72396 row has recommended-dose metadata; it is not an assay on the BDTQ molecule. The importer trusts the nonexact owner CID and accepts its generic positive outcome. Current bare ACTIVE is therefore unsupported as biological activity even apart from the identity mismatch. No antibacterial summary or potency is asserted in this owner.',
            ['bioactivities[0]','bioactivities[0].call'],['owner','assay','assay-owner','pubchem','inventories'],
            [('scripts/extract_pubchem_bioassay.py','Compound identity and assay-semantics admission'),('data/raw/pubchem_bioassay.tsv','Historical imported row with CID72396/AID1195'),('scripts/seed_from_sources.py','Historical key-based emission requires an explicit maintained correction')],
            'Implement a reviewed identity-aware and protocol-aware exclusion/qualification path for this exact historical row. Do not hand-delete the generated object or invent a potency, clinical approval or general rule that every Other assay is invalid. Audit any broader AID1195 cohort separately before broad changes.',
            ['The BDTQ owner no longer claims an unqualified ACTIVE response from AID1195.','Source row/provenance and the exclusion rationale remain auditable; no unsupported replacement assay is introduced.','Regression tests cover nonexact CID joins, non-assay positive flags and unchanged genuinely experimental assays.'])
    fid = 'F2' if is_x else 'F4'
    strain = 'ATCC 15835' if is_x else 'DSM 43036'
    acc = 'KY971520.1' if is_x else 'AJ628149.4'
    add(fid,slug+'-deposited-strain-context','provenance','minor','Producer omits the deposited strain qualification',
        f'{acc} source feature supplies {strain}, whereas the record gives only species1877. DSMZ lists DSM43036 andATCC15835 as equivalent collection numbers; this is lost context, not evidence of mismatched strains. A strain qualification alone does not prove this exact metabolite is produced.',
        ['producer_organisms[0].strain'],['owner','sequences','dsmz','taxonomy','ownership'],
        [('curation/mibig_producer_strains.tsv','Implemented complete-row-pinned producer-strain qualifications')],
        f'Add a reviewed {bgc}:1 qualification for {strain} citing {acc} and exact source-row hash. Preserve taxon, database assertion, grades, chemical identity and BGC fields. Mention collection equivalence only with the inspected DSMZ source.',
        ['Source-row pin and deposited spelling are exact.','Only strain and separate curator qualification evidence change; no grade or scientific-status promotion.','Canary and full reproduction/native gates pass.'])
    finish = now()
    review_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+slug
    review = dict(schema_version='1.0.0',review_id=review_id,kind='record',repository=REPO,title=f'Gentamicin exact-owner review: {slug}',started_at=capture['started_at'],finished_at=finish,
        reviewer=dict(identity='Codex',kind='agent',independence='self_review',independence_basis='Same assistant performing the ongoing campaign, not independent human sign-off.'),
        skill='.claude/skills/review-yaml-record/SKILL.md',completion='partial',verdict='needs_curation',native_verdict='SEEDED retained; exact-product REVIEWED gate not met',scientific_review=True,
        summary='One major identity-scope finding and one minor missing strain qualification; structure encoding and database grading are internally consistent.' if is_x else 'One provisional identity blocker, two confirmed major defects (nonexact PubChem xref and non-assay ACTIVE call), and one minor missing strain qualification. NPAtlas equivalence is supported.',
        source=source,scope=dict(description='One exact native owner, all nested assertions and history, and complete resolved mechanism.',selection='Next pending exact owner in full3115-record campaign; same-label sibling is separately reviewed. No sampling or scope reduction.',coverage='partial',population_size=1,reviewed_target_ids=[tid],exclusions=[dict(target='Other3114owners and their components',reason='Outside this one-owner observation, not excluded from the full campaign; unassessed and partial work remain pending.')]),
        targets=[target],checks=checks,evidence=ev,assessments=assessments,findings=findings,actions=actions,
        limitations=['Full exact-product evidence remains incomplete; inaccessible1963and1975papers cannot be treated as refutation.2015primary abstract only; no full experimental or stereochemical adjudication.',
            'PMID19362651 is a source-level additional reference whose content was not inspected after a PubMed challenge; no mechanistic claims are inferred from it.',
            'Wikidata Q3061522 andQ6839685 returned403. Independent NCBI taxon verification does not recover those mappings.',
            'Web-only source text was reinspected while authoring; accessed_at for those entries records that local reinspection, not an invented exact original request timestamp. HTTP payload receipts retain actual timestamps.',
            'The label gate has499warnings and4649adapter skips across the corpus; it is not a chemical-identity or primary-evidence certificate.',
            'Only new review artifacts are written. No record, component, inventory, page, history or native status was modified; no GitHub mutation was performed.'],
        notes=['Source hashes match both the reviewed working tree and base commit; this observation explicitly assesses that immutable revision.',
            'Same-label structures are not duplicates: retain their distinct keys pending exact product adjudication.',
            'The record contains no clinical or molecular-target claim; the broader gentamicin literature does not authorize importing those mechanisms here.'],tags=['gentamicin','exact-identity','record-review-campaign'])
    p = W/f'{slug}-review.yaml'
    p.write_text(yaml.safe_dump(json.loads(json.dumps(review)),sort_keys=False,allow_unicode=False,width=88))
    saved.append(dict(review_id=review_id,path=str(p),target_id=tid))
(W/'drafts.json').write_text(json.dumps(saved,indent=2))
print(json.dumps(saved,indent=2))
