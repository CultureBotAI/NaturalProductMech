import hashlib
import json
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
RUN = Path('/private/tmp/npmech-gentamicin-review-c2YN3q')
prior = Path('/private/tmp/npmech-capsular-publish-7cKqTV/review-campaign-checkpoint-final.json')
old = json.loads(prior.read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
observations, reviews = deepcopy(old['all_review_observations']), deepcopy(old['reviews'])
heads = {f['issue_key']: f for f in old['latest_finding_heads']}
newpaths = set()
for label in ('initials', 'successors'):
    for item in json.loads((W / (label + '.json')).read_text()):
        d = yaml.safe_load(Path(item['yaml']).read_text())
        t = d['targets'][0]
        row = dict(review_id=d['review_id'], yaml=item['yaml'], yaml_sha256=sha(item['yaml']),
            markdown=item['markdown'], markdown_sha256=sha(item['markdown']), target_id=t['target_id'], path=t['path'],
            verdict=d['verdict'], completion=d['completion'], scientific_review=d['scientific_review'], findings=d['findings'], finished_at=d['finished_at'])
        observations.append(row)
        if label == 'initials':
            reviews.append(row)
            newpaths.add(t['path'])
        for f in d['findings']:
            heads[f['issue_key']] = dict(f, review_id=d['review_id'], finished_at=d['finished_at'])
records = deepcopy(old['records'])
for r in records:
    if r['path'] in newpaths:
        r.update(sha256=sha(r['path']), bytes=Path(r['path']).stat().st_size, review_state='partial')
    else:
        assert sha(r['path']) == r['sha256']
    for c in r['graph_components']:
        assert sha(c['path']) == c['sha256']
for r in observations:
    assert sha(r['yaml']) == r['yaml_sha256'] and sha(r['markdown']) == r['markdown_sha256']
pending = [p for p in old['pending_in_priority_order'] if p not in newpaths]
stops = deepcopy(old['access_stops_no_alternate_retrieval'])
newstops = []
for name in ('wikidata-Q3061522.json', 'wikidata-Q6839685.json'):
    p = RUN / (name + '.receipt.json')
    newstops.append(dict(path=str(p), sha256=sha(p), receipt=json.loads(p.read_text())))
for url, result in [
    ('https://pubmed.ncbi.nlm.nih.gov/25641167/', 'CAPTCHA; EPA HERO independently reproduced primary abstract inspected, not full paper'),
    ('https://pubmed.ncbi.nlm.nih.gov/19362651/', 'CAPTCHA; additional source-level reference not inspected'),
    ('https://pubs.acs.org/doi/10.1021/jm00340a034', 'HTTP403; 1963 discovery paper not inspected'),
    ('https://doi.org/10.1021/jo00907a028', 'Tool-inaccessible; 1975 A3 primary paper not inspected'),
    ('https://pubmed.ncbi.nlm.nih.gov/15556005/', 'CAPTCHA; unfinished bryostatin lead, no canonical assessment'),
    ('https://pubs.acs.org/doi/10.1021/np060361d', 'HTTP403; unfinished bryostatin lead, no canonical assessment'),
]:
    newstops.append(dict(url=url, result=result, recorded_at=now, timestamp_note='Prior in-turn web observation retained from handoff; exact request timestamp unavailable.'))
stops.extend(newstops)
counts = dict(Counter(f['severity'] for f in heads.values() if f['status'] in ('open', 'deferred')))
assert len(observations) == 52 and len(reviews) == 32 and len(pending) == 3083
assert counts == {'blocker': 13, 'major': 8, 'minor': 1}
out = dict(checkpoint_format=2, base=old['base'], branch='review/gentamicin-records-20261013', recorded_at=now,
    objective=old['objective'], goal_status='active', population=3115, graph_components=243,
    records=records, reviews=reviews, all_review_observations=observations, partial_reviews=31,
    scientific_review_bundles=52, completed_scientific_reviews=1, unassessed_records=3083,
    count_note='52 observations cover32owners: one historical completed full assessment,31partial owners,3083unassessed. Two scoped dispositions add no owner coverage; native statuses remain SEEDED.',
    pending_in_priority_order=pending, partial_followups=old['partial_followups'] + sorted(newpaths), priority_method=old['priority_method'],
    findings=counts, latest_finding_heads=list(heads.values()), prior_checkpoint=str(prior), prior_checkpoint_sha256=sha(prior),
    access_stops_no_alternate_retrieval=stops, new_access_stops=newstops,
    access_stop_note='Prior234mixed string/dict ledger entries preserved verbatim. Eight additional observations have actual receipt timestamps or explicitly unavailable request times. No denied full-text alternatives attempted.',
    publication=dict(requested=True, status='pending', pr=940, issues=[941,942,943,944,945],
        resolved_findings='Four scoped findings: nonexact xref, non-assay ACTIVE row, two deposited qualifiers. Issues942-944 to close on merge.',
        remaining='Issue941 exact identities and945 broader assay cohort/importer remain open.'),
    required_work_remaining='Continue all3083unassessed owners and31partial follow-ups; all243components remain in corpus scope.',
    scientific_input_delta=json.loads((W / 'scope-audit.json').read_text()),
    durable_mapping='reviews/evidence/20261013-gentamicin/manifest.json',
    unpublished_research_handoff=dict(saved_reviews=0, targets=['bryostatin-2','bryostatin'], directory=str(RUN),
        note='Only initial target/source captures; unassessed, not included in this PR or counted as owner coverage.'),
    live_sessions_note='Prepublication checkpoint does not attest final QC/CI or merge completion.')
(W / 'checkpoint.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(dict(observations=52, assessed=32, partial=31, unassessed=3083, findings=counts)))
