import json
from pathlib import Path

import yaml
from naturalproductmech.curate.curation_event import record_curation_event
from naturalproductmech.validation.write_validated import write_validated_natural_product

W = Path(__file__).parent
for item in json.loads((W / 'initials.json').read_text()):
    review = yaml.safe_load(Path(item['yaml']).read_text())
    target = review['targets'][0]
    path = Path(target['path'])
    doc = yaml.safe_load(path.read_text())
    assert doc['identifier'] == target['target_id']
    x2 = item['slug'] == 'gentamicin-2'
    assert doc['chemical_structure']['standard_inchi_key'] == (
        'HFLKNINDVFJPQT-UHFFFAOYSA-N' if x2 else 'BDTQHFBWYNCGHN-CUYCKOLISA-N')
    did = 'curator-gentamicin-exact-product-assignment'
    assert not any(d['discussion_id'] == did for d in doc.get('discussions', []))
    evidence = [dict(reference='https://github.com/CultureBotAI/NaturalProductMech/issues/941',
                     explanation='Open exact-product adjudication; this discussion mitigates, not resolves, the finding.'),
                dict(reference='DOI:10.7164/antibiotics.57.436', evidence_source='full_text',
                     explanation='Study measures the gentamicin C complex and distinguishes biosynthetic intermediates; not direct proof of this exact graph.')]
    if x2:
        rationale = ('HFLK connectivity agrees with an X2 precursor candidate, but this source graph leaves all 14 tetrahedral centers unspecified. '
                     'The generic gentamicin label does not distinguish it from the C complex. Preserve the source label and graph until primary congener and stereochemical adjudication; do not adopt a stereo-resolved CID as exact equivalence.')
        evidence += [dict(reference='PMID:25641167', evidence_source='abstract',
                          explanation='Only the primary abstract reproduced by EPA HERO was inspected; X2 is distinguished from the C complex. Full experimental and stereochemical scope remains unverified.'),
                     dict(reference='https://pubchem.ncbi.nlm.nih.gov/compound/15574862', evidence_source='database',
                          explanation='HFLKNINDVFJPQT-ZFAMMYHGSA-N is a stereo-resolved registry candidate, not this exact unspecified key.')]
    else:
        rationale = ('The BDTQ graph exactly matches NPAtlas NPA009026, but the generic gentamicin name and complex-level citations do not establish its exact natural-product assignment. '
                     'CID86490 is an A3-connectivity lead with different stereochemical resolution, not a replacement xref. The 1963 discovery and 1975 A3 structure papers remain uninspected after access failures. '
                     'Retain the original source assertions without promoting evidence grades or scientific status; do not merge with the HFLK owner or transfer C-complex claims.')
        evidence += [dict(reference='https://www.npatlas.org/api/v1/compound/NPA009026?include=classifications', evidence_source='database',
                          explanation='Inspected official API graph and key match exactly; the source origin citation is not independent structural proof.'),
                     dict(reference='https://pubchem.ncbi.nlm.nih.gov/compound/86490', evidence_source='database',
                          explanation='BDTQHFBWYNCGHN-UHFFFAOYSA-N is a connectivity-only A3 identity lead.')]
    history = doc.pop('curation_history')
    doc.setdefault('discussions', []).append(dict(discussion_id=did, kind='CURATION_TODO', status='OPEN',
        posed_by='codex', prompt='Which exact gentamicin congener and stereochemical resolution do these source claims establish?',
        rationale=rationale, evidence=evidence))
    doc['curation_history'] = history
    record_curation_event(doc, curator='codex', action='RECORD_CURATED', llm_assisted=True,
                          changes='Add cited OPEN exact-gentamicin-product qualification for #941; preserve chemistry, original source assertions, grades and SEEDED status.')
    write_validated_natural_product(doc, path)
    print(path)
