## Scope

Review the two exact gentamicin owners separately. Two partial full-owner assessments and two immutable scoped dispositions preserve their distinct structures and native SEEDED status. The full 3,115-owner campaign remains unfinished; the bryostatin investigation is not part of this PR.

## Review Findings

- Exact congener/product assignments remain unresolved; no structure replacement, merge, or stereochemical completion is justified.
- The BDTQ owner cross-references nonexact PubChem CID72396.
- Its sole ACTIVE call is AID1195 recommended-dose metadata, not biological activity on this structure.
- Both producers omit strain context supplied by their deposited sequence records.

## Corrections and Adversarial Disposition

- Withhold only nonexact CID72396 through the existing MIBiG xref decision table. Retain the exact NPAtlas xref.
- Add a narrowly scoped, complete-row-pinned historical BioAssay exclusion table and seeder consumer. Withhold only BDTQ/CID72396/AID1195, preserve raw provenance and generate an attributed table-owned discussion.
- Preserve DSM 43036 and ATCC 15835 deposited context through the existing strain table.
- Add cited OPEN exact-product discussions, without merging, renaming, replacing chemistry or promoting evidence/status.
- Preserve source/check captures, failed attempts, immutable finding lineage and whole-campaign accounting in `reviews/evidence/20261013-gentamicin/`.

Closes #942.
Closes #943.
Closes #944.
Closes #946 (portable archive filenames; original provenance locators and bytes preserved).
Closes #947 (dedicated non-release provenance tag preserves the exact scoped-review base across squash merge; fresh-clone regression).

Does not close #941 (pre-existing exact-product uncertainty) or #945 (remaining AID1195 cohort and importer checks). Mitigation is not scientific identity sign-off. The adversarial pass is by the implementing assistant, not independent human approval.

## Verification

- Baseline full QC: 790 passed, 3 skipped; 3,115 owners reproduce offline.
- Remediation-focused suite: 333 passed; exact owners pass strict schema validation.
- Archive integrity and lineage check passes; full lint passes.
- Whole-corpus scope audit: only two owners change; 3,113 other owners, 243 components, raw inventories, PATHS and 48 prior review pairs unchanged.
- Full current QC, shared review checks and protected CI must pass before merge; final results will be posted.

Coverage is 52 observations across 32 owners (31 partial, one historical completed assessment), leaving 3,083 unassessed owners. This is not completion of the corpus-wide review goal.
