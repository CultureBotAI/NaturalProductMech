## Confirmed Review Finding

The BDTQ gentamicin owner's only `bioactivities` object is an ACTIVE call from PubChem AID1195, CID72396. This CID is not the owner structure. Independently, the inspected AID1195 protocol assigns Active to every substance because a recommended daily dose is present. It does not establish biological activity on the pure owner compound.

Source: https://pubchem.ncbi.nlm.nih.gov/rest/pug/assay/aid/1195/description/JSON

Severity: major. `scripts/extract_pubchem_bioassay.py` trusts imported xrefs and accepts the positive summary flag. The seeder retains the historical keyed row even after the xref is withheld.

## Scoped Acceptance

- Withhold this exact historical row through a complete-row-pinned, attributed curation input, not a manual YAML deletion.
- Preserve the raw row and expose the exclusion reason and citation in the generated owner.
- Fail closed on source drift, ambiguity, duplicate decisions and unapplied exclusions.
- Test that different CIDs, structures, AIDs and genuinely experimental rows are unchanged; no broad exclusion of the `Other` assay type.
- Verify strict validation, offline reproduction and full QC.

A broader audit of AID1195 rows and future importer identity/protocol checks is separate work; do not silently broaden this two-owner remediation.
