## Confirmed Review Findings

The source features of AJ628149.4 and KY971520.1 identify DSM 43036 and ATCC 15835 respectively, while the corresponding BGC0000696:1 and BGC0001603:1 owners omit `producer_organisms[].strain`.

- https://www.ncbi.nlm.nih.gov/nuccore/AJ628149.4
- https://www.ncbi.nlm.nih.gov/nuccore/KY971520.1

DSMZ lists these as equivalent collection numbers. This is lost deposited context, not a strain conflict and not exact-product experimental proof.

Severity: minor for each owner. Add two complete-source-row-pinned decisions through `curation/mibig_producer_strains.tsv`. Preserve taxon, source assertion, chemistry, BGC fields, grades and SEEDED status. Verify canary, guarded generation, scope invariants, reproduction and full QC.
