import csv
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml
from rdkit import Chem, rdBase
from rdkit.Chem import Draw, rdMolDescriptors

W = Path(__file__).parent
out = dict(rdkit_version=rdBase.rdkitVersion, records=[], sequences=[], taxonomy=[])
mols, legends = [], []
for slug in ('gentamicin-2', 'gentamicin'):
    path = Path(f'data/natural_products/carbohydrates/{slug}.yaml')
    d = json.loads((W / f'{slug}-resolved.json').read_text())
    c = d['chemical_structure']
    m = Chem.MolFromSmiles(c['smiles'])
    centers = Chem.FindMolChiralCenters(m, includeUnassigned=True)
    out['records'].append(dict(path=str(path), id=d['identifier'], graph_refs=d.get('causal_graph_refs', []), graphs=d.get('causal_graphs', []), key=Chem.MolToInchiKey(m), matches_inchi=Chem.MolToInchi(m)==c['standard_inchi'], matches_key=Chem.MolToInchiKey(m)==c['standard_inchi_key'], formula=rdMolDescriptors.CalcMolFormula(m), charge=Chem.GetFormalCharge(m), chiral_centers=centers, fields=list(d)))
    mols.append(m)
    legends.append(slug)
    key = c['standard_inchi_key']
    tables = {}
    for name in ('mibig_compounds','chebi_structures','chebi_origins','lotus_occurrences','npclassifier','antibioticmech_inchikeys','pubchem_bioassay'):
        with Path(f'data/raw/{name}.tsv').open() as f:
            tables[name] = [r for r in csv.DictReader(f, delimiter='\t') if key in r.values() or any('gentamicin' in v.lower() for v in r.values())]
    out['records'][-1]['source_rows'] = tables
for p in json.loads((W/'pubchem.json').read_text())['PropertyTable']['Properties']:
    m = Chem.MolFromSmiles(p['SMILES'])
    mols.append(m)
    legends.append('PubChem CID'+str(p['CID']))
Draw.MolsToGridImage(mols, molsPerRow=2, subImgSize=(650,450), legends=legends).save(str(W/'structures.png'))
for seq in ET.parse(W/'sequences.xml').getroot().findall('GBSeq'):
    source = []
    for ft in seq.findall('./GBSeq_feature-table/GBFeature'):
        if ft.findtext('GBFeature_key') == 'source':
            source = [(q.findtext('GBQualifier_name'),q.findtext('GBQualifier_value')) for q in ft.findall('./GBFeature_quals/GBQualifier')]
    refs = [dict(title=r.findtext('GBReference_title'), journal=r.findtext('GBReference_journal'), pmid=r.findtext('GBReference_pubmed')) for r in seq.findall('./GBSeq_references/GBReference')]
    out['sequences'].append(dict(accession=seq.findtext('GBSeq_accession-version'),definition=seq.findtext('GBSeq_definition'), source=source, references=refs))
for t in ET.parse(W/'taxonomy.xml').getroot().findall('Taxon'):
    out['taxonomy'].append(dict(taxid=t.findtext('TaxId'), name=t.findtext('ScientificName'), rank=t.findtext('Rank'), lineage=t.findtext('Lineage')))
(W/'inspection.json').write_text(json.dumps(out, indent=2))
print(json.dumps(out, indent=2))
