import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
prior = json.loads(Path('/private/tmp/npmech-capsular-publish-7cKqTV/review-campaign-checkpoint-final.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
selected = {'data/natural_products/carbohydrates/' + slug + '.yaml' for slug in ('gentamicin', 'gentamicin-2')}
changed = []
for row in prior['records']:
    if sha(row['path']) != row['sha256']:
        assert row['path'] in selected
        old = yaml.safe_load(subprocess.check_output(['git', 'show', prior['base'] + ':' + row['path']]))
        new = yaml.safe_load(Path(row['path']).read_text())
        p, = new['producer_organisms']
        assert p.pop('strain') == ('DSM 43036' if row['path'].endswith('/gentamicin.yaml') else 'ATCC 15835')
        ev = p['evidence'].pop()
        assert ev['evidence_type'] == 'CURATOR_INFERENCE' and '#944' in ev['notes']
        ds = new.pop('discussions')
        opened, = [d for d in ds if d['status'] == 'OPEN']
        assert opened['discussion_id'] == 'curator-gentamicin-exact-product-assignment'
        if row['path'].endswith('/gentamicin.yaml'):
            assert len(ds) == 3 and new['xrefs'] == ['npatlas:NPA09026']
            new['xrefs'].append('pubchem:72396')
            assert 'bioactivities' not in new
            new['bioactivities'] = old['bioactivities']
        else:
            assert len(ds) == 1
        assert new['curation_history'][:len(old['curation_history'])] == old['curation_history']
        assert len(new['curation_history']) == len(old['curation_history']) + 2
        new['curation_history'] = old['curation_history']
        assert new == old
        changed.append(row['path'])
    for comp in row['graph_components']:
        assert sha(comp['path']) == comp['sha256']
assert set(changed) == selected
for r in prior['all_review_observations']:
    assert sha(r['yaml']) == r['yaml_sha256'] and sha(r['markdown']) == r['markdown_sha256']
assert not subprocess.check_output(['git', 'diff', prior['base'], '--', 'data/raw', 'data/natural_products/PATHS.tsv', 'data/causal_graphs'])
out = dict(checked_at=datetime.now(timezone.utc).isoformat().replace('+00:00','Z'), base=prior['base'],
    owners=3115, components=243, changed=changed, unchanged_owners=3113, immutable_prior_observations=48,
    invariants='Raw sources, paths, graph components, all chemical graphs, taxa, occurrences, database assertions, grades and SEEDED statuses unchanged; only scoped xref/assay exclusions, two deposited qualifiers, cited discussions and append-only history differ.')
(W / 'scope-audit.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
