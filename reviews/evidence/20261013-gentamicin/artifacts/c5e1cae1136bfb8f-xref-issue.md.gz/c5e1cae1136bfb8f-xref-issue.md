## Confirmed Review Finding

`gentamicin.yaml` / BGC0000696:1 carries BDTQHFBWYNCGHN-CUYCKOLISA-N (C18H36N4O10), but its PubChem CID72396 xref resolves to VEGXETMJINRLTH-BOZYPMBZSA-N (C19H39N5O7). Connectivity and formula differ.

Inspected official properties: https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/72396/property/InChIKey,MolecularFormula/JSON

Severity: major. Withhold only this nonexact xref using the implemented full-row-pinned `curation/mibig_xref_exclusions.tsv` path. Retain the exact NPAtlas NPA09026 alias/NPA009026 match and the unchanged owner chemistry. No replacement CID is established.

The historical AID1195 row is joined by the stored owner key: xref exclusion alone does not remove it. That defect requires a separate correction.

Acceptance: exact row pin, scoped generation, retained valid xref/raw provenance, regression tests and reproduction/full QC.
