## Adversarial Review

Separate pass by the implementing assistant, not independent human approval. Reviewed the exact owners, generated-input boundaries, historical assay join, source payloads and review provenance.

- **Identity, blocker/major:** same generic label conceals distinct A3-like and X2-connectivity graphs. Neither a same-name merge nor a replacement CID is justified. Tracked in #941; cited OPEN record discussions will mitigate, not close it.
- **Grounding, major:** CID72396 differs from the BDTQ owner in connectivity and formula. The NPAtlas xref is independently exact and must survive. #942.
- **Evidence, major:** AID1195's Active flag means dose data are available, not activity on the owner molecule. Removing the xref alone leaves this key-indexed historical row intact. #943.
- **Provenance, minor:** deposited DSM 43036 / ATCC 15835 context is missing. These are equivalent collection designations, not conflicting strains. #944.
- **Broader follow-up:** 23 additional AID1195 owner rows remain outside this two-owner remediation. Future importer identity and protocol checks need a separate cohort-level change.

Remediation requirements: exact full-row pins, unchanged raw inventories and chemistry, explicit table-owned exclusion provenance, strict failure on source drift or unapplied decisions, no broad `Other` filter, immutable successor findings and durable evidence/check receipts. Final checks and disposition follow before merge.
