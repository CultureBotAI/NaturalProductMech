import json
import subprocess
from pathlib import Path

W = Path(__file__).parent
RUN = Path('/private/tmp/npmech-gentamicin-review-c2YN3q')
subprocess.run(['uv', 'run', 'python', str(RUN / 'author.py')], check=True)
rows = []
for item in json.loads((RUN / 'drafts.json').read_text()):
    subprocess.run(['uv', 'run', 'python', 'scripts/record_review.py', 'validate', item['path']], check=True)
    subprocess.run(['uv', 'run', 'python', 'scripts/record_review.py', 'save', '--content', item['path']], check=True)
    rid = item['review_id']
    rows.append(dict(slug=Path(item['path']).name.removesuffix('-review.yaml'), review_id=rid,
                     yaml=f'reviews/structured/{rid}/review.yaml', markdown=f'reviews/structured/{rid}/review.md'))
(W / 'initials.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
