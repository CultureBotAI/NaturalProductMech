## Adversarial Publication Finding in PR #940

The two immutable scoped dispositions accurately captured working-tree inputs at Git base `232d46bacaa6e70ca9f309cb22aae3b1585c4a3c`. That commit is an intermediate review commit, not the original main base. The repository's protected merge queue uses SQUASH, so its object is not guaranteed to remain reachable through main after branch deletion.

The canonical review reader requires the base commit to exist even for working-tree attestations. A locally passing review check therefore does not by itself prove a fresh post-merge clone can validate these reviews.

Preserve the exact commit with a dedicated non-release review-base tag, verify retrieval in a fresh repository, document the required tag for restricted fetches and add a regression. Do not rewrite immutable reviews, change the merge-queue policy or bypass protection. Later reviews should capture a base already durable on main where possible.
