import importlib.util
import json
import subprocess
import tempfile
from pathlib import Path

import yaml

ROOT = Path.cwd()
W = Path(__file__).parent
work = Path(tempfile.mkdtemp(prefix='fresh-provenance-', dir=W))
bare, clone = work / 'simulated-post-cleanup.git', work / 'fresh-main-clone'
assert not bare.exists() and not clone.exists()
tag = 'review-base/gentamicin-20261013'
revision = '232d46bacaa6e70ca9f309cb22aae3b1585c4a3c'
subprocess.run(['git','init','--bare',str(bare)], check=True)
subprocess.run(['git','-C',str(bare),'fetch','--no-tags',str(ROOT),
                'refs/heads/main:refs/heads/main',f'refs/tags/{tag}:refs/tags/{tag}'], check=True)
subprocess.run(['git','-C',str(bare),'symbolic-ref','HEAD','refs/heads/main'], check=True)
refs = subprocess.check_output(['git','-C',str(bare),'for-each-ref','--format=%(refname)'],text=True).splitlines()
assert set(refs) == {'refs/heads/main', 'refs/tags/'+tag}
subprocess.run(['git','clone','--no-local','--no-checkout',str(bare),str(clone)], check=True)
assert subprocess.check_output(['git','-C',str(clone),'rev-parse',tag+'^{commit}'],text=True).strip() == revision
remote_refs = subprocess.check_output(['git','-C',str(clone),'for-each-ref','--format=%(refname)','refs/remotes'],text=True).splitlines()
assert set(remote_refs) == {'refs/remotes/origin/HEAD','refs/remotes/origin/main'}
spec = importlib.util.spec_from_file_location('review_provenance',ROOT/'scripts/record_review.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
results = []
for item in json.loads((W/'successors.json').read_text()):
    review = yaml.safe_load(Path(item['yaml']).read_text())
    result = module.source_provenance(clone, review)
    assert result['status'] == 'working_tree_attestation', result
    results.append(dict(review_id=review['review_id'],result=result))
(W/'fresh-provenance.json').write_text(json.dumps(dict(remote_refs=refs,tag=tag,revision=revision,results=results),indent=2)+'\n')
print(json.dumps(results,indent=2))
