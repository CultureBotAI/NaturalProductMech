## Adversarial Finding in PR #940

The evidence archiver derives a filename from `Path(original).name`. For root-level historical inputs such as `<git-sha>:uv.lock`, this retains a colon in the committed artifact filename. Git checkouts on Windows cannot materialize these names even though macOS/Linux checks pass.

Fix the generated archive paths, not the original provenance locators or immutable review bundles. Preserve raw and compressed hashes and map the unchanged `<sha>:path` locator in the manifest. Add a regression asserting portable stored filenames and exact archive membership. Remove only superseded generated paths verified against the previous manifest.
