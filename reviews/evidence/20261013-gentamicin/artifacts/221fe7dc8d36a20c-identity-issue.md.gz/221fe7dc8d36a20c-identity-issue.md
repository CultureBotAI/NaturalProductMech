## Scientific Review Finding

Targets:
- `data/natural_products/carbohydrates/gentamicin.yaml`: BDTQHFBWYNCGHN-CUYCKOLISA-N, MIBiG BGC0000696:1
- `data/natural_products/carbohydrates/gentamicin-2.yaml`: HFLKNINDVFJPQT-UHFFFAOYSA-N, MIBiG BGC0001603:1

The generic name does not distinguish an A3-connectivity candidate from an X2-connectivity precursor. NPAtlas NPA009026 exactly matches the BDTQ owner and must not be discarded with the nonexact PubChem xref. PubChem CID86490 is a connectivity-only A3 lead; CID15574862 is a stereo-resolved X2 lead, not an exact replacement for the HFLK key.

The inspected 2004 paper (DOI:10.7164/antibiotics.57.436) measures the gentamicin C complex and discusses distinct precursors. The 2015 abstract (PMID:25641167) is X2-specific, but full experimental and stereochemical closure is incomplete. The 1963 discovery and 1975 A3 structural papers remain uninspected after access failures. Missing text is not evidence that either compound is unnatural.

Severity: provisional blocker for the BDTQ exact-product assignment; major for the HFLK unqualified generic label. These are separate stable findings, tracked together for source adjudication.

## Acceptance

- Adjudicate each exact congener and supported stereochemical resolution against inspected primary evidence.
- Re-audit producer, locus, occurrence, xref and assay assignments separately.
- Preserve source labels and original inventories; use a tested maintained qualification/correction path.
- Do not merge owners, transfer mixture claims, install connectivity-only xrefs, or promote SEEDED while unresolved.
- An OPEN record discussion is mitigation, not closure of this issue.
