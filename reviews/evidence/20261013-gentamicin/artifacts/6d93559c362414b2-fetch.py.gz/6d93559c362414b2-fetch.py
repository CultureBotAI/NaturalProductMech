import hashlib
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

W = Path(__file__).parent
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
name, url = sys.argv[1:]
receipt = dict(url=url, started_at=now())
try:
    with urllib.request.urlopen(url, timeout=90) as response:
        body = response.read()
        receipt.update(status=response.status, final_url=response.url)
except urllib.error.HTTPError as exc:
    body = exc.read()
    receipt.update(status=exc.code, error=str(exc))
except Exception as exc:
    body = str(exc).encode()
    receipt.update(status=None, error=repr(exc))
with (W / name).open('xb') as handle:
    handle.write(body)
receipt.update(finished_at=now(), sha256=hashlib.sha256(body).hexdigest(), bytes=len(body))
with (W / (name + '.receipt.json')).open('x') as handle:
    json.dump(receipt, handle, indent=2)
print(json.dumps(receipt, indent=2))
