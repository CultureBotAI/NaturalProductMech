# Final Archive Packaging Repair

The first final-archive test passed 27 tests and failed one because its campaign
checkpoint was absent. The temporary checkpoint builder had assumed all access
observations were dictionaries; the retained historical ledger has 121 strings
and 97 structured entries. Preserve that legacy history unchanged and compare
URLs only on structured entries when adding the six new capsular denial receipts.

The repair changes no scientific input or immutable review bundle. The archive
builder now requires the checkpoint before creating output, refuses to replace
any Git-tracked archive, and verifies every existing output hash before resuming
this unpublished archive. Its initial manifest and failed test receipt are kept
as historical diagnostics. Final archive tests are rerun before commit.
