## Summary

Publish two immutable, partial vibrioferrin record reviews. They distinguish constitutional identity from database agreement, preserve source-specific evidence grades, and retain the full 3,115-owner/243-component review campaign.

An adversarial self-review and issue-driven remediation follow on this branch. The exact BGC0000947 product identity and inaccessible primary evidence remain unresolved; this PR must not imply full scientific sign-off.

## Validation

Initial review validation, canonical append-only checks and contract tests passed during assessment. Fresh remediation and full quality gates will be recorded before merge.
