## Summary

- Publish two immutable partial vibrioferrin record assessments and two linked, scoped remediation dispositions.
- Withhold only the nonexact PubChem197680 cross-reference from CHEBI:84585; retain the distinct BGC0000947 owner and its registry match.
- Add complete-source-row-pinned producer/locus citation corrections, routing BGC0002527's entry PMID instead of its bioactivity citation without changing evidence grades.
- Preserve WP1 and MVPO1 source strains, including the unresolved MVPO1/MVP01 spelling discrepancy and separate AQ3354 occurrence context.
- Add cited OPEN qualifications for the unresolved structural identity and indirect occurrence provenance. Archive local calculations, source data, receipts and campaign checkpoints without redistributing publisher text or denial bodies.

Closes #930. Closes #931. Closes #933. Closes #934.

Refs #929 and #932: these scientific questions remain open. A warning is not an identity adjudication or a newly verified occurrence.

## Adversarial Review

[Separate adversarial self-review](https://github.com/CultureBotAI/NaturalProductMech/pull/928#issuecomment-6154057162), performed by the implementing assistant, not an independent reviewer. Six issues filed; four are resolved by this PR, two remain explicit scientific follow-ups. The initial immutable reports are unchanged.

## Verification

- Fresh full local QC: 786 passed, 3 skipped, 2 dependency warnings; all 3,115 records pass strict validation and reproduce byte-for-byte. Site, provenance, path lock and governance gates pass.
- Configured label check passes with the existing 499 nonblocking warnings and 4,649 no-adapter skips.
- Corrected focused suite: 309 passed. Final successor contract, append-only and evidence-archive checks pass separately; final CI covers the resulting PR tree.
- Only two scientific owners changed. All 3,113 other owners, 243 graph components, raw inventories and the path lock remain unchanged. Both edited records regenerate byte-identically and remain SEEDED.
- Exact successor input commit retained by `review-base/vibrioferrin-remediation-20261013` for squash-merge provenance.

The full review campaign remains unfinished: 42 observations cover 27 owners (one historical completed full assessment, 26 partial); 3,088 owners remain unassessed. Scoped dispositions do not inflate owner coverage. Unfinished capsular research and its access stops are preserved as a handoff, not a completed assessment.
