from pathlib import Path
import yaml

work = Path(__file__).parent
root = Path('reviews/structured')
a = yaml.safe_load((root / '20261013T193946Z-vibrioferrin-2/review.yaml').read_text())
b = yaml.safe_load((root / '20261013T193947Z-vibrioferrin/review.yaml').read_text())
for name, doc, indexes in [('identity', a, [0]), ('xref', b, [0]), ('citation', b, [1]),
                           ('origin', b, [2]), ('strains', a, [1])]:
    parts = ['Adversarial self-review of PR #928; this is not an independent review.\n']
    for source, selected in [(doc, indexes)] + ([(b, [3])] if name == 'strains' else []):
        for i in selected:
            finding = source['findings'][i]
            parts += [f"## {finding['severity']}: {finding['title']}", finding['description'],
                      f"Review: `{source['review_id']}` / `{finding['finding_id']}`; key `{finding['issue_key']}`.",
                      'Maintained owners: ' + ', '.join('`' + p['path'] + '`' for p in finding['owner_paths']),
                      '## Acceptance']
            for action in source['actions']:
                if finding['finding_id'] in action['finding_ids']:
                    parts += [action['description']] + ['- ' + c for c in action['acceptance_checks']]
    with (work / (name + '.md')).open('x') as f:
        f.write('\n\n'.join(parts) + '\n')
