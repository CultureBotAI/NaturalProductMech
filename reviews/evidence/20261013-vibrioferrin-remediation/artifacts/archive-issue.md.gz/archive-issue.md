Adversarial self-review of PR #928; this is not an independent review.

## Major: temporary-only evidence prevents durable audit

Both immutable review bundles reference local source-row joins, chemistry results, access receipts, validation logs and a full campaign checkpoint under `/private/tmp`. Those disappear outside this workspace. Checksums alone do not make local calculations and campaign accounting recoverable.

## Acceptance

- Archive local calculations, scripts, inspected structured database payloads, receipts and the 3,115-owner/243-component campaign checkpoint with exact hashes and review mappings.
- Keep publisher full text, derived page images/text, subscription previews, abstracts and denial bodies reference-only, with stable URLs and hashes.
- Preserve all existing immutable YAML/Markdown bytes. Record fixes in new scoped successor reviews, not edits to the original findings.
- Test compressed and uncompressed checksums, receipts, snapshot mapping, full-population accounting, successor lineage and unresolved findings.
