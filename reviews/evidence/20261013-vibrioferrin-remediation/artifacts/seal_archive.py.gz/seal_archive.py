import gzip
import hashlib
import json
import subprocess
from pathlib import Path

work = Path(__file__).parent
dest = Path('reviews/evidence/20261013-vibrioferrin-remediation')
manifest_path = dest / 'manifest.json'
manifest = json.loads(manifest_path.read_text())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert not subprocess.check_output(['git', 'ls-files', '--', str(dest)])
assert 'final_verification' not in manifest
for row in manifest['artifacts']:
    assert sha((dest / row['path']).read_bytes()) == row['stored_sha256']
receipt_path = work / 'archive-final-corrected.receipt.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['exit_code'] == 0
assert sha(Path(receipt['log']).read_bytes()) == receipt['log_sha256']
for path in [Path(__file__), receipt_path, Path(receipt['log'])]:
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    relative = 'artifacts/' + path.name + '.gz'
    with (dest / relative).open('xb') as handle:
        handle.write(stored)
    manifest['artifacts'].append(dict(original_path=str(path), path=relative,
        bytes=len(raw), sha256=sha(raw), stored_bytes=len(stored), stored_sha256=sha(stored)))
manifest['final_verification'] = dict(receipt=str(receipt_path),
    note='Corrected final archive passed28focused tests after the retained initial packaging failure. Final CI validates this sealed manifest and the additional receipt artifacts.')
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
print(len(manifest['artifacts']))
