Adversarial self-review of PR #928; this is not an independent review.


## minor: The ChEBI alginolyticus origin citation is indirect, not that study's detection experiment

The full PMID22146715 paper does mention V.alginolyticus and V.parahaemolyticus as previously known sources. Its experiment, however, produces structurally characterized vibrioferrin in E.coli from sediment clone MG93-1; the donor taxon is not established by the protein homology comparisons. ChEBI84585 repeats the alginolyticus origin/PMID pair, so the import is faithful. Treat this as indirect prior-literature support and trace the actual isolation/biosynthesis source. Do not infer that alginolyticus cannot produce vibrioferrin, delete the occurrence merely because the paper is indirect, or turn the metagenomic clone into an identified native producer.

Review: `20261013T193947Z-vibrioferrin` / `F3`; key `chebi84585-alginolyticus-indirect-origin-citation`.

Maintained owners: `data/raw/chebi_origins.tsv`, `scripts/seed_from_sources.py`, `data/natural_products/amino_acids_and_peptides/vibrioferrin.yaml`

## Acceptance

Qualify the ChEBI2011 alginolyticus occurrence as indirect literature context; trace the actual native detection/production source. Preserve the upstream origin pair and do not replace its taxon with E.coli or infer a metagenomic donor. A generated-row correction requires an implemented tested path; reserved decisions.tsv has no effect.

- Distinguish background organism mention, sequence homology, experimental host and natural producer.

- Any retained direct detection citation supports the exact product and taxon.

- Do not delete a biologically plausible occurrence merely because its current source is indirect.

- Use maintained input/transform with regression tests; do not patch generated scientific fields.

- For authorized curation: validated writer and append-only event, seeder dry run/canary, exact diff, strict validation, verify-corpus, verify-reproduction and full qc.

- Retain raw source assertions, taxon IDs, source versions and independent producer/locus evidence grades.
