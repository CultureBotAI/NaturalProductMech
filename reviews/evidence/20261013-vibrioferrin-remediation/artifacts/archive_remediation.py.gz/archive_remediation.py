import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml

work = Path(__file__).parent
dest = Path('reviews/evidence/20261013-vibrioferrin-remediation')
upstream_path = Path('reviews/evidence/20261013-vibrioferrin/manifest.json')
artifacts = []
sha = lambda raw: hashlib.sha256(raw).hexdigest()

# Only this unpublished archive may be resumed, after proving its bytes are ours.
assert (work / 'review-campaign-checkpoint.json').is_file()
assert not subprocess.check_output(['git', 'ls-files', '--', str(dest)])
previous_manifest = dest / 'manifest.json'
if previous_manifest.exists():
    previous_raw = previous_manifest.read_bytes()
    previous = json.loads(previous_raw)
    expected_paths = {dest / row['path'] for row in previous['artifacts']}
    assert expected_paths == {p for p in (dest / 'artifacts').rglob('*') if p.is_file()}
    for row in previous['artifacts']:
        assert sha((dest / row['path']).read_bytes()) == row['stored_sha256']
    with (work / 'archive-initial-manifest.json').open('xb') as handle:
        handle.write(previous_raw)


def retain(path, name, raw=None):
    raw = path.read_bytes() if raw is None else raw
    stored = gzip.compress(raw, mtime=0)
    relative = 'artifacts/' + name + '.gz'
    with (dest / relative).open('wb') as handle:
        handle.write(stored)
    artifacts.append(dict(original_path=str(path), path=relative, bytes=len(raw), sha256=sha(raw),
                          stored_bytes=len(stored), stored_sha256=sha(stored)))


(dest / 'artifacts').mkdir(parents=True, exist_ok=True)
for path in sorted(work.iterdir()):
    if path.is_file():
        retain(path, path.name)
upstream = json.loads(upstream_path.read_text())
reviews = []
for item in json.loads((work / 'successors.json').read_text()):
    path = Path('reviews/structured') / item['review_id'] / 'review.yaml'
    report = yaml.safe_load(path.read_text())
    for evidence in report['evidence']:
        original = Path(evidence['reference'])
        if original.is_absolute() or evidence['reference'].startswith('https://') or not original.is_file():
            continue
        if not any(r['original_path'] == str(original) for r in artifacts):
            raw = subprocess.check_output(['git', 'show', f"{report['source']['git_revision']}:{original}"])
            retain(original, item['review_id'] + '-' + evidence['evidence_id'], raw)
    snapshots = []
    for evidence in report['evidence']:
        candidates = artifacts + upstream['artifacts'] + upstream['reference_only_sources']
        matches = [r for r in candidates if r['sha256'] == evidence['snapshot_sha256']]
        assert matches, evidence['evidence_id']
        exact = [r for r in matches if r['original_path'] == evidence['reference']]
        match = (exact or matches)[0]
        snapshots.append(dict(evidence_id=evidence['evidence_id'], sha256=evidence['snapshot_sha256'],
            original_path=match['original_path'], archive='current' if match in artifacts else 'upstream'))
    md = path.with_suffix('.md')
    reviews.append(dict(review_id=item['review_id'], path=str(path), sha256=sha(path.read_bytes()),
        markdown=str(md), markdown_sha256=sha(md.read_bytes()), source_base=report['source']['git_revision'],
        evidence_snapshots=snapshots))
manifest = dict(format_version=1, recorded_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    upstream_manifest=str(upstream_path), upstream_sha256=sha(upstream_path.read_bytes()),
    input_tag='review-base/vibrioferrin-remediation-20261013', artifacts=artifacts, reviews=reviews,
    checkpoint=str(work / 'review-campaign-checkpoint.json'), pr=928, resolved_issue_candidates=[930,931,933,934],
    open_scientific_issues=[929,932], scope='Two partial scoped dispositions, no newly assessed owner.')
with (dest / 'manifest.json').open('w') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(artifacts=len(artifacts), reviews=len(reviews))))
