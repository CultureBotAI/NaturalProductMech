## Adversarial Self-Review of PR #928

The implementing assistant performed this pass. It is not an independent review.

### Findings and Disposition

- #929, blocker: BGC0000947 has a non-ester constitution inconsistent with the inspected named-product structure evidence. Added a cited OPEN qualification, preserved both owners and all organism assertions. Remains open: the exact alginolyticus structure and any migration require primary-source adjudication.
- #930, major: CHEBI:84585 incorrectly asserts PubChem197680 exact equivalence. Excluded only the exact BGC0000946 source assertion with a full-row pin. The separate FPHR owner retains that CID; NPAtlas remains unadjudicated, not excluded for failed access.
- #931, major: BGC0002527's compound-bioactivity citation was used for producer/locus claims. A guarded, full-row-pinned correction routes the source's entry PMID separately for each claim. Original citation/level and decision provenance remain visible. No experimental grade or coordinate claim is upgraded. Generic extractor routing for other unreviewed rows is deliberately unchanged.
- #932, minor: the ChEBI alginolyticus citation is indirect background in a metagenomic-expression paper. Added an OPEN qualification; retained the upstream occurrence. Remains open pending native detection provenance, not fixed by the warning alone.
- #933, minor: WP1 and MVPO1 strain provenance was omitted. Added only exact deposited strain qualifiers, preserving the publisher's MVP01 spelling discrepancy and separate AQ 3354 occurrence context.
- #934, major: temporary-only review evidence was not durable. Archived local calculations, source-row joins, public structured records, receipts and full campaign accounting. Publisher content, abstracts and denial bodies remain URL/hash references. New scoped successors will retain immutable predecessors and distinguish resolved defects from incomplete science.

### Adversarial Checks

Tests exercise complete raw-row drift, missing/duplicate decisions, unknown or blank fields, invalid references/dates, distinct producer/locus citations, no-op routing without a decision, non-organism and unemitted targets, concurrent structure corrections, unchanged noncitation fields, same-key qualification carry-forward, archive snapshots and 3,115-owner/243-component accounting.

The initial focused run had one malformed synthetic test fixture: it modeled a structure correction without its required citation. Corrected the fixture; all 309 selected tests then passed. Subsequent curation/archive checks passed (26 tests), with one additional qualification-preservation regression added before full QC. Initial documentation check correctly detected stale generated statistics; the write path and full QC verify regeneration.

Full corpus comparison found exactly two changed owners, 3,113 unchanged owners, unchanged 243 graph components, unchanged raw inventories/path lock, and unchanged 40 existing review pairs. Both changed records regenerate byte-identically. Both remain SEEDED with incomplete scientific assessments.
