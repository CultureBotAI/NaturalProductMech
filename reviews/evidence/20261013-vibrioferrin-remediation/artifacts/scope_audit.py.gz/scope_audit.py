import hashlib
import json
import subprocess
from pathlib import Path
import yaml

work = Path(__file__).parent
checkpoint = json.loads(Path('/private/tmp/npmech-vibrioferrin-resume-42VRr6/review-campaign-checkpoint.json').read_text())
changed = {'data/natural_products/amino_acids_and_peptides/vibrioferrin.yaml',
           'data/natural_products/amino_acids_and_peptides/vibrioferrin-2.yaml'}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
files = {str(p) for p in Path('data/natural_products').rglob('*.yaml')}
assert files == {r['path'] for r in checkpoint['records']}
owners = []
for item in checkpoint['records']:
    path = item['path']
    raw = Path(path).read_bytes()
    if path not in changed:
        assert digest(raw) == item['sha256'], path
        continue
    before = subprocess.check_output(['git', 'show', f"{checkpoint['base']}:{path}"])
    old, new = yaml.safe_load(before), yaml.safe_load(raw)
    assert len(new['curation_history']) == len(old['curation_history']) + 2
    assert new['curation_history'][:len(old['curation_history'])] == old['curation_history']
    assert new['curation_history'][-1]['curator'] == 'codex'
    for doc in (old, new):
        doc.pop('curation_history')
    previous_discussions = old.pop('discussions', [])
    new_discussions = new.pop('discussions')
    qualification = new_discussions.pop()
    assert qualification['status'] == 'OPEN'
    producer = new['producer_organisms'][0]
    is_chebi = old['identifier'] == 'CHEBI:84585'
    assert producer.pop('strain') == ('WP1' if is_chebi else 'MVPO1')
    assert producer['evidence'].pop()['evidence_type'] == 'CURATOR_INFERENCE'
    if is_chebi:
        assert new['xrefs'] == ['npatlas:NPA024673']
        new['xrefs'] = old['xrefs']
        excluded = new_discussions.pop(0)
        assert excluded['discussion_id'] == 'source-xref-exclusion-BGC0000946-1-pubchem-197680'
        assert excluded['status'] == 'RESOLVED'
        for field in ('producer_organisms', 'biosynthetic_gene_clusters'):
            claim = new[field][1]
            assert claim['evidence'][0]['reference'] == 'PMID:26452553'
            assert claim['evidence'][0]['evidence_type'] == 'DATABASE_ASSERTION'
            assert len(claim['evidence']) == 2
            assert claim['evidence'][1]['evidence_type'] == 'CURATOR_INFERENCE'
            claim['evidence'] = old[field][1]['evidence']
    assert new_discussions == previous_discussions
    assert old == new, path
    owners.append(dict(path=path, before_sha256=digest(before), after_sha256=digest(raw)))
components = list(Path('data/causal_graphs').rglob('*.yaml'))
assert len(components) == 243
assert not subprocess.check_output(['git', 'diff', checkpoint['base'], '--', 'data/causal_graphs',
                                   'data/raw', 'data/natural_products/PATHS.tsv'])
for review in checkpoint['all_review_observations']:
    assert digest(Path(review['yaml']).read_bytes()) == review['yaml_sha256']
    assert digest(Path(review['markdown']).read_bytes()) == review['markdown_sha256']
result = dict(owners=len(files), components=len(components), unchanged_owners=len(files)-2,
    changed_owners=owners, immutable_prior_observations=40,
    scope='Only reviewed xref exclusion, two strain qualifiers, paired citation routing, OPEN qualifications and append-only history changed. Raw inventories, chemistry, taxonomy, occurrences and grades remain unchanged.')
with (work / 'scope-audit.json').open('x') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result))
