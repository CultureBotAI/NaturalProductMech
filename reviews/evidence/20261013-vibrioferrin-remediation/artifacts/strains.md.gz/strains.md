Adversarial self-review of PR #928; this is not an independent review.


## minor: The producer lacks the source strain and its spelling qualification

DQ201184.2 explicitly records strain MVPO1 (letter O), whereas the publisher abstract says MVP01 (zero). The producer carries only NCBITaxon663 and no strain. Preserve both literal source spellings with their provenance; do not silently normalize them or assert that the spellings denote distinct strains. The deposited locus remains traceable, so this is a bounded provenance omission. F1 prevents an unqualified exact-structure production upgrade.

Review: `20261013T193946Z-vibrioferrin-2` / `F2`; key `mibig-BGC0000947-vibrioferrin-source-strain`.

Maintained owners: `curation/mibig_producer_strains.tsv`, `src/naturalproductmech/curate/producer_strains.py`, `data/raw/mibig_compounds.tsv`, `scripts/extract_mibig.py`, `scripts/seed_from_sources.py`, `data/natural_products/amino_acids_and_peptides/vibrioferrin-2.yaml`

## Acceptance

Qualify the0947 producer with deposited strain provenance using source-row digest c1452d9f35f0197165f3205d6bb9cfa300df22c601e3f524c6df8dbf48bedd3a, preserving MVPO1 versus MVP01 as an unresolved spelling discrepancy. Do not silently pick a canonical spelling or upgrade biosynthetic evidence. Keep any structure migration separate.

- GenBank literal and publisher literal remain distinguishable with citations.

- Only the exact0947:1 producer gains the bounded qualifier; no taxon or grade changes.

- Use maintained input/transform with regression tests; do not patch generated scientific fields.

- For authorized curation: validated writer and append-only event, seeder dry run/canary, exact diff, strict validation, verify-corpus, verify-reproduction and full qc.

- Retain raw source assertions, taxon IDs, source versions and independent producer/locus evidence grades.

## minor: The deposited WP1 strain is missing from the producer claim

AB082123.1 names V.parahaemolyticus strain WP1, but the corresponding BGC0000946 producer has only species-rank NCBITaxon670. The AQ3354 detection_context in a different ChEBI occurrence is not this accession's strain and must not be copied across. CA is already represented by strain-rank NCBITaxon1283330 and needs no inferred taxon replacement.

Review: `20261013T193947Z-vibrioferrin` / `F4`; key `mibig-BGC0000946-vibrioferrin-source-strain`.

Maintained owners: `curation/mibig_producer_strains.tsv`, `src/naturalproductmech/curate/producer_strains.py`, `data/raw/mibig_compounds.tsv`, `scripts/extract_mibig.py`, `scripts/seed_from_sources.py`

## Acceptance

Add WP1 to the0946 producer through the existing row-pinned strain table, citing AB082123.1 and the0946:1 digest2a6d88d4055ff04c4496c977d1bc1af425c5f12c860c7c85a591c681734cfe7c. Leave AQ3354 occurrence context and CA strain-rank taxon unchanged.

- Only the correct0946 producer gains WP1 and separate qualifier evidence.

- No invented strain taxid or experimental grade upgrade.

- Use maintained input/transform with regression tests; do not patch generated scientific fields.

- For authorized curation: validated writer and append-only event, seeder dry run/canary, exact diff, strict validation, verify-corpus, verify-reproduction and full qc.

- Retain raw source assertions, taxon IDs, source versions and independent producer/locus evidence grades.
