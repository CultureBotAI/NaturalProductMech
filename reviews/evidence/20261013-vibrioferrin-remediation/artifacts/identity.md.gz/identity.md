Adversarial self-review of PR #928; this is not an independent review.


## blocker: The imported constitution is not the vibrioferrin described by the cited structure evidence

The stored FPHRKFJYHKRDFJ graph has four free carboxylic acids and no ester. The inspected 1994 structure-elucidation abstract names an ethanolamine citrate ester; the full 2011 paper depicts that ester in Figure1 and supports it with NMR in Figure3/Table1. That chemistry matches the IGQXNKDXMPSELX constitution, not this owner. The difference is connectivity, not protonation or merely incomplete stereochemistry. PubChem197680 and MIBiG0947 do reproduce the stored graph, but registry agreement does not validate its assignment to the named product or the seven LOTUS citations. The exact alginolyticus product in the paywalled2007 experiment still needs adjudication; do not claim a corrected per-strain assignment from the metagenomic2011 experiment.

Review: `20261013T193946Z-vibrioferrin-2` / `F1`; key `mibig-BGC0000947-vibrioferrin-constitution`.

Maintained owners: `data/raw/mibig_compounds.tsv`, `scripts/extract_mibig.py`, `scripts/seed_from_sources.py`, `data/raw/lotus_occurrences.tsv`, `data/natural_products/amino_acids_and_peptides/vibrioferrin-2.yaml`

## Acceptance

First record a cited identity qualification if curation is authorized. Adjudicate0947 exact product from legitimately accessible primary evidence. Existing CHEBI84585 already occupies the candidate key; REPLACE_WITH_CHEBI intentionally rejects this collision. Any eventual merge/migration requires a separately implemented, audited path that rechecks each occurrence, BGC and history claim. Never transfer old-key assertions automatically.

- Compare experimental constitution and supported stereochemical resolution, not just names/formulae.

- Preserve both owners until an evidence-backed migration is designed; account for all seven LOTUS claims individually.

- No lost provenance, accidental duplicate ChEBI owner, or transferred unsupported organism claim.

- Use maintained input/transform with regression tests; do not patch generated scientific fields.

- For authorized curation: validated writer and append-only event, seeder dry run/canary, exact diff, strict validation, verify-corpus, verify-reproduction and full qc.

- Retain raw source assertions, taxon IDs, source versions and independent producer/locus evidence grades.
