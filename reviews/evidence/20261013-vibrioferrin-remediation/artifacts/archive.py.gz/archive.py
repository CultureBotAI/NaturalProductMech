"""Publish local audit artifacts; retain publisher and denial content by reference."""
import gzip
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml

dest = Path('reviews/evidence/20261013-vibrioferrin')
works = [Path('/private/tmp/npmech-vibrioferrin-review-eZIUfP'),
         Path('/private/tmp/npmech-vibrioferrin-resume-42VRr6')]
artifacts, references = [], []
digest = lambda raw: hashlib.sha256(raw).hexdigest()
runtime = ['/private/tmp/npmech-rdkit-2026.03.5/share/RDKit',
           '/private/tmp/npmech-rdkit-2026.03.5/bin/python',
           '/private/tmp/antibioticmech-pdf-tools-20261009']


def retain(path, name, raw=None):
    raw = path.read_bytes() if raw is None else raw
    stored = gzip.compress(raw, mtime=0)
    relative = 'artifacts/' + name + '.gz'
    with (dest / relative).open('xb') as handle:
        handle.write(stored)
    artifacts.append(dict(original_path=str(path), path=relative, sha256=digest(raw), bytes=len(raw),
                          stored_sha256=digest(stored), stored_bytes=len(stored)))


(dest / 'artifacts').mkdir(parents=True, exist_ok=False)
metadata_url = json.loads((works[0] / 'metadata.json.receipt.json').read_text())['url']
for i, work in enumerate(works):
    for path in sorted(work.iterdir()):
        if not path.is_file():
            continue
        rp = path.with_name(path.name + '.receipt.json')
        receipt = json.loads(rp.read_text()) if rp.exists() else {}
        publisher = path.name in {'metadata.json', 'source-inspection.json', 'source-read.log',
                                 'primary2007.txt', 'html-read.log', 'jstage2011.txt'}
        publisher |= path.name.startswith('jstage2011-page-')
        external = 'url' in receipt and (receipt.get('status') != 200 or path.name in {
            'primary2007.html', 'jstage2011.pdf', 'metadata.json'})
        if publisher or external:
            raw = path.read_bytes()
            if receipt.get('sha256'):
                assert digest(raw) == receipt['sha256']
            url = receipt.get('url') or (metadata_url if path.name in {
                'source-inspection.json', 'source-read.log'} else
                'https://doi.org/10.1007/s00203-007-0261-6' if path.name in {
                    'primary2007.txt', 'html-read.log'} else
                'https://www.jstage.jst.go.jp/article/bbb/75/12/75_110379/_pdf')
            references.append(dict(original_path=str(path), sha256=digest(raw), bytes=len(raw),
                source_url=url, reason='Publisher content, abstract metadata, derived text/image or error body: reference only.'))
        else:
            retain(path, f'{i}-' + path.name)

checkpoint_path = works[1] / 'review-campaign-checkpoint.json'
checkpoint = json.loads(checkpoint_path.read_text())
assert digest(checkpoint_path.read_bytes()) == '3f8d4563ae28034e41effe3083c4f4f495529017af32d9444ec9f67658da4224'
prior = Path(checkpoint['prior_checkpoint'])
assert digest(prior.read_bytes()) == checkpoint['prior_checkpoint_sha256']
retain(prior, 'prior-checkpoint.json')
for name in ('qc.log', 'qc.receipt.json'):
    retain(Path('/private/tmp/npmech-myxochromide-publish-MyX4Nq') / name, 'prior-' + name)
retain(Path(__file__), 'archive.py')
reviews = []
for rid in ['20261013T193946Z-vibrioferrin-2', '20261013T193947Z-vibrioferrin']:
    path = Path('reviews/structured') / rid / 'review.yaml'
    md = path.with_suffix('.md')
    doc = yaml.safe_load(path.read_text())
    for ev in doc['evidence']:
        p = Path(ev['reference'])
        if not str(p).startswith('/') and not str(p).startswith('https:') and p.is_file():
            if not any(r['original_path'] == str(p) for r in artifacts):
                raw = subprocess.check_output(['git', 'show', f"{doc['source']['git_revision']}:{p}"])
                retain(p, 'git-' + str(p).replace('/', '__'), raw)
    snapshots = []
    for ev in doc['evidence']:
        if 'snapshot_sha256' not in ev:
            continue
        matches = [r for r in artifacts + references if r['sha256'] == ev['snapshot_sha256']]
        assert matches, ev['evidence_id']
        exact = [r for r in matches if r['original_path'] == ev['reference']]
        row = (exact or matches)[0]
        snapshots.append(dict(evidence_id=ev['evidence_id'], original_path=row['original_path'], sha256=row['sha256']))
    known = {r['original_path'] for r in artifacts + references}
    missing = {p.rstrip('.') for p in re.findall(r'/private/tmp/[A-Za-z0-9_./-]+', path.read_text())} - known - set(runtime)
    assert not missing, missing
    reviews.append(dict(review_id=rid, path=str(path), sha256=digest(path.read_bytes()),
        markdown=str(md), markdown_sha256=digest(md.read_bytes()), source_base=doc['source']['git_revision'],
        evidence_snapshots=snapshots))
manifest = dict(format_version=1, recorded_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    corpus_base=checkpoint['base'], pr=928, issues=list(range(929,935)), checkpoint=str(checkpoint_path),
    artifacts=artifacts, reference_only_sources=references, reviews=reviews,
    runtime_directories=runtime, unavailable_artifacts=[],
    snapshot_note='Historical immutable review inputs and full campaign checkpoint; later scoped dispositions do not increase whole-owner coverage.')
with (dest / 'manifest.json').open('x') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(artifacts=len(artifacts), reference_only=len(references),
                     stored_bytes=sum(r['stored_bytes'] for r in artifacts))))
