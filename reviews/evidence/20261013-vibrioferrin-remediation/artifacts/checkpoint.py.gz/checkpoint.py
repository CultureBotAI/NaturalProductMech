import csv
import hashlib
import json
import subprocess
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import yaml

work = Path(__file__).parent
prior = Path('/private/tmp/npmech-vibrioferrin-resume-42VRr6/review-campaign-checkpoint.json')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(prior) == '3f8d4563ae28034e41effe3083c4f4f495529017af32d9444ec9f67658da4224'
doc = deepcopy(json.loads(prior.read_text()))
assert len(doc['all_review_observations']) == 40
for review in doc['all_review_observations']:
    assert sha(review['yaml']) == review['yaml_sha256']
    assert sha(review['markdown']) == review['markdown_sha256']
scope = json.loads((work / 'scope-audit.json').read_text())
changed = {r['path']: r for r in scope['changed_owners']}
components = []
for row in doc['records']:
    if row['path'] in changed:
        assert row['sha256'] == changed[row['path']]['before_sha256']
        row['sha256'] = changed[row['path']]['after_sha256']
        row['bytes'] = Path(row['path']).stat().st_size
    assert sha(row['path']) == row['sha256']
    for component in row['graph_components']:
        assert sha(component['path']) == component['sha256']
        components.append(component['path'])
assert len(doc['records']) == 3115 and len(components) == 243
new = []
for item in json.loads((work / 'successors.json').read_text()):
    path = Path('reviews/structured') / item['review_id'] / 'review.yaml'
    md = path.with_suffix('.md')
    report = yaml.safe_load(path.read_text())
    row = dict(review_id=report['review_id'], yaml=str(path), yaml_sha256=sha(path),
        markdown=str(md), markdown_sha256=sha(md), target_id=report['targets'][0]['target_id'],
        path=report['targets'][0]['path'], verdict=report['verdict'], completion=report['completion'],
        scientific_review=True, findings=report['findings'], finished_at=report['finished_at'],
        scope='Scoped disposition only; does not increase whole-owner assessment coverage.')
    doc['all_review_observations'].append(row)
    new.append(row)
    for finding in report['findings']:
        heads = [f for f in doc['latest_finding_heads'] if f['issue_key'] == finding['issue_key']]
        assert len(heads) == 1
        previous, = finding['previous_occurrences']
        assert heads[0]['review_id'] == previous['review_id']
        doc['latest_finding_heads'].remove(heads[0])
        doc['latest_finding_heads'].append(dict(**finding, review_id=report['review_id'], finished_at=report['finished_at']))
assert len(doc['all_review_observations']) == 42
assert len(doc['reviews']) == 27 and len(doc['partial_followups']) == 26
assert len(doc['pending_in_priority_order']) == 3088
findings = dict(Counter(f['severity'] for f in doc['latest_finding_heads'] if f['status'] in ('open', 'deferred')))
assert findings == {'blocker': 9, 'major': 7, 'minor': 1}
doc['prior_verification'] = doc['verification']
doc['verification'] = {}
for path in work.glob('*.receipt.json'):
    receipt = json.loads(path.read_text())
    if 'log' in receipt:
        assert sha(receipt['log']) == receipt['log_sha256']
    doc['verification'][path.name] = dict(path=str(path), sha256=sha(path), result=receipt)
for label in ['qc', 'labels', 'strict', 'focused-corrected', 'canonical', 'contract', 'queue-after']:
    assert doc['verification'][label + '.receipt.json']['result']['exit_code'] == 0
queue_path = work / 'native-queue-after.tsv'
with queue_path.open() as handle:
    queue = list(csv.DictReader(handle, delimiter='\t'))
owner_paths = {r['path'] for r in doc['records']}
queue_paths = {r['path'] for r in queue}
assert owner_paths <= queue_paths and queue_paths - owner_paths == {'curation/unresolved_taxa.tsv'}
doc['queue_verification'] = dict(path=str(queue_path), sha256=sha(queue_path), rows=len(queue),
    owner_paths=len(owner_paths), non_owner_paths=['curation/unresolved_taxa.tsv'],
    note='All3115owners retained; unresolved-taxa rows are diagnostics, not an extra owner or scientific assessment.')
caps = Path('/private/tmp/npmech-capsular-review-UUGHOQ')
caps_receipts = []
for path in sorted(caps.glob('*.receipt.json')):
    receipt = json.loads(path.read_text())
    if receipt.get('status') != 403:
        continue
    payload = Path(str(path).removesuffix('.receipt.json'))
    assert sha(payload) == receipt['sha256']
    caps_receipts.append(dict(path=str(path), sha256=sha(path), receipt=receipt))
    if not any(isinstance(r, dict) and r.get('url') == receipt['url']
               for r in doc['access_stops_no_alternate_retrieval']):
        doc['access_stops_no_alternate_retrieval'].append(dict(url=receipt['url'], status=403,
            description='Explicit denial during unfinished capsular research; no alternate retrieval of the same source.',
            provenance=str(path), provenance_sha256=sha(path), started_at=receipt['started_at'],
            finished_at=receipt['finished_at'], payload_sha256=receipt['sha256']))
assert len(caps_receipts) == 6
with (work / 'capsular-access-receipts.json').open('x') as handle:
    json.dump(caps_receipts, handle, indent=2)
doc.update(prior_checkpoint=str(prior), prior_checkpoint_sha256=sha(prior),
    previous_base=doc['base'], base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    recorded_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    goal_status='active', scientific_review_bundles=42, new_reviews=new, findings=findings,
    scientific_inputs_unchanged=False, scientific_input_delta=scope,
    count_note='42observations cover27owners:1historical completed full assessment,26partial owners,3088unassessed. Two scoped dispositions add no owner coverage. All3115native records remain SEEDED;243components remain in scope.',
    this_turn_classification='Publication and bounded remediation: xref, citation routing and two strain defects resolved. Identity and indirect occurrence findings qualified but open. No new owner assessment.',
    review_bundle_state='Original40observations immutable; two validated scoped successors saved for PR928.',
    publication=dict(pr=928, state='awaiting final publication and CI', original_reviews_committed=True,
                     fixes_committed=True, merged=False, resolved_issue_candidates=[930,931,933,934], open_issues=[929,932]),
    live_sessions=0, required_work_remaining='Assess all3088unassessed owners and finish26partial assessments with their exact attached components; publication is not goal completion.',
    unpublished_research_handoff=dict(workspace=str(caps), saved_reviews=0,
        owners=doc['pending_in_priority_order'][:3], status='Capsular research interrupted by user publication request; no assessments saved.',
        note='17MIBiG payloads and GenBank loci,6taxa,3PubChem properties and synonyms captured. Reinspect current maintained inputs before review. PMID11773119/PMC120111,17599305,18215476 full texts and three Wikidata endpoints denied; do not retry through alternate routes. Remaining independent primary leads and chemistry calculations were not completed. Do not replay exclusive-output scripts.'),
    scoped_disposition_observations=[r['review_id'] for r in doc['all_review_observations'] if r.get('scope')],
    frontier_note='Next unassessed owners are the three capsular-polysaccharide records. All26partial owners remain unfinished; scoped remediation is not new whole-owner coverage.',
    verification_reuse_note='Publication performed fresh scoped tests, strict validation, label gate, full QC, queue, canonical and contract checks. Original review receipts remain historical in the upstream archive.',
    this_turn_artifacts=dict(workspace=str(work), successor_index=str(work / 'successors.json'),
        scope_audit=str(work / 'scope-audit.json'), full_qc=str(work / 'qc.receipt.json')),
    durable_remediation_mapping='reviews/evidence/20261013-vibrioferrin-remediation/manifest.json')
with (work / 'review-campaign-checkpoint.json').open('x') as handle:
    json.dump(doc, handle, indent=2)
print(json.dumps(dict(observations=42, assessed=27, partial=26, unassessed=3088, findings=findings,
                     access_observations=len(doc['access_stops_no_alternate_retrieval']))))
