from pathlib import Path
import yaml
from naturalproductmech.curate.curation_event import record_curation_event
from naturalproductmech.validation.write_validated import write_validated_natural_product

specs = [
    ('vibrioferrin-2', 'naturalproductmech:mibig-c1b0b2a6f8',
     'FPHRKFJYHKRDFJ-LWYCVJHGSA-N', 929, 'constitution',
     'Does the imported BGC0000947 constitution identify the experimentally established vibrioferrin product?',
     'The stored graph has four free carboxylic acids and no ester. The 1994 structure-elucidation abstract and the inspected 2011 metagenomic product (Figure 1 and Figure 3/Table 1) instead support a citrate-ethanolamine ester. Agreement with PubChem197680 and MIBiG0947 does not resolve the biological assignment. The 2011 E. coli expression experiment does not establish the exact alginolyticus product; the 2007 full text requires subscription and was not inspected. Preserve both existing owners and all seven LOTUS assertions pending individual source adjudication. Do not merge into CHEBI:84585, assign replacement stereochemistry or transfer organism claims automatically.'),
    ('vibrioferrin', 'CHEBI:84585', 'IGQXNKDXMPSELX-BIAKFKOBSA-N', 932, 'indirect-origin',
     'Which primary experiment supports the ChEBI Vibrio alginolyticus occurrence?',
     'ChEBI pairs V. alginolyticus with PMID:22146715. That paper mentions native Vibrio sources as prior literature, but its characterized experimental product comes from E. coli expressing marine sediment clone MG93-1. The donor taxon is not established by sequence homology. The occurrence remains a faithful DATABASE_ASSERTION, not a direct alginolyticus detection experiment in that paper. Retain the upstream pair and trace the native isolation or biosynthesis evidence; do not delete the occurrence from this indirect citation alone, replace its taxon with E. coli, or infer an identified environmental donor.'),
]
for slug, identifier, key, issue, local_id, prompt, rationale in specs:
    path = Path('data/natural_products/amino_acids_and_peptides') / (slug + '.yaml')
    doc = yaml.safe_load(path.read_text())
    assert doc['identifier'] == identifier and doc['chemical_structure']['standard_inchi_key'] == key
    assert doc['curation_status'] == 'SEEDED'
    did = 'curator-vibrioferrin-' + local_id
    assert not any(d['discussion_id'] == did for d in doc.get('discussions', []))
    evidence = [
        dict(reference='PMID:22146715', evidence_source='full_text',
             explanation='2011 metagenomic expression study, Figure 1 and Figure 3/Table 1; native taxa are prior-literature context, not the experimentally identified donor.'),
        dict(reference=f'https://github.com/CultureBotAI/NaturalProductMech/issues/{issue}',
             explanation='Open scientific adjudication; a visible qualification is not resolution.'),
    ]
    if issue == 929:
        evidence += [dict(reference='PMID:7961600', evidence_source='abstract',
                          explanation='1994 structural elucidation names the citrate ester; full text was not inspected.'),
                     dict(reference='DOI:10.1007/s00203-007-0261-6', evidence_source='abstract',
                          explanation='2007 alginolyticus study; subscription preview only. No corrected per-strain structure inferred.')]
    else:
        evidence += [dict(reference='https://www.ebi.ac.uk/chebi/84585', evidence_source='database',
                          explanation='Upstream origin pairing is preserved, not asserted as independent experimental verification.')]
    history = doc.pop('curation_history')
    doc.setdefault('discussions', []).append(dict(discussion_id=did, kind='CURATION_TODO',
        status='OPEN', posed_by='codex', prompt=prompt, rationale=rationale, evidence=evidence))
    doc['curation_history'] = history
    record_curation_event(doc, curator='codex', action='RECORD_CURATED',
        changes='Add a cited OPEN vibrioferrin qualification. Preserve chemistry, organism assertions, evidence grades and SEEDED status; no identity migration or occurrence reassignment.',
        llm_assisted=True)
    write_validated_natural_product(doc, path)
    print(path)
