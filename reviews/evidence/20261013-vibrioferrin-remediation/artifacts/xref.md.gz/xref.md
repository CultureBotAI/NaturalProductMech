Adversarial self-review of PR #928; this is not an independent review.


## major: PubChem197680 is not an exact chemical cross-reference

The official PubChem response encodes FPHRKFJYHKRDFJ-LWYCVJHGSA-N, whereas this owner and ChEBI84585 encode IGQXNKDXMPSELX-BIAKFKOBSA-N. RDKit and visual comparison confirm four free acids/no ester versus three free acids/one ester. Equal formula and exact mass do not establish equivalence. The incorrect xref originates in BGC0000946:1; BGC0002527:1 contributes a separate NPAtlas identifier whose equivalence remains unknown after403. Withhold only the proven nonexact PubChem assertion, not the NPAtlas identifier.

Review: `20261013T193947Z-vibrioferrin` / `F1`; key `chebi84585-nonexact-pubchem197680`.

Maintained owners: `curation/mibig_xref_exclusions.tsv`, `src/naturalproductmech/curate/xref_exclusions.py`, `data/raw/mibig_compounds.tsv`, `scripts/extract_mibig.py`, `scripts/seed_from_sources.py`

## Acceptance

Withhold literal pubchem:197680 from BGC0000946:1 with complete-row digest2a6d88d4055ff04c4496c977d1bc1af425c5f12c860c7c85a591c681734cfe7c. Cite the official PubChem response and preserve the rejected assertion in the table-owned discussion. Do not select a replacement CID or exclude NPAtlas based on failed access.

- Reject stale/duplicate pins and xref reintroduction.

- ChEBI identity, NPAtlas assertion and other owner claims unchanged.

- Use maintained input/transform with regression tests; do not patch generated scientific fields.

- For authorized curation: validated writer and append-only event, seeder dry run/canary, exact diff, strict validation, verify-corpus, verify-reproduction and full qc.

- Retain raw source assertions, taxon IDs, source versions and independent producer/locus evidence grades.
