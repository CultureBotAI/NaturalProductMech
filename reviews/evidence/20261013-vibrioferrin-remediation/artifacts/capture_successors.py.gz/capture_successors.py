import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

work = Path(__file__).parent
old = Path('/private/tmp/npmech-vibrioferrin-resume-42VRr6')
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
inputs = ['docs/CURATION.md', 'docs/record-reviews.md', 'docs/record-review-profile.md',
          '.claude/skills/review-yaml-record/SKILL.md', 'schema/record_review.yaml',
          'src/naturalproductmech/schema/naturalproductmech.yaml',
          'src/naturalproductmech/schema/mech_shared.yaml', 'scripts/record_review.py',
          'scripts/seed_from_sources.py', 'scripts/extract_mibig.py',
          'src/naturalproductmech/curate/producer_strains.py',
          'src/naturalproductmech/curate/claim_references.py',
          'src/naturalproductmech/curate/xref_exclusions.py',
          'curation/mibig_producer_strains.tsv', 'curation/mibig_xref_exclusions.tsv',
          'curation/mibig_claim_references.tsv', 'data/raw/mibig_compounds.tsv',
          'reviews/evidence/20261013-vibrioferrin/manifest.json',
          'tests/test_vibrioferrin_curation.py', 'tests/test_vibrioferrin_review_archive.py',
          'tests/test_claim_references.py']
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
for slug, rid in [('vibrioferrin-2', '20261013T193946Z-vibrioferrin-2'),
                  ('vibrioferrin', '20261013T193947Z-vibrioferrin')]:
    target = json.loads((old / (slug + '-targets.json')).read_text())
    path = work / (slug + '-targets.json')
    with path.open('x') as handle:
        json.dump(target, handle, indent=2)
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(path)]
    for item in inputs + [f'reviews/structured/{rid}/review.yaml']:
        command.extend(['--input', item])
    started = now()
    capture = work / (slug + '-inspect.json')
    with capture.open('x') as handle:
        result = subprocess.run(command, stdout=handle, check=True)
    doc = json.loads(capture.read_text())
    for item in doc['source']['inputs']:
        raw = subprocess.check_output(['git', 'show', f"{base}:{item['path']}"])
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
    receipt = dict(command=command, started_at=started, finished_at=now(), exit_code=result.returncode,
                   log=str(capture), log_sha256=hashlib.sha256(capture.read_bytes()).hexdigest())
    with (work / (slug + '-inspect.receipt.json')).open('x') as handle:
        json.dump(receipt, handle, indent=2)
    print(slug, base, len(doc['source']['inputs']))
