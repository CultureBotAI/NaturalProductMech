"""Record scoped dispositions without replacing whole-record observations."""
import hashlib
import json
import shlex
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import yaml

work = Path(__file__).parent
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


class NoAliasSafeDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


results = []
for slug, prior_id, statuses, issues in [
    ('vibrioferrin-2', '20261013T193946Z-vibrioferrin-2', {'F1': 'open', 'F2': 'resolved'}, {'F1': 929, 'F2': 933}),
    ('vibrioferrin', '20261013T193947Z-vibrioferrin',
     {'F1': 'resolved', 'F2': 'resolved', 'F3': 'open', 'F4': 'resolved'},
     {'F1': 930, 'F2': 931, 'F3': 932, 'F4': 933}),
]:
    prior = Path('reviews/structured') / prior_id / 'review.yaml'
    old = yaml.safe_load(prior.read_text())
    capture = json.loads((work / (slug + '-inspect.json')).read_text())
    inspection = json.loads((work / (slug + '-inspect.receipt.json')).read_text())
    for item in capture['source']['inputs']:
        assert sha(item['path']) == item['sha256'], item['path']
    target = capture['targets'][0]['target_id']
    owner = Path(capture['targets'][0]['path'])
    checks = []
    summaries = {
        'focused-corrected': '309 focused tests passed after correcting a malformed synthetic structure-correction fixture.',
        'focused-curation': '26 focused curation, citation and archive tests passed; a further qualification-preservation regression is covered by full QC.',
        'strict': 'Both exact owners passed strict closed-schema validation with zero errors.',
        'reseed-a': 'CHEBI:84585 regenerates byte-identically, including curator qualifications and history.',
        'reseed-b': 'BGC0000947 owner regenerates byte-identically, including qualification and history.',
        'scope-audit': 'All3115owners/243components retained; two owners changed,3113unchanged. Raw inventories, path lock and40prior review pairs unchanged.',
        'labels': 'Configured label check passed with499existing nonblocking mismatches and4649no-adapter skips; not chemical equivalence approval.',
        'qc': 'Fresh full native QC passed:786tests,3skips,2dependency warnings; all-owner strict validation, reproduction, site, provenance and governance passed. Exact receipts are retained.',
    }
    for label, summary in summaries.items():
        r = json.loads((work / (label + '.receipt.json')).read_text())
        assert r['exit_code'] == 0 and sha(r['log']) == r['log_sha256']
        checks.append(dict(check_id=label, name=label, status='passed', required=True,
            command=shlex.join(r['command']), exit_code=0, expected_exit_code=0, target_ids=[target], summary=summary,
            scope_note=f"Executed {r['started_at']} to {r['finished_at']}; log {r['log']}; SHA256 {r['log_sha256']}"))
    for label, summary in [
        ('focused', 'One synthetic test fixture omitted the required structure-correction citation;308tests passed and1failed. Corrected fixture and subsequent focused/full QC runs pass.'),
        ('docs-stats', 'Initial check detected stale generated statistics; docs-write regenerated them and full QC passed the documentation check.'),
    ]:
        r = json.loads((work / (label + '.receipt.json')).read_text())
        assert r['exit_code'] == 1
        checks.append(dict(check_id=label+'-initial', name=label+' initial attempt', status='failed',
            required=False, command=shlex.join(r['command']), exit_code=1, expected_exit_code=0,
            target_ids=[target], summary=summary))
    checks.append(dict(check_id='remaining-primary', name='Uncompleted exact-source scientific checks',
        status='unavailable', required=True, target_ids=[target],
        summary='All predecessor full-text and authority-access limits remain. No new primary retrieval, exact-strain identity adjudication or full-record sign-off is claimed.'))
    evidence = []

    def ev(eid, kind, path, locator, summary):
        evidence.append(dict(evidence_id=eid, kind=kind, reference=str(path), locator=locator,
            accessed_at=now(), support='supports', summary=summary, snapshot_sha256=sha(path)))

    ev('owner', 'record_content', owner, 'Entire current owner and append-only history',
       'Reviewed citation/xref/strain changes and OPEN qualifications are visible. Chemistry, organism assertions, evidence grades and SEEDED status remain unchanged.')
    ev('prior', 'record_content', prior, 'Immutable predecessor findings and access limitations',
       'The full-record partial assessment remains intact. This successor is limited to disposition of its findings.')
    for eid, path, summary in [
        ('strain-table', 'curation/mibig_producer_strains.tsv', 'Exact full-row-pinned WP1 and MVPO1 qualifiers; MVP01 publisher spelling and AQ3354 occurrence context remain distinct.'),
        ('xref-table', 'curation/mibig_xref_exclusions.tsv', 'Only BGC0000946 PubChem197680 exact equivalence is withheld; BGC0000947 CID and CHEBI84585 NPAtlas assertion remain.'),
        ('citation-table', 'curation/mibig_claim_references.tsv', 'The2527 source entry PMID is routed to producer and locus with separate curator attribution; raw bioactivity citation is retained.'),
        ('citation-code', 'src/naturalproductmech/curate/claim_references.py', 'Guarded source-pinned loader rejects drift and malformed decisions; routing preserves other qualifications and evidence grades.'),
        ('archive', 'reviews/evidence/20261013-vibrioferrin/manifest.json', '115retained artifacts and21reference-only sources preserve input hashes, receipt lineage and the whole-corpus checkpoint.'),
    ]:
        ev(eid, 'record_content', path, 'Current maintained input; distinct-owner changes are context only', summary)
    ev('scope-proof', 'validation', work / 'scope-audit.json', 'Full corpus hashes and object-level comparison',
       'Only the reviewed claims and two OPEN qualifications changed; no owner migration, occurrence reassignment or unrelated scientific edit.')
    ev('regressions', 'validation', work / 'focused-curation.log', 'Focused remediation and archive tests',
       '26tests passed before an additional qualification-preservation regression in full QC.')
    ev('native-qc', 'validation', work / 'qc.log', 'Fresh full native quality gate',
       'All native gates passed; deterministic consistency is not scientific completion.')
    reused = ['chemistry', 'pubchem', 'sequences', 'metadata', 'primary2011', 'primary2007']
    reused += ['mibig-BGC0000947.5'] if slug.endswith('-2') else ['mibig-BGC0002527.2', 'chebi']
    for eid in reused:
        item = deepcopy(next(e for e in old['evidence'] if e['evidence_id'] == eid))
        item['locator'] += '; same captured source reassessed for scoped disposition, not a new retrieval'
        item['accessed_at'] = now()
        evidence.append(item)
    reasons = {
        929: 'A cited OPEN qualification exposes the constitutional conflict but does not resolve it. The exact alginolyticus product, seven occurrence assertions and any migration into the occupied CHEBI84585 identity remain open. No structure or stereocenter changed.',
        930: 'Resolved the false exact cross-reference through a complete-row-pinned exclusion of pubchem:197680 on0946 only. The source assertion remains in the unchanged inventory and a resolved table-owned discussion. Neither a replacement CID nor NPAtlas equivalence is inferred.',
        931: 'Resolved this2527 citation-routing defect with an implemented tested full-row-pinned correction. PMID26452553 remains DATABASE_ASSERTION; separate CURATOR_INFERENCE preserves the original activity DOI/level and decision source. This does not fix generic extraction for unreviewed rows, validate the full primary experiment or upgrade grades.',
        932: 'A cited OPEN discussion qualifies the ChEBI origin as indirect prior-literature context. The upstream occurrence remains unchanged; native detection provenance is not yet resolved and no taxon is reassigned.',
        933: 'Resolved missing deposited strain context only. WP1 stays separate from AQ3354; MVPO1 is the GenBank literal and MVP01 the explicitly retained publisher spelling. No canonical spelling, strain taxid, species-wide production or evidence upgrade is inferred.',
    }
    findings = []
    for original in old['findings']:
        finding = deepcopy(original)
        fid = finding['finding_id']
        finding['status'] = statuses[fid]
        finding['previous_occurrences'] = [dict(repository=old['repository'], review_id=prior_id, finding_id=fid)]
        finding['external_issues'] = [f'https://github.com/CultureBotAI/NaturalProductMech/issues/{issues[fid]}']
        finding['evidence_ids'] = ['owner', 'prior', 'scope-proof', 'regressions', 'native-qc'] + {
            929: ['chemistry', 'primary2011', 'primary2007', 'mibig-BGC0000947.5'],
            930: ['pubchem', 'chemistry', 'xref-table'],
            931: ['mibig-BGC0002527.2', 'citation-table', 'citation-code', 'metadata'],
            932: ['chebi', 'primary2011', 'primary2007'],
            933: ['strain-table', 'sequences', 'primary2007'],
        }[issues[fid]]
        finding['disposition_reason'] = reasons[issues[fid]]
        if issues[fid] == 931:
            finding['owner_paths'] += [dict(repository=old['repository'], path=path, role=role) for path, role in [
                ('curation/mibig_claim_references.tsv', 'Implemented complete-source-row-pinned citation correction'),
                ('src/naturalproductmech/curate/claim_references.py', 'Guarded loader and claim-specific evidence routing')]]
        findings.append(finding)
    unresolved = [f['finding_id'] for f in findings if f['status'] == 'open']
    actions = [deepcopy(a) for a in old['actions'] if set(a['finding_ids']) & set(unresolved)]
    for action in actions:
        action['description'] = (
            'Adjudicate the exact BGC0000947 alginolyticus product and each of the seven LOTUS assertions before any structure migration. The cited OPEN qualification is already present. The candidate CHEBI84585 destination is occupied, so a merge needs a separately implemented, audited migration; never transfer claims by label alone.'
            if slug.endswith('-2') else
            'Trace primary native alginolyticus detection or biosynthesis evidence for the retained ChEBI occurrence. The OPEN indirect-citation qualification is already present. Do not replace its taxon with the heterologous E.coli host or infer the environmental donor; any generated-row correction needs its own implemented tested path.')
    source = deepcopy(capture['source'])
    source['state'] = 'git_commit'
    rid = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + slug + '-scoped-disposition'
    summary = ('Strain qualifier resolved; constitutional identity remains open.' if slug.endswith('-2') else
               'Nonexact xref, claim citation routing and WP1 qualifier resolved; indirect occurrence provenance remains open.')
    doc = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=old['repository'],
        title=slug + ': scoped source-correction disposition', started_at=inspection['started_at'], finished_at=now(),
        reviewer=dict(identity='Codex', kind='agent', independence='self_review',
            independence_basis='The implementing assistant performed a separate adversarial pass; not an independent human review.'),
        skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial', verdict='needs_curation',
        scientific_review=True, summary=summary, source=source, targets=capture['targets'],
        scope=dict(description='One exact owner; scoped predecessor disposition, not a new whole-record assessment.',
            selection='User-authorized PR, adversarial review and issue remediation.', coverage='partial', population_size=1,
            reviewed_target_ids=[target], exclusions=[dict(target='Other owners and remaining predecessor scientific checks',
                reason='No new whole-owner coverage. Full scope remains3115owners and243components.')]),
        checks=checks, evidence=evidence, findings=findings,
        assessments=[
            dict(assessment_id='bounded-fixes', area='scope', topic='Exact-owner source corrections', outcome='supported',
                target_ids=[target], evidence_ids=['owner', 'prior', 'strain-table', 'xref-table', 'citation-table', 'scope-proof', 'regressions'],
                summary=summary + ' The field-by-field comparison preserves all other scientific assertions.'),
            dict(assessment_id='remaining', area='evidence', topic='Remaining scientific uncertainty', outcome='concern',
                target_ids=[target], evidence_ids=['owner', 'prior', 'primary2011', 'primary2007'],
                summary='OPEN qualifications are not completed identity or native occurrence adjudication. Both owners remain SEEDED and their earlier access limitations still apply.'),
            dict(assessment_id='audit', area='provenance', topic='Immutable history and durable evidence', outcome='supported',
                target_ids=[target], evidence_ids=['prior', 'archive', 'scope-proof', 'native-qc'],
                summary='Original40observations remain unchanged; scoped successors retire only supported defects. Full campaign coverage is not inflated.')],
        actions=actions,
        limitations=['Scoped partial disposition only; no newly assessed owner and no full scientific sign-off.',
            'All predecessor primary and authority access limitations remain. No alternate retrieval after denial.',
            'Full QC preceded saving these successors; canonical append-only checks and contract tests follow saving.',
            'Exact inspected commit is retained by review-base/vibrioferrin-remediation-20261013.',
            'Generic extractor citation selection for other unreviewed rows remains unchanged; the new correction is explicitly source-scoped.',
            'The campaign retains3088unassessed owners and26partial assessments;1historical completed full assessment is not native REVIEWED promotion.'],
        related_reviews=[dict(repository=old['repository'], review_id=prior_id,
            relationship='Scoped disposition of exact predecessor findings; immutable whole-record assessment retained.')],
        links=['https://github.com/CultureBotAI/NaturalProductMech/pull/928'])
    draft = work / (slug + '-successor.yaml')
    with draft.open('x') as handle:
        yaml.dump(doc, handle, Dumper=NoAliasSafeDumper, sort_keys=False, allow_unicode=False, width=94)
    results.append(dict(review_id=rid, draft=str(draft)))
with (work / 'successors.json').open('x') as handle:
    json.dump(results, handle, indent=2)
print(json.dumps(results))
