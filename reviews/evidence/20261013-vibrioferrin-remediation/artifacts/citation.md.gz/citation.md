Adversarial self-review of PR #928; this is not an independent review.


## major: A compound-bioactivity citation displaces the entry-specific taxon/locus reference

BGC0002527.2 attaches DOI10.1021/ic9016883 to siderophore bioactivity and retains PMID26452553 at entry level. The extractor chooses the former through its generic priority rule, and mibig_evidence reuses it for both the CA producer and CP005094.1 locus. The inspected2009 abstract concerns iron binding/photochemistry and marine bacteria; the2016 abstract explicitly concerns Azotobacter vibrioferrin and genome-based capacity. This confirms cross-claim citation selection, not a claim to have read either full paper or proved their every negative. Preserve the original database assertion and route claim-appropriate references separately. Full2016 evidence is still needed before assigning experimental grades or asserting those coordinates were tested.

Review: `20261013T193947Z-vibrioferrin` / `F2`; key `mibig-BGC0002527-bioactivity-reference-used-for-locus`.

Maintained owners: `data/raw/mibig_compounds.tsv`, `scripts/extract_mibig.py`, `scripts/seed_from_sources.py`

## Acceptance

Separate citation selection for compound structure/activity from producer/locus assertions. Preserve2527 bioactivity DOI in its correct source context, retain entry PMID26452553 for its appropriate claim, and inspect the full primary work before upgrading grades. Any extractor/schema change must account for other affected rows rather than silently reassigning the whole corpus.

- Regression fixture has differing compound-bioactivity and entry references and verifies claim-specific routing.

- Pin current2527:1 complete-row digest3be82cba240a164478055eac8f68fd1cceac0f615451f6b31133d121b58a73a1 for a bounded correction.

- Source citation provenance remains DATABASE_ASSERTION unless primary curation is separately justified.

- Use maintained input/transform with regression tests; do not patch generated scientific fields.

- For authorized curation: validated writer and append-only event, seeder dry run/canary, exact diff, strict validation, verify-corpus, verify-reproduction and full qc.

- Retain raw source assertions, taxon IDs, source versions and independent producer/locus evidence grades.
