# Unfinished Research Handoff

The user redirected to publishing vibrioferrin work before any capsular review
was saved. These notes preserve leads, not findings or review coverage.

Workspace: `/private/tmp/npmech-capsular-review-UUGHOQ`. Do not replay exclusive
writers. Reinspect maintained inputs at the new commit before assessment.

Three pending owners are `carbohydrates/capsular-polysaccharide-2.yaml`,
`carbohydrates/capsular-polysaccharide-3.yaml`, and
`unclassified/capsular-polysaccharide.yaml`. Source joins, 17 versioned MIBiG
records, 17 GenBank loci, six taxa and three PubChem property responses are
captured. `pubchem-synonyms.json` had not yet been read when interrupted.

- Klebsiella: key ODLPTSAMUCYJMF-UHFFFAOYSA-N, CID3083199. Registry title points
  to K15, whereas five deposited sources are K5/K20/K54. A finite six-sugar
  graph must not be assumed equivalent to every serotype's polymer.
- Streptococcus: key NOVHANKYCIGDMV-KSYJWRBWSA-N, CID3083207. Nine source loci
  concern Ia/III/VI strains. Check the registry's exact type-II identity and
  primary chemistry; do not treat the provisional heptasaccharide lead as a
  finalized conclusion.
- Actinobacillus: key FJTWZGAJWZJDEU-SRTYELMFSA-N, CID195740. Source deposits
  name serotypes12/6/7; source0753 is72-14676, not the abstract's WF83 example.
  Inspect the n-propoxy/geminal-diol representation against the reported
  glycosylglycerol phosphate polymer with RDKit and primary evidence.

Independent primary leads not yet inspected: PMID3568000 (K15 structure),
PMID2036652 (serotype7 structure), DOI10.1016/S0021-9258(18)33057-6 (1983GBSII),
DOI10.1128/iai.73.5.3096-3103.2005 (GBS structural/genetic diversity), and
PMID6192144 (typeII immunochemistry). Type-II linkage assignments may have
been revised; inspect actual primary text/figures before adjudication.

Do not retry denied cited papers by alternative routes: PMID17599305,
PMID11773119/PMC120111 and PMID18215476. The three Wikidata denial receipts
are also preserved. Check exact Wikidata IDs against the source row before
declaring a mapping checked. Absence of A.lignieresii from an abstract is not
proof its full paper lacks support. All three PubChem property responses
match their respective stored graphs; do not misuse nonexact-xref exclusions.
