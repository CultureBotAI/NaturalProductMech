"""Publish auditable local evidence without redistributing publisher content."""
import gzip
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml

dest = Path('reviews/evidence/20261013-myxochromide')
works = [Path('/private/tmp/npmech-myxochromide-review-RK6G2y'),
         Path('/private/tmp/npmech-myxochromide-resume-A59XD1')]
artifacts, references, missing = [], [], []
digest = lambda raw: hashlib.sha256(raw).hexdigest()
url = 'https://www.wiley-vch.de/contents/jc_2002/2006/z503737_s.pdf'
runtime = ['/private/tmp/npmech-rdkit-2026.03.5/share/RDKit',
           '/private/tmp/npmech-rdkit-2026.03.5/bin/python',
           '/private/tmp/antibioticmech-pdf-tools-20261009']


def retain(path, name, raw=None):
    raw = path.read_bytes() if raw is None else raw
    stored = gzip.compress(raw, mtime=0)
    relative = 'artifacts/' + name + '.gz'
    with (dest / relative).open('xb') as handle:
        handle.write(stored)
    artifacts.append(dict(original_path=str(path), path=relative, sha256=digest(raw), bytes=len(raw),
                          stored_sha256=digest(stored), stored_bytes=len(stored)))


(dest / 'artifacts').mkdir(parents=True, exist_ok=False)
for i, work in enumerate(works):
    for path in sorted(work.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        rp = path.with_name(path.name + '.receipt.json')
        receipt = json.loads(rp.read_text()) if rp.exists() else {}
        publisher = path.name in {'wenzel2006-si.pdf', 'wenzel2006-si.txt'} or bool(re.fullmatch(r'si-\d+\.png', path.name))
        external = 'url' in receipt and (receipt.get('status') != 200 or path.name.startswith('PMID'))
        if publisher or external:
            raw = path.read_bytes()
            if receipt:
                assert digest(raw) == receipt['sha256']
            references.append(dict(original_path=str(path), sha256=digest(raw), bytes=len(raw),
                source_url=receipt.get('url', url),
                reason='Publisher content, derived figure/text, abstract metadata or error response: reference only.'))
        else:
            retain(path, f'{i}-' + path.name)

checkpoint_path = works[1] / 'review-campaign-checkpoint.json'
checkpoint = json.loads(checkpoint_path.read_text())
assert digest(checkpoint_path.read_bytes()) == 'd358c28e474ae549d3e0b3ca22e7434b555f73be09ffeb0cbbf97f80b002b31e'
prior = Path(checkpoint['prior_checkpoint'])
assert digest(prior.read_bytes()) == checkpoint['prior_checkpoint_sha256']
retain(prior, 'prior-checkpoint.json')
for name in ('qc-final.log', 'qc-final.receipt.json'):
    retain(Path('/private/tmp/npmech-ferrichrome-publish-i31W5V') / name, 'prior-' + name)
retain(Path(__file__), 'archive.py')
reviews = []
for rid in ['20261013T182624Z-myxochromide-a', '20261013T182624Z-myxochromide-a-2']:
    path = Path('reviews/structured') / rid / 'review.yaml'
    md = path.with_suffix('.md')
    doc = yaml.safe_load(path.read_text())
    for ev in doc['evidence']:
        p = Path(ev['reference'])
        if not str(p).startswith('/') and not str(p).startswith('https:') and p.is_file():
            if not any(r['original_path'] == str(p) for r in artifacts):
                raw = subprocess.check_output(['git', 'show', f"{doc['source']['git_revision']}:{p}"])
                retain(p, 'git-' + str(p).replace('/', '__'), raw)
    snapshots = []
    for ev in doc['evidence']:
        if 'snapshot_sha256' not in ev:
            continue
        matches = [r for r in artifacts + references if r['sha256'] == ev['snapshot_sha256']]
        assert matches, ev['evidence_id']
        exact = [r for r in matches if r['original_path'] == ev['reference']]
        row = (exact or matches)[0]
        snapshots.append(dict(evidence_id=ev['evidence_id'], original_path=row['original_path'], sha256=row['sha256']))
    known = {r['original_path'] for r in artifacts + references}
    for token in set(re.findall(r'/private/tmp/[A-Za-z0-9_./-]+', path.read_text())) - known - set(runtime):
        token = token.rstrip('.')
        assert token == str(works[1] / 'strict.tsv') and not Path(token).exists(), token
        if token not in {m['original_path'] for m in missing}:
            missing.append(dict(original_path=token, reason='Planned output never created: initial uv wrapper failed before validation; strict-native.tsv retains the successful retry.'))
    reviews.append(dict(review_id=rid, path=str(path), sha256=digest(path.read_bytes()),
        markdown=str(md), markdown_sha256=digest(md.read_bytes()), source_base=doc['source']['git_revision'],
        evidence_snapshots=snapshots))
manifest = dict(format_version=1, recorded_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    corpus_base=checkpoint['base'], pr=923, issues=[924,925,926,927], checkpoint=str(checkpoint_path),
    artifacts=artifacts, reference_only_sources=references, reviews=reviews,
    runtime_directories=runtime, unavailable_artifacts=missing,
    snapshot_note='Historical evidence and full campaign checkpoint. Original reports stay immutable; later scoped dispositions do not count as new full-record assessments.')
with (dest / 'manifest.json').open('x') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(artifacts=len(artifacts), reference_only=len(references),
                     stored_bytes=sum(r['stored_bytes'] for r in artifacts))))
