from pathlib import Path
import fitz

W = Path(__file__).parent
doc = fitz.open(W / 'wenzel2006-si.pdf')
for n in [4, 5, 11]:
    doc[n - 1].get_pixmap(matrix=fitz.Matrix(2, 2)).save(W / f'si-{n}.png')
print('Rendered PDF pages 4, 5, 11 for visual inspection')
