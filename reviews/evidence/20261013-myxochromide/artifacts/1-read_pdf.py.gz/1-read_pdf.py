import hashlib
import json
from pathlib import Path

import fitz

W = Path(__file__).parent
source = W / 'wenzel2006-si.pdf'
doc = fitz.open(source)
with (W / 'wenzel2006-si.txt').open('x') as f:
    for i, page in enumerate(doc):
        f.write(f'\nPAGE {i + 1}\n')
        f.write(page.get_text())
for i in range(min(3, len(doc))):
    doc[i].get_pixmap(matrix=fitz.Matrix(2, 2)).save(W / f'si-{i + 1}.png')
print(json.dumps(dict(pages=len(doc), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), rendered_pages=list(range(1, min(3, len(doc)) + 1)), pymupdf=fitz.VersionBind), indent=2))
