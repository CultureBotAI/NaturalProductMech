import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

W = Path(__file__).parent
label, *command = sys.argv[1:]
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
r = dict(command=command, cwd=str(Path.cwd()), started_at=now())
log = W / (label + '.log')
with log.open('x') as f:
    result = subprocess.run(command, stdout=f, stderr=subprocess.STDOUT)
r.update(finished_at=now(), exit_code=result.returncode, log=str(log), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (W / (label + '.receipt.json')).open('x') as f:
    json.dump(r, f, indent=2)
print(json.dumps(r, indent=2))
print(log.read_text()[-5000:])
sys.exit(result.returncode)
