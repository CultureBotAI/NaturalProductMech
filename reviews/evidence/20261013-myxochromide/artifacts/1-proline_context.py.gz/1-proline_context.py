import json
from pathlib import Path
from rdkit import Chem, rdBase

W = Path(__file__).parent
O = Path('/private/tmp/npmech-myxochromide-review-RK6G2y')
assert rdBase.rdkitVersion == '2026.03.5'
rows = []
for n in [1422, 1425, 1426, 1427, 1428]:
    d = json.loads((O / f'BGC000{n}.4.json').read_text())
    for module in d['biosynthesis']['modules']:
        for substrate in module.get('a_domain', {}).get('substrates', []):
            if substrate['name'] == 'proline':
                m = Chem.MolFromSmiles(substrate['structure'])
                rows.append(dict(accession=d['accession'], module=module['name'], substrate=substrate, methods=module['a_domain'].get('evidence'), key=Chem.MolToInchiKey(m), centers=Chem.FindMolChiralCenters(m, includeUnassigned=True)))
assert len(rows) == 5
out = dict(rows=rows, note='Module substrate annotations are source predictions/inferences, not experimental proof of incorporated stereochemistry; compare only as an internal source discrepancy.')
with (W / 'proline-context.json').open('x') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
