import csv
import hashlib
import json
import subprocess
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
P = Path('/private/tmp/npmech-ferrichrome-publish-i31W5V/review-campaign-checkpoint.json')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(P) == 'e6a2e52026d9528ae78f52cbb86abb5059858d5e6ada64da6463830ac1c33844'
p = deepcopy(json.loads(P.read_text()))
records = {r['path']: r for r in p['records']}
components = {g['path']: g for r in p['records'] for g in r['graph_components']}
assert len(records) == 3115 and len(components) == 243
actual = {str(f) for root in ['data/natural_products', 'data/causal_graphs'] for f in Path(root).rglob('*.yaml')}
assert actual == records.keys() | components.keys()
for path, row in (records | components).items():
    assert sha(path) == row['sha256'], path
for r in p['all_review_observations']:
    assert sha(r['yaml']) == r['yaml_sha256'] and sha(r['markdown']) == r['markdown_sha256']
assert len(p['all_review_observations']) == 34
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == p['base']
branch = subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip()
assert branch == 'review/myxochromide-records-20261013'
new = []
for item in json.loads((W / 'reviews-v2.json').read_text()):
    yp = Path('reviews/structured') / item['review_id'] / 'review.yaml'
    mp = yp.with_suffix('.md')
    doc = yaml.safe_load(yp.read_text())
    path = doc['targets'][0]['path']
    assert records[path]['review_state'] == 'unassessed'
    assert doc['completion'] == 'partial'
    for inp in doc['source']['inputs']:
        assert sha(inp['path']) == inp['sha256']
        assert hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + inp['path']])).hexdigest() == inp['sha256']
    for f in [yp, mp]:
        assert all(line == line.rstrip() for line in f.read_text().splitlines()), f
    row = dict(review_id=doc['review_id'], yaml=str(yp), yaml_sha256=sha(yp), markdown=str(mp), markdown_sha256=sha(mp),
               target_id=doc['targets'][0]['target_id'], path=path, verdict=doc['verdict'], completion=doc['completion'],
               scientific_review=doc['scientific_review'], findings=doc['findings'], finished_at=doc['finished_at'])
    new.append(row)
    p['reviews'].append(row)
    p['all_review_observations'].append(row)
    p['partial_followups'].append(path)
    p['pending_in_priority_order'].remove(path)
    records[path]['review_state'] = 'partial'
    for finding in doc['findings']:
        assert not any(h['issue_key'] == finding['issue_key'] for h in p['latest_finding_heads'])
        p['latest_finding_heads'].append(dict(**finding, review_id=doc['review_id'], finished_at=doc['finished_at']))
assert len(p['reviews']) == len({r['path'] for r in p['reviews']}) == 25
assert len(p['all_review_observations']) == 36
assert len(p['partial_followups']) == 24
assert len(p['pending_in_priority_order']) == 3090
assert {str(f) for f in Path('reviews/structured').rglob('review.yaml')} == {r['yaml'] for r in p['all_review_observations']}
with (W / 'queue.tsv').open() as f:
    queue = list(csv.DictReader(f, delimiter='\t'))
assert len(queue) == 8930
assert {r['path'] for r in queue if r['path'].startswith('data/natural_products/')} == records.keys()
assert {r['status'] for r in records.values()} == {'SEEDED'}
findings = dict(Counter(f['severity'] for f in p['latest_finding_heads'] if f['status'] in ('open', 'deferred')))
assert findings == {'blocker': 8, 'major': 7, 'minor': 1}
p['prior_verification'] = p['verification']
p['verification'] = {}
for f in sorted(W.glob('*.receipt.json')):
    receipt = json.loads(f.read_text())
    if 'log' in receipt:
        assert sha(receipt['log']) == receipt['log_sha256']
    p['verification'][f.name] = dict(path=str(f), sha256=sha(f), result=receipt)
for label in ['canonical', 'contract', 'strict-native', 'chemistry', 'core', 'proline-context', 'labels', 'corpus', 'queue', 'save-a', 'save-b']:
    assert p['verification'][label + '.receipt.json']['result']['exit_code'] == 0
new_stops = []
for item in json.loads((W / 'discovery.json').read_text())['limitations']:
    stop = dict(url=item['url'], description=item['condition'], observed_date='2026-10-13', status=None,
                provenance=str(W / 'discovery.json'), provenance_sha256=sha(W / 'discovery.json'),
                note='Web tool observation; no HTTP status or exact UTC request time supplied. Recorded date is not an invented HTTP receipt. No alternate retrieval.')
    new_stops.append(stop)
    p['access_stops_no_alternate_retrieval'].append(stop)
assert len(p['access_stops_no_alternate_retrieval']) == 206
p.update(previous_base=p['base'], base=base, branch=branch, recorded_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
         prior_checkpoint=str(P), prior_checkpoint_sha256=sha(P), goal_status='active', scientific_inputs_unchanged=True,
         scientific_input_delta={'changed_owners': [], 'changed_components': [], 'tracked_changes': []},
         scientific_review_bundles=36, partial_reviews=24, unassessed_records=3090, new_reviews=new,
         findings=findings, live_sessions=0, new_access_stops=new_stops,
         previous_turn_classification='No progress on record coverage: prior publication verified; safe next owners remained available.',
         this_turn_classification='Progress: two new exact-owner scientific reviews, independent2006 primary evidence, three bounded findings and current validation; no scientific curation.',
         count_note='36 immutable observations cover25 owners: one historical completed full assessment and24 partial owners, leaving3090 unassessed. All3115 native owners remain SEEDED; full243-component scope is retained.',
         review_bundle_state='34 prior observations remain committed and byte-identical;2 new canonical pairs are saved, uncommitted on the local review branch.',
         frontier_note='Next unassessed exact owners are vibrioferrin-2.yaml and vibrioferrin.yaml, followed by capsular-polysaccharide-2.yaml and capsular-polysaccharide-3.yaml. All24 partial owner follow-ups and unresolved finding heads remain in scope.',
         required_work_remaining='Review all3090 unassessed owners with their attached components; finish24 partial assessments and retain unresolved findings. No reduction of3115-owner/243-component objective.',
         queue_verification=dict(rows=len(queue), owner_count=3115, non_owner_paths=sorted({r['path'] for r in queue} - records.keys()), path=str(W / 'queue.tsv'), sha256=sha(W / 'queue.tsv')),
         verification_reuse_note='Fresh inspect/strict/RDKit/corpus/label checks and canonical/contract checks ran. Full native QC/reproduction is explicitly a prior executed run verified against unchanged domain inputs; not a fresh run. Existing skips/warnings remain.',
         access_stop_note='206 historical access observations, not206 current authorization denials.204 inherited observations and recoveries retained;2 new web-source limits recorded without inventing HTTP statuses. The2006 supplement was independently found and retrieved before any denial for it.')
p['prior_publication'] = p['publication']
p['publication'] = dict(requested_this_turn=False, committed=False, pushed=False, github_mutations=False)
p['historical_unsaved_draft_failures'] = p.pop('initial_unsaved_draft_failures', [])
p['current_draft_revision_note'] = 'Both initial drafts validated; a pre-save revision narrowed BGC and proposed-action wording to each exact owner. Only v2 was saved; no immutable bundle was changed.'
p['historical_bundle_whitespace_checks'] = p.pop('new_bundle_whitespace_checks', [])
p['new_bundle_whitespace_checks'] = [dict(path=r[k], method='Every line compared with rstrip in checkpoint.py', passed=True) for r in new for k in ['yaml', 'markdown']]
p['unpublished_research_handoff'] = dict(workspace=str(W), prior_workspace='/private/tmp/npmech-myxochromide-review-RK6G2y',
    saved_reviews=2, status='Two saved partial owner reviews; no curation or publication.', owners=[r['path'] for r in new],
    next_step='Preserve both immutable pairs, evidence receipts and all source-access stops. Resume the remaining full-corpus queue; do not replay exclusive-output helpers.')
p['working_chemistry_command'] = p['verification']['chemistry.receipt.json']['result']['command']
p['this_turn_artifacts'] = [dict(path=str(f), sha256=sha(f)) for f in sorted(W.iterdir()) if f.is_file()]
out = W / 'review-campaign-checkpoint.json'
with out.open('x') as f:
    json.dump(p, f, indent=2)
print(json.dumps(dict(checkpoint=str(out), sha256=sha(out), base=base, branch=branch, observations=36, distinct_assessed=25,
                     completed_historical=1, partial=24, unassessed=3090, owners=3115, components=243, findings=findings,
                     access_observations=206, live_sessions=0, next_owners=p['pending_in_priority_order'][:4]), indent=2))
