import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml


class NoAliasSafeDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


W = Path(__file__).parent
O = Path('/private/tmp/npmech-myxochromide-review-RK6G2y')
P = Path('/private/tmp/npmech-ferrichrome-publish-i31W5V')
REPO = 'CultureBotAI/NaturalProductMech'
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
capture = json.loads((W / 'capture.json').read_text())
chem = json.loads((W / 'chemistry.json').read_text())


def owned(path, role):
    return dict(repository=REPO, path=path, role=role)


def local(eid, kind, path, locator, summary, support='supports', **extra):
    return dict(evidence_id=eid, kind=kind, reference=str(path), locator=locator,
                accessed_at=now(), support=support, summary=summary,
                snapshot_sha256=sha(path), **extra)


def remote(eid, root, name, kind, locator, summary, support='supports'):
    r = json.loads((root / (name + '.receipt.json')).read_text())
    assert sha(root / name) == r['sha256']
    return dict(evidence_id=eid, kind=kind, reference=r['url'],
                locator=f"{locator}; captured {r['started_at']}..{r['finished_at']}, HTTP{r['status']}; payload {root / name}; receipt SHA256 {sha(root / (name + '.receipt.json'))}",
                accessed_at=now(), support=support, summary=summary, snapshot_sha256=r['sha256'])


def check(label, tid, summary, root=W, required=True, expected=0):
    r = json.loads((root / (label + '.receipt.json')).read_text())
    assert r['exit_code'] == expected and sha(r['log']) == r['log_sha256']
    return dict(check_id=label, name=label, status='passed' if expected == 0 else 'failed',
                required=required, command=shlex.join(r['command']), exit_code=r['exit_code'],
                expected_exit_code=0, target_ids=[tid], summary=summary,
                scope_note=f"Actual run {r['started_at']}..{r['finished_at']}; {r['log']}; SHA256 {r['log_sha256']}")


source_owners = [owned('data/raw/mibig_compounds.tsv', 'Versioned source chemistry, taxon and locus assertions; retain raw provenance'),
                 owned('scripts/extract_mibig.py', 'MIBiG extraction'),
                 owned('scripts/seed_from_sources.py', 'Structure-key grouping, evidence grading and generated records')]
strain_owners = [owned('curation/mibig_producer_strains.tsv', 'Implemented complete-source-row-pinned strain qualification'),
                 owned('src/naturalproductmech/curate/producer_strains.py', 'Validated strain qualification loader and evidence helper'), *source_owners]
written = []
for slug, accessions, a in [('myxochromide-a', [1425, 1426, 1427, 1428], True), ('myxochromide-a-2', [1422], False)]:
    inspection = json.loads((W / (slug + '-inspect.json')).read_text())
    target = inspection['targets'][0]
    tid = target['target_id']
    owner = Path(target['path'])
    d = json.loads((W / (slug + '-resolved.json')).read_text())
    c = next(r for r in chem['results'] if r['label'] == slug)
    for sc in d['source_concepts']:
        digest = hashlib.sha256(('MIBIG\x00' + sc['source_id'] + ':1').encode()).hexdigest()[:10]
        assert sc['minted_identifier'] == 'naturalproductmech:mibig-' + digest
    correction_owners = source_owners + [owned(str(owner), 'Curator-owned cited qualification only through validated curation; seeded chemistry is not hand-editable')]
    findings = []
    if a:
        findings.append(dict(finding_id='F1', issue_key='mibig-BGC0001425-1428-myxochromide-a-core-identity',
            category='identity', severity='blocker', status='open', certainty='provisional',
            title='The imported A-type structure conflicts with the experimentally characterized peptide core',
            description='The four source rows encode a 21-membered lactone with the terminal amino-acid carboxamide attached at the alpha carbon. The independently inspected 2006 A-series structure has a 19-membered glutamine-based core. Its A3 side-chain length matches this C45 graph, so the ring difference is not explained merely by A2/A3/A4 chain variation. Virtual hydrolysis also exposes an R-proline fragment, opposite the same MIBiG entries\' S-proline substrate depiction. These differences are confirmed observations, but the exact assignment across all four 2017 strain entries remains provisional: the cited 2017 full paper is unavailable, and the older structure elucidation used DK1050, not every listed strain. The existing shared-structure discussion does not state this chemical conflict. Do not select a replacement or transfer claims merely from the common label.',
            target_ids=[tid], field_paths=['label', 'chemical_structure', 'biosynthesis_origin', 'producer_organisms', 'biosynthetic_gene_clusters', 'discussions'],
            evidence_ids=['owner', 'inventories', 'chemistry', 'core', 'proline', 'si2006', 'paper-access'],
            owner_paths=correction_owners, rule_id='review-checklist:Identity/Structure; docs/HARMONIZATION.md:one record per exact structure',
            native_severity='blocker', normalization_reason='If the experimentally characterized A-core assignment applies, this is a different constitution, not a stylistic label issue. Severity reflects the identity consequence; certainty remains provisional until per-strain exact-product adjudication.'))
        findings.append(dict(finding_id='F2', issue_key='mibig-BGC0001426-1428-myxochromide-a-source-strains',
            category='provenance', severity='minor', status='open', certainty='confirmed',
            title='Three species-level producer claims omit the deposited source strains',
            description='GenBank source features identify KX622596.1 as DK897, KX622597.1 as A47 and KX622598.1 as Mx48. The matching BGC0001426/1427/1428 producer items retain only NCBITaxon:34 and the species label, without strain qualifiers. Their BGC links still preserve traceability, making this a bounded provenance defect rather than proof of species-wide production. Qualify these exact source claims without altering taxon IDs, evidence grades or unresolved product identity. DK1622 is already represented by a strain-rank taxon.',
            target_ids=[tid], field_paths=['producer_organisms[1].strain', 'producer_organisms[2].strain', 'producer_organisms[3].strain'],
            evidence_ids=['owner', 'inventories', 'sequences', 'taxonomy', 'ownership', 'local-search'],
            owner_paths=strain_owners, rule_id='review-checklist:Producer organisms; docs/CURATION.md:MIBiG producer strain context',
            native_severity='minor', normalization_reason='Explicit BGC/accession provenance remains, but inspected strain qualifiers have been lost. This finding does not establish exact-congener biosynthesis.'))
    else:
        findings.append(dict(finding_id='F1', issue_key='mibig-BGC0001422-myxochromide-a-proline-stereo',
            category='identity', severity='major', status='open', certainty='provisional',
            title='Assigned proline stereochemistry requires source-level adjudication',
            description='The source-matching graph gives an R-proline fragment on virtual hydrolysis; BGC0001422\'s own module-5 substrate depicts S-proline. The independent 2006 A-series table names L-proline, but concerns M. xanthus DK1050 rather than M. fulvus HW-1. Sequence-based substrate predictions cannot prove the final product configuration, and the cited 2017 HW-1 evidence is unavailable. Thus the discrepancy warrants an explicit qualification and exact-strain check, not an automatic stereo flip. The two undefined alanine centers and stereo_complete:false are internally correct and must not be filled from another strain.',
            target_ids=[tid], field_paths=['chemical_structure.smiles', 'chemical_structure.standard_inchi', 'chemical_structure.standard_inchi_key', 'producer_organisms[0]', 'discussions'],
            evidence_ids=['owner', 'chemistry', 'core', 'proline', 'mibig-1422', 'si2006', 'paper-access'],
            owner_paths=correction_owners, rule_id='review-checklist:Structure/Producer organisms; preserve stereochemical and strain scope',
            native_severity='major', normalization_reason='An assigned center conflicts with source context and may change exact identity, but prediction and another strain\'s experiment do not confirm that this owner is wrong.'))

    checks = [check(slug + '-inspect', tid, 'Canonical inspection before assessment captured current base and all target/context hashes.'),
              check('strict', tid, 'Initial just wrapper failed before validation because sandboxed uv could not access its existing global cache. A separately recorded native retry passed.', required=False, expected=2),
              check('strict-native', tid, 'Documented just validate-strict passed on both exact owners: two scanned, zero errors; no attached graph components.'),
              check('chemistry', tid, 'Pinned RDKit2026.03.5 verifies both owner SMILES/InChI/key roundtrips, stereo flags, and all five versioned MIBiG compound structures, formulae and masses.'),
              check('core', tid, 'Diagnostic virtual hydrolysis and molecule renderings expose residue connectivity/configuration; not a source experiment.'),
              check('proline-context', tid, 'All five source module-5 proline depictions were parsed and compared with the owner-derived fragments; evidence remains prediction/inference.'),
              check('corpus', tid, 'Fresh full-corpus PATHS/filesystem integrity check passed.'),
              check('labels', tid, 'Fresh configured ID-label gate passed with retained nonblocking warnings and no-adapter skips; this is not chemical-equivalence verification.'),
              check('local-search', tid, 'Ignored-inclusive bounded identifier/name/slug search covered curation, raw and native corpus, components, reviews, docs, scripts, src, conf and tests.', required=False),
              check('queue', tid, 'Native pending-record diagnostics regenerated to a session-specific TSV, without editing the tracked queue or promoting status.', required=False),
              check('si-read', tid, 'Existing PyMuPDF1.28.2 read all14 PDF pages and rendered pages1-3; required relevant figures/tables inspected.', required=False),
              check('si-more', tid, 'Rendered and visually inspected PDF pages4,5,11 for configurations, A2-A4 structures and DK1622 knockout methods.', required=False),
              check('qc-final', tid, 'PRIOR executed native QC: 752 passed,3 skipped,2 dependency warnings; all3115 strict, exact reproduction, raw provenance, generated site and history/component gates passed. Corpus and maintained inputs have not changed since that run. It preceded two already-merged scoped successor reviews and an archive test; later focused/canonical checks covered those. Not a fresh run and not scientific approval.', root=P)]
    checks += [dict(check_id='primary2017', name='Exact strain and compound primary attribution', status='unavailable', required=True,
                    target_ids=[tid], evidence_ids=['paper-access', 'paper-metadata'],
                    summary='The cited PMID28128551 full paper remains HTTP403. Metadata/abstract and the independent 2006 supplement do not establish every2017 exact-strain/congener assertion.'),
               dict(check_id='imodulondb', name='Structured expression-source applicability', status='not_applicable', required=False,
                    target_ids=[tid], summary='The owner names no gene, protein, regulator, pathway step or transcriptomics dataset. Structured MIBiG/GenBank/taxonomy sources were inspected first. Genes in contextual publications are not owner claims; no iModulonDB coverage or absence claim is made.')]
    if not a:
        checks.append(dict(check_id='npatlas-equivalence', name='NPAtlas exact equivalence', status='unavailable', required=True,
                           target_ids=[tid], evidence_ids=['npatlas-access'], summary='Official NPA017265 API returned403. A dynamic frontend search snippet is not proof that the entry is missing or nonexact. No alternate retrieval attempted.'))

    evidence = [local('owner', 'record_content', owner, 'Entire raw YAML, all nested evidence, discussions and history',
                      'Exact generated MINTED/SEEDED owner; four source concepts and an OPEN shared-structure task.' if a else 'Exact generated MINTED/SEEDED owner; one source concept, one NPAtlas xref and no discussion.'),
                local('resolved', 'record_content', W / (slug + '-resolved.json'), 'Complete native read_natural_product analysis view', 'No inline or referenced graph; raw and resolved claims agree.'),
                local('inventories', 'database', W / 'source-rows.json', 'Full parsed rows with line numbers and complete row_digest values; five exact owner rows plus12 label-context rows',
                      'Current inventories match the earlier captures. Exact rows are MIBiG1713-1716 and NPClassifier1579.' if a else 'Current inventories match the earlier captures. Exact rows are MIBiG1710 and NPClassifier2341.',
                      search_scope='Structured full scans of seven maintained TSVs: mibig_compounds, npclassifier, lotus_occurrences, chebi_structures, chebi_origins, antibioticmech_inchikeys, pubchem_bioassay. Exact keys plus myxochrom label context. No matching exact-key occurrence, ChEBI grounding, sibling or assay rows in this bounded snapshot; not global registry absence.'),
                local('chemistry', 'validation', W / 'chemistry.json', slug + ' and corresponding version4 MIBiG structures',
                      f"Computed {c['formula']}, charge{c['charge']}, exact mass{c['exact_mass']} Da; {c['specified']} specified/{c['unspecified']} undefined tetrahedral centers; ring sizes{c['ring_sizes']}; {len(c['carbon_double_bonds'])} specified E carbon double bonds. Exact roundtrips passed. These are calculations, not measurements."),
                local('core', 'validation', W / 'core-diagnostics.json', 'Virtual ester/amide hydrolysis excluding terminal carboxamides',
                      'Owner-derived proline is ONIBWKKTOPOVIA-SCSAIBSYSA-N (R); positional connectivity and stereotags were preserved computationally. A diagnostic only, not proof of an actual hydrolysis experiment.'),
                local('proline', 'database', W / 'proline-context.json', 'Module5 substrate structures and declared evidence methods',
                      'All five MIBiG entries depict ONIBWKKTOPOVIA-BYPYZUCNSA-N (S) proline. BGC0001425 marks structure-based inference; the others mark sequence-based prediction. None is independent experimental proof of final product stereochemistry.', 'partial'),
                remote('sequences', O, 'sequences.xml', 'authority', 'Five GBSeq source features, organism/strain/taxid qualifiers, accession versions and citation fields',
                       'KX622595.1:DK1622; KX622596.1:DK897; KX622597.1:A47; KX622598.1:Mx48; KX622592.1:HW-1. All cite PMID28128551. Sequence annotation anchors the isolate and deposited locus, not exact metabolite production.'),
                remote('taxonomy', O, 'taxonomy.xml', 'authority', 'TaxId246197,34,483219; ScientificName/Rank/Lineage',
                       '246197 and483219 are strain-rank nodes;34 is species-rank. Names match the owners. Myxococcota/Myxococcales lineages support MYXOBACTERIAL; taxonomy is independent of chemical filing and natural-versus-engineered origin.'),
                remote('paper-metadata', O, 'PMID28128551.json', 'database', 'EuropePMC core metadata and abstract',
                       'PMID28128551 resolves to DOI10.1021/acschembio.6b00953, the2017 myxochromide genome-mining study. Abstract describes122genomes,16candidate producers and4new core types, not exact per-strain structural or knockout evidence.', 'partial'),
                remote('paper-access', O, 'paper28128551.html', 'primary_source', 'Denial payload only, not article content',
                       'HTTP403 stops full2017 paper access. No alternate copy retrieved; absence of accessible full text is not evidence of absence.', 'unknown'),
                remote('si-metadata', W, 'PMID16506259.json', 'database', 'EuropePMC PMID/DOI/title/authors metadata',
                       'PMID16506259 and DOI10.1002/anie.200503737 identify the independent2006 Wenzel et al. study; authors/title match the publisher supplement.'),
                remote('si2006', W, 'wenzel2006-si.pdf', 'primary_source', 'PDF pages2-5, Figures1-2/Table1; page11; full14-page extraction plus visual inspection',
                       'A3 was characterized from DK1050, a DK1622 derivative; Figures1-2 depict a glutamine-based19-membered core shared by A2-A4. Table1 assigns L-proline; A3 has an18-carbon octaenoyl chain. Page11 reports a verified DK1622 mchC insertion mutant lacking myxochromide A. This is independent2006 evidence, not the denied2017 article and not proof for HW-1, DK897, A47 or Mx48.', 'partial'),
                local('local-search', 'search', W / 'local-search.log', 'rg --no-ignore --hidden -l -i; exact command and times in receipt',
                      'No matching implemented curation-table row or prior canonical review was found in the bounded search, including ignored files. Existing queue/archived checkpoints and other myxochromide owners are contextual leads, not reviewed members.',
                      search_scope='curation data/raw data/natural_products data/causal_graphs reviews docs scripts src conf tests; myxochromide, both key prefixes, five BGCs,28128551,NPA017265. Ignored and hidden files included; compressed archives are not claimed text-exhaustive.'),
                local('discovery', 'search', W / 'discovery.json', 'Queries, inspected source and access-limited leads',
                      'Bounded independent-paper search found the2006 supplement.1993Wiley open failed;2018PMC page returned reCAPTCHA. Those texts and snippets do not support findings.',
                      search_scope='Web search on2026-10-13; three recorded queries. Sources are leads until inspected. No mirror or denied-source alternate retrieval.'),
                local('ownership', 'record_content', Path('docs/CURATION.md'), 'Implemented structure/locus/strain/xref paths and reserved decisions table',
                      'Strain table can qualify exact source rows without grading changes. Generic decisions.tsv is not consumed. REPLACE_WITH_CHEBI is narrow and cannot be assumed to support this unresolved multi-entry migration.'),
                local('native-gates', 'validation', P / 'qc-final.log', 'Prior actual full native QC at unchanged scientific inputs',
                      'All3115strict/reproduction checks passed;752tests passed,3skipped. Read-only corpus hash audit and fresh strict/corpus/labels support bounded reuse; review outputs get separate current canonical checks.'),
                local('capture', 'validation', W / 'capture.json', 'Current full corpus and34 prior review-pair hash attestation',
                      '3115owners/243components and34prior immutable observations reverified. Only the unrelated ferrichrome xref-exclusion row changed among old myxochromide inspection inputs; that diff was read. All captured current inputs match base606252dd3.'),
                local('rules', 'record_content', Path('docs/HARMONIZATION.md'), 'Identity, producer/locus separation, filing and taxonomy rules', 'Multi-label classification files UNCLASSIFIED, without erasing NRPS/PKS source assertions; MIBiG quality flags do not establish truth.')]
    for n in accessions:
        evidence.append(remote('mibig-' + str(n), O, f'BGC000{n}.4.json', 'database', 'accession/version/status, compounds[0], taxonomy, loci, classes, legacy references',
                               'Active exact version4 compound graph, source taxon, sequence accession and PMID match the inventory. MIBiG method, formula and mass were checked;0..0 bounds remain unstated. Quality and placeholder reviewers are not truth signals. No latest-version claim.'))
    if not a:
        evidence.append(remote('npatlas-access', O, 'NPA017265.json', 'authority', 'Official API denial payload only', 'HTTP403. Current exact equivalence unresolved; no evidence that the xref is wrong or absent.', 'unknown'))

    def assess(aid, area, topic, outcome, summary, ids, **extra):
        return dict(assessment_id=aid, area=area, topic=topic, outcome=outcome, summary=summary, target_ids=[tid], evidence_ids=ids, **extra)

    mibig_ids = ['mibig-' + str(n) for n in accessions]
    assessments = [assess('identity', 'identity', 'One exact owner, source concepts and chemical form', 'concern',
                           'Resolved by path, identifier and key, not label. Source-concept hashes and exact imported graph agree, but the source-to-biological-product assignment has the provisional conflict in F1. Do not merge the two A-labelled owners or equate C44 and C45 forms.', ['owner', 'inventories', 'chemistry', 'core', 'proline', 'si2006']),
                   assess('structure', 'consistency', 'Internal chemical encodings and stereochemical resolution', 'supported',
                           'Pinned RDKit regenerates the exact stored InChI/key and MIBiG formula/mass; the stereo_complete flag accurately describes the encoded graph, not confidence that its assignments are scientifically correct.', ['owner', 'chemistry']),
                   assess('grounding', 'grounding', 'Minted identity and external equivalence', 'supported' if a else 'unknown',
                           'Minting follows source/accession:compound-index hashes, with no exact-key ChEBI match in the pinned inventory. No xrefs, parents or congener relations need equivalence checks.' if a else 'Minting follows the pinned inventory and source hash. NPA017265 is faithfully imported but exact equivalence remains unverified after403; no exclusion is justified by the denial.', ['owner', 'inventories'] + ([] if a else ['npatlas-access'])),
                   assess('classification', 'representation', 'Computed filing versus asserted classes, taxonomy and origin', 'supported',
                           'Amino-acid/peptide singleton files AMINO_ACIDS_AND_PEPTIDES.' if a else 'The two NPClassifier pathway labels correctly file UNCLASSIFIED; it is not missing classification.',
                           ['owner', 'inventories', 'rules'], dimensions=[dict(name='classification_model', value='npclassifier.gnps2.org@2026-09-07', definition='Pinned computed classification, not admission evidence', evidence_ids=['owner', 'inventories']), dict(name='bgc_classes', value='NRPS and PKS', definition='Independent MIBiG-asserted biosynthetic classes', evidence_ids=mibig_ids), dict(name='taxon_group', value='MYXOBACTERIAL', definition='NCBI lineage facet, independent of chemical filing and origin', evidence_ids=['taxonomy'])]),
                   assess('origin', 'evidence', 'Natural origin and exact-strain scope', 'unknown',
                           'NATURAL_PRODUCT is a MIBiG-origin assertion, not a computed classifier result. Independent native A-series evidence supports natural production generally, but F1 prevents unqualified exact-graph attribution. Isotope-feeding or heterologous experiments in contextual papers do not change this owner to ENGINEERED.', ['owner', 'paper-metadata', 'si2006'] + mibig_ids),
                   assess('producers', 'scope', 'Organism identity, strain and producer evidence tier', 'concern' if a else 'unknown',
                           'DK1622 is strain-scoped; its imported knockout grade is consistent with an independent native-disruption experiment. Three other items appropriately stay SOURCE_ASSERTION, but omit source strains (F2). That evidence does not verify the disputed exact molecule.' if a else 'HW-1 has a strain-rank taxon matching the GenBank source. SOURCE_ASSERTION is faithful; DK1622 experiments cannot upgrade HW-1. Exact HW-1 product configuration remains unresolved.', ['owner', 'sequences', 'taxonomy', 'si2006'] + mibig_ids),
                   assess('bgcs', 'provenance', 'Versioned active loci, methods and product links', 'supported',
                           ('All four retained version4 entries are active and accession/host/reference fields agree. DK1622 alone has an imported knockout method; other loci remain CLUSTER_UNSTATED.' if a else 'The retained version4 BGC0001422 entry is active and its accession, HW-1 host and reference fields agree. Its absent locus method correctly yields CLUSTER_UNSTATED.') + ' Empty boundaries are not converted to sequence-length intervals. This confirms source fidelity, not final exact-product identity.', ['owner', 'inventories', 'sequences'] + mibig_ids),
                   assess('evidence', 'evidence', 'Claim-level citation placement and publication identity', 'supported',
                           'Each producer and BGC has its own DATABASE_ASSERTION citing PMID28128551 and entry-level provenance; DOI/PMID metadata resolve. No paraphrases pose as quoted snippets. Independent2006 support is review evidence, not silently inserted as a record citation.', ['owner', 'paper-metadata', 'si-metadata'] + mibig_ids),
                   assess('optional', 'completeness', 'Occurrences, activity, targets, quantities and clinical assertions', 'not_applicable',
                           'The complete owner has no occurrences, pure-compound assay, summary activity, molecular target, clinical status, dataset, parent/congener or cross-corpus link to adjudicate. Bounded source scans do not add any. Optional absence is not a defect or a global evidence-absence claim.', ['owner', 'resolved', 'inventories', 'local-search']),
                   assess('mechanism', 'graph', 'Full resolved pathway and component ownership', 'not_applicable',
                           'No inline graph, biosynthetic_pathway or causal_graph_refs exists on this exact owner; native resolved view and component hash inventory agree. Contextual mch genes are not curated mechanism claims. The whole-corpus243-component objective remains in scope elsewhere.', ['owner', 'resolved', 'capture']),
                   assess('discussions', 'completeness', 'Unresolved identity questions', 'concern',
                           'The OPEN shared-structure task preserves the four-entry equivalence question but does not describe the newly identified core conflict or missing strains.' if a else 'No discussion qualifies the newly identified source proline discrepancy. A cited curator qualification is a bounded proposed action, not a completed correction.', ['owner', 'core', 'proline', 'si2006']),
                   assess('audit', 'provenance', 'Scientific status, history and generated ownership', 'supported',
                           'Both seed history events remain unchanged and status stays SEEDED. Source fields are generated; fixes belong to maintained source transforms or implemented tables, with guarded writing/history and reproduction. Current review does not authorize mutation or publication.', ['owner', 'ownership', 'capture', 'native-gates'])]

    actions = [dict(action_id='A1', finding_ids=['F1'], target_ids=[tid], owner_paths=correction_owners,
                    description='Adjudicate exact product structure, residue configurations and congener scope against the cited2017 evidence when legitimately accessible or user-provided. Retain the independent2006 comparison and explicit strain boundaries. First add a cited curator qualification if authorized; do not silently flip stereochemistry, change keys or transfer production evidence. ' + ('This four-source owner would require a separately audited multi-row migration; the current REPLACE_WITH_CHEBI path is not a generic fix.' if a else 'Do not choose a different-strain A-series structure as a replacement for HW-1. A supported source correction needs an implemented guarded path; no exact ChEBI replacement has been selected.'),
                    acceptance_checks=['Independent rendering and pinned RDKit verification of any candidate; distinguish A2/A3/A4 side chains and peptide constitution/configuration.', 'Evidence maps the chosen structure to each exact source strain; method grades remain claim-specific.', 'No owner collision, unsourced label merge, loss of original source claims, or unreviewed component/assay transfer.', 'For authorized curation: guarded writer with event, source-specific seeder canary, strict validation, verify-corpus, verify-reproduction and full qc.'], generator='scripts/seed_from_sources.py after an implemented reviewed input correction; not direct seeded-field editing')]
    if a:
        actions.append(dict(action_id='A2', finding_ids=['F2'], target_ids=[tid], owner_paths=strain_owners,
                            description='Qualify BGC0001426:1=DK897,1427:1=A47,1428:1=Mx48 using the existing strain table and complete source-row digests captured here; cite the corresponding GenBank version. Preserve F1 and do not infer strain taxon IDs or change evidence grades. A later identity migration must independently reassess these qualifications.',
                            acceptance_checks=['Reject duplicate, stale or mismatched source rows.', 'Only the three exact producer items gain strain qualifiers and separate CURATOR_INFERENCE evidence.', 'Retain all four source concepts, taxon IDs, original references and locus grades.', 'Run seeder dry run and one-owner canary, inspect exact diff, verify reproduction and full QC after authorized curation.'], generator='scripts/seed_from_sources.py'))
    else:
        actions.append(dict(action_id='A2', finding_ids=[], target_ids=[tid], owner_paths=source_owners,
                            description='Reassess exact NPA017265 identity only when permitted source content becomes available. Preserve its current unknown state; do not use the separate NPA009587 search hit as a substitute.',
                            acceptance_checks=['Compare exact constitution, isotope and stereochemical resolution of the actual identifier.', 'A later observation must distinguish access recovery from proof of equivalence or a confirmed mismatch.']))
    source = inspection['source']
    source['state'] = 'git_commit'
    finished = now()
    rid = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + slug
    review = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=REPO,
                  title='Myxochromide A exact-owner scientific review: ' + ('C45 four-source structure' if a else 'C44 HW-1 structure'),
                  started_at=capture['started_at'], finished_at=finished,
                  reviewer=dict(identity='Codex', kind='agent', independence='self_review', independence_basis='Same assistant performing the ongoing repository audit; no independent human approval claimed.'),
                  skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial', verdict='needs_curation', native_verdict='SEEDED retained; REVIEWED sign-off not met', scientific_review=True,
                  summary='One provisional identity blocker and one confirmed minor strain-provenance defect; scientific attribution remains partial.' if a else 'One provisional major proline-configuration concern; primary HW-1 attribution and NPAtlas equivalence remain partial.',
                  source=source, scope=dict(description='One exact native owner, every nested claim, history and complete resolved mechanism.',
                                           selection='Next exact owner in the full3115-owner campaign queue; same-label sibling is context only and receives its own review.', coverage='partial', population_size=1, reviewed_target_ids=[tid],
                                           exclusions=[dict(target='Other3114 native owners and their components', reason='Not assessed by this single-record observation; the full3115-owner/243-component objective, prior partial follow-ups and unassessed remainder remain active.')]),
                  targets=[target], checks=checks, evidence=evidence, assessments=assessments, findings=findings, actions=actions,
                  limitations=['The cited2017 full paper is unavailable after403; no alternate retrieval.2006 evidence is independent and must not be generalized across strains.',
                               'The1993 publisher page failed to fetch and the2018PMC page returned reCAPTCHA; neither text supports findings.',
                               'Registry and source agreement prove representation fidelity, not natural-product identity. Predicted module substrates are not experimental residue assignments.',
                               'Full native QC is a verified prior run; fresh strict, chemistry, corpus, labels and later canonical/contract checks cover this read-only observation. Existing label warnings/no-adapter skips remain.',
                               'Temporary evidence snapshots retain hashes and receipts; only the canonical review pair is newly written to the repository. No source PDF is redistributed.',
                               'All scientific records, generated pages, source tables, graph components and native statuses are unchanged. This is not completion of the whole-corpus goal.'] + ([] if a else ['NPAtlas NPA017265 exact equivalence remains unknown after403.']),
                  notes=['Inspect captures match exact current base606252dd3. The only changed prior context, the ferrichrome xref-exclusion row, is unrelated and was inspected.',
                         'The local checklist still mentions reserved decisions.tsv generically; the current review profile and CURATION implementation explicitly override that obsolete suggestion.',
                         'Poppler commands were unavailable on PATH; the existing PyMuPDF runtime succeeded. A broad filesystem binary search was deliberately cancelled after finding the alternative; no absence claim depends on it.'],
                  tags=['record-review', 'myxochromide', 'partial', 'read-only'])
    output = W / (slug + '-review-v2.yaml')
    with output.open('x') as f:
        yaml.dump(review, f, Dumper=NoAliasSafeDumper, sort_keys=False, allow_unicode=False, width=100)
    written.append(dict(review_id=rid, content=str(output), target=target['path']))
with (W / 'reviews-v2.json').open('x') as f:
    json.dump(written, f, indent=2)
print(json.dumps(written, indent=2))
