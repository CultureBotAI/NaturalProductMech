import hashlib
import json
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

W = Path(__file__).parent
O = Path('/private/tmp/npmech-myxochromide-review-RK6G2y')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipts = []
for name in ['sequences.xml', 'taxonomy.xml', 'paper28128551.html', 'NPA017265.json', 'PMID28128551.json'] + [f'BGC000{i}.4.json' for i in [1422, 1425, 1426, 1427, 1428]]:
    r = json.loads((O / (name + '.receipt.json')).read_text())
    assert sha(O / name) == r['sha256']
    receipts.append(dict(file=str(O / name), **r))
sequences = []
for e in ET.parse(O / 'sequences.xml').getroot().findall('GBSeq'):
    features = []
    for f in e.findall('GBSeq_feature-table/GBFeature'):
        if f.findtext('GBFeature_key') not in ['source', 'misc_feature']:
            continue
        features.append(dict(key=f.findtext('GBFeature_key'), location=f.findtext('GBFeature_location'), qualifiers=[dict(name=q.findtext('GBQualifier_name'), value=q.findtext('GBQualifier_value')) for q in f.findall('GBFeature_quals/GBQualifier')]))
    sequences.append(dict(accession=e.findtext('GBSeq_accession-version'), definition=e.findtext('GBSeq_definition'), length=e.findtext('GBSeq_length'), organism=e.findtext('GBSeq_organism'), features=features, references=[dict(title=r.findtext('GBReference_title'), journal=r.findtext('GBReference_journal'), pubmed=r.findtext('GBReference_pubmed')) for r in e.findall('GBSeq_references/GBReference')]))
taxa = [dict(taxid=t.findtext('TaxId'), name=t.findtext('ScientificName'), rank=t.findtext('Rank'), lineage=t.findtext('Lineage')) for t in ET.parse(O / 'taxonomy.xml').getroot().findall('Taxon')]
mibig = []
for i in [1422, 1425, 1426, 1427, 1428]:
    d = json.loads((O / f'BGC000{i}.4.json').read_text())
    mibig.append({k: d[k] for k in ['accession', 'version', 'status', 'taxonomy', 'loci', 'compounds', 'legacy_references']})
paper = json.loads((O / 'PMID28128551.json').read_text())['resultList']['result'][0]
out = dict(inspected_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'), receipts=receipts, sequences=sequences, taxonomy=taxa, mibig=mibig, paper={k: paper.get(k) for k in ['id', 'doi', 'title', 'authorString', 'abstractText', 'isOpenAccess', 'pmcid']})
with (W / 'source-summary.json').open('x') as f:
    json.dump(out, f, indent=2)
print(json.dumps({k: v for k, v in out.items() if k not in ['receipts', 'mibig']}, indent=2))
