import json
from pathlib import Path

from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, rdMolDescriptors

W = Path(__file__).parent
O = Path('/private/tmp/npmech-myxochromide-review-RK6G2y')
assert rdBase.rdkitVersion == '2026.03.5'
results = []

def inspect(label, smiles, key, inchi=None):
    m = Chem.MolFromSmiles(smiles)
    assert m is not None
    assert Chem.MolToInchiKey(m) == key, label
    if inchi:
        assert Chem.MolToInchi(m) == inchi
        assert Chem.MolToInchiKey(Chem.MolFromInchi(inchi)) == key
    centers = Chem.FindMolChiralCenters(m, includeUnassigned=True)
    double_bonds = [dict(atoms=[b.GetBeginAtomIdx(), b.GetEndAtomIdx()], stereo=str(b.GetStereo())) for b in m.GetBonds() if b.GetBondType() == Chem.BondType.DOUBLE and b.GetBeginAtom().GetAtomicNum() == b.GetEndAtom().GetAtomicNum() == 6]
    stereo = [dict(type=str(s.type), specified=str(s.specified), centered_on=s.centeredOn) for s in Chem.FindPotentialStereo(m)]
    result = dict(label=label, key=key, formula=rdMolDescriptors.CalcMolFormula(m), inchi=Chem.MolToInchi(m), charge=Chem.GetFormalCharge(m), exact_mass=Descriptors.ExactMolWt(m), chiral_centers=centers, specified=sum(c != '?' for _, c in centers), unspecified=sum(c == '?' for _, c in centers), ring_sizes=[len(r) for r in m.GetRingInfo().AtomRings()], carbon_double_bonds=double_bonds, potential_stereo=stereo)
    results.append(result)
    return result

for slug, accessions in [('myxochromide-a', [1425, 1426, 1427, 1428]), ('myxochromide-a-2', [1422])]:
    d = json.loads((W / (slug + '-resolved.json')).read_text())
    s = d['chemical_structure']
    r = inspect(slug, s['smiles'], s['standard_inchi_key'], s['standard_inchi'])
    assert s['stereo_complete'] == all(i['specified'] == 'Specified' for i in r['potential_stereo'])
    for i in accessions:
        live = json.loads((O / f'BGC000{i}.4.json').read_text())['compounds'][0]
        r = inspect(f'BGC000{i}.4', live['structure'], s['standard_inchi_key'])
        assert r['formula'] == live['formula']
        assert abs(r['exact_mass'] - live['mass']) < 0.00001
out = dict(rdkit_version=rdBase.rdkitVersion, results=results, note='Computed formula, mass in Da, rings and stereo are graph diagnostics, not experimental assignments or permission to transfer claims between same-label structures.')
with (W / 'chemistry.json').open('x') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
