import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from naturalproductmech.graph_components import read_natural_product
from naturalproductmech.curate.structure_corrections import row_digest

W = Path(__file__).parent
P = Path('/private/tmp/npmech-ferrichrome-publish-i31W5V')
O = Path('/private/tmp/npmech-myxochromide-review-RK6G2y')
R = Path.cwd()
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
started = now()
cp = P / 'review-campaign-checkpoint.json'
assert sha(cp) == 'e6a2e52026d9528ae78f52cbb86abb5059858d5e6ada64da6463830ac1c33844'
prior = json.loads(cp.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == prior['base']
subprocess.run(['git', 'diff', '--quiet', 'HEAD'], check=True)
owners = {r['path']: r for r in prior['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
assert len(owners) == 3115 and len(components) == 243
actual = {str(p.relative_to(R)) for folder in ('data/natural_products', 'data/causal_graphs') for p in (R / folder).rglob('*.yaml')}
assert actual == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(R / path) == row['sha256'], path
for row in prior['all_review_observations']:
    assert sha(R / row['yaml']) == row['yaml_sha256']
    assert sha(R / row['markdown']) == row['markdown_sha256']
assert len(prior['all_review_observations']) == 34
source_receipts = []
for path in sorted(O.glob('*.json.receipt.json')):
    receipt = json.loads(path.read_text())
    payload = O / path.name.removesuffix('.receipt.json')
    assert sha(payload) == receipt['sha256'], path
    source_receipts.append(receipt)
old_inspect = json.loads((O / 'myxochromide-a-inspect.json').read_text())
contexts = [i['path'] for i in old_inspect['source']['inputs']]
changed_contexts = [i['path'] for i in old_inspect['source']['inputs'] if sha(R / i['path']) != i['sha256']]
assert changed_contexts == ['curation/mibig_xref_exclusions.tsv'], changed_contexts
selected = prior['pending_in_priority_order'][:2]
assert [Path(p).stem for p in selected] == ['myxochromide-a', 'myxochromide-a-2']
keys = set()
for path in selected:
    d = read_natural_product(R / path)
    assert not owners[path]['graph_components']
    keys.add(d['chemical_structure']['standard_inchi_key'])
    slug = Path(path).stem
    targets = json.loads((O / (slug + '-targets.json')).read_text())
    assert targets['targets'][0]['target_id'] == d['identifier']
    with (W / (slug + '-targets.json')).open('x') as f:
        json.dump(targets, f, indent=2)
    with (W / (slug + '-resolved.json')).open('x') as f:
        json.dump(d, f, indent=2)
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(W / (slug + '-targets.json'))]
    for context in sorted(set(contexts)):
        command += ['--input', context]
    receipt = dict(command=command, started_at=now())
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    inspection = json.loads(result.stdout)
    for inp in inspection['source']['inputs']:
        assert hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + inp['path']])).hexdigest() == inp['sha256']
    output = W / (slug + '-inspect.json')
    with output.open('x') as f:
        f.write(result.stdout)
    receipt.update(finished_at=now(), exit_code=0, log=str(output), log_sha256=sha(output))
    with (W / (slug + '-inspect.receipt.json')).open('x') as f:
        json.dump(receipt, f, indent=2)
rows = {}
for name in ('mibig_compounds', 'npclassifier', 'lotus_occurrences', 'chebi_structures', 'chebi_origins', 'antibioticmech_inchikeys', 'pubchem_bioassay'):
    with (R / 'data/raw' / (name + '.tsv')).open() as f:
        rows[name] = [dict(line=i, source_row_sha256=row_digest(row), **row) for i, row in enumerate(csv.DictReader(f, delimiter='\t'), 2)
                      if row.get('standard_inchi_key') in keys or 'myxochrom' in ' '.join(row.values()).lower()]
assert rows == json.loads((O / 'source-rows.json').read_text())
with (W / 'source-rows.json').open('x') as f:
    json.dump(rows, f, indent=2)
report = dict(started_at=started, finished_at=now(), base=base, prior_checkpoint=str(cp), prior_checkpoint_sha256=sha(cp),
              previous_turn_classification='no progress on record coverage: prior publication verified; next safe action is myxochromide review',
              owners_verified=3115, components_verified=243, prior_observations_verified=34,
              exact_git_tree_inputs_verified=True, changed_contexts_since_research=changed_contexts,
              source_row_counts={n: len(v) for n, v in rows.items()},
              inherited_access_count=len(prior['access_stops_no_alternate_retrieval']), source_receipts=source_receipts,
              prior_native_checks=dict(workspace=str(P), qc_receipt_sha256=sha(P / 'qc-final.receipt.json'), labels_receipt_sha256=sha(P / 'labels.receipt.json'),
                                       note='Previously executed native QC and labels at current scientific tree. New reviews require fresh canonical/contract checks.'))
with (W / 'capture.json').open('x') as f:
    json.dump(report, f, indent=2)
print(json.dumps(report, indent=2))
