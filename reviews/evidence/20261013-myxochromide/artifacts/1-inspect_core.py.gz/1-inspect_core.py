import json
from pathlib import Path

from rdkit import Chem, rdBase
from rdkit.Chem import Draw

W = Path(__file__).parent
assert rdBase.rdkitVersion == '2026.03.5'
results = []
for slug in ['myxochromide-a', 'myxochromide-a-2']:
    d = json.loads((W / (slug + '-resolved.json')).read_text())
    m = Chem.MolFromSmiles(d['chemical_structure']['smiles'])
    Draw.MolToFile(m, str(W / (slug + '-structure.png')), size=(1400, 850))
    rw = Chem.RWMol(m)
    cuts = []
    for carbon in m.GetAtoms():
        if carbon.GetAtomicNum() != 6 or not any(b.GetBondType() == Chem.BondType.DOUBLE and b.GetOtherAtom(carbon).GetAtomicNum() == 8 for b in carbon.GetBonds()):
            continue
        for b in carbon.GetBonds():
            hetero = b.GetOtherAtom(carbon)
            if b.GetBondType() == Chem.BondType.SINGLE and hetero.GetAtomicNum() in [7, 8] and hetero.GetDegree() > 1:
                cuts.append((carbon.GetIdx(), hetero.GetIdx()))
    for carbon, hetero in cuts:
        rw.RemoveBond(carbon, hetero)
        oxygen = rw.AddAtom(Chem.Atom(8))
        rw.AddBond(carbon, oxygen, Chem.BondType.SINGLE)
        atom = rw.GetAtomWithIdx(hetero)
        atom.SetNoImplicit(False)
        atom.SetNumExplicitHs(0)
    hydrolyzed = rw.GetMol()
    Chem.SanitizeMol(hydrolyzed)
    Chem.AssignStereochemistry(hydrolyzed, cleanIt=True, force=True)
    residues = []
    for f in Chem.GetMolFrags(hydrolyzed, asMols=True):
        residues.append(dict(smiles=Chem.MolToSmiles(f), key=Chem.MolToInchiKey(f), centers=Chem.FindMolChiralCenters(f, includeUnassigned=True)))
    results.append(dict(slug=slug, broken_bonds=cuts, fragments=residues))
out = dict(rdkit_version=rdBase.rdkitVersion, diagnostic='Virtual amide/ester hydrolysis excluding terminal carboxamides; preserves stereotags while recalculating priorities. Not a source observation or a proposed record.', results=results)
with (W / 'core-diagnostics.json').open('x') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
