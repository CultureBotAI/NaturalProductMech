import copy
import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
R = Path.cwd()
REPO = 'CultureBotAI/NaturalProductMech'


class NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read(name):
    return json.loads((W / name).read_text())


def owner(path, role):
    return dict(repository=REPO, path=path, role=role)


def local_evidence(eid, kind, path, locator, summary, support='supports', reference=None):
    p = Path(path)
    return dict(evidence_id=eid, kind=kind, reference=reference or str(p), locator=locator,
                accessed_at=now(), support=support, summary=summary, snapshot_sha256=sha(p))


def fetched(eid, kind, name, locator, summary, support='supports'):
    receipt = read(name + '.receipt.json')
    assert sha(W / name) == receipt['sha256']
    evidence = local_evidence(eid, kind, W / name,
                              locator + '; captured ' + receipt['finished_at'] + '; local payload ' + str(W / name),
                              summary, support, receipt['url'])
    if kind == 'search':
        evidence['search_scope'] = ('Exact public URL ' + receipt['url'] + ' at ' + receipt['finished_at']
                                    + '; HTTP403 and metadata/abstract only. Retrieval stopped for this paper, including alternate hosts/paths. No absence-of-evidence claim follows.')
    return evidence


chemistry = {r['slug']: r for r in read('chemistry.json')}
metadata = {r['id']: r for r in read('literature-metadata.json')['resultList']['result']}
configs = [
    ('compound-3', 'BGC0002321.3', '4', '31081214', 'CP034458.1', 'Metschnikowia aff. pulcherrima', 'species'),
    ('compound-3-2', 'BGC0002165.3', '8', '31553484', 'CH445335.1', 'Parastagonospora nodorum SN15', 'strain'),
    ('compound-3-3', 'BGC0002173.2', '2', '30977375', 'DS499598.1', 'Aspergillus fumigatus A1163', 'strain'),
]
written = []
for slug, bgc, index, pmid, genome, taxon, rank in configs:
    inspect = read(slug + '-inspect-final.json')
    target = copy.deepcopy(inspect['targets'][0])
    tid = target['target_id']
    path = target['path']
    doc = read(slug + '-resolved.json')
    c = chemistry[slug]
    first = slug == 'compound-3'
    for item in target['owner_paths']:
        if item['path'] == 'curation/mibig_xref_exclusions.tsv':
            item['role'] = 'Implemented complete-row-pinned literal PubChem and NPAtlas exclusions; no decision applies here'
    source = copy.deepcopy(inspect['source'])
    source['state'] = 'git_commit'
    checks = []

    def check(label, summary, required=True):
        receipt = read(label + '.receipt.json')
        assert receipt['exit_code'] == 0
        assert sha(Path(receipt['log'])) == receipt['log_sha256']
        checks.append(dict(check_id=label, name=label, status='passed', required=required,
                           command=shlex.join(receipt['command']), exit_code=0, expected_exit_code=0,
                           target_ids=[tid], summary=summary,
                           scope_note='Actual run ' + receipt['started_at'] + ' to ' + receipt['finished_at']
                           + '; log SHA256 ' + receipt['log_sha256']))

    check('strict-final', 'All three selected exact owners passed closed-schema validation with zero errors.')
    check('qc-current', 'Full native QC passed on the same unchanged 47a738c2 scientific inputs: 741 tests passed, 3 skipped, 2 dependency warnings. All 3115 owners passed schema validation; provenance, generated site, exact reproduction, graph/history tests and PATHS.tsv integrity passed. This is deterministic evidence, not biological sign-off.')
    check('labels-current', 'Configured label gate passed: 13434 canonical, 646 synonyms, 35 exceptions, 499 nonblocking warning mismatches and 4649 no-adapter skips. Minted compound identity is not certified by this gate; exact producer taxon/name/rank were independently checked against NCBI.')
    check('chemistry', 'Pinned RDKit2026.03.5 independently regenerated the exact stored Standard InChI and key, and matched the versioned MIBiG compound. This checks representation, not experimental identity.')
    check('search-final', 'Ignored-inclusive identifier, name, slug, key and citation search covered repository files except .git and .venv. Complete selected-owner parsing and structured source-table scans supplied the bounded absence findings.', False)
    check('queue-current', 'Native pending queue contains the full corpus; diagnostics do not count as completed scientific reviews. No status was promoted.', False)
    check('queue-final', 'Queue regenerated after this batch assessment:8930 diagnostic rows cover all3115 distinct owners plus the non-owner unresolved_taxa.tsv diagnostics. Native SEEDED statuses are unchanged; structured review completion is tracked separately.', False)
    checks.append(dict(check_id='primary-claims', name='Exact compound primary-source assessment',
                       status='passed' if first else 'unavailable', required=True, target_ids=[tid],
                       evidence_ids=['paper', 'figure', 'supplement'] if first else ['metadata', 'access'],
                       summary=('Full paper methods/results/discussion and Figure2 plus relevant supplementary spectra and SNF2 panels were inspected. This completed assessment identifies a proposed identity and two curation findings; it does not certify a definitively elucidated compound.' if first else
                                'The publisher returned HTTP403. Metadata and abstract cannot establish the paper-local compound3 structure, experimental strain/context, or a compound-specific production/cluster method. No alternate-route retrieval was attempted.')))
    checks.append(dict(check_id='imodulondb', name='Structured expression-source applicability',
                       status='not_applicable', required=False, target_ids=[tid],
                       summary='The owner asserts no named gene/protein/regulator/module or transcriptomics dataset. Exact MIBiG, taxonomy and GenBank source adapters were used first. Contextual genes in the paper/sequence annotation are not additional owner assertions; no iModulonDB coverage or absence claim is made.'))
    evidence = [
        local_evidence('owner', 'record_content', R / path, 'Complete raw YAML, discussions and both history entries',
                       'Exact generated, MINTED, SEEDED owner. No xrefs, occurrences, bioactivity summaries/measurements, pathway, molecular targets, clinical assertions, datasets, related_records or causal_graph_refs/inline graphs are present. The existing needs-a-name discussion explicitly queues paper-local numbering.', reference=path),
        local_evidence('resolved', 'record_content', W / (slug + '-resolved.json'), 'Complete native read_natural_product result, verified equal to the current owner',
                       'Resolved mechanism has no attached components or hidden mechanism claims. Raw YAML and resolved JSON have distinct hashes.'),
        local_evidence('inventories', 'database', W / 'source-rows.json', 'Complete parsed exact-key scans of seven pinned TSV inventories with row numbers',
                       'Exactly one MIBiG row for ' + bgc.split('.')[0] + ':' + index + ' and one NPClassifier row. No exact-key match in the pinned LOTUS, ChEBI structure/origin, AntibioticMech or PubChem BioAssay inventories. This is not a live/global registry absence claim.'),
        local_evidence('chemistry', 'validation', W / 'chemistry.json', slug + ' result from RDKit2026.03.5',
                       f"Stored SMILES regenerates {c['key']} and exact InChI; formula {c['formula']}, charge {c['formal_charge']}, computed neutral monoisotopic mass {c['exact_mass']} Da. {c['specified_centers']} specified and {c['unspecified_centers']} unspecified tetrahedral centers agree with stereo_complete. These are calculations, not measurements."),
        fetched('mibig', 'database', bgc + '.json', 'Exact accession/version; compounds[' + str(int(index)-1) + '], loci, taxonomy, biosynthesis classes and legacy references',
                'Active entry names compound3 at exact index ' + index + '; stored structure, host, locus bounds, method list and classes match. Quality/questionable and reviewer metadata are not scientific truth signals. This verifies the pinned version, not a claim that it is the latest version.'),
        fetched('taxonomy', 'authority', 'taxonomy.xml', 'Exact direct Taxon node for ' + doc['producer_organisms'][0]['taxon_id'],
                taxon + ' resolves at rank ' + rank + '; its lineage contains Fungi. A taxon/group classification does not prove compound production.'),
        fetched('genome', 'authority', genome + '-region.xml', 'GBSeq and source/CDS features within the exact requested BGC interval; returned coordinates are rebased to the window',
                ('CP034458.1 interval1429481..1436146 is 6666nt, chromosomeIII, strain APC1.2. CDS annotations connect MPUL0C04960/70/80/90 to Pul3/4/2/1 and QBM88525.1..QBM88528.1. These are contextual mappings, not new native protein assertions.' if first else
                 'CH445335.1 interval1238225..1260054 is 21830nt, SN15 scaffold11. CDSs SNOG_07860..07866 have EAT85326.1/EAT85327.2..EAT85332.2 protein accessions and hypothetical-product annotations; no experimental SthB mapping is inferred.' if slug == 'compound-3-2' else
                 'DS499598.1 interval2415644..2423329 is 7686nt, A1163 scaffold5. AFUB_071550/071560/071569/071570 encode annotated putative/hypothetical products EDP50814.1..EDP50817.1. Annotation alone does not prove the exact compound3 pathway.')),
        fetched('metadata', 'primary_source', 'literature-metadata.json', 'EuropePMC PMID:' + pmid + ' title, DOI, abstract and publication links only',
                metadata[pmid]['title'] + '; DOI:' + metadata[pmid]['doi'] + '. ' +
                ('The abstract concerns yeast SNF2 regulation; the full text was separately inspected.' if first else
                 'The abstract establishes native cryptic-cluster activation for stemphyloxinII(1) and heterologous/cell-free SthB aldolase work, not which context produced compound3.' if slug == 'compound-3-2' else
                 'The abstract concerns fumihopasideA, afum deletion/reconstitution and heat/UV protection. It does not identify compound3 or establish its assay/production context.'), 'supports' if first else 'partial'),
        local_evidence('scope-proof', 'validation', W / 'final-resumption.json', 'Ignored-inclusive complete owner/component hash comparison and exact Git-tree verification',
                       'All3115 owners,243 components and26 prior immutable observations are unchanged; every captured input equals its bytes at commit47a738c235579895703f4f76b6af05cadaf31c99. This review assesses that exact revision, which also matches the current scientific content.'),
    ]
    evidence[2]['search_scope'] = 'Complete structured scans of mibig_compounds, npclassifier, lotus_occurrences, chebi_structures, chebi_origins, antibioticmech_inchikeys and pubchem_bioassay TSVs. Repository rg --no-ignore --hidden included ignored/hidden files except .git and .venv; no universal absence inference.'
    if first:
        evidence.extend([
            fetched('paper', 'primary_source', 'paper31081214.xml', 'PMID31081214; DOI10.1111/mmi.14272; PMC6851878; Results compound analysis, PUL transcription and SNF2 complementation, Discussion and Experimental Procedures',
                    'APC1.2(CCOS978) wild type, W8(CCOS1866) spontaneous snf2 mutant and complemented derivatives were studied. The paper properly designates the isolate M.aff.pulcherrima. Compound3 is proposed as a di-N-hydroxylated cyclodileucine intermediate or shunt product, not a fully characterized identity. UPLC-HR-HESI-MS and isotope feeding support C12H22N2O4 and a two-leucine-derived backbone. Reduced PUL transcripts and restored compound secretion after SNF2 complementation support correlation at the PUL locus, not a direct PUL-gene knockout. The antifungal assays compare whole yeast cells, not purified compound3.'),
            local_evidence('figure', 'primary_source', W / 'media/MMI-112-317-g002.jpg', 'Figure2B, bottom compound3 structure and question mark; Figure2A, WT/W8/complemented chromatograms',
                           'Visually inspected proposed connectivity has two carbonyls, two N-hydroxyls and two isobutyl substituents without assigned stereochemistry, matching the stored graph. Caption reports compound3 m/z259.165[M+H]+ and C12H22N2O4. The panel and accompanying text qualify the identity as proposed.', reference='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC6851878/supplementaryFiles'),
            local_evidence('supplement', 'primary_source', W / 'media/MMI-112-317-s001.pdf', 'Supplemental FiguresS1-S6 text; S4 spectra on PDFpages5-6 and S5/S6 on pages8-9 visually inspected',
                           'S3 compares a synthetic standard for compound1, not compound3. S4 compound3 spectra support incorporation of two leucine carbon backbones; neither mass shifts nor formula determine all bond positions or stereochemistry. S5/S6 localize the regulatory mutation to SNF2/MPUL0C08850 and document random-genomic complementation, not perturbation of the PUL cluster.', reference='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC6851878/supplementaryFiles'),
        ])
    else:
        access_name = 'paper31553484.pdf' if slug == 'compound-3-2' else 'paper30977375.html'
        evidence.append(fetched('access', 'search', access_name, 'HTTP403 error payload, not full paper or supporting information',
                                'Required primary figures, methods and exact compound-number mapping are unavailable. The first web-tool access was unavailable; a request to the same public URL returned403. Retrieval stopped for this source; no alternate path or host bypass.', 'unknown'))
    assessments = []

    def assess(aid, area, topic, outcome, summary, eids, dimensions=None):
        a = dict(assessment_id=aid, area=area, topic=topic, outcome=outcome, summary=summary,
                 target_ids=[tid], evidence_ids=eids)
        if dimensions:
            a['dimensions'] = dimensions
        assessments.append(a)

    assess('identity', 'identity', 'Paper-local exact identity and chemical boundaries', 'concern' if first else 'unknown',
           ('Figure2B establishes that the imported graph represents the paper\'s proposed compound3, not pulcherriminic acid or cyclodileucine. The missing qualification is a material evidence-status defect (F1), not proof of wrong connectivity. No replacement structure or extra stereochemistry is justified.' if first else
            'The versioned database graph is unambiguous, but the exact paper-local compound3 assignment and experimental stereochemistry cannot be checked from the abstract. Do not rename it after the end product, merge it with another compound3, or promote status.'),
           ['owner', 'mibig', 'chemistry'] + (['paper', 'figure', 'supplement'] if first else ['metadata', 'access']),
           [dict(name='exact-key', value=c['key'], definition='Stored exact owner identity, not a proposed replacement', evidence_ids=['owner','chemistry']),
            dict(name='stereo-resolution', value=f"{c['specified_centers']} specified/{c['unspecified_centers']} unspecified centers", definition='Computed representation only; experimental assignment is assessed separately', evidence_ids=['chemistry'])])
    assess('representation', 'consistency', 'Structure-source roundtrip', 'supported',
           'SMILES, InChI and key agree under the pinned chemistry runtime and match the exact MIBiG compound index. stereo_complete correctly describes encoded tetrahedral resolution. Formula/mass are review calculations because the owner does not assert those optional fields.', ['owner','mibig','chemistry'])
    assess('grounding', 'grounding', 'Minted identity and exact equivalence', 'supported',
           'No pinned3-star ChEBI exact-key match supports grounding; keeping the content-hashed minted ID is consistent with the inventory. No xref, broader-parent or sibling-equivalence assertion needs to be repaired. This conclusion does not assert that no registry name exists.', ['owner','inventories'])
    assess('classification', 'representation', 'Independent origin, taxon and chemical-class facets', 'supported',
           'Filing and non-glycoside prediction match NPClassifier@2026-09-07 and PATHS.tsv; BGC classes remain source assertions. FUNGAL agrees with the independently resolved taxon lineage. Natural-product origin comes from the MIBiG claim rather than structural similarity. ' +
           ('For this source, native WT secretion supports natural origin of the detected feature, but proposed exact identity must remain qualified.' if first else
            'Natural versus engineered production of this specific numbered compound is not resolved from the abstract; retain that limit instead of treating taxonomy as production evidence. ' + ('TERPENE/SACCHARIDE describe the cluster; they do not require every intermediate, including this non-glycoside graph, to contain a sugar.' if slug == 'compound-3-3' else '')),
           ['owner','inventories','mibig','taxonomy'] + (['paper'] if first else ['metadata','access']))
    assess('producer', 'scope', 'Strain and biological-origin evidence', 'concern' if first else 'unknown',
           ('The native isotope/secretion experiments concern APC1.2(CCOS978), not an unspecified species-wide sample. M.aff.pulcherrima and BGC_CORRELATED are appropriately conservative; the missing explicit strain is F2. Natural isolate, spontaneous mutant and complemented derivative must not be conflated.' if first else
            taxon + ' is a strain-level taxon and matches the sequence source. SOURCE_ASSERTION honestly preserves the database grade; native versus engineered production of compound3 remains unverified. No transfer from the end-product abstract is justified.'),
           ['owner','mibig','taxonomy','genome'] + (['paper'] if first else ['metadata','access']),
           [dict(name='taxon-rank', value=rank, definition='NCBI rank for the exact producer taxon ID', evidence_ids=['taxonomy']),
            dict(name='producer-grade', value=doc['producer_organisms'][0]['evidence_basis'], definition='Native record grade, not upgraded by this review', evidence_ids=['owner','mibig'])])
    assess('origin', 'evidence', 'Natural versus engineered origin of the exact compound', 'supported' if first else 'unknown',
           ('The paper detects the feature assigned to proposed compound3 in wild-type APC1.2 culture, supporting natural origin at the explicitly proposed identity resolution. Mutant/complemented experiments are distinct contexts and do not justify calling all samples unmodified.' if first else
            'NATURAL_PRODUCT is faithfully imported from an asserted database origin, but the abstract does not distinguish native production of this exact compound3 from heterologous reconstruction or another experimental context. This biological facet remains unknown despite correct fungal taxonomy and computed chemical filing.'),
           ['owner','mibig'] + (['paper','figure'] if first else ['metadata','access']))
    assess('cluster', 'evidence', 'Versioned active BGC and compound-specific locus support', 'supported' if first else 'unknown',
           ('The active BGC0002321v3 locus maps to the four PUL genes. The primary paper compares expression/secreted metabolites across WT, snf2 mutant and complemented strains. SNF2 is a separate broad regulator; its rescue is not a direct PUL-cluster causal experiment. CLUSTER_CORRELATED is therefore not upgraded.' if first else
            'Active accession/version, exact interval and named host are confirmed. Empty MIBiG method metadata correctly remains CLUSTER_UNSTATED. Abstract experiments on the overall pathway/end product cannot be assigned to compound3 without full-text inspection.'),
           ['owner','mibig','genome'] + (['paper','supplement'] if first else ['metadata','access']))
    assess('activity', 'scope', 'Compound-specific activity and mechanism', 'supported',
           'The owner correctly makes no pure-compound assay, target, activity-summary, pathway or causal-graph assertion. ' +
           ('Whole-cell antifungal competition and SNF2 regulation must not be promoted to activity of purified compound3.' if first else
            'End-product phytotoxicity/SthB catalysis or fumihopasideA heat/UV protection cannot be projected to this numbered intermediate.'),
           ['owner','resolved'] + (['paper'] if first else ['metadata']))
    assess('optional', 'completeness', 'Occurrences, cross-corpus links, clinical and dataset fields', 'not_applicable',
           'These optional claims are not present in the complete owner; exact-key source scans support the absence of seeded occurrences/assays/sibling joins in the listed inventories. No need to populate unrelated optional fields merely to complete a review.', ['owner','resolved','inventories'])
    assess('naming', 'nomenclature', 'Existing paper-local naming question', 'supported',
           'The needs-a-name discussion acknowledges the unresolved descriptive name. A paper-local compound number is not globally unique. ' +
           ('A proposed di-N-hydroxylated derivative may be described with explicit paper context; no approved common name or exact registry xref was established.' if first else
            'A descriptive name requires the inaccessible primary compound mapping; the generic label is already queued rather than silently treated as a common name.'), ['owner','mibig'] + (['paper'] if first else ['access']))
    assess('audit', 'provenance', 'History, deterministic validation and maintained ownership', 'supported',
           'Both history entries are seeding events, and SEEDED remains accurate. All required native deterministic checks passed. Scientific findings do not authorize edits or status promotion. Future producer corrections belong to the pinned strain table; a structure qualification can be a curator-prefixed discussion retained through guarded writers. Reserved decisions.tsv is not consumed.', ['owner','scope-proof'])
    findings, actions = [], []
    if first:
        uncertainty_owner = [owner(path, 'Only curator-prefixed discussion content is a maintained curator input; chemical_structure remains seeder-owned'),
                             owner('docs/CURATION.md', 'Guarded discussion carry-forward and curation-event contract')]
        strain_owner = [owner('curation/mibig_producer_strains.tsv', 'Implemented complete-source-row-pinned strain qualification'),
                        owner('src/naturalproductmech/curate/producer_strains.py', 'Validated strain decision consumer'),
                        owner('scripts/seed_from_sources.py', 'Guarded generated producer emission')]
        findings = [dict(finding_id='F1', issue_key='compound3-BGC0002321-proposed-structure-unqualified', category='evidence', severity='major', status='open', certainty='confirmed',
                         title='The proposed chemical identity lacks its primary-source qualification',
                         description='The owner preserves a definite molecular graph but its only discussion concerns naming. The source identifies compound3 as a proposed di-N-hydroxylated intermediate/shunt product; Figure2 marks its structure as proposed and S4 supports composition/backbone rather than definitive connectivity. MIBiG attribution and stereo_complete:false do not communicate this separate constitutional uncertainty. Add an explicit cited qualification; this finding does not establish a different correct structure or justify deleting the owner.',
                         target_ids=[tid], field_paths=['chemical_structure','discussions'], evidence_ids=['owner','paper','figure','supplement'], owner_paths=uncertainty_owner,
                         rule_id='review-checklist:Structure; review-checklist:Discussions; docs/CURATION.md:Preserve disagreement', native_severity='major',
                         normalization_reason='The omitted evidence status materially overstates confidence in exact chemical identity. It is not a blocker because the stored graph matches the proposed source figure and wrong connectivity has not been proved.'),
                    dict(finding_id='F2', issue_key='compound3-BGC0002321-missing-APC1-2-strain', category='provenance', severity='minor', status='open', certainty='confirmed',
                         title='The experimentally named APC1.2 strain is omitted',
                         description='PMID31081214 methods identify APC1.2(CCOS978), and CP034458.1 names strain APC1.2. The producer uses species-rank NCBITaxon2163413 without a strain field. Retain the isolate context without changing the taxon ID, grading, BGC host or proposed structural assignment.',
                         target_ids=[tid], field_paths=['producer_organisms[0].strain'], evidence_ids=['owner','paper','taxonomy','genome'], owner_paths=strain_owner,
                         rule_id='review-checklist:Producer organisms', native_severity='minor',
                         normalization_reason='A bounded provenance omission: the source taxon and conservative evidence grade are not wrong, but the known strain qualifier is missing.')]
        actions = [dict(action_id='A1', finding_ids=['F1'], target_ids=[tid], owner_paths=uncertainty_owner,
                        description='In a separately authorized curation, add a cited curator-prefixed discussion explicitly distinguishing the proposed di-N-hydroxylated identity from confirmed formula/backbone evidence. Preserve chemistry and unresolved stereochemistry; do not claim a structure correction.',
                        generator='Guarded read/write_validated_natural_product with record_curation_event; then verify same-key reseed carry-forward',
                        acceptance_checks=['Cite Figure2B and the compound-analysis Results/S4; say proposed, not fully characterized.',
                                           'Keep the two stereocenters unassigned; do not upgrade producer/locus evidence or attach whole-cell activity to purified compound3.',
                                           'Verify curator-prefixed discussion survives reseeding and all other owners/components remain unchanged.',
                                           'Run strict validation, exact reproduction, site regeneration/check and full QC; save a linked successor without rewriting this review.']),
                   dict(action_id='A2', finding_ids=['F2'], target_ids=[tid], owner_paths=strain_owner,
                        description='Add an attributed APC1.2(CCOS978) strain qualification for BGC0002321:4 through the implemented complete-row-pinned table. Preserve the original database assertion and cite PMID31081214 separately.',
                        generator='scripts/seed_from_sources.py',
                        acceptance_checks=['Compute expected_source_row_sha256 with the existing row_digest on the complete untouched source row.',
                                           'Confirm the same source index/key, taxon, genome and version; reject source drift.',
                                           'Canary the one owner; preserve original chemistry, taxon ID, BGC_CORRELATED and CLUSTER_CORRELATED.',
                                           'Run strict, reproduction and full QC and prove unrelated owners/components unchanged.'])]
    limitations = [
        'This assesses one exact owner at commit47a738c235579895703f4f76b6af05cadaf31c99, whose scientific inputs still match the worktree. It is not a three-record category merge or an all-corpus scientific sign-off.',
        'RDKit validates internal representation, not experimental structure; database quality flags and green QC do not resolve scientific uncertainty.',
        'Evidence payloads/receipts are retained in the session workspace; stable public references, exact locators and hashes are recorded here. No Git publication or source-archive adoption occurred in this read-only review turn.',
        'All prior193 access limitations remain in the campaign; two new publisher403 stops apply to the other/current compound3 papers. No alternate-route access was used.',
    ]
    if first:
        limitations += ['Completion means the current record\'s assertions have been assessed, including a confirmed negative judgement about missing qualification. The proposed identity itself is not experimentally resolved, neither finding is fixed, and native REVIEWED status is not warranted.',
                        'No independent reanalysis of raw instrument/RNAseq files or the optional primer DOCX was performed; those are not required to adjudicate the existing compound-level claims. Relevant primary figures, spectra captions and methods were inspected.']
    else:
        limitations += ['Publisher full text/supporting information are unavailable. Exact chemical numbering, stereochemistry, native versus heterologous production context, and compound-specific pathway evidence remain unassessed. No finding is raised merely because the paper could not be accessed.']
    finished = now()
    rid = datetime.fromisoformat(finished.replace('Z','+00:00')).strftime('%Y%m%dT%H%M%SZ') + '-' + slug
    review = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=REPO,
                  title='Compound 3 (' + bgc + '): ' + ('proposed identity and isolate scope' if first else 'source-linked partial review'),
                  started_at='2026-10-13T15:04:31.228229Z', finished_at=finished,
                  reviewer=dict(identity='Codex', kind='agent', independence='self_review', independence_basis='Same assistant/thread as the corpus review campaign; not independent human sign-off.'),
                  skill='.claude/skills/review-yaml-record/SKILL.md', completion='completed' if first else 'partial',
                  verdict='needs_curation' if first else 'pass_with_limitations', scientific_review=True,
                  summary=('Completed assessment of the existing owner finds one major missing proposed-identity qualification and one minor missing strain qualifier. The graph matches the proposed primary figure, internal chemistry is consistent, and conservative locus grading is sound. No curation or scientific-status promotion performed.' if first else
                           'Exact versioned source representation, internal chemistry, producer taxonomy and sequence interval are consistent. Required full-text compound-specific identity/production checks remain unavailable after HTTP403; no confirmed new finding in the inspected subset. This is not a whole-record scientific pass.'),
                  source=source, targets=[target],
                  scope=dict(description='One exact owner; same-label records are context only. Full campaign denominator remains3115 owners and243 components.',
                             selection='Next exact pending owner from the exhaustive campaign queue; no sampling or scope reduction.', coverage='full' if first else 'partial', population_size=1,
                             reviewed_target_ids=[tid], exclusions=[dict(target='Other3114 owners', reason='Outside this single-record observation; retained in the full campaign checkpoint.')]),
                  checks=checks, evidence=evidence, assessments=assessments, findings=findings, actions=actions,
                  limitations=limitations,
                  notes=['Source state is git_commit because all input hashes were independently checked against Git47a738c2 before assessment. The observation does not silently replace stale provenance.',
                         'Save/contract checks occur after authoring and are captured in separate receipts, not invented as pre-save successes.',
                         'Only review artifacts are authorized here. No record/history/status mutation, regeneration, GitHub issue, PR or paid provider call.'])
    output = W / (rid + '.yaml')
    with output.open('x') as f:
        yaml.dump(review, f, Dumper=NoAliasDumper, sort_keys=False, allow_unicode=False, width=100)
    written.append(dict(slug=slug, review_id=rid, draft=str(output), completion=review['completion'], verdict=review['verdict']))
with (W / 'authored-reviews-v3.json').open('x') as f:
    json.dump(written, f, indent=2)
print(json.dumps(written, indent=2))
