import json
from pathlib import Path

from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, rdMolDescriptors

W = Path(__file__).parent
assert rdBase.rdkitVersion == '2026.03.5'
rows = []
for slug, bgc, index in (('compound-3', 'BGC0002321.3', 3),
                         ('compound-3-2', 'BGC0002165.3', 7),
                         ('compound-3-3', 'BGC0002173.2', 1)):
    d = json.loads((W / (slug + '-resolved.json')).read_text())
    s = d['chemical_structure']
    m = Chem.MolFromSmiles(s['smiles'])
    assert m is not None
    inchi = Chem.MolToInchi(m)
    key = Chem.MolToInchiKey(m)
    assert inchi == s['standard_inchi'] and key == s['standard_inchi_key']
    source = json.loads((W / (bgc + '.json')).read_text())['compounds'][index]
    assert source['name'] == d['label']
    assert Chem.MolToInchiKey(Chem.MolFromSmiles(source['structure'])) == key
    centers = Chem.FindMolChiralCenters(m, includeUnassigned=True)
    row = dict(slug=slug, identifier=d['identifier'], rdkit_version=rdBase.rdkitVersion,
               inchi=inchi, key=key, formula=rdMolDescriptors.CalcMolFormula(m),
               formal_charge=Chem.GetFormalCharge(m), exact_mass=Descriptors.ExactMolWt(m),
               chiral_centers=centers, unspecified_centers=sum(c == '?' for _, c in centers),
               specified_centers=sum(c != '?' for _, c in centers),
               stereo_complete=s['stereo_complete'], exact_mibig_match=True)
    assert s['stereo_complete'] == (row['unspecified_centers'] == 0)
    rows.append(row)
with (W / 'chemistry.json').open('x') as f:
    json.dump(rows, f, indent=2)
print(json.dumps(rows, indent=2))
