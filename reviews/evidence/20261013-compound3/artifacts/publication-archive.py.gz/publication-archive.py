"""Preserve historical local evidence; publisher content stays reference-only."""

import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path('/private/tmp/npmech-compound3-review-2EX0Ug')
DEST = ROOT / 'reviews/evidence/20261013-compound3'
PUBLISHER = {'literature-metadata.json', 'paper31081214.xml', 'paper31081214-supp.zip',
             'paper31553484.pdf', 'paper30977375.html'}


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


checkpoint = json.loads((WORK / 'review-campaign-checkpoint.json').read_text())
assert digest((WORK / 'review-campaign-checkpoint.json').read_bytes()) == (
    '574ee60f7aff2a85fd9bb0090989b66d3c1fe2d86fc78e1b0494f7a1bf530f4b')
artifacts = []
reference_only = []
(DEST / 'artifacts').mkdir(parents=True, exist_ok=False)


def retain(path, name=None, blob=None):
    blob = path.read_bytes() if blob is None else blob
    stored = gzip.compress(blob, mtime=0)
    relative = 'artifacts/' + (name or path.name) + '.gz'
    with (DEST / relative).open('xb') as handle:
        handle.write(stored)
    artifacts.append(dict(original_path=str(path), path=relative, bytes=len(blob),
                          sha256=digest(blob), stored_bytes=len(stored),
                          stored_sha256=digest(stored)))


for path in sorted(WORK.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    if path.name in PUBLISHER or path.parent.name == 'media':
        receipt_path = (WORK / 'paper31081214-supp.zip.receipt.json' if path.parent.name == 'media'
                        else path.with_name(path.name + '.receipt.json'))
        receipt = json.loads(receipt_path.read_text())
        if path.parent.name != 'media':
            assert digest(path.read_bytes()) == receipt['sha256']
        reference_only.append(dict(
            original_path=str(path), sha256=digest(path.read_bytes()), bytes=path.stat().st_size,
            source_url=receipt['url'], accessed_at=receipt['finished_at'],
            reason='Publisher article, figure, supplement, abstract or denial payload; reference-only.',
            locator=str(path.relative_to(WORK)),
        ))
    else:
        retain(path)

inherited = checkpoint['inherited_scientific_access_stops']
assert digest(Path(inherited['checkpoint']).read_bytes()) == inherited['sha256']
retain(Path(inherited['checkpoint']), 'inherited-checkpoint.json')
retain(Path(__file__), 'publication-archive.py')

reviews = []
for slug in ['compound-3', 'compound-3-2', 'compound-3-3']:
    review_id = '20261013T152822Z-' + slug
    path = Path('reviews/structured') / review_id / 'review.yaml'
    markdown = path.with_suffix('.md')
    doc = yaml.safe_load((ROOT / path).read_text())
    owner = doc['targets'][0]['path']
    raw = subprocess.check_output(['git', 'show', f"{doc['source']['git_revision']}:{owner}"])
    retain(Path(owner), slug + '-raw.yaml', raw)
    by_hash = {}
    for row in artifacts + reference_only:
        by_hash.setdefault(row['sha256'], []).append(row)
    snapshots = []
    for evidence in doc['evidence']:
        if 'snapshot_sha256' not in evidence:
            continue
        matches = by_hash[evidence['snapshot_sha256']]
        assert len(matches) == 1, (evidence['evidence_id'], matches)
        snapshots.append(dict(evidence_id=evidence['evidence_id'],
                              original_path=matches[0]['original_path'],
                              sha256=evidence['snapshot_sha256']))
    reviews.append(dict(review_id=review_id, path=str(path), sha256=digest((ROOT / path).read_bytes()),
                        markdown=str(markdown), markdown_sha256=digest((ROOT / markdown).read_bytes()),
                        source_base=doc['source']['git_revision'], evidence_snapshots=snapshots))

manifest = dict(
    format_version=1, recorded_at=datetime.now(timezone.utc).isoformat(),
    corpus_base=checkpoint['base'], pr='https://github.com/CultureBotAI/NaturalProductMech/pull/913',
    publication_issue=916, scientific_issues=[914, 915],
    checkpoint=str(WORK / 'review-campaign-checkpoint.json'),
    artifacts=artifacts, reference_only_sources=reference_only, reviews=reviews,
    runtime_directories=['/private/tmp/npmech-rdkit-2026.03.5/share/RDKit',
                         '/private/tmp/npmech-rdkit-2026.03.5/bin/python'],
    snapshot_note='Historical observations and source hashes are retained unchanged. '
                  'Publication does not advance scientific coverage or resolve experimental uncertainty.',
)
with (DEST / 'manifest.json').open('x') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(artifacts=len(artifacts), reference_only=len(reference_only),
                     stored_bytes=sum(row['stored_bytes'] for row in artifacts))))
