import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

from naturalproductmech.graph_components import read_natural_product

ROOT = Path.cwd()
WORK = Path(__file__).parent
PRIOR = Path('/private/tmp/npmech-bacilysin-review-ixdJYA/review-campaign-checkpoint.json')


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


started = now()
assert sha(PRIOR) == '7ac7abc75d1ad8bd83b0a7dc1d50d899b8296d70291a58cfc0cc698a9f9d1390'
prior = json.loads(PRIOR.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == prior['base']
owners = {r['path']: r for r in prior['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
assert {str(p.relative_to(ROOT)) for folder in ('data/natural_products', 'data/causal_graphs')
        for p in (ROOT / folder).rglob('*.yaml')} == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(ROOT / path) == row['sha256']
for row in prior['all_review_observations']:
    assert sha(ROOT / row['yaml']) == row['yaml_sha256']
    assert sha(ROOT / row['markdown']) == row['markdown_sha256']
inherited = prior['inherited_scientific_access_stops']
original = Path(inherited['checkpoint'])
assert sha(original) == inherited['sha256']
stops = json.loads(original.read_text())['access_stops_no_alternate_retrieval'] + prior['new_access_stops']
assert len(stops) == 193
with (WORK / 'inherited-access-stops.json').open('x') as handle:
    json.dump(stops, handle, indent=2)
matches = [r for r in stops if any(token in json.dumps(r).lower() for token in
           ('31081214', '31553484', '30977375', 'bgc0002321', 'bgc0002165', 'bgc0002173'))]
with (WORK / 'access-stop-matches.json').open('x') as handle:
    json.dump(dict(checked_at=now(), checked_count=len(stops), matches=matches), handle, indent=2)
previous_inspect = json.loads(Path('/private/tmp/npmech-bacilysin-review-ixdJYA/bacilysin-inspect.json').read_text())
contexts = [r['path'] for r in previous_inspect['source']['inputs']
            if not r['path'].startswith('data/natural_products/amino_acids_and_peptides/bacilysin')]
selected = prior['pending_in_priority_order'][:3]
assert selected == ['data/natural_products/amino_acids_and_peptides/compound-3.yaml',
                    'data/natural_products/polyketides/compound-3-2.yaml',
                    'data/natural_products/terpenoids/compound-3-3.yaml']
contexts += selected
captures = []
keys = set()
for path in selected:
    doc = read_natural_product(ROOT / path)
    slug = Path(path).stem
    keys.add(doc['chemical_structure']['standard_inchi_key'])
    target = dict(target_id=doc['identifier'], path=path, label=doc['label'], record_class='NaturalProductRecord',
                  kind='generated', owner_paths=previous_inspect['targets'][0]['owner_paths'])
    target_path = WORK / (slug + '-targets.json')
    with target_path.open('x') as handle:
        json.dump(dict(targets=[target]), handle, indent=2)
    with (WORK / (slug + '-resolved.json')).open('x') as handle:
        json.dump(doc, handle, indent=2)
    graph_paths = [g['path'] for g in owners[path]['graph_components']]
    command = [str(ROOT / '.venv/bin/python'), 'scripts/record_review.py', 'inspect', '--targets', str(target_path)]
    for context in sorted(set(contexts + graph_paths)):
        command += ['--input', context]
    receipt = dict(command=command, started_at=now())
    result = subprocess.run(command, capture_output=True, text=True)
    output = WORK / (slug + '-inspect.json')
    with output.open('x') as handle:
        handle.write(result.stdout)
    with (WORK / (slug + '-inspect.stderr')).open('x') as handle:
        handle.write(result.stderr)
    receipt.update(finished_at=now(), exit_code=result.returncode, log=str(output), log_sha256=sha(output))
    with (WORK / (slug + '-inspect.receipt.json')).open('x') as handle:
        json.dump(receipt, handle, indent=2)
    assert result.returncode == 0
    captures.append(dict(slug=slug, path=path, target_id=doc['identifier'], sha256=sha(ROOT / path),
                         key=doc['chemical_structure']['standard_inchi_key'], graphs=len(doc.get('causal_graphs', [])),
                         components=graph_paths))
rows = {}
for name in ('mibig_compounds', 'lotus_occurrences', 'chebi_structures', 'chebi_origins',
             'npclassifier', 'antibioticmech_inchikeys', 'pubchem_bioassay'):
    with (ROOT / 'data/raw' / (name + '.tsv')).open() as handle:
        rows[name] = [dict(line=line, **row) for line, row in enumerate(csv.DictReader(handle, delimiter='\t'), 2)
                      if row.get('standard_inchi_key') in keys]
with (WORK / 'source-rows.json').open('x') as handle:
    json.dump(rows, handle, indent=2)
report = dict(base=base, started_at=started, finished_at=now(), captures=captures,
              prior_checkpoint=str(PRIOR), prior_checkpoint_sha256=sha(PRIOR),
              owners_verified=3115, components_verified=243, prior_observations_verified=25,
              ignored_inclusive=True, previous_turn_classification=prior['this_turn_classification'])
with (WORK / 'capture.json').open('x') as handle:
    json.dump(report, handle, indent=2)
print(json.dumps(report, indent=2))
