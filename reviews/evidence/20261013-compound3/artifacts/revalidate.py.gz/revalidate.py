import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from naturalproductmech.graph_components import read_natural_product

W = Path(__file__).parent
R = Path.cwd()


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


started = now()
checkpoint = W / 'resumed-campaign-checkpoint.json'
assert sha(checkpoint) == '52734684ee09ef064a96f0e9378321fd42aecd471889b3fa624b3d770c2c0aa5'
cp = json.loads(checkpoint.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == cp['base']
owners = {r['path']: r for r in cp['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
assert len(owners) == 3115 and len(components) == 243
assert {str(p.relative_to(R)) for folder in ('data/natural_products', 'data/causal_graphs')
        for p in (R / folder).rglob('*.yaml')} == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(R / path) == row['sha256'], path
for row in cp['all_review_observations']:
    assert sha(R / row['yaml']) == row['yaml_sha256']
    assert sha(R / row['markdown']) == row['markdown_sha256']
for slug in ('compound-3', 'compound-3-2', 'compound-3-3'):
    old = json.loads((W / (slug + '-inspect-resumed.json')).read_text())
    assert old['source']['git_revision'] == base
    for item in old['source']['inputs']:
        assert sha(R / item['path']) == item['sha256'], item['path']
        assert hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + item['path']])).hexdigest() == item['sha256']
    assert read_natural_product(R / old['targets'][0]['path']) == json.loads((W / (slug + '-resolved.json')).read_text())
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(W / (slug + '-targets.json'))]
    for item in old['source']['inputs']:
        command.extend(['--input', item['path']])
    receipt = dict(command=command, started_at=now())
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout) == old
    output = W / (slug + '-inspect-final.json')
    with output.open('x') as f:
        f.write(result.stdout)
    receipt.update(finished_at=now(), exit_code=0, log=str(output), log_sha256=sha(output))
    with (W / (slug + '-inspect-final.receipt.json')).open('x') as f:
        json.dump(receipt, f, indent=2)
report = dict(started_at=started, finished_at=now(), base=base, owners=3115, components=243,
              observations=len(cp['all_review_observations']), ignored_inclusive=True,
              targets_and_context_unchanged=True, exact_git_tree_hashes_verified=True,
              previous_turn_classification='progress: completed existing full QC and branch cleanup; no scientific observation added')
with (W / 'final-resumption.json').open('x') as f:
    json.dump(report, f, indent=2)
print(json.dumps(report, indent=2))
