import collections
import copy
import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
R = Path.cwd()


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


prior_path = W / 'resumed-campaign-checkpoint.json'
prior = json.loads(prior_path.read_text())
assert sha(prior_path) == '52734684ee09ef064a96f0e9378321fd42aecd471889b3fa624b3d770c2c0aa5'
cp = copy.deepcopy(prior)
owners = {r['path']: r for r in cp['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
assert len(owners) == 3115 and len(components) == 243
assert {str(p.relative_to(R)) for folder in ('data/natural_products', 'data/causal_graphs')
        for p in (R / folder).rglob('*.yaml')} == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(R / path) == row['sha256'], path
for row in prior['all_review_observations']:
    assert sha(R / row['yaml']) == row['yaml_sha256']
    assert sha(R / row['markdown']) == row['markdown_sha256']

verification = {}
for label in ('qc-current', 'labels-current', 'strict-final', 'chemistry', 'search-final',
              'queue-final', 'validate-v3', 'save-compound-3', 'save-compound-3-2',
              'save-compound-3-3', 'canonical-final', 'contract-final'):
    p = W / (label + '.receipt.json')
    receipt = json.loads(p.read_text())
    assert receipt['exit_code'] == 0, label
    assert sha(Path(receipt['log'])) == receipt['log_sha256'], label
    verification[label] = dict(receipt=str(p), receipt_sha256=sha(p), **receipt)

saved = []
for item in json.loads((W / 'authored-reviews-v3.json').read_text()):
    folder = R / 'reviews/structured' / item['review_id']
    yp, mp = folder / 'review.yaml', folder / 'review.md'
    d = yaml.safe_load(yp.read_text())
    assert d == yaml.safe_load(Path(item['draft']).read_text())
    target = d['targets'][0]
    assert d['source']['git_revision'] == cp['base']
    for source in d['source']['inputs']:
        assert sha(R / source['path']) == source['sha256']
    row = dict(review_id=d['review_id'], yaml=str(yp.relative_to(R)), yaml_sha256=sha(yp),
               markdown=str(mp.relative_to(R)), markdown_sha256=sha(mp),
               target_id=target['target_id'], path=target['path'], verdict=d['verdict'],
               completion=d['completion'], scientific_review=d['scientific_review'],
               findings=d['findings'], finished_at=d['finished_at'])
    saved.append(row)
    cp['reviews'].append(row)
    cp['all_review_observations'].append(row)
    owners[target['path']]['review_state'] = d['completion']
    owners[target['path']]['latest_review_id'] = d['review_id']
    for f in d['findings']:
        cp['latest_finding_heads'].append(dict(f, review_id=d['review_id'], finished_at=d['finished_at']))

all_review_paths = {str(p.relative_to(R)) for p in (R / 'reviews/structured').rglob('review.yaml')}
assert all_review_paths == {r['yaml'] for r in cp['all_review_observations']}
assert len(all_review_paths) == 29
with (W / 'queue-final.tsv').open() as f:
    queue = list(csv.DictReader(f, delimiter='\t'))
queue_paths = {r['path'] for r in queue}
assert queue_paths & owners.keys() == owners.keys()
assert queue_paths - owners.keys() == {'curation/unresolved_taxa.tsv'}

cp['pending_in_priority_order'] = [p for p in prior['pending_in_priority_order']
                                  if owners[p]['review_state'] == 'unassessed']
assert set(cp['pending_in_priority_order']) == {p for p, r in owners.items() if r['review_state'] == 'unassessed'}
cp['partial_followups'] = sorted(p for p, r in owners.items() if r['review_state'] == 'partial')
cp['completed_review_owners'] = [p for p, r in owners.items() if r['review_state'] == 'completed']
cp['partial_reviews'] = len(cp['partial_followups'])
cp['scientific_review_bundles'] = len(cp['all_review_observations'])
cp['completed_scientific_reviews'] = len(cp['completed_review_owners'])
cp['unassessed_records'] = len(cp['pending_in_priority_order'])
assert (cp['completed_scientific_reviews'], cp['partial_reviews'], cp['unassessed_records']) == (1,20,3094)
assert cp['completed_scientific_reviews'] + cp['partial_reviews'] + cp['unassessed_records'] == 3115
cp['findings'] = dict(collections.Counter(f['severity'] for f in cp['latest_finding_heads'] if f['status'] in ('open','deferred')))
assert cp['findings'] == {'blocker':6,'major':7,'minor':1}

inherited = json.loads((W / 'inherited-access-stops.json').read_text())
assert len(inherited) == 193
new_stops = []
for pmid, doi, name in (('31553484','10.1002/chem.201904360','paper31553484.pdf'),
                        ('30977375','10.1021/acs.orglett.9b00984','paper30977375.html')):
    receipt = json.loads((W / (name + '.receipt.json')).read_text())
    assert receipt['status'] == 403 and sha(W / name) == receipt['sha256']
    stop = dict(aliases=['PMID:'+pmid,'DOI:'+doi], url=receipt['url'],
                reason='HTTP403 at the exact public URL after a web-tool unavailability result. Error payload is not full text; no alternate-route retrieval.',
                no_alternate_retrieval=True, scope='Primary paper figures, methods and compound-specific chemical/production context remain unassessed.',
                captured_at=receipt['finished_at'], payload_sha256=receipt['sha256'], receipt=str(W / (name + '.receipt.json')))
    new_stops.append(stop)
cp['new_access_stops'].extend(new_stops)
cp['access_stops_no_alternate_retrieval'] = inherited + new_stops
assert len(cp['access_stops_no_alternate_retrieval']) == 195
cp['access_stop_note'] = 'All193 inherited source limitations retained plus two publisher403 stops,195 total. The accessible yeast paper and supplements were inspected. The OA-resolver404 was an endpoint failure, not a denial of the available article.'
cp['recorded_at'] = now()
cp['branch'] = subprocess.check_output(['git','branch','--show-current'],text=True).strip()
cp['prior_checkpoint'] = str(prior_path)
cp['prior_checkpoint_sha256'] = sha(prior_path)
cp['previous_turn_classification'] = 'progress: completed fullQC and branch cleanup; no new scientific observation'
cp['this_turn_classification'] = 'progress: three exact-owner scientific reviews saved; one complete assessment with two findings and two honest partial assessments; all remaining owners and prior evidence/lineage retained'
cp['count_note'] = '29 observations covering21 distinct owners:1 completed assessment (needs_curation),20 partial owners,3094 unassessed. Completion is review coverage, not chemical-identity approval or native REVIEWED status. All3115 native records remain SEEDED;243 graph components retained.'
cp['required_work_remaining'] = 'Review all3094 unassessed owners and finish all20 partial assessments, including referenced graph components. Preserve all open findings and195 source-access limits. Finding remediation is separate from review completion and requires curation authorization.'
cp['frontier_note'] = 'Next two pending owners are ferrichrome-2.yaml and ferrichrome.yaml, distinct keys/owners. This does not retire the20 partial followups or the completed yeast review\'s two open curation findings.'
cp['publication'] = dict(status='not_requested_in_goal_continuation', committed=False, pushed=False,
                         note='Only three new immutable review pairs were saved; no record mutation, regeneration, GitHub issues or publication.')
cp['review_bundle_state'] = 'working_tree_new_immutable_bundles'
cp['live_sessions'] = 0
cp['verification'] = verification
cp['queue_verification'] = dict(rows=len(queue), owner_count=3115, non_owner_paths=['curation/unresolved_taxa.tsv'],
                                path=str(W/'queue-final.tsv'), sha256=sha(W/'queue-final.tsv'))
cp['new_reviews'] = saved
cp['scientific_inputs_unchanged'] = True
cp['initial_unsaved_draft_failures'] = ['YAML aliases rejected before saving; replaced by no-alias emission.',
                                        'Search access evidence lacked explicit search_scope; bounded URL/time/HTTP403 scope added before saving.']
cp['working_chemistry_command'] = verification['chemistry']['command']
cp['working_chemistry_note'] = 'PinnedRDKit2026.03.5 with existing NumPy; exact structure roundtrip and encoded stereochemistry, not experimental elucidation.'
cp['do_not_replay'] = ['Exclusive-write capture/revalidation/author/checkpoint helpers and named receipts; preserve them and choose new names for a fresh observation.']
output = W / 'review-campaign-checkpoint.json'
with output.open('x') as f:
    json.dump(cp, f, indent=2)
print(json.dumps(dict(checkpoint=str(output),sha256=sha(output),population=3115,components=243,
                      observations=29,completed_assessments=1,partial_owners=20,unassessed=3094,
                      open_findings=cp['findings'],access_limits=195,next_targets=cp['pending_in_priority_order'][:2]),indent=2))
