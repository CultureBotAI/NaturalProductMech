import hashlib
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

work = Path(__file__).parent
name, url = sys.argv[1:]


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


receipt = dict(url=url, started_at=now())
try:
    with urllib.request.urlopen(url, timeout=90) as response:
        data = response.read()
        receipt.update(status=response.status, final_url=response.url)
except urllib.error.HTTPError as error:
    data = error.read()
    receipt.update(status=error.code, error=str(error))
except (urllib.error.URLError, TimeoutError) as error:
    data = b''
    receipt.update(status=None, error=str(error), transport_failure=True)
receipt.update(finished_at=now(), sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))
with (work / name).open('xb') as handle:
    handle.write(data)
with (work / (name + '.receipt.json')).open('x') as handle:
    json.dump(receipt, handle, indent=2)
print(json.dumps(receipt, indent=2))
