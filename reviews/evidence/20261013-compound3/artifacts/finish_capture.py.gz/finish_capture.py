import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from naturalproductmech.graph_components import read_natural_product

ROOT = Path.cwd()
WORK = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


cp = json.loads((WORK / 'resumed-campaign-checkpoint.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == cp['base']
captures = []
started = now()
for old in json.loads((WORK / 'capture.json').read_text())['captures']:
    slug = old['slug']
    previous = json.loads((WORK / (slug + '-inspect.json')).read_text())
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(WORK / (slug + '-targets.json'))]
    for item in previous['source']['inputs']:
        command += ['--input', item['path']]
    receipt = dict(command=command, started_at=now())
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    current = json.loads(result.stdout)
    delta = [r['path'] for r in current['source']['inputs']
             if r['sha256'] != next(x['sha256'] for x in previous['source']['inputs'] if x['path'] == r['path'])]
    assert set(delta) == {'docs/CURATION.md', 'curation/mibig_xref_exclusions.tsv',
                          'src/naturalproductmech/curate/xref_exclusions.py'}
    assert sha(ROOT / old['path']) == old['sha256']
    assert read_natural_product(ROOT / old['path']) == json.loads((WORK / (slug + '-resolved.json')).read_text())
    output = WORK / (slug + '-inspect-resumed.json')
    with output.open('x') as handle:
        handle.write(result.stdout)
    receipt.update(finished_at=now(), exit_code=0, log=str(output), log_sha256=sha(output), changed_context=delta)
    with (WORK / (slug + '-inspect-resumed.receipt.json')).open('x') as handle:
        json.dump(receipt, handle, indent=2)
    captures.append(dict(slug=slug, target_unchanged=True, changed_context=delta))
report = dict(started_at=started, finished_at=now(), base=cp['base'], ignored_inclusive=True,
              owners=3115, components=243, unchanged_prior_observations=25, observations=26,
              publication_changed_owners=['data/natural_products/amino_acids_and_peptides/bacilysin-2.yaml'],
              captures=captures, checkpoint=str(WORK / 'resumed-campaign-checkpoint.json'),
              checkpoint_sha256=sha(WORK / 'resumed-campaign-checkpoint.json'),
              assessment='All three changed context files were inspected in PR908: the NPAtlas exclusion extension '
                         'and two exact BGC0000888 decisions do not affect these targets, which have no xrefs. '
                         'Their structures, source rows and claim grades remain unchanged; judgements use fresh47a738c2 capture.',
              initial_capture_failure='The first resumption assertion omitted the known consumer file from its expected context delta; '
                                      'no new inspection file was written by that attempt. The exhaustive campaign checkpoint was retained.')
with (WORK / 'resumption.json').open('x') as handle:
    json.dump(report, handle, indent=2)
print(json.dumps(report, indent=2))
