import collections
import copy
import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

from naturalproductmech.graph_components import read_natural_product

ROOT = Path.cwd()
WORK = Path(__file__).parent
PRIOR = Path('/private/tmp/npmech-bacilysin-review-ixdJYA/review-campaign-checkpoint.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


started = now()
assert sha(PRIOR) == '7ac7abc75d1ad8bd83b0a7dc1d50d899b8296d70291a58cfc0cc698a9f9d1390'
cp = json.loads(PRIOR.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == '47a738c235579895703f4f76b6af05cadaf31c99'
owners = {r['path']: r for r in cp['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
assert {str(p.relative_to(ROOT)) for folder in ('data/natural_products', 'data/causal_graphs')
        for p in (ROOT / folder).rglob('*.yaml')} == owners.keys() | components.keys()
changed = [p for p, r in (owners | components).items() if sha(ROOT / p) != r['sha256']]
assert changed == ['data/natural_products/amino_acids_and_peptides/bacilysin-2.yaml']
proof = json.loads(gzip.decompress((ROOT / 'reviews/evidence/20261013-bacilysin-remediation/artifacts/scope-audit.json.gz').read_bytes()))
assert proof['owner_sha256'] == sha(ROOT / changed[0])
owners[changed[0]].update(sha256=proof['owner_sha256'], bytes=(ROOT / changed[0]).stat().st_size)
for row in cp['all_review_observations']:
    for key in ('yaml', 'markdown'):
        assert sha(ROOT / row[key]) == row[key + '_sha256']
path = Path('reviews/structured/20261013T143632Z-bacilysin-2-xref-resolution/review.yaml')
doc = yaml.safe_load((ROOT / path).read_text())
target = doc['targets'][0]
entry = dict(review_id=doc['review_id'], yaml=str(path), yaml_sha256=sha(ROOT / path),
             markdown=str(path.with_suffix('.md')), markdown_sha256=sha(ROOT / path.with_suffix('.md')),
             target_id=target['target_id'], path=target['path'], verdict=doc['verdict'],
             completion=doc['completion'], scientific_review=doc['scientific_review'],
             findings=doc['findings'], finished_at=doc['finished_at'])
cp['all_review_observations'].append(entry)
cp['reviews'] = [r for r in cp['reviews'] if r['path'] != target['path']] + [entry]
for finding in doc['findings']:
    previous = {(r['review_id'], r['finding_id']) for r in finding['previous_occurrences']}
    removed = [f for f in cp['latest_finding_heads'] if (f['review_id'], f['finding_id']) in previous]
    assert len(removed) == 1 and removed[0]['issue_key'] == finding['issue_key']
    cp['latest_finding_heads'] = [f for f in cp['latest_finding_heads'] if (f['review_id'], f['finding_id']) not in previous]
    cp['latest_finding_heads'].append(dict(finding, review_id=doc['review_id'], finished_at=doc['finished_at']))
cp.update(base=base, previous_base=cp['base'], scientific_review_bundles=26,
          branch=subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip(),
          prior_checkpoint=str(PRIOR), prior_checkpoint_sha256=sha(PRIOR),
          findings=dict(collections.Counter(f['severity'] for f in cp['latest_finding_heads'] if f['status'] in ('open', 'deferred'))),
          publication=dict(pr=908, merge_commit=base, closed_issues=[909, 911, 912], open_identity_issue=910,
                           provenance_tag='review-base/bacilysin-xref-20261013'),
          count_note='26 observations;18 partial owners;0 complete;3097 unassessed;3115 owners/243 components.',
          previous_turn_classification='progress: published reviews, resolved one xref finding and retained durable evidence',
          live_sessions=0, recorded_at=now())
assert cp['findings'] == {'blocker': 6, 'major': 6}
assert len(cp['reviews']) == 18 and len(cp['pending_in_priority_order']) == 3097
assert {str(p.relative_to(ROOT)) for p in (ROOT / 'reviews/structured').rglob('review.yaml')} == {r['yaml'] for r in cp['all_review_observations']}
with (WORK / 'resumed-campaign-checkpoint.json').open('x') as handle:
    json.dump(cp, handle, indent=2)
captures = []
for old in json.loads((WORK / 'capture.json').read_text())['captures']:
    slug = old['slug']
    previous = json.loads((WORK / (slug + '-inspect.json')).read_text())
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(WORK / (slug + '-targets.json'))]
    for item in previous['source']['inputs']:
        command += ['--input', item['path']]
    receipt = dict(command=command, started_at=now())
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    current = json.loads(result.stdout)
    delta = [r['path'] for r in current['source']['inputs']
             if r['sha256'] != next(x['sha256'] for x in previous['source']['inputs'] if x['path'] == r['path'])]
    assert set(delta) <= {'docs/CURATION.md', 'curation/mibig_xref_exclusions.tsv'}
    assert sha(ROOT / old['path']) == old['sha256']
    assert read_natural_product(ROOT / old['path']) == json.loads((WORK / (slug + '-resolved.json')).read_text())
    output = WORK / (slug + '-inspect-resumed.json')
    with output.open('x') as handle:
        handle.write(result.stdout)
    receipt.update(finished_at=now(), exit_code=0, log=str(output), log_sha256=sha(output), changed_context=delta)
    with (WORK / (slug + '-inspect-resumed.receipt.json')).open('x') as handle:
        json.dump(receipt, handle, indent=2)
    captures.append(dict(slug=slug, target_unchanged=True, changed_context=delta))
report = dict(started_at=started, finished_at=now(), base=base, ignored_inclusive=True,
              owners=3115, components=243, unchanged_prior_observations=25, observations=26,
              publication_changed_owners=changed, captures=captures,
              checkpoint=str(WORK / 'resumed-campaign-checkpoint.json'),
              checkpoint_sha256=sha(WORK / 'resumed-campaign-checkpoint.json'),
              assessment='Re-read the published xref consumer/documentation changes; they concern BGC0000888 only. '
                         'The three target structures, source rows and claim grades remain unchanged; new judgements use fresh47a738c2 capture.')
with (WORK / 'resumption.json').open('x') as handle:
    json.dump(report, handle, indent=2)
print(json.dumps(report, indent=2))
