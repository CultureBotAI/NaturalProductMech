from pathlib import Path
import yaml
from naturalproductmech.curate.curation_event import record_curation_event
from naturalproductmech.validation.write_validated import write_validated_natural_product

specs = [
    ('amino_acids_and_peptides/myxochromide-a', 'naturalproductmech:mibig-82041a5d45',
     'NDLATPRQLJTXJX-OBQOMHFNSA-N', 924, 'core-identity',
     'Does the imported C45 graph represent the experimentally established product of each of BGC0001425-1428?',
     'The imported graph has a 21-membered lactone and alpha-carboxamide connectivity, whereas the independent 2006 A3 structure from DK1050, a DK1622 derivative, has a 19-membered glutamine-based core. The side-chain length agrees with A3, so chain variation alone does not explain the ring difference. Calculated R-proline also differs from the source-context L-proline assignment. These comparisons do not establish every 2017 strain-specific product: the cited PMID:28128551 full text was unavailable (HTTP403). Chemistry and all source claims are retained pending exact-strain adjudication, not independently validated for this graph. Do not merge the same-label C44 owner, select replacement stereochemistry, or transfer production, occurrence or mechanism claims without primary evidence and a guarded migration.'),
    ('unclassified/myxochromide-a-2', 'naturalproductmech:mibig-99085b9c8b',
     'TXEVVKPQBOIUHV-DHXUWNHESA-N', 925, 'hw1-proline',
     'What experimental evidence establishes the assigned proline configuration of the BGC0001422 HW-1 product?',
     'The source-matching C44 graph yields R-proline in a virtual-hydrolysis calculation, while BGC0001422 predicts an S-proline substrate. Prediction does not establish final-product stereochemistry. The independent 2006 L-proline assignment concerns M. xanthus DK1050, not M. fulvus HW-1; the cited 2017 HW-1 full text was unavailable (HTTP403). Retain the assigned center, two undefined alanine centers, incomplete-stereo flag and imported evidence grades until exact-strain evidence is inspected. This qualification is not a stereo correction, experimental identity approval, or permission to merge the C45 owner.'),
]
for relative, identifier, key, issue, local_id, prompt, rationale in specs:
    path = Path('data/natural_products') / (relative + '.yaml')
    doc = yaml.safe_load(path.read_text())
    assert doc['identifier'] == identifier
    assert doc['chemical_structure']['standard_inchi_key'] == key
    assert doc['curation_status'] == 'SEEDED'
    did = 'curator-myxochromide-a-' + local_id
    assert not any(d['discussion_id'] == did for d in doc.get('discussions', []))
    accessions = ['1425', '1426', '1427', '1428'] if issue == 924 else ['1422']
    evidence = [dict(reference=f'https://mibig.secondarymetabolites.org/repository/BGC000{a}.4/annotations.json',
                     evidence_source='database', explanation='Retained source graph and module substrate context; predictions are not experimental residue assignments.') for a in accessions]
    evidence += [
        dict(reference='https://www.wiley-vch.de/contents/jc_2002/2006/z503737_s.pdf',
             evidence_source='full_text', explanation='Independent 2006 supplement, Figures 1-2 and Table 1: A-series structure and L-proline from DK1050. Not an HW-1, DK897, A47 or Mx48 experiment.'),
        dict(reference='PMID:28128551', evidence_source='abstract',
             explanation='Cited 2017 genome-mining study; metadata and abstract do not resolve exact per-strain configurations. Full text was unavailable.'),
        dict(reference=f'https://github.com/CultureBotAI/NaturalProductMech/issues/{issue}',
             explanation='Open identity adjudication; qualification does not resolve this finding.'),
    ]
    history = doc.pop('curation_history')
    doc.setdefault('discussions', []).append(dict(discussion_id=did, kind='CURATION_TODO',
        status='OPEN', posed_by='codex', prompt=prompt, rationale=rationale, evidence=evidence))
    doc['curation_history'] = history
    record_curation_event(doc, curator='codex', action='RECORD_CURATED',
        changes='Add a cited OPEN myxochromide exact-identity qualification. Preserve chemistry, source assertions, evidence grades and SEEDED status; no identity migration or stereochemical correction.',
        llm_assisted=True)
    write_validated_natural_product(doc, path)
    print(path)
