import hashlib
import json
import subprocess
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import yaml

work = Path(__file__).parent
prior = Path('/private/tmp/npmech-myxochromide-resume-A59XD1/review-campaign-checkpoint.json')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(prior) == 'd358c28e474ae549d3e0b3ca22e7434b555f73be09ffeb0cbbf97f80b002b31e'
doc = deepcopy(json.loads(prior.read_text()))
assert len(doc['all_review_observations']) == 36
for review in doc['all_review_observations']:
    assert sha(review['yaml']) == review['yaml_sha256']
    assert sha(review['markdown']) == review['markdown_sha256']
scope = json.loads((work / 'scope-audit.json').read_text())
changed = {r['path']: r for r in scope['changed_owners']}
components = []
for row in doc['records']:
    if row['path'] in changed:
        assert row['sha256'] == changed[row['path']]['before_sha256']
        row['sha256'] = changed[row['path']]['after_sha256']
    assert sha(row['path']) == row['sha256']
    for component in row['graph_components']:
        assert sha(component['path']) == component['sha256']
        components.append(component['path'])
assert len(doc['records']) == 3115 and len(components) == 243
new = []
for item in json.loads((work / 'successors.json').read_text()):
    path = Path('reviews/structured') / item['review_id'] / 'review.yaml'
    md = path.with_suffix('.md')
    report = yaml.safe_load(path.read_text())
    row = dict(review_id=report['review_id'], yaml=str(path), yaml_sha256=sha(path),
        markdown=str(md), markdown_sha256=sha(md), target_id=report['targets'][0]['target_id'],
        path=report['targets'][0]['path'], verdict=report['verdict'], completion=report['completion'],
        scientific_review=True, findings=report['findings'], finished_at=report['finished_at'],
        scope='Scoped disposition only; does not increase whole-owner assessment coverage.')
    doc['all_review_observations'].append(row)
    new.append(row)
    for finding in report['findings']:
        heads = [f for f in doc['latest_finding_heads'] if f['issue_key'] == finding['issue_key']]
        assert len(heads) == 1
        previous, = finding['previous_occurrences']
        assert heads[0]['review_id'] == previous['review_id']
        doc['latest_finding_heads'].remove(heads[0])
        doc['latest_finding_heads'].append(dict(**finding, review_id=report['review_id'], finished_at=report['finished_at']))
assert len(doc['all_review_observations']) == 38
assert len(doc['reviews']) == 25 and len(doc['partial_followups']) == 24
assert len(doc['pending_in_priority_order']) == 3090
findings = dict(Counter(f['severity'] for f in doc['latest_finding_heads'] if f['status'] in ('open', 'deferred')))
assert findings == {'blocker': 8, 'major': 7}
doc['prior_verification'] = doc['verification']
doc['verification'] = {}
for path in work.glob('*.receipt.json'):
    receipt = json.loads(path.read_text())
    if 'log' in receipt:
        assert sha(receipt['log']) == receipt['log_sha256']
    doc['verification'][path.name] = dict(path=str(path), sha256=sha(path), result=receipt)
for label in ['qc', 'labels', 'strict', 'focused-corrected', 'canonical', 'contract']:
    assert doc['verification'][label + '.receipt.json']['result']['exit_code'] == 0
doc.update(prior_checkpoint=str(prior), prior_checkpoint_sha256=sha(prior),
    previous_base=doc['base'], base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    recorded_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    goal_status='active', scientific_review_bundles=38, new_reviews=new, findings=findings,
    scientific_inputs_unchanged=False, scientific_input_delta=scope,
    count_note='38 observations cover25 owners: one historical completed full assessment,24 partial owners,3090 unassessed. Two scoped dispositions add no owner coverage. All3115 native records remain SEEDED;243 components remain in scope.',
    this_turn_classification='Publication and bounded remediation: strain defect resolved; two identity findings explicitly qualified and remain open. No new owner assessment.',
    review_bundle_state='Original36 observations immutable; two validated scoped successors saved for PR923.',
    publication=dict(pr=923, state='awaiting final publication and CI', original_reviews_committed=True,
                     fixes_committed=True, merged=False, resolved_issue_candidates=[926,927], open_issues=[924,925]),
    live_sessions=0, required_work_remaining='Assess all3090 unassessed owners and finish24 partial assessments with their exact attached components; publication is not goal completion.',
    unpublished_research_handoff=dict(workspace='/private/tmp/npmech-vibrioferrin-review-eZIUfP', saved_reviews=0,
        owners=doc['pending_in_priority_order'][:2], status='Research started before publication request; no vib review saved.',
        note='capture.py partially failed; finish_capture.py completed. All fetch sessions terminal, including PMC262695 fullTextXML HTTP500. Do not replay exclusive writers; retain denied NPAtlas/Wikidata stops. Supplemental ChEBI-origin join by CHEBI:84585 still needed.'))
with (work / 'review-campaign-checkpoint.json').open('x') as handle:
    json.dump(doc, handle, indent=2)
print(json.dumps(dict(observations=38, assessed=25, partial=24, unassessed=3090, findings=findings)))
