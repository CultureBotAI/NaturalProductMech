import hashlib
import json
import subprocess
from pathlib import Path
import yaml

work = Path(__file__).parent
checkpoint = json.loads(Path('/private/tmp/npmech-myxochromide-resume-A59XD1/review-campaign-checkpoint.json').read_text())
changed = {'data/natural_products/amino_acids_and_peptides/myxochromide-a.yaml',
           'data/natural_products/unclassified/myxochromide-a-2.yaml'}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
files = {str(p) for p in Path('data/natural_products').rglob('*.yaml')}
assert files == {r['path'] for r in checkpoint['records']}
owners = []
for item in checkpoint['records']:
    path = item['path']
    raw = Path(path).read_bytes()
    if path not in changed:
        assert digest(raw) == item['sha256'], path
        continue
    before = subprocess.check_output(['git', 'show', f"{checkpoint['base']}:{path}"])
    old, new = yaml.safe_load(before), yaml.safe_load(raw)
    assert new['curation_history'][:len(old['curation_history'])] == old['curation_history']
    for doc in (old, new):
        doc.pop('curation_history')
    previous_discussions = old.pop('discussions', [])
    new_discussions = new.pop('discussions')
    assert new_discussions[:-1] == previous_discussions
    assert new_discussions[-1]['status'] == 'OPEN'
    if path.endswith('/myxochromide-a.yaml'):
        for producer, expected in zip(new['producer_organisms'][1:], ['DK897', 'A47', 'Mx48'], strict=True):
            assert producer.pop('strain') == expected
            assert producer['evidence'].pop()['evidence_type'] == 'CURATOR_INFERENCE'
    assert old == new, path
    owners.append(dict(path=path, before_sha256=digest(before), after_sha256=digest(raw)))
components = list(Path('data/causal_graphs').rglob('*.yaml'))
assert len(components) == 243
assert not subprocess.check_output(['git', 'diff', checkpoint['base'], '--', 'data/causal_graphs',
                                   'data/raw', 'data/natural_products/PATHS.tsv'])
for review in checkpoint['all_review_observations']:
    assert digest(Path(review['yaml']).read_bytes()) == review['yaml_sha256']
    assert digest(Path(review['markdown']).read_bytes()) == review['markdown_sha256']
result = dict(owners=len(files), components=len(components), unchanged_owners=len(files)-2,
    changed_owners=owners, immutable_prior_observations=36,
    scope='Only three pinned strain qualifiers, two OPEN discussions and append-only history changed.')
with (work / 'scope-audit.json').open('x') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result))
