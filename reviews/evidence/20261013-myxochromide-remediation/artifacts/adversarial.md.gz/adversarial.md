# PR 923 Adversarial Self-Review

Reviewer: Codex, the implementing assistant. This is a separate adversarial pass,
not an independent human approval. Inspected the two saved reviews, their exact
owners, maintained strain loader, source-row hashes, GenBank source features,
chemical diagnostics, publication scope, curation carry-forward and validation
contracts, then checked the resulting diff.

- #924: provisional C45 identity blocker. The observed constitution conflicts
  with the independent 2006 A3 structure, but that experiment cannot establish
  all four 2017 strain products. Keep OPEN; add qualification without migration.
- #925: provisional HW-1 configuration concern. Predicted substrates and an
  experiment in another strain cannot justify a final-product stereo flip.
  Keep OPEN and preserve both undefined alanine centers.
- #926: confirmed narrow provenance defect. Source qualifiers DK897, A47 and
  Mx48 were missing. Address through complete-row-pinned strain decisions,
  retaining original taxon IDs, source references and evidence grades.
- #927: publication durability defect. Temporary evidence would be lost from
  another checkout. Address with tested raw/stored hashes, exact historical
  owner snapshots, receipt mapping and full-population checkpoint retention.
  Publisher content remains reference-only, not silently redistributed.

Regression checks demonstrate the three qualifications affect only their exact
producer items. Separate scope audit verifies 3,113 other owners, 243 graph
components, all raw inputs, the path lock and 36 prior observations unchanged.
Original review findings are not rewritten: linked partial successors resolve
only the strain defect. No record is promoted to REVIEWED and no new owner is
counted as assessed. The initial incorrect focused-test filename produced no
test results; retain that failed attempt and the successful corrected run.

Final native QC, successor validation, canonical/contract checks, archive tests
and required PR/merge-queue CI must pass before closure and merge. Passing
deterministic checks do not resolve the two scientific identity issues.
