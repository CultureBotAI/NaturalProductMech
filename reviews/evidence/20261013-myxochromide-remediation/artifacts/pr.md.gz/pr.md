## Summary

- Publish two immutable partial scientific reviews for the distinct C45 and C44 myxochromide A owners.
- Restore source strains DK897, A47 and Mx48 through complete-row-pinned curation decisions; preserve original source assertions, taxon IDs and evidence grades.
- Add cited OPEN identity qualifications to both owners without changing either chemical graph, filling undefined centers or promoting SEEDED status.
- Retain original reviews, evidence hashes, execution receipts and the full campaign checkpoint. Publisher text and figures are reference-only, not redistributed.
- Add two linked partial scoped dispositions: resolve the strain defect only; retain both identity findings as open.

## Adversarial Review

A separate adversarial self-review was performed by the implementing assistant, not an independent human reviewer. Findings were filed before remediation:

- Fixes #926: missing deposited strain qualifiers, addressed with narrow source-row overlays and regression tests.
- Fixes #927: ephemeral review evidence, addressed with tested durable archives and historical input snapshots.
- #924 remains OPEN: C45 peptide-core identity requires exact-strain primary evidence.
- #925 remains OPEN: HW-1 proline configuration is not established by predicted substrates or another strain's experiment.

## Validation

- Full local native QC: 758 passed, 3 skipped; all 3,115 strict/schema and byte-identical reproduction checks passed, along with generated site, provenance, path lock, governance and documentation gates.
- Focused curation/strain/original-archive tests: 23 passed. The initial incorrect test filename ran no tests and is retained as a failed attempt.
- ID-label gate passed with existing 499 nonblocking warnings and 4,649 no-adapter skips; this is not chemical-equivalence approval.
- Both exact owners regenerate byte-identically. The other 3,113 owners, all 243 graph components, raw inventories and original 36 review pairs are unchanged.
- Successor canonical/contract and remediation-archive checks follow the full native run; final PR and merge-queue CI validate the complete tree.

The review-base/myxochromide-remediation-20261013 tag retains the exact inspected input commit through squash merge and branch deletion.

## Coverage

38 saved observations cover 25 owners, not 38 independently reviewed compounds: one historical completed full assessment and 24 partial assessments. All 3,090 unassessed owners and 243 graph components remain in scope. Unfinished vibrioferrin research is outside this PR. Publication and passing gates do not complete the scientific-review campaign.
