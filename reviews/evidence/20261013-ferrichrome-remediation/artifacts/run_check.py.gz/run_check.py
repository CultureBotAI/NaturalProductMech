import hashlib
import json
import shlex
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

work = Path(__file__).parent
label, *command = sys.argv[1:]
log = work / (label + '.log')
started = datetime.now(timezone.utc).isoformat()
with log.open('x') as handle:
    result = subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT)
receipt = dict(command=command, started_at=started,
               finished_at=datetime.now(timezone.utc).isoformat(),
               exit_code=result.returncode, log=str(log),
               log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (work / (label + '.receipt.json')).open('x') as handle:
    json.dump(receipt, handle, indent=2)
print(shlex.join(command), result.returncode, flush=True)
print(log.read_text()[-6000:], flush=True)
sys.exit(result.returncode)
