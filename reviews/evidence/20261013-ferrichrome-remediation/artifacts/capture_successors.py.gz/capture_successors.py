import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml

WORK = Path(__file__).parent
OLD = Path('/private/tmp/npmech-ferrichrome-resume-mXOYL5')
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
inputs = ['docs/CURATION.md', 'docs/record-reviews.md', 'docs/record-review-profile.md',
          '.claude/skills/review-yaml-record/SKILL.md', 'schema/record_review.yaml',
          'src/naturalproductmech/schema/naturalproductmech.yaml',
          'src/naturalproductmech/schema/mech_shared.yaml',
          'scripts/record_review.py', 'scripts/seed_from_sources.py',
          'src/naturalproductmech/curate/xref_exclusions.py',
          'curation/mibig_xref_exclusions.tsv', 'data/raw/mibig_compounds.tsv',
          'reviews/evidence/20261013-ferrichrome/manifest.json',
          'tests/test_ferrichrome_curation.py', 'tests/test_ferrichrome_review_archive.py']
for slug, prior in [('ferrichrome-2', '20261013T170121Z-ferrichrome-2'),
                    ('ferrichrome', '20261013T170122Z-ferrichrome')]:
    target = json.loads((OLD / (slug + '-targets.json')).read_text())
    path = WORK / (slug + '-targets.json')
    with path.open('x') as handle:
        json.dump(target, handle, indent=2)
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(path)]
    for item in inputs + [f'reviews/structured/{prior}/review.yaml']:
        command.extend(['--input', item])
    started = datetime.now(timezone.utc).isoformat()
    capture = WORK / (slug + '-inspect.json')
    with capture.open('x') as handle:
        result = subprocess.run(command, stdout=handle, check=True)
    doc = json.loads(capture.read_text())
    for item in doc['source']['inputs']:
        raw = subprocess.check_output(['git', 'show', f"{base}:{item['path']}"])
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
    receipt = dict(command=command, started_at=started, finished_at=datetime.now(timezone.utc).isoformat(),
                   exit_code=result.returncode, log=str(capture), log_sha256=hashlib.sha256(capture.read_bytes()).hexdigest())
    with (WORK / (slug + '-inspect.receipt.json')).open('x') as handle:
        json.dump(receipt, handle, indent=2)
    owner = Path(doc['targets'][0]['path'])
    with (WORK / (slug + '-owner.json')).open('x') as handle:
        json.dump(yaml.safe_load(owner.read_text()), handle, indent=2)
    print(slug, base, len(doc['source']['inputs']))
