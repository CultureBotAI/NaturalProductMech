"""Archive scoped dispositions and the actual local remediation receipts."""

import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml

ROOT = Path.cwd()
WORK = Path(__file__).parent
DEST = ROOT / 'reviews/evidence/20261013-ferrichrome-remediation'
UPSTREAM = Path('reviews/evidence/20261013-ferrichrome/manifest.json')
artifacts = []


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def retain(path, name, raw=None):
    raw = path.read_bytes() if raw is None else raw
    stored = gzip.compress(raw, mtime=0)
    relative = 'artifacts/' + name + '.gz'
    with (DEST / relative).open('xb') as handle:
        handle.write(stored)
    artifacts.append(dict(original_path=str(path), path=relative, bytes=len(raw), sha256=digest(raw),
                          stored_bytes=len(stored), stored_sha256=digest(stored)))


(DEST / 'artifacts').mkdir(parents=True, exist_ok=False)
for path in sorted(WORK.iterdir()):
    if path.is_file() and not path.name.endswith('-issue.md') and path.name != 'pr.md':
        retain(path, path.name)
upstream = json.loads(UPSTREAM.read_text())
reviews = []
for item in json.loads((WORK / 'successors-v2.json').read_text()):
    rid = item['review_id']
    path = Path('reviews/structured') / rid / 'review.yaml'
    doc = yaml.safe_load(path.read_text())
    for field in ('owner', 'xref-table', 'archive', 'prior'):
        evidence = next(e for e in doc['evidence'] if e['evidence_id'] == field)
        original = Path(evidence['reference'])
        if not any(a['original_path'] == str(original) for a in artifacts):
            raw = subprocess.check_output(['git', 'show', f"{doc['source']['git_revision']}:{original}"])
            retain(original, rid + '-' + field, raw)
    all_rows = artifacts + upstream['artifacts'] + upstream['reference_only_sources']
    snapshots = []
    for evidence in doc['evidence']:
        if 'snapshot_sha256' not in evidence:
            continue
        matches = [r for r in all_rows if r['sha256'] == evidence['snapshot_sha256']]
        assert matches, evidence['evidence_id']
        exact = [r for r in matches if r['original_path'] == evidence['reference']]
        match = (exact or matches)[0]
        snapshots.append(dict(evidence_id=evidence['evidence_id'], sha256=evidence['snapshot_sha256'],
                              original_path=match['original_path'],
                              archive='current' if match in artifacts else 'upstream'))
    reviews.append(dict(review_id=rid, path=str(path), sha256=digest(path.read_bytes()),
                        markdown=str(path.with_suffix('.md')),
                        markdown_sha256=digest(path.with_suffix('.md').read_bytes()),
                        source_base=doc['source']['git_revision'], evidence_snapshots=snapshots))
manifest = dict(format_version=1, recorded_at=datetime.now(timezone.utc).isoformat(),
                upstream_manifest=str(UPSTREAM), upstream_sha256=digest(UPSTREAM.read_bytes()),
                input_tag='review-base/ferrichrome-remediation-20261013',
                artifacts=artifacts, reviews=reviews, pr=917, resolved_issues=[919, 920, 921, 922],
                open_identity_issue=918,
                scope='Two scoped partial successors add no assessed owner; original 23-owner coverage remains.')
with (DEST / 'manifest.json').open('x') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(artifacts=len(artifacts), reviews=len(reviews))))
