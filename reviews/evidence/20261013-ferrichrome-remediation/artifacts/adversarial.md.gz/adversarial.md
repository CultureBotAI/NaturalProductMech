## Adversarial Self-Review

This was a separate adversarial pass by the implementing assistant, not an independent human approval.

1. **Blocker, #918:** BGC0000900's imported C26/N-formyl structure conflicts with named C27/triacetyl ferrichrome. A cited OPEN qualification now prevents a silent assumption, but no supported replacement was selected. The scientific blocker stays open.
2. **Major, #919:** CID644246 is nonexact for the C26 owner. The complete-row-pinned exclusion removes it only there, preserves CID90658043 and raw source provenance, and leaves CID644246 on its exact iron-55 owner.
3. **Major/provisional, #920:** Isotope-specific origin was unqualified. The new cited OPEN discussion identifies iron-55, three unspecified centers and the unresolved source-drawing/tracer/product alternatives. This repairs qualification, not experimental identification.
4. **Publication provenance, #921:** Temporary-only evidence is now archived with original/stored hashes, exact evidence-snapshot mapping, retrieval receipts and full campaign accounting. Publisher/patent/denial payloads remain reference-only. Original reviews are immutable.
5. **Generated documentation, #922:** Local and PR QC exposed the stale discussion count. Regeneration changes 346 to 348; the initial failure is retained and the full gate is being rerun.

Verification so far: 202 focused tests passed; strict validation reports zero errors; both exact-owner re-seeds are byte-identical; all other 3,113 owners, all 243 components and all 32 historical review pairs are unchanged. The configured label gate passed with existing warnings/skips. Full QC and canonical successor checks are still in progress; no scientific status was promoted.
