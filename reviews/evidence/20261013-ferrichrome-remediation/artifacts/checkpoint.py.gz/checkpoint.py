"""Preserve the active all-record objective after publishing scoped repairs."""

import hashlib
import json
import subprocess
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import yaml

WORK = Path(__file__).parent
PRIOR = Path('/private/tmp/npmech-ferrichrome-resume-mXOYL5/review-campaign-checkpoint.json')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


p = deepcopy(json.loads(PRIOR.read_text()))
assert sha(PRIOR) == '0e6f2c5ec7316ff240e7dac81c871325b0c5b7b770c67023a06bb0c0a3ebad9d'
records = {r['path']: r for r in p['records']}
components = {c['path']: c for r in p['records'] for c in r['graph_components']}
assert len(records) == 3115 and len(components) == 243
actual = {str(path) for root in ['data/natural_products', 'data/causal_graphs']
          for path in Path(root).rglob('*.yaml')}
assert actual == records.keys() | components.keys()
scope = json.loads((WORK / 'scope-audit.json').read_text())
changed = {r['path']: r for r in scope['changed_owners']}
for path, row in (records | components).items():
    if path in changed:
        assert row['sha256'] == changed[path]['before_sha256']
        assert sha(path) == changed[path]['after_sha256']
        row['sha256'] = sha(path)
        row['bytes'] = Path(path).stat().st_size
    else:
        assert sha(path) == row['sha256'], path
for r in p['all_review_observations']:
    assert sha(r['yaml']) == r['yaml_sha256'] and sha(r['markdown']) == r['markdown_sha256']
new = []
for item in json.loads((WORK / 'successors-v2.json').read_text()):
    yp = Path('reviews/structured') / item['review_id'] / 'review.yaml'
    mp = yp.with_suffix('.md')
    doc = yaml.safe_load(yp.read_text())
    row = dict(review_id=doc['review_id'], yaml=str(yp), yaml_sha256=sha(yp),
               markdown=str(mp), markdown_sha256=sha(mp), target_id=doc['targets'][0]['target_id'],
               path=doc['targets'][0]['path'], verdict=doc['verdict'], completion=doc['completion'],
               scientific_review=doc['scientific_review'], findings=doc['findings'], finished_at=doc['finished_at'])
    new.append(row)
    p['all_review_observations'].append(row)
    p['scoped_disposition_observations'].append(row)
    for finding in doc['findings']:
        heads = p['latest_finding_heads']
        matches = [h for h in heads if h['issue_key'] == finding['issue_key']]
        assert len(matches) == 1
        heads.remove(matches[0])
        heads.append(dict(**finding, review_id=doc['review_id'], finished_at=doc['finished_at']))
assert len(p['reviews']) == len({r['path'] for r in p['reviews']}) == 23
assert len(p['all_review_observations']) == 34
assert {str(f) for f in Path('reviews/structured').rglob('review.yaml')} == {
    r['yaml'] for r in p['all_review_observations']}
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
branch = subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip()
assert branch == 'main'
assert subprocess.check_output(['git', 'rev-parse', 'origin/main'], text=True).strip() == base
assert not subprocess.check_output(['git', 'status', '--porcelain'])
findings = dict(Counter(f['severity'] for f in p['latest_finding_heads'] if f['status'] in ('open', 'deferred')))
assert findings == {'blocker': 7, 'major': 6}
p.update(previous_base=p['base'], base=base, branch=branch, recorded_at=datetime.now(timezone.utc).isoformat(),
         prior_checkpoint=str(PRIOR), prior_checkpoint_sha256=sha(PRIOR), findings=findings,
         scientific_review_bundles=34, new_reviews=new, scientific_inputs_unchanged=False,
         scientific_input_delta=scope, live_sessions=0, goal_status='active',
         count_note='34 observations cover 23 owners: one historical completed full assessment and 22 partial '
                    'owners, leaving 3092 unassessed. Two scoped dispositions add no newly assessed owner. '
                    'All 3115 native owners remain SEEDED.',
         this_turn_classification='Progress: user-requested PR publication, adversarial issues, scoped fixes, '
                                  'durable evidence, validation, merge and branch cleanup; no new review coverage.',
         publication=dict(pr=917, merged=True, merge_commit=base, deleted_branch='review/ferrichrome-records-20261013',
                          closed_issues=[919, 920, 921, 922], open_issue=918,
                          input_tag='review-base/ferrichrome-remediation-20261013'),
         review_bundle_state='All 34 immutable observations committed and merged.',
         durable_prior_mapping='reviews/evidence/20261013-ferrichrome/manifest.json',
         durable_remediation_mapping='reviews/evidence/20261013-ferrichrome-remediation/manifest.json',
         frontier_note='Next exact owners remain myxochromide-a.yaml and myxochromide-a-2.yaml. '
                       'Unpublished research is not coverage. Ferrichrome identity issue #918 remains open.',
         required_work_remaining='Review all 3092 unassessed owners and attached components; finish 22 partial '
                                 'owner assessments and retain every unresolved finding. Full scope remains 3115/243.')
p['prior_verification'] = p['verification']
p['verification'] = {}
for path in sorted(WORK.glob('*.receipt.json')):
    receipt = json.loads(path.read_text())
    if 'log' in receipt:
        assert sha(receipt['log']) == receipt['log_sha256']
    p['verification'][path.name] = dict(path=str(path), sha256=sha(path), result=receipt)
assert p['verification']['qc-final.receipt.json']['result']['exit_code'] == 0
p['verification_reuse_note'] = 'Fresh successful qc-final and label gates cover the scoped scientific fixes. '
p['verification_reuse_note'] += 'Canonical and contract checks follow the two successors. Reuse only as prior '
p['verification_reuse_note'] += 'executed checks after verifying exact relevant input hashes; never call reuse a fresh run.'
p['unpublished_research_handoff'] = dict(
    workspace='/private/tmp/npmech-myxochromide-review-RK6G2y', saved_reviews=0,
    owners=['data/natural_products/amino_acids_and_peptides/myxochromide-a.yaml',
            'data/natural_products/unclassified/myxochromide-a-2.yaml'],
    status='Interrupted read-only research, not counted as assessment or disposition.',
    next_step='Revalidate after ferrichrome merge; inspect actual receipts and primary-access stops before resuming. '
              'No review bundles saved. Do not replay exclusive-output helpers or retry denied paper/NPAtlas endpoints.')
assert len(p['pending_in_priority_order']) == 3092
assert len(p['access_stops_no_alternate_retrieval']) == 202
handoff = Path(p['unpublished_research_handoff']['workspace'])
stops = []
for filename in ['paper28128551.html.receipt.json', 'NPA017265.json.receipt.json']:
    receipt_path = handoff / filename
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 403
    payload = receipt_path.with_name(filename.removesuffix('.receipt.json'))
    assert sha(payload) == receipt['sha256']
    stop = dict(description='Interrupted myxochromide research HTTP403; no alternative retrieval. '
                            'No saved review or new assessed owner.',
                receipt=str(receipt_path), receipt_sha256=sha(receipt_path), **receipt)
    stops.append(stop)
    p['access_stops_no_alternate_retrieval'].append(stop)
p['unpublished_research_handoff']['access_stops'] = stops
p['new_access_stops'] = stops
p['access_stop_note'] = ('204 historical access observations, including two preserved denials from interrupted '
                         'myxochromide research. The earlier PubChem/ChEBI recoveries are retained; historical '
                         'observations are not a count of current authorization denials.')
with (WORK / 'review-campaign-checkpoint.json').open('x') as handle:
    json.dump(p, handle, indent=2)
print(json.dumps(dict(base=base, owners=3115, components=243, observations=34, distinct_assessed=23,
                     partial=22, unassessed=3092, findings=findings, checkpoint=str(WORK / 'review-campaign-checkpoint.json'),
                     sha256=sha(WORK / 'review-campaign-checkpoint.json'))))
