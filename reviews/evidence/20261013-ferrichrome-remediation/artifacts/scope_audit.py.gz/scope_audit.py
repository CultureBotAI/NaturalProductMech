import hashlib
import json
import subprocess
from pathlib import Path
import yaml

WORK = Path(__file__).parent
BASE = '504e6b18472feaa68e45b2f53293330e9a7e13bf'
checkpoint = json.loads(Path('/private/tmp/npmech-ferrichrome-resume-mXOYL5/review-campaign-checkpoint.json').read_text())
changed = {f'data/natural_products/amino_acids_and_peptides/{s}.yaml'
           for s in ['ferrichrome-2', 'ferrichrome']}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


files = {str(p) for p in Path('data/natural_products').rglob('*.yaml')}
assert files == {r['path'] for r in checkpoint['records']}
owners = []
for path in sorted(files):
    raw = Path(path).read_bytes()
    before = subprocess.check_output(['git', 'show', f'{BASE}:{path}']) if path in changed else None
    prior = next(r for r in checkpoint['records'] if r['path'] == path)
    if path not in changed:
        assert digest(raw) == prior['sha256'], path
    else:
        old, new = yaml.safe_load(before), yaml.safe_load(raw)
        assert new['curation_history'][:len(old['curation_history'])] == old['curation_history']
        assert new['curation_status'] == 'SEEDED'
        for doc in (old, new):
            doc.pop('curation_history')
            doc.pop('discussions', None)
        if path.endswith('ferrichrome-2.yaml'):
            assert old['xrefs'] == ['pubchem:90658043', 'pubchem:644246']
            assert new['xrefs'] == ['pubchem:90658043']
            old['xrefs'] = new['xrefs']
        assert old == new, path
        owners.append(dict(path=path, before_sha256=digest(before), after_sha256=digest(raw)))
components = list(Path('data/causal_graphs').rglob('*.yaml'))
assert len(components) == 243
assert not subprocess.check_output(['git', 'diff', BASE, '--', 'data/causal_graphs', 'data/raw',
                                   'data/natural_products/PATHS.tsv'])
for review in checkpoint['all_review_observations']:
    assert digest(Path(review['yaml']).read_bytes()) == review['yaml_sha256']
    assert digest(Path(review['markdown']).read_bytes()) == review['markdown_sha256']
result = dict(owners=len(files), components=len(components), unchanged_owners=len(files)-2,
              changed_owners=owners, immutable_prior_observations=32,
              scope='Only exact xref removal, cited qualifications and append-only history changed.')
with (WORK / 'scope-audit.json').open('x') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result))
