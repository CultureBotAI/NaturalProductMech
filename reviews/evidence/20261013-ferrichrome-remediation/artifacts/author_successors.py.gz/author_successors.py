"""Write scoped dispositions only after real verification receipts exist."""

import hashlib
import json
import shlex
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import yaml

WORK = Path(__file__).parent
ARCHIVE = 'reviews/evidence/20261013-ferrichrome/manifest.json'


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


class NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


result = []
for slug, prior in [('ferrichrome-2', '20261013T170121Z-ferrichrome-2'),
                    ('ferrichrome', '20261013T170122Z-ferrichrome')]:
    old = yaml.safe_load(Path(f'reviews/structured/{prior}/review.yaml').read_text())
    capture = json.loads((WORK / (slug + '-inspect.json')).read_text())
    receipt = json.loads((WORK / (slug + '-inspect.receipt.json')).read_text())
    owner = Path(capture['targets'][0]['path'])
    target = capture['targets'][0]['target_id']
    for item in capture['source']['inputs']:
        assert digest(Path(item['path']).read_bytes()) == item['sha256'], item['path']
    checks = []
    summaries = {
        'focused': '202 focused tests passed, including exclusion scope, qualification carry-forward, '
                   'archive integrity, full campaign accounting and shared seeder safeguards.',
        'strict': 'Both exact owners passed closed-schema strict validation with zero errors.',
        'reseed-a': 'The C26 owner re-seeded byte-identically with one unchanged record.',
        'reseed-b': 'The iron-55 owner re-seeded byte-identically with one unchanged record.',
        'scope-audit': 'All 3115 owners and 243 components retained. Only the two intended owners changed; '
                       'all other 3113 owners, raw inventories, path lock and 32 prior review pairs are unchanged.',
        'render': 'All 3115 pages regenerated; only two record pages, browse/search xref data and discussion count changed.',
        'qc-final': 'Full native QC passed; consult the retained log for exact test and skip counts. Lint, pinned '
              'governance, documentation, raw provenance, source queue, tests, all-owner strict validation, '
              'site consistency, exact reproduction and path-lock gates passed. This is not biological sign-off.',
        'labels': 'Fresh configured label gate passed; warning mismatches and no-adapter skips remain '
                  'nonblocking and do not certify exact chemical identity.',
    }
    for label, summary in summaries.items():
        r = json.loads((WORK / (label + '.receipt.json')).read_text())
        assert r['exit_code'] == 0, label
        assert digest(Path(r['log']).read_bytes()) == r['log_sha256']
        checks.append(dict(check_id=label, name=label, status='passed', required=True,
                           command=shlex.join(r['command']), exit_code=0, expected_exit_code=0,
                           target_ids=[target], summary=summary,
                           scope_note=f"Actual run {r['started_at']} to {r['finished_at']}; log SHA256 {r['log_sha256']}"))
    failed = json.loads((WORK / 'qc.receipt.json').read_text())
    assert failed['exit_code'] == 1
    checks.append(dict(check_id='qc-initial', name='Initial full QC before statistics refresh',
                       status='failed', required=False, target_ids=[target], exit_code=1, expected_exit_code=0,
                       command=shlex.join(failed['command']),
                       summary='Initial QC correctly rejected stale README discussion coverage. The generated '
                               'statistics were refreshed and qc-final reran the full gate successfully.'))
    checks.append(dict(check_id='exact-primary', name='Experimental exact-product attribution',
                       status='unavailable', required=True, target_ids=[target],
                       summary='Previously denied primary text remains unavailable. No alternative retrieval '
                               'or newly inspected experimental identity is claimed. This successor is partial.'))
    evidence = []

    def ev(eid, kind, reference, locator, summary):
        path = Path(reference)
        evidence.append(dict(evidence_id=eid, kind=kind, reference=str(reference), locator=locator,
                             accessed_at=now(), support='supports', summary=summary,
                             snapshot_sha256=digest(path.read_bytes())))

    ev('owner', 'record_content', owner, 'Entire current YAML, including exact graph and append-only history',
       'Cited OPEN qualification is present. Chemistry, source concepts, conservative evidence grades and '
       'SEEDED status are unchanged. Only the nonexact CID on the C26 owner was removed.')
    ev('prior', 'record_content', f'reviews/structured/{prior}/review.yaml', 'Exact predecessor findings',
       'The immutable original remains the historical full-record assessment; this successor only assesses disposition.')
    ev('xref-table', 'record_content', 'curation/mibig_xref_exclusions.tsv', 'BGC0000900:1 / pubchem:644246',
       'Complete untouched row pin 78b115cce5a8a133196da68d8dd417a75f5a8f42aa0344a1d3c76d389e58f791 '
       'scopes the exclusion to the C26 owner; the separate iron-55 owner retains the same CID.')
    ev('scope-proof', 'validation', WORK / 'scope-audit.json', 'Complete filesystem and field comparison',
       'All owner/component and review denominators preserved; no identity migration or unrelated scientific change.')
    ev('regressions', 'validation', WORK / 'focused.log', '202 focused tests',
       'Decision pinning, exact-owner preservation, same-key-only carry-forward and durable evidence checks passed.')
    ev('archive', 'validation', ARCHIVE, '116 retained artifacts, 13 explicit reference-only sources',
       'Evidence snapshots and source receipts survive publication without redistributing publisher/patent text.')
    for eid in (['chemistry', 'pubchem', 'chebi-ferrichrome', 'chebi-deferrichrome', 'mibig']
                + (['paper-metadata', 'paper-access', 'locus-patent'] if slug == 'ferrichrome' else [])):
        item = deepcopy(next(e for e in old['evidence'] if e['evidence_id'] == eid))
        item['locator'] += '; same retained capture used for scoped disposition, not a fresh network retrieval'
        item['accessed_at'] = now()
        evidence.append(item)
    findings = []
    for original in old['findings']:
        finding = deepcopy(original)
        issue = 918 if slug == 'ferrichrome-2' and finding['finding_id'] == 'F1' else (
            919 if slug == 'ferrichrome-2' else 920)
        finding['status'] = 'open' if issue == 918 else 'resolved'
        finding['previous_occurrences'] = [dict(repository=old['repository'], review_id=prior,
                                                finding_id=finding['finding_id'])]
        finding['external_issues'] = [f'https://github.com/CultureBotAI/NaturalProductMech/issues/{issue}']
        finding['evidence_ids'] = ['owner', 'prior', 'chemistry', 'pubchem', 'scope-proof', 'regressions']
        if issue == 918:
            finding['evidence_ids'] += ['chebi-ferrichrome', 'chebi-deferrichrome']
            finding['disposition_reason'] = ('Cited OPEN constitutional-conflict discussion mitigates silent reuse, '
                'but no experimentally established replacement was selected. The blocker remains open; '
                'qualification is not correction of identity or exact-product origin.')
        elif issue == 919:
            finding['evidence_ids'] += ['xref-table']
            finding['disposition_reason'] = ('The row-pinned exclusion removes only nonexact CID644246 from '
                'the C26 owner, retaining CID90658043, raw provenance and all unrelated claims. '
                'The iron-55 owner retains its exact CID644246. Re-seed, strict, tests and full QC pass.')
        else:
            finding['evidence_ids'] += ['paper-metadata', 'paper-access', 'locus-patent']
            finding['disposition_reason'] = ('Resolve only the missing exact-form qualification: a cited OPEN '
                'discussion explicitly identifies iron-55, unspecified centers and the unresolved source '
                'drawing/tracer/product alternatives. Experimental attribution remains unknown; the exact '
                'CID, isotope, stereochemistry, evidence grades and SEEDED status are preserved.')
        findings.append(finding)
    assessments = [
        dict(assessment_id='scoped-repair', area='scope', topic='Exact-owner repair and qualification',
             outcome='supported', summary=('Nonexact CID removed only from C26 owner; qualification states the '
             'constitutional conflict without choosing a replacement.' if slug == 'ferrichrome-2' else
             'The iron-55 form and incomplete stereochemistry are visibly qualified; no exact chemical information '
             'or PubChem equivalence was deleted to conceal the attribution uncertainty.'),
             target_ids=[target], evidence_ids=['owner', 'pubchem', 'xref-table', 'regressions']),
        dict(assessment_id='identity-limit', area='identity', topic='Unresolved exact experimental product',
             outcome='concern' if slug == 'ferrichrome-2' else 'unknown',
             summary=('C26 versus named C27 constitution remains a confirmed blocker in #918.' if slug == 'ferrichrome-2'
                      else 'Missing qualification is repaired, but whether iron-55 denotes a tracer, source error or '
                           'intended product remains unresolved. No whole-record pass or REVIEWED promotion.'),
             target_ids=[target], evidence_ids=['owner', 'prior', 'chemistry', 'chebi-ferrichrome']),
        dict(assessment_id='preserved-inputs', area='provenance', topic='Maintained ownership and immutable history',
             outcome='supported', summary='Maintained source-row decision plus guarded writer and curation events; '
             'same-key re-seed preserves qualifications. All unrelated inputs and prior observations remain unchanged. '
             'Full QC verifies reproducibility, not scientific completeness.',
             target_ids=[target], evidence_ids=['owner', 'scope-proof', 'archive', 'regressions']),
    ]
    source = deepcopy(capture['source'])
    source['state'] = 'git_commit'
    rid = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + slug + '-scoped-disposition'
    doc = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=old['repository'],
               title=f'{slug}: scoped xref and exact-form qualification disposition',
               started_at=receipt['started_at'].replace('+00:00', 'Z'), finished_at=now(),
               reviewer=dict(identity='Codex', kind='agent', independence='self_review',
                             independence_basis='Same assistant implemented the changes and performed a separate '
                                                'adversarial pass; not independent human review.'),
               skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial',
               verdict='needs_curation' if slug == 'ferrichrome-2' else 'pass_with_limitations',
               scientific_review=True,
               summary=('Resolve only F2; F1 remains open despite explicit mitigation.' if slug == 'ferrichrome-2'
                        else 'Resolve missing isotope-specific qualification only; experimental product attribution remains unknown.'),
               source=source, targets=capture['targets'],
               scope=dict(description='One exact owner; scoped predecessor disposition, not a new full-record review.',
                          selection='User-authorized adversarial PR review and issue remediation.', coverage='partial',
                          population_size=1, reviewed_target_ids=[target], exclusions=[
                              dict(target='All other 3114 owners and earlier unresolved scientific checks',
                                   reason='No additional scientific coverage; campaign stays 3115 owners and 243 components.')]),
               checks=checks, evidence=evidence, assessments=assessments, findings=findings,
               actions=([dict(action_id='A1', description='Establish the exact primary product before any structure '
                             'migration; retain the OPEN qualification until then.', finding_ids=['F1'],
                             target_ids=[target], owner_paths=old['findings'][0]['owner_paths'],
                             acceptance_checks=['Inspect exact product, isotope and stereochemical evidence.',
                             'Audit all old-key joins; use supported source corrections and guarded migration only.',
                             'Canary, strict validation, reproduction and full QC must pass.'])]
                        if slug == 'ferrichrome-2' else []),
               limitations=['Partial, scoped successor: no newly assessed owner and no native status promotion.',
                            'Experimental product attribution remains unresolved. Earlier primary access limits remain; '
                            'publication does not retry denied endpoints or declare missing evidence false.',
                            'The exact inspected input tree is retained by review-base/ferrichrome-remediation-20261013. '
                            'The full QC rerun follows the generated README count correction in c1583b769; '
                            'all 17 inspected scientific and review inputs still match the tagged tree. '
                            'Canonical successor checks and PR/merge-queue CI follow saving.',
                            'Full QC preceded these new review bundles; their canonical and contract validation is separate.'],
               related_reviews=[dict(repository=old['repository'], review_id=prior,
                                     relationship='Scoped disposition; original full assessment remains immutable.')],
               links=['https://github.com/CultureBotAI/NaturalProductMech/pull/917'])
    draft = WORK / (slug + '-successor-v2.yaml')
    with draft.open('x') as handle:
        yaml.dump(doc, handle, Dumper=NoAliasDumper, sort_keys=False, allow_unicode=False, width=94)
    result.append(dict(review_id=rid, draft=str(draft)))
with (WORK / 'successors-v2.json').open('x') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result))
