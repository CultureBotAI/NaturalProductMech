from pathlib import Path
import yaml
from naturalproductmech.curate.curation_event import record_curation_event
from naturalproductmech.validation.write_validated import write_validated_natural_product

ROOT = Path('data/natural_products/amino_acids_and_peptides')
SPECS = [
    ('ferrichrome-2', 'naturalproductmech:mibig-ab69cdf6e5', 'ZZDYFKJSJLUQON-UFYCRDLUSA-N', {
        'discussion_id': 'curator-ferrichrome-constitution-conflict',
        'kind': 'CURATION_TODO', 'status': 'OPEN', 'posed_by': 'codex',
        'prompt': 'The imported C26 structure has two N-acetyl and one N-formyl hydroxamates, whereas named ferrichrome and its metal-free ligand have C27 and three N-acetyl groups. Which exact product does BGC0000900 version 5 establish?',
        'rationale': 'This is a constitutional conflict, not merely removal of iron. The current structure, natural-origin assertion, producer, locus and LOTUS occurrence are retained as source assertions pending exact-product adjudication, not independently validated claims for this graph. PubChem CID90658043 matches the imported structure but does not establish its name or biosynthesis. Do not replace it with CHEBI:5019, CHEBI:90132 or the separate iron-55 owner, merge owners, or transfer occurrences, assays or graphs without primary evidence and a guarded migration. The cited occurrence paper remains unavailable; no production is inferred from detection.',
        'evidence': [
            {'reference': 'https://mibig.secondarymetabolites.org/repository/BGC0000900.5/annotations.json', 'evidence_source': 'database', 'explanation': 'Versioned source structure agrees with the imported C26 graph; agreement is not independent named-product proof.'},
            {'reference': 'CHEBI:5019', 'evidence_source': 'database', 'explanation': 'Named ferrichrome is C27H42FeN9O12 with three N-acetyl groups.'},
            {'reference': 'CHEBI:90132', 'evidence_source': 'database', 'explanation': 'The metal-free ligand is C27H45N9O12, also triacetylated; metal removal does not explain the C26 graph.'},
            {'reference': 'https://github.com/CultureBotAI/NaturalProductMech/issues/918', 'explanation': 'Open exact-product adjudication; adding this qualification does not resolve the identity blocker.'},
        ],
    }),
    ('ferrichrome', 'naturalproductmech:mibig-91bcef2bc6', 'GGUNGDGGXMHBMJ-HCMAANCNSA-N', {
        'discussion_id': 'curator-ferrichrome-55fe-attribution',
        'kind': 'CURATION_TODO', 'status': 'OPEN', 'posed_by': 'codex',
        'prompt': 'The stored graph explicitly contains iron-55 and three unspecified peptide stereocenters. Does BGC0000901 version 5 support this exact isotope-specific product, a tracer experiment, or an erroneous source drawing?',
        'rationale': 'The NATURAL_PRODUCT, producer and locus fields are imported database assertions, not independent experimental confirmation of the iron-55 form. PMID:25062661 abstract supports ferrichrome production in general but does not establish this exact isotopic product; full text returned HTTP403. Available locus-patent cloning and enzyme assays do not characterize the isotope-specific complete product. Keep the exact PubChem CID644246, unchanged graph, incomplete stereo flag, SOURCE_ASSERTION and CLUSTER_UNSTATED grades, and SEEDED status. Do not silently remove iron-55, assign stereochemistry, substitute CHEBI:5019, or infer that the organism cannot incorporate labeled iron.',
        'evidence': [
            {'reference': 'https://mibig.secondarymetabolites.org/repository/BGC0000901.5/annotations.json', 'evidence_source': 'database', 'explanation': 'Version 5 contains the stored isotope-specific structure.'},
            {'reference': 'https://pubchem.ncbi.nlm.nih.gov/compound/644246', 'evidence_source': 'database', 'explanation': 'Exact structure match; not evidence for isotope-specific biosynthesis.'},
            {'reference': 'PMID:25062661', 'evidence_source': 'abstract', 'explanation': 'General ferrichrome production context only; primary full text was unavailable.'},
            {'reference': 'https://patents.google.com/patent/JP2003230381A/en', 'evidence_source': 'full_text', 'explanation': 'Inspected translated patent prose supplies cloning/enzyme context, not exact isotope-specific complete-product characterization; sequence figures were not audited.'},
            {'reference': 'https://github.com/CultureBotAI/NaturalProductMech/issues/920', 'explanation': 'Qualification repair; experimental product attribution remains unresolved.'},
        ],
    }),
]

for slug, identifier, key, discussion in SPECS:
    path = ROOT / (slug + '.yaml')
    doc = yaml.safe_load(path.read_text())
    assert doc['identifier'] == identifier
    assert doc['chemical_structure']['standard_inchi_key'] == key
    assert doc['curation_status'] == 'SEEDED'
    assert all(d['discussion_id'] != discussion['discussion_id'] for d in doc.get('discussions', []))
    history = doc.pop('curation_history')
    doc.setdefault('discussions', []).append(discussion)
    doc['curation_history'] = history
    record_curation_event(doc, curator='codex', action='RECORD_CURATED',
                         changes='Add a cited OPEN exact-form qualification; preserve imported chemistry, conservative evidence grades and SEEDED status. No structure or experimental identity adjudication.',
                         llm_assisted=True)
    write_validated_natural_product(doc, path)
    print(path)
