import csv
import hashlib
import json
import subprocess
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import yaml

W = Path(__file__).parent
P = Path('/private/tmp/npmech-myxochromide-publish-MyX4Nq/review-campaign-checkpoint-final.json')
O = Path('/private/tmp/npmech-vibrioferrin-review-eZIUfP')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(P) == '74cc20070a92f2b1fe6f64abd6df14750c0c1ad29ea151365167d11491bce215'
p = deepcopy(json.loads(P.read_text()))
records = {r['path']: r for r in p['records']}
components = {g['path']: g for r in p['records'] for g in r['graph_components']}
assert len(records) == 3115 and len(components) == 243
assert {str(f) for root in ['data/natural_products','data/causal_graphs'] for f in Path(root).rglob('*.yaml')} == records.keys() | components.keys()
for path,row in (records | components).items():
    assert sha(path) == row['sha256'], path
assert len(p['all_review_observations']) == 38
for r in p['all_review_observations']:
    assert sha(r['yaml']) == r['yaml_sha256'] and sha(r['markdown']) == r['markdown_sha256']
assert not subprocess.check_output(['git','diff','--name-only','HEAD'])
base = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert base == p['base']
branch = subprocess.check_output(['git','branch','--show-current'],text=True).strip()
assert branch == 'review/vibrioferrin-records-20261013'
new = []
for item in json.loads((W/'reviews.json').read_text()):
    yp = Path('reviews/structured')/item['review_id']/'review.yaml'
    mp = yp.with_suffix('.md')
    doc = yaml.safe_load(yp.read_text())
    path = doc['targets'][0]['path']
    assert records[path]['review_state'] == 'unassessed' and doc['completion'] == 'partial'
    for inp in doc['source']['inputs']:
        assert sha(inp['path']) == inp['sha256']
        assert hashlib.sha256(subprocess.check_output(['git','show',base+':'+inp['path']])).hexdigest() == inp['sha256']
    for file in [yp,mp]:
        assert all(line == line.rstrip() for line in file.read_text().splitlines()), file
    row = dict(review_id=doc['review_id'],yaml=str(yp),yaml_sha256=sha(yp),markdown=str(mp),markdown_sha256=sha(mp),target_id=doc['targets'][0]['target_id'],path=path,verdict=doc['verdict'],completion=doc['completion'],scientific_review=doc['scientific_review'],findings=doc['findings'],finished_at=doc['finished_at'])
    new.append(row)
    p['reviews'].append(row)
    p['all_review_observations'].append(row)
    p['partial_followups'].append(path)
    p['pending_in_priority_order'].remove(path)
    records[path]['review_state'] = 'partial'
    for finding in doc['findings']:
        assert not any(h['issue_key'] == finding['issue_key'] for h in p['latest_finding_heads'])
        p['latest_finding_heads'].append(dict(**finding,review_id=doc['review_id'],finished_at=doc['finished_at']))
assert len(p['reviews']) == len({r['path'] for r in p['reviews']}) == 27
assert len(p['all_review_observations']) == 40
assert len(p['partial_followups']) == 26 and len(p['pending_in_priority_order']) == 3088
assert {str(f) for f in Path('reviews/structured').rglob('review.yaml')} == {r['yaml'] for r in p['all_review_observations']}
with (W/'native-queue-after.tsv').open() as f:
    queue = list(csv.DictReader(f,delimiter='\t'))
assert len(queue) == 8930 and {r['path'] for r in queue if r['path'].startswith('data/natural_products/')} == records.keys()
assert {r['status'] for r in records.values()} == {'SEEDED'}
findings = dict(Counter(f['severity'] for f in p['latest_finding_heads'] if f['status'] in ('open','deferred')))
assert findings == {'blocker':9,'major':9,'minor':3}, findings
p['prior_verification'] = p['verification']
p['verification'] = {}
for f in sorted(W.glob('*.receipt.json')):
    r = json.loads(f.read_text())
    if 'log' in r:
        assert sha(r['log']) == r['log_sha256']
    p['verification'][f.name] = dict(path=str(f),sha256=sha(f),result=r)
for label in ['canonical','contract','validate','strict','chemistry-retry','corpus','labels','queue-after','save-a','save-b']:
    assert p['verification'][label+'.receipt.json']['result']['exit_code'] == 0
new_stops = []
for root in [O,W]:
    for f in sorted(root.glob('*.receipt.json')):
        r = json.loads(f.read_text())
        if 'url' not in r:
            continue
        payload = f.with_name(f.name.removesuffix('.receipt.json'))
        assert sha(payload) == r['sha256']
        if r.get('status') != 200 or f.name == 'primary2007.html.receipt.json':
            stop = dict(url=r['url'],status=r.get('status'),started_at=r['started_at'],finished_at=r['finished_at'],provenance=str(f),provenance_sha256=sha(f),payload_sha256=r['sha256'],description='Subscription preview only; full paper not accessed' if f.name=='primary2007.html.receipt.json' else r.get('error','Source inaccessible'),note='No alternate retrieval after explicit authorization denial. HTTP500 is an endpoint error; subsequent same-endpoint retry/public-page checks were before challenges.')
            new_stops.append(stop)
web = json.loads((W/'web-observations.json').read_text())
for item in web['access_stops']:
    new_stops.append(dict(url=item['url'],description=item['outcome'],observed_date='2026-10-13',status=None,provenance=str(W/'web-observations.json'),provenance_sha256=sha(W/'web-observations.json'),note='Web tool did not supply an HTTP status or exact request timestamp; none invented. No alternate retrieval.'))
p['access_stops_no_alternate_retrieval'].extend(new_stops)
p.update(previous_base=p['base'],base=base,branch=branch,recorded_at=datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),prior_checkpoint=str(P),prior_checkpoint_sha256=sha(P),goal_status='active',scientific_inputs_unchanged=True,scientific_input_delta=dict(changed_owners=[],changed_components=[],tracked_changes=[]),scientific_review_bundles=40,partial_reviews=26,unassessed_records=3088,new_reviews=new,findings=findings,live_sessions=0,new_access_stops=new_stops,previous_turn_classification='No scientific-review progress: prior publication status verified and an empty branch deleted. Safe next owners remained available.',this_turn_classification='Progress: two new exact-owner scientific reviews; primary2011 full text/figures, structured source/chemistry/taxonomy checks, six findings and current review validation. No scientific curation.',count_note='40immutable observations cover27owners: one historical completed full assessment and26partial owners;3088unassessed. All3115owners remain SEEDED; all243components retained in scope.',review_bundle_state='38prior observations committed and byte-identical;2new canonical pairs saved and uncommitted on local review branch.',frontier_note='Next unassessed owners are capsular-polysaccharide-2.yaml and capsular-polysaccharide-3.yaml. All26partial follow-ups and unresolved finding heads remain in scope.',required_work_remaining='Review3088unassessed owners and attached components; finish26partial assessments; retain unresolved findings. No reduction of3115-owner/243-component objective.',queue_verification=dict(rows=len(queue),owner_count=3115,path=str(W/'native-queue-after.tsv'),sha256=sha(W/'native-queue-after.tsv')),verification_reuse_note='Fresh inspect/strict/RDKit/corpus/label/queue and canonical/contract checks. Full native QC/reproduction is explicitly the verified prior executed run; current base merge-group CI also passed. No new full QC run or scientific approval is implied.',access_stop_note=f"{len(p['access_stops_no_alternate_retrieval'])} historical access observations, not all authorization denials.206inherited plus{len(new_stops)}previously unpublished vibrioferrin endpoint limits/challenges; successful earlier metadata remains distinct from later page denial.")
p['prior_publication'] = p['publication']
p['publication'] = dict(requested_this_turn=False,committed=False,pushed=False,github_mutations=False)
p['current_draft_revision_note'] = 'Initial two review drafts validated and saved unchanged. Capture helper initially failed on str/Path mismatch before writing outputs; corrected. Chemistry diagnostic failed on missing optional2527formula before writing a result; corrected and passed. bs4 unavailable; stdlib HTMLParser succeeded.'
p['historical_bundle_whitespace_checks'] = p.get('historical_bundle_whitespace_checks',[]) + p.get('new_bundle_whitespace_checks',[])
p['new_bundle_whitespace_checks'] = [dict(path=r[k],method='All lines compared with rstrip in checkpoint.py',passed=True) for r in new for k in ['yaml','markdown']]
p['queue_verification_note'] = 'Fresh after-bundle queue covers all3115SEEDED owners;8930diagnostic rows are not8930owners and do not indicate scientific coverage.'
p['unpublished_research_handoff'] = dict(workspace=str(W),prior_workspace=str(O),saved_reviews=2,status='Two partial exact-owner reviews, no curation/publication.',owners=[r['path'] for r in new],next_step='Preserve immutable pairs and receipt/source-access ledger; resume full queue and partial follow-ups. Do not replay exclusive-output scripts.')
p['working_chemistry_command'] = p['verification']['chemistry-retry.receipt.json']['result']['command']
p['this_turn_artifacts'] = [dict(path=str(f),sha256=sha(f)) for f in sorted(W.iterdir()) if f.is_file()]
out = W/'review-campaign-checkpoint.json'
with out.open('x') as f:
    json.dump(p,f,indent=2)
print(json.dumps(dict(checkpoint=str(out),sha256=sha(out),base=base,branch=branch,observations=40,distinct_assessed=27,completed_historical=1,partial=26,unassessed=3088,owners=3115,components=243,findings=findings,access_observations=len(p['access_stops_no_alternate_retrieval']),live_sessions=0,next_owners=p['pending_in_priority_order'][:4]),indent=2))
