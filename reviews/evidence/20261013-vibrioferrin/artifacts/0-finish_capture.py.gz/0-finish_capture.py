import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

W = Path(__file__).parent
P = Path('/private/tmp/npmech-myxochromide-resume-A59XD1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
cp = P / 'review-campaign-checkpoint.json'
assert sha(cp) == 'd358c28e474ae549d3e0b3ca22e7434b555f73be09ffeb0cbbf97f80b002b31e'
prior = json.loads(cp.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == prior['base']
owners = {r['path']: r for r in prior['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
assert len(owners) == 3115 and len(components) == 243
assert {str(f) for root in ['data/natural_products', 'data/causal_graphs'] for f in Path(root).rglob('*.yaml')} == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(Path(path)) == row['sha256']
for r in prior['all_review_observations']:
    assert sha(Path(r['yaml'])) == r['yaml_sha256'] and sha(Path(r['markdown'])) == r['markdown_sha256']
receipts, refs, keys = [], set(), set()
for slug in ['vibrioferrin-2', 'vibrioferrin']:
    receipt = json.loads((W / (slug + '-inspect.receipt.json')).read_text())
    assert receipt['exit_code'] == 0 and sha(Path(receipt['log'])) == receipt['log_sha256']
    receipts.append(receipt)
    inspection = json.loads(Path(receipt['log']).read_text())
    for inp in inspection['source']['inputs']:
        assert sha(Path(inp['path'])) == inp['sha256']
        assert hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + inp['path']])).hexdigest() == inp['sha256']
    d = json.loads((W / (slug + '-resolved.json')).read_text())
    keys.add(d['chemical_structure']['standard_inchi_key'])
    for slot in ['occurrences', 'producer_organisms', 'biosynthetic_gene_clusters']:
        for obj in d.get(slot, []):
            refs.update(e['reference'] for e in obj.get('evidence', []))
aliases = ['vibrioferrin', *keys, 'CHEBI:84585', '197680', 'NPA024673', 'BGC0000946', 'BGC0000947', 'BGC0002527', 'Q134280', 'Q3556827', 'Q2157875']
aliases += [r.split(':', 1)[1].strip().lower() for r in refs]
matches = []
for s in prior['access_stops_no_alternate_retrieval']:
    terms = json.dumps({k: v for k, v in s.items() if k in ['url', 'aliases', 'description', 'error', 'reference']} if isinstance(s, dict) else s).lower()
    if any(a.lower() in terms for a in aliases):
        matches.append(s)
rows = json.loads((W / 'source-rows.json').read_text())
report = dict(started_at=min(r['started_at'] for r in receipts), finished_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    base=base, prior_checkpoint=str(cp), prior_checkpoint_sha256=sha(cp), owners_verified=3115, components_verified=243,
    prior_observations_verified=36, exact_git_tree_inputs_verified=True, references=sorted(refs),
    source_aliases_checked=aliases, prior_access_matches=matches, inherited_access_count=206,
    source_row_counts={n: len(v) for n, v in rows.items()},
    previous_turn_classification='progress: two saved myxochromide scientific reviews and completed checks',
    recovery_note='Initial capture.py finished both inspections and source-row scans, then failed on a historical string access-ledger item. This helper handles both ledger shapes, rechecks hashes and completes the missing capture receipt without overwriting any inspection or restarting a running process.',
    prior_native_verification=dict(qc_workspace='/private/tmp/npmech-ferrichrome-publish-i31W5V', labels_and_corpus_workspace=str(P), note='Prior actually executed checks at unchanged scientific inputs; not fresh runs.'))
with (W / 'capture.json').open('x') as f:
    json.dump(report, f, indent=2)
print(json.dumps(report, indent=2))
