import hashlib
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

W = Path(__file__).parent
name, url = sys.argv[1:]
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
r = dict(url=url, started_at=now())
try:
    with urllib.request.urlopen(url, timeout=90) as response:
        body = response.read()
        r.update(status=response.status, final_url=response.url)
except urllib.error.HTTPError as error:
    body = error.read()
    r.update(status=error.code, error=str(error))
except Exception as error:
    body = str(error).encode()
    r.update(status=None, error=repr(error))
with (W / name).open('xb') as f:
    f.write(body)
r.update(finished_at=now(), sha256=hashlib.sha256(body).hexdigest(), bytes=len(body))
with (W / (name + '.receipt.json')).open('x') as f:
    json.dump(r, f, indent=2)
print(json.dumps(r, indent=2))
