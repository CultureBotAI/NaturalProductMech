import json
from pathlib import Path
from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, Draw, rdMolDescriptors

W = Path(__file__).parent
O = Path('/private/tmp/npmech-vibrioferrin-review-eZIUfP')
assert rdBase.rdkitVersion == '2026.03.5'
rows = json.loads((W/'source-rows.json').read_text())
results = []
mols = []
def inspect(label, smiles, key, inchi=None):
    m = Chem.MolFromSmiles(smiles)
    assert m is not None and Chem.MolToInchiKey(m) == key, label
    if inchi:
        assert Chem.MolToInchi(m) == inchi
        assert Chem.MolToInchiKey(Chem.MolFromInchi(inchi)) == key
    stereo = [dict(type=str(s.type), specified=str(s.specified), centered_on=s.centeredOn) for s in Chem.FindPotentialStereo(m)]
    r = dict(label=label, key=key, formula=rdMolDescriptors.CalcMolFormula(m), inchi=Chem.MolToInchi(m), charge=Chem.GetFormalCharge(m), exact_mass=Descriptors.ExactMolWt(m), chiral_centers=Chem.FindMolChiralCenters(m, includeUnassigned=True), potential_stereo=stereo,
             free_carboxylic_acids=len(m.GetSubstructMatches(Chem.MolFromSmarts('[CX3](=O)[OX2H1]'))), esters=len(m.GetSubstructMatches(Chem.MolFromSmarts('[CX3](=O)[OX2H0][#6]'))))
    results.append(r)
    return m, r
for slug, accessions in [('vibrioferrin-2', ['BGC0000947.5']), ('vibrioferrin', ['BGC0000946.5','BGC0002527.2'])]:
    s = json.loads((W/(slug+'-resolved.json')).read_text())['chemical_structure']
    m,r = inspect(slug, s['smiles'], s['standard_inchi_key'], s['standard_inchi'])
    assert s['stereo_complete'] == all(i['specified'] == 'Specified' for i in r['potential_stereo'])
    mols.append(m)
    for a in accessions:
        c = json.loads((O/(a+'.json')).read_text())['compounds'][0]
        _, r = inspect(a,c['structure'],s['standard_inchi_key'])
        r['source_formula'] = c.get('formula')
        r['source_mass'] = c.get('mass')
        if 'formula' in c:
            assert r['formula'] == c['formula']
        if 'mass' in c:
            assert abs(r['exact_mass']-c['mass']) < 0.00001
for row in rows['chebi_structures']:
    inspect(row['chebi_id'],row['smiles'],row['standard_inchi_key'])
p = json.loads((O/'pubchem197680.json').read_text())['PropertyTable']['Properties'][0]
_,r = inspect('PubChem197680',p['SMILES'],p['InChIKey'],p['InChI'])
assert r['formula'] == p['MolecularFormula']
Draw.MolsToGridImage(mols,molsPerRow=2,subImgSize=(800,500),legends=['vibrioferrin-2: FPHRKFJYHKRDFJ','vibrioferrin: IGQXNKDXMPSELX']).save(W/'structure-comparison.png')
with (W/'chemistry.json').open('x') as f:
    json.dump(dict(rdkit_version=rdBase.rdkitVersion,results=results,note='Computed graph diagnostics, not measured properties or experimental structure assignments.'),f,indent=2)
print(json.dumps(results,indent=2))
