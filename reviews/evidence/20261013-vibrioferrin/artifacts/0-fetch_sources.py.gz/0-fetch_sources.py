import json
import subprocess
from pathlib import Path
from urllib.parse import urlencode

W = Path(__file__).parent
capture = json.loads((W / 'capture.json').read_text())
assert not capture['prior_access_matches'], capture['prior_access_matches']
query = ' OR '.join('(EXT_ID:' + r.split(':', 1)[1].strip() + ' AND SRC:MED)' if r.startswith('PMID:') else 'DOI:"' + r.split(':', 1)[1].strip().lower() + '"' for r in capture['references'])
urls = [
    ('metadata.json', 'https://www.ebi.ac.uk/europepmc/webservices/rest/search?' + urlencode(dict(query=query, format='json', resultType='core', pageSize=100))),
    ('BGC0000946.5.json', 'https://mibig.secondarymetabolites.org/repository/BGC0000946.5/annotations.json'),
    ('BGC0002527.2.json', 'https://mibig.secondarymetabolites.org/repository/BGC0002527.2/annotations.json'),
    ('pubchem197680.json', 'https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/197680/property/InChI,InChIKey,MolecularFormula,IsomericSMILES/JSON'),
    ('CHEBI84585.json', 'https://www.ebi.ac.uk/chebi/backend/api/public/compound/84585/'),
    ('NPA024673.json', 'https://www.npatlas.org/api/v1/compound/NPA024673?include=classifications'),
    ('taxonomy.xml', 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=taxonomy&id=354,663,670,1283330&retmode=xml'),
    ('sequences.xml', 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=DQ201184.2,AB082123.1&rettype=gbwithparts&retmode=xml'),
    ('CP005094-locus.xml', 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=CP005094.1&seq_start=876779&seq_stop=886792&rettype=gbwithparts&retmode=xml'),
    ('wikidata-Q134280.json', 'https://www.wikidata.org/wiki/Special:EntityData/Q134280.json'),
    ('wikidata-Q3556827.json', 'https://www.wikidata.org/wiki/Special:EntityData/Q3556827.json'),
    ('wikidata-Q2157875.json', 'https://www.wikidata.org/wiki/Special:EntityData/Q2157875.json'),
]
for name, url in urls:
    subprocess.run(['.venv/bin/python', str(W / 'fetch.py'), name, url], check=True)
