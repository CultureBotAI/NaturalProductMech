import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml
from naturalproductmech.graph_components import read_natural_product
from naturalproductmech.curate.structure_corrections import row_digest

work = Path(__file__).parent
previous = Path('/private/tmp/npmech-vibrioferrin-review-eZIUfP')
checkpoint = Path('/private/tmp/npmech-myxochromide-publish-MyX4Nq/review-campaign-checkpoint-final.json')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
started = now()
assert sha(checkpoint) == '74cc20070a92f2b1fe6f64abd6df14750c0c1ad29ea151365167d11491bce215'
prior = json.loads(checkpoint.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == prior['base'] == '39811a084202d1c1a47472622e3008bed7000083'
assert not subprocess.check_output(['git', 'status', '--porcelain'])
owners = {r['path']: r for r in prior['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
actual = {str(p) for folder in ['data/natural_products', 'data/causal_graphs'] for p in Path(folder).rglob('*.yaml')}
assert actual == owners.keys() | components.keys()
assert len(owners) == 3115 and len(components) == 243
for path, row in (owners | components).items():
    assert sha(path) == row['sha256'], path
assert len(prior['all_review_observations']) == 38
for row in prior['all_review_observations']:
    assert sha(row['yaml']) == row['yaml_sha256']
    assert sha(row['markdown']) == row['markdown_sha256']
old = json.loads((previous / 'vibrioferrin-inspect.json').read_text())
changed = [i['path'] for i in old['source']['inputs'] if sha(i['path']) != i['sha256']]
assert changed == ['curation/mibig_producer_strains.tsv'], changed
selected = prior['pending_in_priority_order'][:2]
assert [Path(p).stem for p in selected] == ['vibrioferrin-2', 'vibrioferrin']
for path in selected:
    slug = Path(path).stem
    doc = read_natural_product(Path(path))
    assert doc == yaml.safe_load(Path(path).read_text()) and not owners[path]['graph_components']
    target = json.loads((previous / (slug + '-targets.json')).read_text())
    assert target['targets'][0]['path'] == path and target['targets'][0]['target_id'] == doc['identifier']
    for suffix, payload in [('targets', target), ('resolved', doc)]:
        with (work / (slug + '-' + suffix + '.json')).open('x') as handle:
            json.dump(payload, handle, indent=2)
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(work / (slug + '-targets.json'))]
    for item in old['source']['inputs']:
        command.extend(['--input', item['path']])
    receipt = dict(command=command, started_at=now())
    result = subprocess.run(command, text=True, capture_output=True, check=True)
    inspected = json.loads(result.stdout)
    for item in inspected['source']['inputs']:
        raw = subprocess.check_output(['git', 'show', f"{base}:{item['path']}"])
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
    output = work / (slug + '-inspect.json')
    with output.open('x') as handle:
        handle.write(result.stdout)
    receipt.update(finished_at=now(), exit_code=0, log=str(output), log_sha256=sha(output))
    with (work / (slug + '-inspect.receipt.json')).open('x') as handle:
        json.dump(receipt, handle, indent=2)
keys = {'FPHRKFJYHKRDFJ-LWYCVJHGSA-N', 'IGQXNKDXMPSELX-BIAKFKOBSA-N'}
rows = {}
for name in ['mibig_compounds', 'npclassifier', 'lotus_occurrences', 'chebi_structures', 'chebi_origins', 'antibioticmech_inchikeys', 'pubchem_bioassay']:
    with Path('data/raw', name + '.tsv').open() as handle:
        rows[name] = [dict(line=i, source_row_sha256=row_digest(row), **row)
            for i, row in enumerate(csv.DictReader(handle, delimiter='\t'), 2)
            if row.get('standard_inchi_key') in keys or 'vibrioferrin' in ' '.join(row.values()).lower()
            or any(v in {'CHEBI:84585', 'CHEBI:84630'} for v in row.values())]
with (work / 'source-rows.json').open('x') as handle:
    json.dump(rows, handle, indent=2)
receipts = []
for path in sorted(previous.glob('*.receipt.json')):
    receipt = json.loads(path.read_text())
    if 'url' in receipt:
        payload = path.with_name(path.name.removesuffix('.receipt.json'))
        assert sha(payload) == receipt['sha256'] and payload.stat().st_size == receipt['bytes']
        receipts.append(dict(receipt_path=str(path), receipt_sha256=sha(path), **receipt))
aliases = ['vibrioferrin', '84585', '84630', '197680', 'NPA024673', 'BGC0000946', 'BGC0000947', 'BGC0002527', 'PMC262695', 'PMC4702634', 'PMC3754555', '22146715', '19821595', '26452553', '17593352', '14617658', '23772063', '22092766', '7961600', '10.1111/j.1574-6968.1992.tb05311.x']
stops = prior['access_stops_no_alternate_retrieval']
matches = [s for s in stops if any(a.lower() in json.dumps(s).lower() for a in aliases)]
report = dict(started_at=started, finished_at=now(), base=base, prior_checkpoint=str(checkpoint),
    prior_checkpoint_sha256=sha(checkpoint), owners_verified=3115, components_verified=243,
    prior_observations_verified=38, changed_previous_context_inputs=changed,
    change_assessment='Only three myxochromide source-strain rows changed; diff inspected. No vibrioferrin source row, owner, rubric or schema changed.',
    source_row_counts={name: len(value) for name, value in rows.items()},
    source_scan_correction='Previous chebi_origins selection missed CHEBI:84585 because it keyed by ChEBI ID, not label/key. Current full structured scan joins the exact ChEBI IDs; previous zero was not an absence finding.',
    inherited_access_count=len(stops), prior_access_matches=matches, preserved_fetch_receipts=receipts,
    previous_turn_classification='No scientific-review progress in the immediate publication-status turn: merged PR923 and issue states were verified and an empty branch removed. Resume the next pending owners; no scientific blocker exists.',
    native_qc_reuse='Prior executed full native QC and merge-group CI from PR923 match current inputs and corpus. Not a fresh QC run or scientific approval; fresh target chemistry/strict and review-output checks follow.')
with (work / 'capture.json').open('x') as handle:
    json.dump(report, handle, indent=2)
print(json.dumps({k:v for k,v in report.items() if k != 'preserved_fetch_receipts'}, indent=2))
