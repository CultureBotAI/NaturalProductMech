from html.parser import HTMLParser
from pathlib import Path
import json
from datetime import datetime, timezone

W = Path(__file__).parent
class Text(HTMLParser):
    def __init__(self):
        super().__init__()
        self.skip = 0
        self.parts = []
    def handle_starttag(self, tag, attrs):
        if tag in {'script','style'}:
            self.skip += 1
    def handle_endtag(self, tag):
        if tag in {'script','style'}:
            self.skip -= 1
    def handle_data(self, data):
        if not self.skip and data.strip():
            self.parts.append(data.strip())
p = Text()
p.feed((W/'primary2007.html').read_text())
with (W/'primary2007.txt').open('x') as f:
    f.write('\n'.join(p.parts))
observations = dict(recorded_at=datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),
    queries=['vibrioferrin "1992" "05311"', '"Structure and iron transport activity of vibrioferrin"'],
    note='Search snippets used only as leads. Earlier EPMC structured metadata was fetched successfully before these page challenges. The same EPMC fullTextXML endpoint returned500 twice for2003 and once for2016; standard public pages were then inspected, not after an authorization denial. Once challenges appeared, no alternate source retrieval was attempted.',
    access_stops=[dict(url=u, outcome='Checking your browser - reCAPTCHA; no article text inspected from this page') for u in ['https://pmc.ncbi.nlm.nih.gov/articles/PMC262695/','https://pmc.ncbi.nlm.nih.gov/articles/PMC4702634/','https://pubmed.ncbi.nlm.nih.gov/7961600/']],
    uninspected_leads=['PMID42479344 (2026 computational stereochemistry paper); not evidence for experimental configuration'])
with (W/'web-observations.json').open('x') as f:
    json.dump(observations,f,indent=2)
print('\n'.join(p.parts))
