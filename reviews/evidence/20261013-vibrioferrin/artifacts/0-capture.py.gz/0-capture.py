import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml
from naturalproductmech.graph_components import read_natural_product
from naturalproductmech.curate.structure_corrections import row_digest

W = Path(__file__).parent
P = Path('/private/tmp/npmech-myxochromide-resume-A59XD1')
R = Path.cwd()
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
started = now()
cp = P / 'review-campaign-checkpoint.json'
assert sha(cp) == 'd358c28e474ae549d3e0b3ca22e7434b555f73be09ffeb0cbbf97f80b002b31e'
prior = json.loads(cp.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == prior['base']
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True)
owners = {r['path']: r for r in prior['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
actual = {str(p.relative_to(R)) for folder in ('data/natural_products', 'data/causal_graphs') for p in (R / folder).rglob('*.yaml')}
assert len(owners) == 3115 and len(components) == 243 and actual == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(R / path) == row['sha256'], path
for row in prior['all_review_observations']:
    assert sha(R / row['yaml']) == row['yaml_sha256']
    assert sha(R / row['markdown']) == row['markdown_sha256']
assert len(prior['all_review_observations']) == 36
old = json.loads((P / 'myxochromide-a-inspect.json').read_text())
contexts = [i['path'] for i in old['source']['inputs'] if not i['path'].startswith('data/natural_products/') or i['path'].endswith('PATHS.tsv')]
assert all(sha(R / i['path']) == i['sha256'] for i in old['source']['inputs'])
selected = prior['pending_in_priority_order'][:2]
assert [Path(p).stem for p in selected] == ['vibrioferrin-2', 'vibrioferrin']
keys, refs = set(), set()
for path in selected:
    d = read_natural_product(R / path)
    assert not owners[path]['graph_components']
    assert d == yaml.safe_load((R / path).read_text())
    keys.add(d['chemical_structure']['standard_inchi_key'])
    for slot in ('producer_organisms', 'biosynthetic_gene_clusters', 'occurrences'):
        for obj in d.get(slot, []):
            for e in obj.get('evidence', []):
                refs.add(e['reference'])
    slug = Path(path).stem
    target = dict(target_id=d['identifier'], path=path, label=d['label'], record_class='NaturalProductRecord', kind='generated', owner_paths=old['targets'][0]['owner_paths'])
    for suffix, payload in [('targets', dict(targets=[target])), ('resolved', d)]:
        with (W / (slug + '-' + suffix + '.json')).open('x') as f:
            json.dump(payload, f, indent=2)
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(W / (slug + '-targets.json'))]
    for context in sorted(set(contexts + selected)):
        command += ['--input', context]
    receipt = dict(command=command, started_at=now())
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    inspection = json.loads(result.stdout)
    for inp in inspection['source']['inputs']:
        assert hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + inp['path']])).hexdigest() == inp['sha256']
    output = W / (slug + '-inspect.json')
    with output.open('x') as f:
        f.write(result.stdout)
    receipt.update(finished_at=now(), exit_code=0, log=str(output), log_sha256=sha(output))
    with (W / (slug + '-inspect.receipt.json')).open('x') as f:
        json.dump(receipt, f, indent=2)
rows = {}
for name in ('mibig_compounds', 'npclassifier', 'lotus_occurrences', 'chebi_structures', 'chebi_origins', 'antibioticmech_inchikeys', 'pubchem_bioassay'):
    with (R / 'data/raw' / (name + '.tsv')).open() as f:
        rows[name] = [dict(line=i, source_row_sha256=row_digest(row), **row) for i, row in enumerate(csv.DictReader(f, delimiter='\t'), 2)
                      if row.get('standard_inchi_key') in keys or 'vibrioferrin' in ' '.join(row.values()).lower()]
with (W / 'source-rows.json').open('x') as f:
    json.dump(rows, f, indent=2)
aliases = ['vibrioferrin', *keys, 'CHEBI:84585', '197680', 'NPA024673', 'BGC0000946', 'BGC0000947', 'BGC0002527', 'Q134280', 'Q3556827', 'Q2157875']
aliases += [r.split(':', 1)[1].strip().lower() for r in refs]
stops = prior['access_stops_no_alternate_retrieval']
matches = []
for s in stops:
    terms = json.dumps({k: v for k, v in s.items() if k in ['url', 'aliases', 'description', 'error', 'reference']}).lower()
    if any(a.lower() in terms for a in aliases):
        matches.append(s)
report = dict(started_at=started, finished_at=now(), base=base, prior_checkpoint=str(cp), prior_checkpoint_sha256=sha(cp),
    previous_turn_classification='progress: two saved myxochromide owner reviews, independent primary evidence and completed validation',
    owners_verified=3115, components_verified=243, prior_observations_verified=36, prior_inspected_context_unchanged=True,
    exact_git_tree_inputs_verified=True, source_row_counts={n: len(v) for n, v in rows.items()},
    references=sorted(refs), source_aliases_checked=aliases, prior_access_matches=matches, inherited_access_count=len(stops),
    prior_native_verification=dict(qc_workspace='/private/tmp/npmech-ferrichrome-publish-i31W5V', labels_and_corpus_workspace=str(P), note='Prior executed runs, not fresh checks; source bytes and full corpus reverified. New owners and review outputs get fresh strict/chemistry/canonical checks.'))
with (W / 'capture.json').open('x') as f:
    json.dump(report, f, indent=2)
print(json.dumps(report, indent=2))
