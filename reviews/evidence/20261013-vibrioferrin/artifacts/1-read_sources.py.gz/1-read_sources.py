import json
import xml.etree.ElementTree as ET
from pathlib import Path

import fitz

W = Path(__file__).parent
O = Path('/private/tmp/npmech-vibrioferrin-review-eZIUfP')
out = {}
root = ET.parse(O / 'taxonomy.xml').getroot()
out['taxonomy'] = [{k: t.findtext(k) for k in ['TaxId', 'ScientificName', 'Rank', 'ParentTaxId', 'Lineage']} for t in root.findall('Taxon')]
out['sequences'] = []
for name in ['sequences.xml', 'CP005094-locus.xml']:
    for seq in ET.parse(O / name).getroot().findall('GBSeq'):
        features = []
        for f in seq.findall('./GBSeq_feature-table/GBFeature'):
            q = {}
            for item in f.findall('./GBFeature_quals/GBQualifier'):
                q.setdefault(item.findtext('GBQualifier_name'), []).append(item.findtext('GBQualifier_value'))
            features.append(dict(key=f.findtext('GBFeature_key'), location=f.findtext('GBFeature_location'), qualifiers={k:v for k,v in q.items() if k != 'translation'}))
        out['sequences'].append(dict(payload=name, accession=seq.findtext('GBSeq_accession-version'), length=seq.findtext('GBSeq_length'), definition=seq.findtext('GBSeq_definition'), features=features, references=[dict(title=r.findtext('GBReference_title'), pubmed=r.findtext('GBReference_pubmed'), journal=r.findtext('GBReference_journal')) for r in seq.findall('./GBSeq_references/GBReference')]))
out['metadata'] = [{k:r.get(k) for k in ['id','doi','title','abstractText','pmcid','isOpenAccess']} for r in json.loads((O/'metadata.json').read_text())['resultList']['result']]
with (W/'source-inspection.json').open('x') as f:
    json.dump(out, f, indent=2)
doc = fitz.open(W/'jstage2011.pdf')
with (W/'jstage2011.txt').open('x') as f:
    for i, p in enumerate(doc):
        f.write(f'\n=== PDF PAGE {i+1} ===\n'+p.get_text())
        p.get_pixmap(matrix=fitz.Matrix(1.6,1.6)).save(W/f'jstage2011-page-{i+1}.png')
print(json.dumps(out, indent=2))
print('JSTAGE pages:', len(doc))
