"""Preserve exhaustive campaign coverage and verify the review-only write boundary."""
import copy
import csv
import hashlib
import json
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path(__file__).parent
PRIOR = Path('/private/tmp/npmech-prodigiosin-review-m1Ai8z/post-merge-campaign-checkpoint.json')
BASE = '9e5163ca9689a98df9af76f1ccb38fe0df72594c'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(PRIOR) == 'e99832882385598300a4b333f7337a36a27ea52f5b20ab77cf910b6b264979e5'
checkpoint = copy.deepcopy(json.loads(PRIOR.read_text()))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE
records = {row['path']: row for row in checkpoint['records']}
components = {c['path']: c for row in records.values() for c in row['graph_components']}
actual = {str(p.relative_to(ROOT)) for folder in ('data/natural_products', 'data/causal_graphs')
          for p in (ROOT / folder).rglob('*.yaml')}
assert actual == records.keys() | components.keys()
for name, row in (records | components).items():
    assert sha(ROOT / name) == row['sha256'], name
for observation in checkpoint['all_review_observations']:
    assert sha(ROOT / observation['yaml']) == observation['yaml_sha256']
    assert sha(ROOT / observation['markdown']) == observation['markdown_sha256']
new = []
for draft in json.loads((WORK / 'assessed-drafts.json').read_text()):
    assert sha(Path(draft['content'])) == draft['sha256']
    path = ROOT / 'reviews/structured' / draft['review_id'] / 'review.yaml'
    review = yaml.safe_load(path.read_text())
    assert review == yaml.safe_load(Path(draft['content']).read_text())
    markdown = path.with_suffix('.md')
    target, = review['targets']
    assert records[target['path']]['review_state'] == 'unassessed'
    assert review['completion'] == 'partial' and review['scientific_review']
    entry = dict(review_id=review['review_id'], yaml=str(path.relative_to(ROOT)), yaml_sha256=sha(path),
                 markdown=str(markdown.relative_to(ROOT)), markdown_sha256=sha(markdown),
                 target_id=target['target_id'], path=target['path'], verdict=review['verdict'],
                 completion=review['completion'], scientific_review=True, findings=review['findings'],
                 finished_at=review['finished_at'])
    new.append(entry)
    checkpoint['all_review_observations'].append(entry)
    checkpoint['reviews'].append(entry)
    records[target['path']]['review_state'] = 'partial'
    checkpoint['partial_followups'].append(target['path'])
    checkpoint['pending_in_priority_order'].remove(target['path'])
assert {str(p.relative_to(ROOT)) for p in (ROOT / 'reviews/structured').rglob('review.yaml')} == {o['yaml'] for o in checkpoint['all_review_observations']}
heads = {}
for observation in sorted(checkpoint['all_review_observations'], key=lambda r: (r['finished_at'], r['review_id'])):
    for finding in observation['findings']:
        for previous in finding.get('previous_occurrences', []):
            predecessor = heads.pop((previous['review_id'], previous['finding_id']))
            assert predecessor['issue_key'] == finding['issue_key']
        heads[(observation['review_id'], finding['finding_id'])] = dict(finding, review_id=observation['review_id'], finished_at=observation['finished_at'])
counts = dict(Counter(f['severity'] for f in heads.values() if f['status'] in {'open', 'deferred'}))
assert counts == {'blocker': 4, 'major': 5, 'minor': 2}
assert len(checkpoint['reviews']) == len(checkpoint['partial_followups']) == 12
assert len(checkpoint['all_review_observations']) == 15
assert len(checkpoint['pending_in_priority_order']) == 3103
assert set(checkpoint['pending_in_priority_order']) | set(checkpoint['partial_followups']) == records.keys()
assert not set(checkpoint['pending_in_priority_order']) & set(checkpoint['partial_followups'])
with (WORK / 'review-queue.tsv').open() as handle:
    queue = list(csv.DictReader(handle, delimiter='\t'))
assert records.keys() <= {r['path'] for r in queue}
assert len(queue) == 8931
qc = json.loads((WORK / 'qc.receipt.json').read_text())
review_check = json.loads((WORK / 'review-check.receipt.json').read_text())
assert qc['exit_code'] == review_check['exit_code'] == 0
assert sha(Path(qc['log'])) == qc['log_sha256']
assert sha(Path(review_check['log'])) == review_check['log_sha256']
assert not subprocess.check_output(['git', 'diff', '--name-only', BASE], text=True).strip()
expected_new = {n[k] for n in new for k in ('yaml', 'markdown')}
untracked = set(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines())
assert untracked == expected_new, untracked ^ expected_new
new_stops = [
    dict(aliases=['PMID:9371453', 'DOI:10.1128/JB.179.22.7055-7062.1997'], reason='ASM publisher403 observed2026-10-13T10:01:33Z', no_alternate_retrieval=True),
    dict(aliases=['DOI:10.1016/S0021-9258(17)43671-4'], reason='Official JBC publisher403 observed2026-10-13T10:18:32Z after DOI-tool error', no_alternate_retrieval=True),
    dict(aliases=['PMID:11112537', 'DOI:10.1021/bi001651a'], reason='Inherited owner/audit publisher403; no new full-text request', no_alternate_retrieval=True),
    dict(aliases=['PMID:11112538'], reason='Inherited owner/audit no usable article content; no new full-text request', no_alternate_retrieval=True),
    dict(aliases=['PMID:11160122'], reason='Inherited owner/audit browser challenge; no new full-text request', no_alternate_retrieval=True),
]
checkpoint['new_access_stops'].extend(new_stops)
checkpoint.update(
    branch=subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip(),
    recorded_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    goal_status='active', partial_reviews=12, scientific_review_bundles=15,
    completed_scientific_reviews=0, unassessed_records=3103,
    count_note='Twelve unique partial owners; fifteen immutable observations include three earlier scoped dispositions. Zero completed owners. No sampling or scope reduction.',
    prior_checkpoint=str(PRIOR), prior_checkpoint_sha256=sha(PRIOR),
    previous_turn_classification='progress: completed full QC and verified prior publication; no new scientific review was saved in the immediate preceding turn',
    this_turn_classification='progress: two new partial scientific observations; exact chemistry and eleven current protein/native CDS checks; one major and two minor findings saved',
    latest_finding_heads=list(heads.values()), findings=counts,
    prior_publication=checkpoint.get('publication'), publication=dict(phase='review-only bundles saved locally; no commit, PR or GitHub mutation this continuation'),
    required_work_remaining='Finish all12 partial owners and review every3103 unassessed owner; resolve source-access and exact experimental-product uncertainties without treating deterministic gates as scientific completion.',
    frontier_note='Next pending exact owners: yersiniabactin-2 and yersiniabactin; all other pending paths and partial follow-ups retained.',
    live_sessions=0, corpus_state='git_commit', review_bundle_state='working_tree',
    access_stop_note='Preserve inherited162 stops, seven prior prodigiosin stops, two newly observed publisher403s and three inherited vibriobactin method limits. Wikidata timeout is not an access-denial stop.',
    working_chemistry_command=['env', 'RDBASE=/private/tmp/npmech-rdkit-2026.03.5/share/RDKit', '/private/tmp/npmech-rdkit-2026.03.5/bin/python'],
    working_chemistry_note='Exact RDKit2026.03.5 full Chem/InChI calculations work with the actual installed data path. Bare rdBase import was insufficient. Initial RDPaths failure is retained, no environment package was patched.',
    verification=dict(qc_receipt=str(WORK / 'qc.receipt.json'), qc_receipt_sha256=sha(WORK / 'qc.receipt.json'),
                      review_check_receipt=str(WORK / 'review-check.receipt.json'), review_check_receipt_sha256=sha(WORK / 'review-check.receipt.json'),
                      records_unchanged=3115, components_unchanged=243, prior_reviews_unchanged=13, new_files=sorted(expected_new), ignored_inclusive=True),
)
checkpoint['do_not_replay'] += ['capture.py', 'audit_current.py output modes', 'prepare_reviews.py', 'finalize_drafts.py', 'finalize_drafts_v2.py', 'checkpoint_current.py']
path = WORK / 'review-campaign-checkpoint.json'
with path.open('x') as handle:
    json.dump(checkpoint, handle, indent=2)
print(json.dumps(dict(checkpoint=str(path), sha256=sha(path), partial_owners=12, observations=15, completed=0,
                      pending=3103, open_findings=counts, next_pending=checkpoint['pending_in_priority_order'][:6]), indent=2))
