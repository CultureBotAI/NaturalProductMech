"""Author new observations without modifying scientific owners or prior reviews."""
import csv
import hashlib
import json
import shlex
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml

WORK = Path(__file__).parent
ROOT = Path.cwd()
REPO = 'CultureBotAI/NaturalProductMech'
BASE = '9e5163ca9689a98df9af76f1ccb38fe0df72594c'


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((WORK / name).read_text())


def owner(path, role):
    return dict(repository=REPO, path=path, role=role)


def evidence(eid, kind, reference, summary, support='supports', locator=None, path=None, accessed=None, search_scope=None):
    out = dict(evidence_id=eid, kind=kind, reference=reference, accessed_at=accessed or now(), support=support, summary=summary)
    if locator:
        out['locator'] = locator
    if path:
        out['snapshot_sha256'] = sha(path)
    if search_scope:
        out['search_scope'] = search_scope
    return out


def assess(aid, area, topic, outcome, summary, evidence_ids, target):
    return dict(assessment_id=aid, area=area, topic=topic, outcome=outcome, summary=summary,
                target_ids=[target], evidence_ids=evidence_ids)


def check(label, target, summary, required=True):
    receipt = read(label + '.receipt.json')
    assert sha(Path(receipt['log'])) == receipt['log_sha256']
    return dict(check_id=label, name=label, status='passed' if receipt['exit_code'] == 0 else 'failed',
                required=required, summary=summary, command=shlex.join(receipt['command']),
                exit_code=receipt['exit_code'], target_ids=[target], evidence_ids=['receipts'])


def capture(slug):
    old = read(slug + '-inspect.json')
    assert old['source']['git_revision'] == BASE
    for item in old['source']['inputs']:
        assert sha(ROOT / item['path']) == item['sha256'], item['path']
    target = old['targets'][0]
    inputs = sorted({i['path'] for i in old['source']['inputs']} | {p['path'] for p in target['owner_paths']} |
                    {'scripts/record_review.py', 'src/naturalproductmech/curate/producer_strains.py'})
    command = [sys.executable, 'scripts/record_review.py', 'inspect', '--targets', str(WORK / (slug + '-targets.json'))]
    for path in inputs:
        command += ['--input', path]
    started = now()
    result = subprocess.run(command, capture_output=True, text=True)
    output = WORK / (slug + '-final-inspect.json')
    with output.open('x') as handle:
        handle.write(result.stdout)
    with (WORK / (slug + '-final-inspect.stderr')).open('x') as handle:
        handle.write(result.stderr)
    receipt = dict(command=command, cwd=str(ROOT), started_at=started, finished_at=now(),
                   exit_code=result.returncode, log=str(output), log_sha256=sha(output))
    with (WORK / (slug + '-final-inspect.receipt.json')).open('x') as handle:
        json.dump(receipt, handle, indent=2)
    assert result.returncode == 0, result.stderr
    captured = json.loads(result.stdout)
    captured['source']['state'] = 'git_commit'
    return captured


def build(slug):
    captured = capture(slug)
    target = captured['targets'][0]
    tid, path = target['target_id'], target['path']
    minted = slug.endswith('-2')
    doc = yaml.safe_load((ROOT / path).read_text())
    bgc = 'BGC0000945' if minted else 'BGC0002494'
    bgc_file = WORK / (bgc + '.3.json')
    annotation = json.loads(bgc_file.read_text())
    classification = read('source-rows.json')
    key = doc['chemical_structure']['standard_inchi_key']
    row, = [r for r in classification['npclassifier'] if r['standard_inchi_key'] == key]
    assert row['pathway_results'] == 'Alkaloids' and row['model_version'] == doc['np_classification']['tool_version']
    chemistry = read('chemistry-current.json')
    assert chemistry['rdkit'] == '2026.03.5'
    assert chemistry['structures'][slug + '_smiles']['key'] == key
    ev = [
        evidence('owner', 'record_content', path,
                 'Complete owner, evidence and history read; complete-mechanism reader resolves ' +
                 ('zero graphs.' if minted else 'one inline graph with 12 nodes and 11 edges, and no referenced components.'),
                 path=ROOT / path, locator='Entire YAML and resolved analysis view'),
        evidence('inventory', 'record_content', str(WORK / 'source-rows.json'),
                 'Complete six TSV inventories parsed by exact keys. MIBiG lines1032/3118, LOTUS lines8442/4223, ChEBI line2054 and NPClassifier lines2276/1371 retain distinct structures. No matching ChEBI occurrence or AntibioticMech row in those complete inventories.',
                 path=WORK / 'source-rows.json', search_scope='csv.DictReader over all rows of the six named committed inventories; ignored-file status does not filter parsed rows. This is not a claim about all external databases.'),
        evidence('receipts', 'validation', str(WORK),
                 'Executed-command receipts preserve UTC timing, commands, actual exit codes and log hashes. The initial chemistry import failure is retained beside the configured successful retry. QC was completed on the same verified corpus bytes.'),
        evidence('capture', 'validation', str(WORK / 'revalidate-current.json'),
                 'Ignored-inclusive Path.rglob and SHA256 checks cover all3115 owners,243 graph components and13 pre-existing immutable review pairs; all match the prior campaign checkpoint.',
                 path=WORK / 'revalidate-current.json'),
        evidence('chemistry', 'validation', str(WORK / 'chemistry-current.json'),
                 'RDKit2026.03.5 recomputes each stored key from SMILES and Standard InChI. Both forms have C35H39N5O11, charge0 and noFe. The minted representation has two unassigned stereocentres; the ChEBI form has none. Within-representation ChEBI matches hold; InChI reconstruction changes amide/imidic-acid encoding.',
                 path=WORK / 'chemistry-current.json', locator='structures, cached_chebi and pubchem'),
        evidence('bgc', 'database', 'https://mibig.secondarymetabolites.org/repository/' + bgc + '.3/annotations.json',
                 'Active entry version3 matches the owner source compound SMILES, taxonomy, genome accession and original locus method. Entry quality is not used as scientific validation. ' +
                 ('AE003852.1 interval2353277..2364087 has no stated locus method and no imported causal grade.' if minted else
                  'U52150.2 has zero/unspecified bounds and Heterologous expression; legacy references explicitly identify PMID10601218 and DOI10.1128/JB.181.24.7588-7596.1999 as one citation.'),
                 path=bgc_file, accessed=read('mibig-945.receipt.json' if minted else 'mibig-2494.receipt.json')['finished_at']),
        evidence('rubric', 'record_content', 'docs/record-review-profile.md',
                 'Exact structure, narrow claim evidence, producer-versus-occurrence and locus-versus-taxon rules. docs/CURATION.md owns implemented corrections; decisions.tsv is reserved and cannot effect a fix.'),
        evidence('local-search', 'search', 'curation; conf; reviews/structured',
                 'No pre-existing vibriobactin-specific correction or structured observation matched the bounded ignored-inclusive search before these reviews were saved.',
                 support='context_only', search_scope='rg --hidden --no-ignore for vibriobactin, BGC0002494, BGC0000945, LLMKLMMXMOTPRU and SNUNDXZQRUCXRW under curation, conf and reviews/structured; only the known generated record_review_queue.tsv was excluded. No global absence claim.'),
        evidence('taxonomy', 'database', 'data/raw/corpus_taxa.obo',
                 'Pinned corpus taxonomy resolves NCBITaxon666 as Vibrio cholerae and243277 as the N16961 strain. Current A5F3F4 explicitly resolves345073 to O395; native O395 deposits use the broader666. Those source scopes remain distinct.',
                 support='partial', path=ROOT / 'data/raw/corpus_taxa.obo', locator='Terms666 and243277; A5F3F4 organism object'),
        evidence('imodulondb', 'database', str(WORK / 'imodulondb.log'),
                 'The complete shared-adapter catalogue lists V. natriegens, not V. cholerae. No applicable dataset was found in that catalogue; no substitute-species query or negative biological conclusion was made.',
                 support='context_only', path=WORK / 'imodulondb.log'),
        evidence('access', 'search', 'https://journals.asm.org/doi/10.1128/jb.179.22.7055-7062.1997',
                 'PMID9371453/DOI10.1128/JB.179.22.7055-7062.1997 returned publisher403 at10:01:33Z. The1984 isolation DOI10.1016/S0021-9258(17)43671-4 first had a DOI-tool error, then official JBC403 at10:18:32Z. No alternate content route was attempted after either403.',
                 support='unknown', accessed='2026-10-13T10:18:32Z', search_scope='Exact cited1997 publisher URL; exact1984 DOI and official JBC fulltext URL. Previous11112537 publisher403,11112538 unusable content and11160122 challenge remain binding; no full-methods claims inferred.'),
    ]
    checks = [
        check(slug + '-inspect', tid, 'Original canonical exact-owner capture before assessment.'),
        check(slug + '-final-inspect', tid, 'Rechecked all earlier hashes and added maintained-source hashes; no silently refreshed changed inputs.'),
        check('revalidate', tid, 'All3115 owners,243 components and13 prior observations match the authoritative post-merge checkpoint.'),
        check('strict-' + slug, tid, 'Native closed-schema validator: one owner, zero errors.'),
        check('qc', tid, 'Full native QC passed:652 tests,3 skipped;3115 owners validate and reproduce; site, provenance, vendor, lint and corpus gates pass. This is not scientific sign-off.'),
        check('labels-enforce', tid, 'Native enforcement exits0;499 warning mismatches and4649 skipped-no-adapter pairs remain corpus-wide. No target-owner warning rows in the report.'),
        check('labels-report', tid, 'Diagnostic report complements enforcement, not a substitute for it; report mode itself always exits0.'),
        check('queue', tid, 'Fresh native queue contains8931 diagnostics covering all3115 owner paths plus curation/unresolved_taxa.tsv; it is not a count of reviews.'),
        check('chemistry', tid, 'Initial import failed because the relocated RDKit environment lacks RDPaths; the configured retry supersedes this execution, without hiding the failure.', required=False),
        check('chemistry-configured', tid, 'Full chemical recalculation passed with exact RDKit2026.03.5 and RDBASE pointing to its existing share/RDKit directory; no package or record was patched.'),
        dict(check_id='primary-completeness', name='Nearest primary sources and exact experimental product', status='unavailable', required=True,
             summary='Blocked1997/1984 sources and uninspected experimental chemical-form details preclude a completed scientific review. Protein primary-method access limits remain explicit.', target_ids=[tid], evidence_ids=['access']),
        dict(check_id='imodulondb-applicability', name='Structured expression-module cross-check', status='not_applicable', required=False,
             summary='Catalogue retrieval succeeded, but no V. cholerae dataset matches either record; expression modules cannot establish chemical identity.',
             command=shlex.join(read('imodulondb.receipt.json')['command']), exit_code=0, target_ids=[tid], evidence_ids=['imodulondb']),
        dict(check_id='wikidata', name='Occurrence organism provenance link', status='unavailable', required=False,
             summary='Official Q160821 page timed out; stable taxon identity is separately checked, but live Wikidata statements were not read.',
             target_ids=[tid], evidence_ids=['taxonomy']),
    ]
    assessments = [
        assess('identity', 'identity', 'Exact chemical representation and grounding', 'supported',
               'Database identity and internal chemistry match ' + key + '. ' +
               ('PubChem5487798 agrees; incomplete stereochemistry is correctly flagged, and the content-hashed MIBiG identifier is not misgrounded to CHEBI9973.' if minted else
                'Live ChEBI9973 and NPAtlasNPA033096 agree with the neutral free-compound form. This is not the ferric complex or the other same-label tautomer/stereo representation.'),
               ['owner', 'chemistry', 'bgc', 'inventory'], tid),
        assess('classification', 'consistency', 'Computed filing versus biological origin and taxonomy', 'supported',
               'Pinned NPClassifier Alkaloids/Ornithine alkaloids/Polyamines remains computed. MIBiG ' + ('OTHER' if minted else 'NRPS/TypeI') +
               ' is an independent source classification. NATURAL_PRODUCT comes from source origin, not structural prediction; the assay host is not reclassified as an engineered producer. OTHER_BACTERIAL is consistent with the retained Vibrio taxon.',
               ['owner', 'inventory', 'bgc', 'taxonomy'], tid),
        assess('audit', 'provenance', 'Generated inputs, status and history', 'supported',
               'Source hashes and full-corpus reproduction match. Native SEEDED status and history remain unchanged; this review does not perform curation. No quantitative activity, molecular target, clinical-status, dataset or cross-corpus assertion is encoded.',
               ['owner', 'capture', 'receipts'], tid),
    ]
    findings, actions = [], []
    if minted:
        ev.append(evidence('pubchem', 'database', 'https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/5487798/property/InChI,InChIKey,MolecularFormula/JSON',
                           'CID5487798 returns the exact stored Standard InChI/key and formula; it does not establish the natural isolate stereochemistry.',
                           path=WORK / 'pubchem-5487798.json', accessed=read('pubchem-5487798.receipt.json')['finished_at']))
        assessments[0]['evidence_ids'].append('pubchem')
        assessments += [
            assess('origin', 'evidence', 'One producer, one occurrence and one BGC', 'unknown',
                   'MIBiG asserts N16961 as source and LOTUS cites species666; neither is promoted. The1997 source remains inaccessible, so experimental strain, occurrence and exact keto/enamine form are not independently established. CLUSTER_UNSTATED is appropriately conservative.',
                   ['owner', 'bgc', 'inventory', 'access'], tid),
            assess('mechanism', 'completeness', 'Unencoded pathway and graph', 'not_applicable',
                   'The whole owner contains no mechanism graph or pathway steps. Optional graph absence is not itself a scientific defect. The ChEBI sibling graph must not be copied across the distinct structure key.',
                   ['owner', 'chemistry'], tid),
        ]
    else:
        assert set(annotation['legacy_references']) == {'pubmed:10601218', 'doi:10.1128/JB.181.24.7588-7596.1999'}
        ev += [
            evidence('chebi', 'database', 'https://www.ebi.ac.uk/chebi/CHEBI:9973',
                     'Live name, definition, InChI/key, formulaC35H39N5O11 and charge0 match. Ferric-vibriobactin is a separate ontology entity. Exclusivity to V. cholerae is copied from ChEBI, not established here by a species-wide experimental survey.',
                     locator='Identity, definition, chemistry and ontology sections', accessed='2026-10-13T10:14:03Z'),
            evidence('npatlas', 'database', 'https://www.npatlas.org/explore/compounds/NPA033096',
                     'Chemical SMILES/InChI/key agree. The displayed Unknown-fungus/Fungi origin metadata conflicts with its V. cholerae isolation citation; it is not imported as a producer and does not invalidate the exact chemical xref.',
                     locator='Properties and original isolation metadata', accessed='2026-10-13T10:14:03Z'),
            evidence('wyckoff1999', 'primary_source', 'https://journals.asm.org/doi/10.1128/jb.181.24.7588-7596.1999',
                     'Heterologous complementation tests Viu-dependent transport, not product biosynthesis. Lou15 supplies siderophore; viu mutants retain production. U52150 maps the transport region flanked by biosynthetic annotations.',
                     support='refutes', locator='Main text, Table1, Table3 and notes, characterization of viu mutants; figures read as captions, not image pixels', accessed='2026-10-13T10:14:03Z'),
            evidence('proteins', 'database', str(WORK / 'proteins-current.json'),
                     'All11 current UniProt entries resolve; their canonical sequences match code11 cds=True translations from six pinned native EMBL deposits. Entry/sequence versions, taxon, strain, coordinates, starts/stops and source annotations support nine database-associated and two explicitly putative edges.',
                     path=WORK / 'proteins-current.json', locator='proteins, source_pins and frameshift'),
            evidence('seeder', 'record_content', 'scripts/seed_from_sources.py',
                     'Lines1165-1175 attach an independent-citation corroboration note solely when a producer taxon matches an occurrence taxon; publication identity is not compared.',
                     support='refutes', path=ROOT / 'scripts/seed_from_sources.py', locator='Producer/occurrence corroboration loop'),
        ]
        assessments[0]['evidence_ids'] += ['chebi', 'npatlas']
        checks += [check('uniprot', tid, 'All11 official current UniProt JSON requests returned200 and the expected primary accessions.'),
                   check('protein-audit', tid, 'Independent current-graph audit passed11 exact native CDS translations, evidence snippets, strain qualifiers and graph predicates; native ENA snapshots remain historical pins.')]
        assessments += [
            assess('cluster', 'evidence', 'BGC locus evidence grade', 'concern',
                   'The source metadata is faithfully reproduced but does not justify CLUSTER_DEMONSTRATED for biosynthesis; seeF1. SOURCE_ASSERTION for the taxon is not a causal producer grade.',
                   ['bgc', 'wyckoff1999', 'owner'], tid),
            assess('origin', 'scope', 'Producer and occurrence context', 'concern',
                   'Named-compound occurrence is supported, but exact assay microstate remains unverified. The missing strain qualifier and false citation-independence note are separate bounded defects; seeF2-F3.',
                   ['owner', 'bgc', 'wyckoff1999', 'proteins', 'seeder'], tid),
            assess('graph', 'graph', 'All11 protein participation edges', 'supported',
                   'Within their explicitly limited predicates, all11 edges have source support. N16961, Lou15 and O395 are not conflated; uncertain initiation, automated enterobactin annotations, inferred/predicted protein existence, absent exact reactions and uninspected assay constructs remain qualified.',
                   ['owner', 'proteins', 'chemistry'], tid),
        ]
        assessments[-1]['dimensions'] = [
            dict(name='strains', value='N16961; Lou15 (El Tor); O395', definition='Distinct reference provenance, not one reconstructed strain pathway.', evidence_ids=['proteins']),
            dict(name='claim-tier', value='9 database-associated; 2 putative', definition='Participation annotations, not eleven demonstrated reactions.', evidence_ids=['owner', 'proteins']),
        ]
        specs = [
            ('F1', 'vibriobactin-bgc2494-transport-as-biosynthesis', 'evidence', 'major',
             'Transport complementation is graded as demonstrated biosynthesis',
             'BGC0002494 imports Heterologous expression from the1999 transport study. Its supported phenotype is siderophore utilization, not biosynthetic production by the locus. CLUSTER_DEMONSTRATED therefore overstates this evidence. This does not refute VibD/VibH participation or native production.',
             ['biosynthetic_gene_clusters[0].link_evidence_basis', 'biosynthetic_gene_clusters[0].locus_evidence_methods', 'producer_organisms[0].notes'],
             ['owner', 'bgc', 'wyckoff1999'],
             [owner('curation/mibig_locus_evidence_overrides.tsv', 'Implemented pinned source-method withdrawal'), owner('scripts/seed_from_sources.py', 'Locus and producer grade harmonization')],
             'Material evidence-tier inflation survives deterministic validation; normalized as major unsupported evidence.'),
            ('F2', 'vibriobactin-same-publication-corroboration', 'provenance', 'minor',
             'The producer and occurrence cite the same publication',
             'The occurrence DOI and producer PMID10601218 are the same publication, explicitly aliased by MIBiG. The generated note incorrectly claims a different citation and independent corroboration. Two database assertions are not two experiments.',
             ['occurrences[0].notes'], ['owner', 'bgc', 'seeder'],
             [owner('scripts/seed_from_sources.py', 'Generated cross-source corroboration wording')],
             'Non-blocking provenance wording; the underlying occurrence need not be removed.'),
            ('F3', 'vibriobactin-lou15-producer-strain', 'scope', 'minor',
             'Producer assertion omits the available Lou15 strain qualifier',
             'The producer row is species666 without strain, while its exact U52150.2 source deposit specifies Lou15 (El Tor). The graph already preserves this source distinction. Carry the strain into the producer assertion without changing taxon identity or SOURCE_ASSERTION grade.',
             ['producer_organisms[0].strain'], ['owner', 'proteins'],
             [owner('curation/mibig_producer_strains.tsv', 'Complete-raw-row-pinned source strain qualification'), owner('scripts/seed_from_sources.py', 'Producer claim generation')],
             'Bounded provenance loss; database producer evidence was not falsely promoted to experimental causality.'),
        ]
        for fid, issue, category, severity, title, description, fields, evidence_ids, owners, reason in specs:
            findings.append(dict(finding_id=fid, issue_key=issue, category=category, severity=severity, status='open',
                                 certainty='confirmed', title=title, description=description, target_ids=[tid],
                                 field_paths=fields, evidence_ids=evidence_ids, owner_paths=owners,
                                 rule_id='Native checklist: narrow claim-level evidence; Gene clusters; Producer organisms; Evidence standard',
                                 native_severity=severity, normalization_reason=reason))
        actions = [
            dict(action_id='withdraw-inapplicable-method', finding_ids=['F1'], target_ids=[tid], owner_paths=findings[0]['owner_paths'],
                 description='Use the implemented WITHDRAW path for the exact BGC0002494 compound row, with all required raw-context pins and inspected citation. Preserve original source methods separately and regrade the unsupported locus claim; do not delete the source entry or invent a replacement causal method.',
                 generator='scripts/seed_from_sources.py', acceptance_checks=['Exact-context withdrawal yields CLUSTER_UNSTATED and retains producer SOURCE_ASSERTION.', 'Original MIBiG methods/citation survive as attributed provenance; source drift fails closed.', 'Dry-run, guarded canary, strict validation, reproduction and full QC pass without native status promotion.']),
            dict(action_id='qualify-corroboration', finding_ids=['F2'], target_ids=[tid], owner_paths=findings[1]['owner_paths'],
                 description='Remove unconditional publication-independence language or establish citation identity using a maintained DOI/PMID mapping. Keep distinct provenance objects.',
                 generator='scripts/seed_from_sources.py', acceptance_checks=['The aliased DOI/PMID case is not described as independent experiments.', 'Tests distinguish source multiplicity from publication independence, including unknown aliases.', 'Reproduction and full QC pass; no occurrence is deleted merely for sharing a citation.']),
            dict(action_id='qualify-producer-strain', finding_ids=['F3'], target_ids=[tid], owner_paths=findings[2]['owner_paths'],
                 description='Add an attributed Lou15 (El Tor) qualification through mibig_producer_strains.tsv, pinned to the complete BGC0002494:1 source row.',
                 generator='scripts/seed_from_sources.py', acceptance_checks=['Generated producer carries Lou15 (El Tor); taxon666 and SOURCE_ASSERTION remain unchanged.', 'The complete raw-row digest, source reference and history are preserved; drift and duplicate tests pass.', 'Guarded canary, reproduction and native QC pass.']),
        ]
    actions.append(dict(action_id='complete-primary-review', finding_ids=[], target_ids=[tid], owner_paths=target['owner_paths'],
                        description='With legitimately accessible primary material, finish exact-product and source-scope review; do not retry access-stopped content through alternate routes or import the sibling graph by name.',
                        acceptance_checks=['Inspect relevant primary text, chemical figures and experimental context at the exact owner stereochemical resolution.', 'Save a linked successor observation and retain all unresolved finding heads; do not promote native status solely because checks passed.']))
    finished = now()
    rid = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + slug
    review = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=REPO,
                  title=('MIBiG vibriobactin: distinct incomplete-stereo representation' if minted else 'ChEBI vibriobactin: locus evidence and reference-protein review'),
                  started_at=read('capture.json')['started_at'], finished_at=finished,
                  reviewer=dict(identity='Codex', kind='agent', independence='self_review', independence_basis='Same assistant/thread as earlier curation; this source-checking pass is not an independent reviewer.'),
                  skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial', verdict='seed_only' if minted else 'needs_curation', scientific_review=True,
                  summary=('Exact database representation and conservative BGC grade supported; primary occurrence/producer and isolate-form verification remains incomplete. No confirmed corrective finding in this bounded observation.' if minted else
                           'One major locus-evidence finding and two minor provenance findings. Chemistry and all11 bounded protein references check; inaccessible primary sources prevent scientific completion.'),
                  source=captured['source'], targets=captured['targets'],
                  scope=dict(description='One exact owner at commit' + BASE + '; complete owner and mechanisms read. Same-label sibling is identity context only. The full campaign remains3115 owners and243 components.',
                             selection='Next pending exact path in the exhaustive post-merge checkpoint: ' + path, coverage='partial', population_size=1, reviewed_target_ids=[tid]),
                  checks=checks, evidence=ev, assessments=assessments, findings=findings, actions=actions,
                  limitations=[
                      'Partial scientific observation, not completed campaign coverage or native status promotion. The whole owner was read; some source verification remains unavailable.',
                      '1997 and1984 full texts were access-stopped. Earlier11112537,11112538 and11160122 method limitations remain. The accessible1999 paper was text/table/caption inspected, not a pixel-level figure or supplementary-material audit.',
                      'Fresh MIBiG checks are exact version3 snapshots, not proof that no newer release exists. Fresh UniProt checks and pinned native EMBL translations establish reference correspondence, not biological initiation or assay-construct identity.',
                      'Current exact RDKit computation is successful only after valid RDBASE configuration. The initial failed import and earlier campaign chemistry failures remain historical observations; this review does not silently resolve them.',
                      'All499 corpus label warnings and4649 skipped-no-adapter pairs remain visible. Live Wikidata Q160821 timed out; no whole-ontology or universal identifier verification is claimed.',
                      'No exact experimental microstate, stereochemical revision, strain equivalence or fungus producer is inferred from shared labels, matching keys or upstream metadata conflicts.',
                  ],
                  notes=['No scientific owner, component, raw inventory, page or curation event was changed. Only new immutable review bundles are saved.',
                         'The review resumed after a completed publication/cleanup turn. Original captured inputs were rehashed and found unchanged before adding maintained-input hashes.',
                         'No applicable iModulonDB organism/dataset exists in the inspected adapter catalogue; this says nothing about the biology.',
                         'Receipt provenance: ' + json.dumps({label: dict(sha256=sha(WORK / (label + '.receipt.json')), **read(label + '.receipt.json')) for label in ['qc', 'chemistry', 'chemistry-configured', 'labels-enforce', 'queue']}, sort_keys=True)],
                  tags=['record-review', 'vibriobactin', 'partial'])
    if not minted:
        audit = read('proteins-current.json')
        review['notes'].append('Protein check coordinates: ' + json.dumps([{k: r[k] for k in ('accession', 'native', 'protein_id', 'location', 'start', 'stop', 'residues', 'taxon', 'strain', 'entry_audit', 'canonical_match')} for r in audit['proteins']], sort_keys=True))
    output = WORK / (rid + '.yaml')
    with output.open('x') as handle:
        yaml.safe_dump(review, handle, sort_keys=False, allow_unicode=False, width=95)
    return dict(review_id=rid, content=str(output), sha256=sha(output), target_id=tid)


if __name__ == '__main__':
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE
    assert read('revalidate-current.json')['observations'] == 13
    result = [build(slug) for slug in ('vibriobactin-2', 'vibriobactin')]
    with (WORK / 'prepared-reviews.json').open('x') as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result, indent=2))
