import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml
from naturalproductmech.graph_components import read_natural_product

root = Path.cwd()
work = Path(__file__).parent
prior = Path('/private/tmp/npmech-prodigiosin-review-m1Ai8z/post-merge-campaign-checkpoint.json')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
started = now()
checkpoint = json.loads(prior.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == checkpoint['base'] == '9e5163ca9689a98df9af76f1ccb38fe0df72594c'
records = {r['path']: r for r in checkpoint['records']}
components = {c['path']: c for r in records.values() for c in r['graph_components']}
actual = {str(p.relative_to(root)) for prefix in ['data/natural_products', 'data/causal_graphs']
          for p in (root / prefix).rglob('*.yaml')}
assert actual == records.keys() | components.keys()
for name, row in (records | components).items():
    assert sha(root / name) == row['sha256'], name
for row in checkpoint['all_review_observations']:
    assert sha(root / row['yaml']) == row['yaml_sha256']
    assert sha(root / row['markdown']) == row['markdown_sha256']
owners = {
    'data/raw/mibig_compounds.tsv': 'Imported chemical, producer and BGC assertions',
    'data/raw/lotus_occurrences.tsv': 'Imported exact structure-organism-reference triples',
    'data/raw/chebi_structures.tsv': 'ChEBI identity and definition',
    'data/raw/chebi_origins.tsv': 'ChEBI occurrence assertions',
    'data/raw/npclassifier.tsv': 'Pinned computed classification',
    'data/raw/antibioticmech_inchikeys.tsv': 'Pinned exact-structure sibling joins',
    'scripts/seed_from_sources.py': 'Generated source harmonization',
    'scripts/extract_mibig.py': 'MIBiG extraction',
    'scripts/extract_lotus.py': 'LOTUS occurrence extraction',
}
inputs = [
    'CLAUDE.md', 'justfile', 'docs/CURATION.md', 'docs/HARMONIZATION.md',
    'docs/record-review-profile.md', 'docs/record-reviews.md', 'conf/record_review.yaml',
    '.claude/skills/review-yaml-record/SKILL.md',
    '.claude/skills/curate-yaml-record/references/review-checklist.md',
    'schema/record_review.yaml', 'src/naturalproductmech/schema/naturalproductmech.yaml',
    'src/naturalproductmech/schema/mech_shared.yaml', 'src/naturalproductmech/schema/history.yaml',
    'src/naturalproductmech/graph_components.py', 'conf/producer_evidence.tsv',
    'conf/id_label_targets.yaml', 'data/raw/corpus_taxa.obo', 'data/raw/MANIFEST.yaml',
    'data/natural_products/PATHS.tsv', 'curation/decisions.tsv',
    'curation/mibig_locus_evidence_overrides.tsv', 'curation/mibig_structure_corrections.tsv',
    'curation/mibig_producer_strains.tsv', 'pyproject.toml', 'uv.lock',
    'data/natural_products/alkaloids/vibriobactin-2.yaml',
    'data/natural_products/alkaloids/vibriobactin.yaml',
]
captures = []
for slug in ['vibriobactin-2', 'vibriobactin']:
    name = f'data/natural_products/alkaloids/{slug}.yaml'
    assert name in checkpoint['pending_in_priority_order']
    doc = yaml.safe_load((root / name).read_text())
    owner_paths = [dict(repository='CultureBotAI/NaturalProductMech', path=p, role=r)
                   for p, r in owners.items()]
    if doc.get('causal_graphs'):
        owner_paths.append(dict(repository='CultureBotAI/NaturalProductMech', path=name,
                               role='Curator-owned inline graph; use validated writer, not seeder edits'))
    target = dict(target_id=doc['identifier'], path=name, label=doc['label'],
                  record_class='NaturalProductRecord', kind='generated', owner_paths=owner_paths)
    target_path = work / (slug + '-targets.json')
    with target_path.open('x') as handle:
        json.dump(dict(targets=[target]), handle, indent=2)
    command = [sys.executable, 'scripts/record_review.py', 'inspect', '--targets', str(target_path)]
    for path in inputs:
        command += ['--input', path]
    for graph_id in doc.get('causal_graph_refs', []):
        command += ['--input', f'data/causal_graphs/{doc["chemical_structure"]["standard_inchi_key"]}/{graph_id}.yaml']
    before = now()
    result = subprocess.run(command, capture_output=True, text=True)
    output = work / (slug + '-inspect.json')
    with output.open('x') as handle:
        handle.write(result.stdout)
    with (work / (slug + '-inspect.stderr')).open('x') as handle:
        handle.write(result.stderr)
    receipt = dict(command=command, cwd=str(root), started_at=before, finished_at=now(),
                   exit_code=result.returncode, log=str(output), log_sha256=sha(output))
    with (work / (slug + '-inspect.receipt.json')).open('x') as handle:
        json.dump(receipt, handle, indent=2)
    assert result.returncode == 0, result.stderr
    resolved = read_natural_product(root / name)
    with (work / (slug + '-resolved.json')).open('x') as handle:
        json.dump(resolved, handle, indent=2)
    captures.append(dict(slug=slug, path=name, target_id=doc['identifier'], sha256=sha(root / name),
                         graphs=len(resolved.get('causal_graphs', [])),
                         edges=sum(len(g['edges']) for g in resolved.get('causal_graphs', [])),
                         components=doc.get('causal_graph_refs', [])))
capture = dict(base=base, started_at=started, finished_at=now(), prior_checkpoint=str(prior),
               prior_checkpoint_sha256=sha(prior), ignored_inclusive=True,
               owners_verified=len(records), components_verified=len(components),
               prior_observations_verified=len(checkpoint['all_review_observations']),
               previous_turn_classification='progress: PR883 merged, five issues addressed, exact tree and branch deletion verified',
               captures=captures)
with (work / 'capture.json').open('x') as handle:
    json.dump(capture, handle, indent=2)
print(json.dumps(capture, indent=2))
