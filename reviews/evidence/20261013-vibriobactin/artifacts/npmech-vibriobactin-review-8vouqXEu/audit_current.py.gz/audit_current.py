"""Read-only checks for the two exactly resolved vibriobactin owners."""
import hashlib
import json
import sqlite3
import subprocess
import sys
import urllib.error
import urllib.request
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

import yaml

WORK = Path(__file__).parent
ROOT = Path.cwd()
PRIOR = Path('/private/tmp/npmech-acetylaszonalenin-20261010-MSlYJu')
BASE = '9e5163ca9689a98df9af76f1ccb38fe0df72594c'
TARGETS = [
    ('Q56632', 'AE003852', 'AAF93939.1', 'N16961', 243277),
    ('P0C6D3', 'AE003852', 'AAF93936.1', 'N16961', 243277),
    ('O07898', 'AE003852', 'AAF93938.1', 'N16961', 243277),
    ('O07899', 'AE003852', 'AAF93937.1', 'N16961', 243277),
    ('Q9KTV9', 'AE003852', 'AAF93940.1', 'N16961', 243277),
    ('Q9KTV7', 'AE003852', 'AAF93945.1', 'N16961', 243277),
    ('Q9RCF7', 'U52150', 'AAD48879.1', 'Lou15 (El Tor)', 666),
    ('A5F3F4', 'AF287252', 'AAG00563.1', 'O395', 345073),
    ('Q9FDB2', 'AF287253', 'AAG00564.1', 'O395', 666),
    ('Q9FDB1', 'AF287254', 'AAG00565.1', 'O395', 666),
    ('Q9FDB0', 'AF287255', 'AAG00566.1', 'O395', 666),
]


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (WORK / name).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')


def owners():
    capture = json.loads((WORK / 'capture.json').read_text())
    docs = {}
    for row in capture['captures']:
        path = ROOT / row['path']
        assert sha(path) == row['sha256'], path
        docs[row['slug']] = yaml.safe_load(path.read_text())
    return docs


def revalidate():
    capture = json.loads((WORK / 'capture.json').read_text())
    prior = Path(capture['prior_checkpoint'])
    assert sha(prior) == capture['prior_checkpoint_sha256']
    old = json.loads(prior.read_text())
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE == old['base']
    records = {r['path']: r for r in old['records']}
    components = {c['path']: c for r in records.values() for c in r['graph_components']}
    actual = {str(p.relative_to(ROOT)) for folder in ('data/natural_products', 'data/causal_graphs')
              for p in (ROOT / folder).rglob('*.yaml')}
    assert actual == records.keys() | components.keys()
    for path, row in (records | components).items():
        assert sha(ROOT / path) == row['sha256'], path
    for row in old['all_review_observations']:
        assert sha(ROOT / row['yaml']) == row['yaml_sha256']
        assert sha(ROOT / row['markdown']) == row['markdown_sha256']
    for slug in owners():
        inspect = json.loads((WORK / (slug + '-inspect.json')).read_text())
        for row in inspect['source']['inputs']:
            assert sha(ROOT / row['path']) == row['sha256'], row['path']
    return dict(base=BASE, owners=len(records), components=len(components),
                observations=len(old['all_review_observations']), ignored_inclusive=True,
                previous_turn='progress: completed full QC and verified merged publication; no new scientific review was saved',
                prior_checkpoint=str(prior), prior_checkpoint_sha256=sha(prior))


def chemistry():
    docs = owners()
    inputs = {}
    for slug, doc in docs.items():
        inputs[slug + '_smiles'] = doc['chemical_structure']['smiles']
        inputs[slug + '_inchi'] = doc['chemical_structure']['standard_inchi']
    with closing(sqlite3.connect('file:/Users/marcin/.data/oaklib/chebi.db?mode=ro', uri=True)) as db:
        rows = list(db.execute("SELECT predicate,value FROM statements WHERE subject=? AND "
                               "(predicate LIKE 'chemrof:%' OR predicate='rdfs:label')", ('CHEBI:9973',)))
    assert len(rows) == len(dict(rows))
    cache = dict(rows)
    assert cache['rdfs:label'] == 'vibriobactin'
    inputs['cached_smiles'] = cache['chemrof:smiles_string']
    inputs['cached_inchi'] = cache['chemrof:inchi_string']
    pubchem = json.loads((WORK / 'pubchem-5487798.json').read_text())['PropertyTable']['Properties'][0]
    assert pubchem['CID'] == 5487798
    inputs['pubchem_inchi'] = pubchem['InChI']
    for slug, bgc in [('vibriobactin', 'BGC0002494'), ('vibriobactin-2', 'BGC0000945')]:
        mibig = json.loads((WORK / (bgc + '.3.json')).read_text())
        assert mibig['accession'] == bgc and mibig['version'] == 3 and mibig['status'] == 'active'
        assert mibig['compounds'][0]['structure'] == docs[slug]['chemical_structure']['smiles']
    script = '''import json,sys
from rdkit import Chem,rdBase
from rdkit.Chem import rdMolDescriptors
assert rdBase.rdkitVersion == '2026.03.5'
results={}
for name,value in json.load(sys.stdin).items():
    mol=Chem.MolFromInchi(value) if name.endswith('_inchi') else Chem.MolFromSmiles(value)
    assert mol is not None
    results[name]=dict(key=Chem.MolToInchiKey(mol),formula=rdMolDescriptors.CalcMolFormula(mol),
      charge=Chem.GetFormalCharge(mol),canonical_smiles=Chem.MolToSmiles(mol),
      elements=sorted({a.GetSymbol() for a in mol.GetAtoms()}),
      stereocentres=Chem.FindMolChiralCenters(mol,includeUnassigned=True))
print(json.dumps(dict(rdkit=rdBase.rdkitVersion,structures=results)))'''
    result = json.loads(subprocess.check_output(['/private/tmp/npmech-rdkit-2026.03.5/bin/python', '-c', script],
                                               input=json.dumps(inputs), text=True))
    for name, row in result['structures'].items():
        expected = docs['vibriobactin-2' if name.startswith(('vibriobactin-2', 'pubchem')) else 'vibriobactin']['chemical_structure']['standard_inchi_key']
        assert row['key'] == expected and row['formula'] == 'C35H39N5O11'
        assert row['charge'] == 0 and 'Fe' not in row['elements']
        undefined = sum(c[1] == '?' for c in row['stereocentres'])
        assert undefined == (2 if name.startswith(('vibriobactin-2', 'pubchem')) else 0)
    for form in ('smiles', 'inchi'):
        assert result['structures']['vibriobactin_' + form]['canonical_smiles'] == result['structures']['cached_' + form]['canonical_smiles']
    assert result['structures']['cached_smiles']['canonical_smiles'] != result['structures']['cached_inchi']['canonical_smiles']
    assert pubchem['InChIKey'] == docs['vibriobactin-2']['chemical_structure']['standard_inchi_key']
    return dict(inputs=inputs, cached_chebi=cache, pubchem=pubchem, **result,
                limitation='Database representation validation, not proof of an experimental product microstate or equality between the owners.')


def download():
    receipts = []
    for accession, *_ in TARGETS:
        url = 'https://rest.uniprot.org/uniprotkb/' + accession + '.json'
        receipt = dict(url=url, started_at=now())
        path = WORK / (accession + '-current.json')
        assert not path.exists()
        try:
            with urllib.request.urlopen(url, timeout=45) as response:
                raw = response.read()
                receipt.update(status=response.status, resolved_url=response.url)
            entry = json.loads(raw)
            assert entry['primaryAccession'] == accession
            with path.open('xb') as handle:
                handle.write(raw)
            receipt.update(path=str(path), sha256=sha(path))
        except (urllib.error.URLError, TimeoutError) as exc:
            receipt.update(error=str(exc), disposition='No retry or alternate route attempted')
        receipt['finished_at'] = now()
        receipts.append(receipt)
    return dict(downloads=receipts, all_successful=all('sha256' in r for r in receipts))


def proteins():
    from Bio import SeqIO
    from Bio.SeqFeature import ExactPosition

    doc = owners()['vibriobactin']
    graph, = doc['causal_graphs']
    edges = {e['subject'].upper(): e for e in graph['edges']}
    assert len(edges) == len(TARGETS) == 11
    old = PRIOR / 'protein-frontier-20261010-pr775.json'
    assert sha(old) == '3ca32742e3bfdeee0477b58b6b6bf80c9193c642d1b985653930563f7b6c8aa7'
    pins = json.loads(old.read_text())['research_downloads']
    records, source_pins = {}, {}
    for name in sorted({t[1] for t in TARGETS}):
        path = PRIOR / (name + '.embl')
        assert sha(path) == pins[str(path)], path
        source_pins[str(path)] = sha(path)
        records[name] = SeqIO.read(path, 'embl')
    results = []
    for acc, name, protein_id, strain, taxon in TARGETS:
        entry_path = WORK / (acc + '-current.json')
        entry = json.loads(entry_path.read_text())
        source_pins[str(entry_path)] = sha(entry_path)
        assert entry['primaryAccession'] == acc and entry['organism']['taxonId'] == taxon
        native = records[name]
        assert native.id == name + ('.2' if name == 'U52150' else '.1')
        source, = [f for f in native.features if f.type == 'source']
        assert source.qualifiers['strain'] == [strain]
        feature, = [f for f in native.features if f.type == 'CDS' and f.qualifiers.get('protein_id') == [protein_id]]
        q = feature.qualifiers
        assert q['codon_start'] == ['1'] and q['transl_table'] == ['11']
        assert not any(key in q for key in ('pseudo', 'pseudogene', 'exception', 'transl_except'))
        assert all(type(p.start) is ExactPosition and type(p.end) is ExactPosition and p.ref is None for p in feature.location.parts)
        nt = feature.extract(native.seq)
        aa = str(nt.translate(table=11, cds=True))
        assert aa == q['translation'][0] == entry['sequence']['value']
        assert len(aa) == entry['sequence']['length'] and len(nt) == 3 * (len(aa) + 1)
        crossref, = [r for r in entry['uniProtKBCrossReferences'] if r['database'] == 'EMBL' and r['id'] == name]
        assert {p['key']: p['value'] for p in crossref['properties']}['ProteinId'] == protein_id
        edge = edges[acc]
        assert edge['object'] == 'vibriobactin'
        putative = acc in ('Q9KTV9', 'Q9KTV7')
        assert edge['predicate'] == ('is_putative_biosynthetic_participant_for' if putative else 'is_database_supported_biosynthetic_participant_for')
        snippets = [e['snippet'] for e in edge['evidence'] if e.get('snippet')]
        assert len(snippets) == 1
        annotation = ' '.join(q.get('product', []) + q.get('note', []))
        comments = [c for c in entry.get('comments', []) if c['commentType'] in ('PATHWAY', 'CAUTION', 'FUNCTION', 'SUBUNIT', 'COFACTOR')]
        if acc in ('Q56632', 'P0C6D3', 'O07898', 'O07899'):
            assert snippets[0] in [t['value'] for c in comments if c['commentType'] == 'PATHWAY' for t in c['texts']]
        else:
            assert snippets[0] in annotation
        if putative:
            assert 'identified by sequence similarity; putative' in annotation
        inference, = [e for e in edge['evidence'] if e['reference'].endswith(native.id) and e['evidence_type'] == 'CURATOR_INFERENCE']
        assert str(feature.location) in inference['notes']
        assert f'{len(nt)} nucleotides' in inference['notes']
        results.append(dict(accession=acc, entry_audit=entry['entryAudit'], entry_type=entry['entryType'],
                            protein_existence=entry['proteinExistence'], taxon=taxon, strain=strain,
                            native=native.id, protein_id=protein_id, location=str(feature.location),
                            start=str(nt[:3]), stop=str(nt[-3:]), residues=len(aa), canonical_match=True,
                            native_annotation=annotation, comments=comments, source=source.qualifiers))
    genome = records['AE003852']
    vibf, = [f for f in genome.features if f.qualifiers.get('locus_tag') == ['VC_2209']]
    assert vibf.type == 'gene' and 'authentic frame shift' in vibf.qualifiers['note'][0]
    overlaps = [f for f in genome.features if f.type == 'CDS' and int(f.location.start) < int(vibf.location.end) and int(f.location.end) > int(vibf.location.start)]
    assert not overlaps
    return dict(source_pins=source_pins, proteins=results, frameshift=dict(location=str(vibf.location), qualifiers=vibf.qualifiers),
                limitation='Fresh UniProt metadata and pinned native sequence reanalysis; not fresh ENA retrieval or assay-construct validation.')


if __name__ == '__main__':
    mode = sys.argv[1]
    started = now()
    result = globals()[mode]()
    result.update(started_at=started, finished_at=now(), helper_sha256=sha(Path(__file__)))
    save(mode + '-current.json', result)
    print(json.dumps(result if mode in ('revalidate', 'download') else {k: v for k, v in result.items() if k not in ('inputs', 'structures', 'cached_chebi', 'source_pins', 'proteins')}, indent=2))
