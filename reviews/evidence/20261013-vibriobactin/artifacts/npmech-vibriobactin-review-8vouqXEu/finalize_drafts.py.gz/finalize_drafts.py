"""Correct draft serialization and presentation before immutable saving."""
import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml

WORK = Path(__file__).parent


class NoAliases(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


REPLACEMENTS = {
    'all3115': 'all 3,115', 'All3115': 'All 3,115', 'all11': 'all 11', 'All11': 'All 11',
    'all13': 'all 13', 'All499': 'All 499', 'and4649': 'and 4,649', 'and13': 'and 13',
    'and243': 'and 243', 'and1984': 'and 1984', 'the1999': 'the 1999', 'The1997': 'The 1997',
    'the1997': 'the 1997', 'The1984': 'The 1984', 'The1984': 'The 1984', 'the1984': 'the 1984',
    'accessible1999': 'accessible 1999', 'Blocked1997': 'Blocked 1997', 'Earlier11112537': 'Earlier PMID:11112537',
    ',11112538': ', PMID:11112538', 'and11160122': 'and PMID:11160122', 'Previous11112537': 'Previous PMID:11112537',
    'remain3115': 'remain 3,115', 'commit9e5163': 'commit 9e5163', 'seeF1': 'see F1', 'seeF2-F3': 'see F2-F3',
    'species666': 'species NCBITaxon:666', 'taxon666': 'taxon NCBITaxon:666', 'PubChem5487798': 'PubChem:5487798',
    'CHEBI9973': 'CHEBI:9973', 'PMID10601218': 'PMID:10601218', 'PMID9371453': 'PMID:9371453',
    'DOI10.': 'DOI:10.', 'RDKit2026': 'RDKit 2026', 'version3': 'version 3', 'formulaC35': 'formula C35',
    'charge0': 'charge 0', 'noFe': 'no Fe', 'lines1032': 'lines 1032', 'lines8442': 'lines 8442',
    'lines2276': 'lines 2276', 'line2054': 'line 2054', 'Lines1165': 'Lines 1165', 'Table1': 'Table 1',
    'Table3': 'Table 3', 'code11': 'code 11', 'deposit specifies': 'deposit specifies', 'returned200': 'returned 200',
    'publisher403': 'publisher 403', 'JBC403': 'JBC 403', 'either403': 'either 403', 'at10:': 'at 10:',
    'source support.': 'source support.', 'passed11': 'passed 11', 'contains8931': 'contains 8,931',
    'failed0': 'failed 0', 'exits0': 'exits 0', 'exit0': 'exit 0', 'passed:652': 'passed: 652',
    'tests,3': 'tests, 3', ';3115': '; 3,115', 'owners,243': 'owners, 243', 'complete3115': 'complete 3,115',
    'ENTRY': 'ENTRY', 'and4649': 'and 4,649', 'fields,3': 'fields, 3', 'to O395': 'to O395',
    'resolves345073': 'resolves 345073', 'broader666': 'broader 666', 'NCBITaxon666': 'NCBITaxon:666',
    'and243277': 'and 243277', 'Terms666': 'Terms 666',
}
TEXT_FIELDS = {'title', 'summary', 'description', 'details', 'definition', 'role', 'normalization_reason',
               'rule_id', 'scope_note', 'locator', 'search_scope', 'limitations', 'acceptance_checks', 'notes'}


def polish(value, enabled=False):
    if isinstance(value, dict):
        return {k: polish(v, k in TEXT_FIELDS) for k, v in value.items()}
    if isinstance(value, list):
        return [polish(v, enabled) for v in value]
    if isinstance(value, str) and enabled and not value.startswith(('Receipt provenance:', 'Protein check coordinates:')):
        for old, new in REPLACEMENTS.items():
            value = value.replace(old, new)
    return value


outputs = []
for item in json.loads((WORK / 'prepared-reviews.json').read_text()):
    original = Path(item['content'])
    assert hashlib.sha256(original.read_bytes()).hexdigest() == item['sha256']
    review = polish(yaml.safe_load(original.read_text()))
    slug = 'vibriobactin-2' if item['target_id'].startswith('naturalproductmech:') else 'vibriobactin'
    failed = json.loads((WORK / ('validate-' + slug + '.receipt.json')).read_text())
    assert failed['exit_code'] == 1
    review['checks'].append(dict(check_id='draft-serialization', name='Initial draft validation', status='failed',
                                 required=False, summary='Draft YAML serialization introduced aliases rejected by the canonical validator. Final serialization disables aliases; original failed draft and receipt are retained.',
                                 command=shlex.join(failed['command']), exit_code=1, target_ids=[item['target_id']], evidence_ids=['receipts']))
    review['notes'].append('Initial draft validation receipt: ' + json.dumps(failed, sort_keys=True))
    if slug == 'vibriobactin':
        doc_owner = dict(repository='CultureBotAI/NaturalProductMech', path='docs/HARMONIZATION.md', role='Producer-versus-occurrence corroboration documentation')
        review['findings'][1]['owner_paths'].append(doc_owner)
        review['actions'][1]['owner_paths'].append(doc_owner)
        review['actions'][1]['acceptance_checks'].append('Documentation and report wording must not equate two source databases with independent publications.')
    finished = datetime.now(timezone.utc)
    review['finished_at'] = finished.isoformat().replace('+00:00', 'Z')
    review['review_id'] = finished.strftime('%Y%m%dT%H%M%SZ') + '-' + slug
    path = WORK / (review['review_id'] + '-final.yaml')
    with path.open('x') as handle:
        yaml.dump(review, handle, Dumper=NoAliases, sort_keys=False, allow_unicode=False, width=95)
    outputs.append(dict(review_id=review['review_id'], content=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), target_id=item['target_id']))
with (WORK / 'final-drafts.json').open('x') as handle:
    json.dump(outputs, handle, indent=2)
print(json.dumps(outputs, indent=2))
