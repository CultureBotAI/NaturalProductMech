"""Separate executed adapter checks from applicability and retain validation history."""
import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml

WORK = Path(__file__).parent


class NoAliases(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


outputs = []
for item in json.loads((WORK / 'final-drafts.json').read_text()):
    path = Path(item['content'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
    review = yaml.safe_load(path.read_text())
    slug = 'vibriobactin-2' if item['target_id'].startswith('naturalproductmech:') else 'vibriobactin'
    applicable, = [c for c in review['checks'] if c['check_id'] == 'imodulondb-applicability']
    command = applicable.pop('command')
    code = applicable.pop('exit_code')
    review['checks'].append(dict(check_id='imodulondb-catalogue', name='Shared-adapter dataset catalogue',
                                 status='passed', required=False, command=command, exit_code=code,
                                 summary='Catalogue retrieval executed successfully; the distinct applicability assessment remains not_applicable.',
                                 target_ids=[item['target_id']], evidence_ids=['imodulondb']))
    failed = json.loads((WORK / ('validate-final-' + slug + '.receipt.json')).read_text())
    assert failed['exit_code'] == 1
    review['checks'].append(dict(check_id='draft-check-semantics', name='Intermediate draft validation', status='failed',
                                 required=False, summary='The applicability assessment incorrectly carried the executed catalogue command exit code. These are now separate checks; the failed draft and receipt remain.',
                                 command=shlex.join(failed['command']), exit_code=1, target_ids=[item['target_id']], evidence_ids=['receipts']))
    review['notes'].append('Intermediate draft validation receipt: ' + json.dumps(failed, sort_keys=True))
    if slug == 'vibriobactin-2':
        review['verdict'] = 'blocked'
        review['native_verdict'] = 'Partial identity and source review; primary evidence completeness blocked'
        review['summary'] = ('Internal chemistry, database identity and the conservative locus grade are supported. '
                             'Primary producer, occurrence and isolate-form verification remains access-limited, '
                             'so this is a partial blocked scientific observation, not a biological pass. '
                             'No confirmed corrective finding in the inspected scope.')
        review['notes'].append('The draft seed_only verdict was replaced because this observation includes scientific source assessment, not just deterministic seed metadata.')
    finished = datetime.now(timezone.utc)
    review['finished_at'] = finished.isoformat().replace('+00:00', 'Z')
    review['review_id'] = finished.strftime('%Y%m%dT%H%M%SZ') + '-' + slug
    output = WORK / (review['review_id'] + '-assessed.yaml')
    with output.open('x') as handle:
        yaml.dump(review, handle, Dumper=NoAliases, sort_keys=False, allow_unicode=False, width=95)
    outputs.append(dict(review_id=review['review_id'], content=str(output), sha256=hashlib.sha256(output.read_bytes()).hexdigest(), target_id=item['target_id']))
with (WORK / 'assessed-drafts.json').open('x') as handle:
    json.dump(outputs, handle, indent=2)
print(json.dumps(outputs, indent=2))
