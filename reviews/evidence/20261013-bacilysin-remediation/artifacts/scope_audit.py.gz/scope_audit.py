import copy
import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path(__file__).parent
ARCHIVE = ROOT / 'reviews/evidence/20261013-bacilysin'
manifest = json.loads((ARCHIVE / 'manifest.json').read_text())
rows = {r['original_path']: r for r in manifest['artifacts']}
checkpoint = json.loads(gzip.decompress((ARCHIVE / rows[manifest['checkpoint']]['path']).read_bytes()))
OWNER = 'data/natural_products/amino_acids_and_peptides/bacilysin-2.yaml'
BASE = manifest['corpus_base']


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


tracked = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE], text=True).splitlines()
owners = {str(p.relative_to(ROOT)) for p in (ROOT / 'data/natural_products').rglob('*.yaml')}
components = {str(p.relative_to(ROOT)) for p in (ROOT / 'data/causal_graphs').rglob('*.yaml')}
assert owners == {p for p in tracked if p.startswith('data/natural_products/') and p.endswith('.yaml')}
assert components == {p for p in tracked if p.startswith('data/causal_graphs/') and p.endswith('.yaml')}
assert len(owners) == 3115 and len(components) == 243
diffs = subprocess.check_output(['git', 'diff', '--name-only', BASE, '--', 'data'], text=True).splitlines()
assert diffs == [OWNER], diffs
before = yaml.safe_load(subprocess.check_output(['git', 'show', f'{BASE}:{OWNER}']))
after = yaml.safe_load((ROOT / OWNER).read_text())
remaining = copy.deepcopy(after)
assert before.pop('xrefs') == ['npatlas:NPA015870', 'pubchem:160175']
assert 'xrefs' not in remaining
discussions = remaining.pop('discussions')
assert len(discussions) == 2
assert remaining['curation_history'][:-1] == before['curation_history']
event = remaining['curation_history'].pop()
assert event['action'] == 'SEEDED_FROM_SOURCES'
assert before == remaining
assert after['curation_status'] == 'SEEDED'
for row in checkpoint['all_review_observations']:
    assert digest((ROOT / row['yaml']).read_bytes()) == row['yaml_sha256']
    assert digest((ROOT / row['markdown']).read_bytes()) == row['markdown_sha256']
report = dict(assessed_at=datetime.now(timezone.utc).isoformat(), base=BASE,
              population=len(owners), components=len(components), changed_owner=OWNER,
              old_owner_sha256=digest(subprocess.check_output(['git', 'show', f'{BASE}:{OWNER}'])),
              owner_sha256=digest((ROOT / OWNER).read_bytes()),
              removed_xrefs=['npatlas:NPA015870', 'pubchem:160175'],
              additions=['two source-pinned discussions', 'one seeder history event'],
              unchanged_scientific_claims=True, unchanged_old_reviews=25,
              raw_inventories_unchanged=True, components_unchanged=True,
              historical_checkpoint_sha256=rows[manifest['checkpoint']]['sha256'],
              primary_stereo_and_occurrence_review='still partial; no replacement chosen')
with (WORK / 'scope-audit.json').open('x') as handle:
    json.dump(report, handle, indent=2)
print(json.dumps(report, indent=2))
