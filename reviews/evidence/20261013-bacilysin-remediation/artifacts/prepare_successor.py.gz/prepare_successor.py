"""Archive actual remediation checks and prepare one scoped immutable successor."""

import copy
import gzip
import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path(__file__).parent
DEST = ROOT / 'reviews/evidence/20261013-bacilysin-remediation'
OLD = Path('reviews/structured/20261013T140252Z-bacilysin-2/review.yaml')
doc = yaml.safe_load((ROOT / OLD).read_text())
captured = json.loads((WORK / 'successor-inspect.json').read_text())
capture_receipt = json.loads((WORK / 'capture.receipt.json').read_text())
owner = Path(doc['targets'][0]['path'])
target_id = doc['targets'][0]['target_id']


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


for item in captured['source']['inputs']:
    assert digest((ROOT / item['path']).read_bytes()) == item['sha256'], item['path']
assert json.loads((WORK / 'qc-final.receipt.json').read_text())['exit_code'] == 0
with (WORK / 'successor-owner.yaml').open('xb') as handle:
    handle.write((ROOT / owner).read_bytes())
(DEST / 'artifacts').mkdir(parents=True, exist_ok=False)
artifacts = []


def retain(path):
    blob = path.read_bytes()
    packed = gzip.compress(blob, mtime=0)
    relative = 'artifacts/' + path.name + '.gz'
    with (DEST / relative).open('xb') as handle:
        handle.write(packed)
    artifacts.append(dict(original_path=str(path), path=relative, sha256=digest(blob),
                          bytes=len(blob), stored_sha256=digest(packed), stored_bytes=len(packed)))


for path in sorted(WORK.iterdir()):
    if path.is_file():
        retain(path)
for name in ['publication-seed-dry.log', 'publication-seed-dry.receipt.json']:
    retain(Path('/private/tmp/npmech-bacilysin-review-ixdJYA') / name)
manifest = dict(format_version=1, recorded_at=datetime.now(timezone.utc).isoformat(),
                corpus_base=captured['source']['git_revision'], artifacts=artifacts,
                note='Actual checks and scope audit; failed attempts retained. No primary-source refresh.')
with (DEST / 'manifest.json').open('x') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')

finished = datetime.now(timezone.utc)
stamp = finished.strftime('%Y%m%dT%H%M%SZ')
review_id = stamp + '-bacilysin-2-xref-resolution'
evidence = []


def ev(eid, path, locator, summary, kind='record_content', support='supports'):
    evidence.append(dict(evidence_id=eid, kind=kind, reference=str(path), locator=locator,
                         accessed_at=finished.isoformat().replace('+00:00', 'Z'), support=support,
                         summary=summary, snapshot_sha256=digest((ROOT / path).read_bytes())))


ev('previous', OLD, 'F1 and its chemistry/primary-evidence limitations',
   'Original confirmed nonexact-xref finding is preserved byte-identically. Only this finding is reassessed.')
ev('owner', owner, 'Complete resolved owner plus raw YAML; xrefs, discussions and history',
   'The two exact-equivalence xrefs are withheld. Source assertions and historical/current NPAtlas context remain in two attributed discussions; identity, all other claims and SEEDED status are unchanged.')
ev('table', Path('curation/mibig_xref_exclusions.tsv'), 'Two BGC0000888:1 decisions',
   'Both decisions pin the complete original source row bb86b4afe26dc6155af06d704d3ea0fc7f50fc98a46fa25d4f590628419c89b7 and literal xrefs. The raw inventory is unchanged.')
ev('consumer', Path('src/naturalproductmech/curate/xref_exclusions.py'), 'Literal IDs and complete-source validation',
   'Only literal PubChem and six-digit NPAtlas IDs are supported; missing, duplicate, malformed and drifted decisions fail. Existing seeder checks prevent reintroduction and unapplied decisions.')
ev('chemistry', Path('reviews/evidence/20261013-bacilysin/artifacts/chemistry.json.gz'),
   'Checksum-pinned compressed RDKit calculation from inspected source snapshots',
   'Owner XFOU-PCPU has peptide connectivity; PubChem160175 is the JJOS anhydride. NPAtlas current XFOU-NWQN adds two assigned centers. This justifies withholding equivalence without selecting a biological assignment.', kind='validation')
ev('history', Path('reviews/evidence/20261013-bacilysin/artifacts/reassignment-chemistry.json.gz'),
   'Checksum-pinned historical/current NPAtlas representation comparison',
   'Historical version1 and embedded ClassyFire match the owner; current version2 differs. Database history is not an independent experimental assignment.', kind='validation')
ev('validation', Path('reviews/evidence/20261013-bacilysin-remediation/manifest.json'),
   'Checksums, commands, times, exit codes and log links for every retained check',
   'Full native QC, focused regressions, strict target validation and exhaustive scope audit passed. Earlier uv-cache/DNS/stale-statistics failures are retained, not relabeled.', kind='validation')
ev('scope', Path('reviews/evidence/20261013-bacilysin-remediation/artifacts/scope-audit.json.gz'),
   'Gitignore-independent owner/component enumeration and structured claim comparison',
   'All3115 owners and243 components remain; only this owner changed, limited to two xrefs, two discussions and one history event. All25 prior observations and raw inventories are unchanged.', kind='validation')

checks = []
summaries = {
    'qc': 'Initial sandbox-only QC stopped at pinned governance DNS; superseded by qc-final.',
    'qc-network': 'QC read the stale README while generation was running; superseded after generation completed.',
    'docs-stats': 'Initial check reported stale generated discussion counts; docs-stats-write regenerated them.',
    'focused': '55 focused xref and historical-archive tests passed.',
    'qc-final': 'Full authoritative QC passed after generation completed; exact output retained.',
}
for name in ['seed-dry', 'canary', 'focused', 'strict', 'scope-audit', 'render',
             'docs-stats', 'docs-stats-write', 'qc', 'qc-network', 'qc-final']:
    receipt = json.loads((WORK / (name + '.receipt.json')).read_text())
    checks.append(dict(check_id=name, name=name, status='passed' if receipt['exit_code'] == 0 else 'failed',
                       required=receipt['exit_code'] == 0, command=shlex.join(receipt['command']),
                       exit_code=receipt['exit_code'], target_ids=[target_id], evidence_ids=['validation'],
                       summary=summaries.get(name, 'Actual command result retained with times and exact log hash.')))
checks.append(dict(check_id='primary-fulltext', name='Whole-record primary chemistry and experiment verification',
                   status='unavailable', required=True, target_ids=[target_id],
                   summary='Inherited full-text/stereochemistry/occurrence gaps remain. No blocked source was retried; whole-record scientific completion and native status promotion are not justified.'))

finding = copy.deepcopy(doc['findings'][0])
finding.update(status='resolved', evidence_ids=['previous', 'owner', 'table', 'consumer', 'chemistry', 'history', 'validation', 'scope'],
               previous_occurrences=[dict(repository=doc['repository'], review_id=doc['review_id'], finding_id='F1')],
               external_issues=['https://github.com/CultureBotAI/NaturalProductMech/issues/911'],
               disposition_reason='Both nonexact xrefs are withheld through complete-row-pinned maintained decisions and regenerated discussions. Scope audit, focused regressions and full QC pass. This resolves only equivalence overstatement, not primary stereochemistry, occurrence evidence or the sibling identity blocker.')
for path in finding['owner_paths']:
    if path['path'] == 'src/naturalproductmech/curate/xref_exclusions.py':
        path['role'] = 'Validated literal PubChem and NPAtlas exclusion consumer'
    elif path['path'] == 'curation/mibig_xref_exclusions.tsv':
        path['role'] = 'Complete-source-row-pinned exact-equivalence exclusions'

result = dict(schema_version='1.0.0', review_id=review_id, kind='record', repository=doc['repository'],
              title='Bacilysin: scoped resolution of nonexact cross-references',
              started_at=capture_receipt['started_at'], finished_at=finished.isoformat().replace('+00:00', 'Z'),
              reviewer=dict(identity='Codex', kind='agent', independence='self_review',
                            independence_basis='Same assistant implemented and adversarially checked the changes; not an independent reviewer.'),
              skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial',
              verdict='pass_with_limitations', scientific_review=True,
              summary='Resolve the two nonexact external equivalence links only. Preserve historical source assertions, unresolved chemistry and all campaign coverage.',
              source=captured['source'], targets=captured['targets'],
              scope=dict(description='One exact owner, bounded predecessor F1 disposition. Campaign remains3115 owners/243 components,18 partially reviewed owners and zero completed scientific reviews.',
                         selection='Explicit issue911 and predecessor finding; not a new population sample.',
                         coverage='partial', population_size=1, reviewed_target_ids=[target_id]),
              checks=checks, evidence=evidence,
              assessments=[
                  dict(assessment_id='equivalence', area='grounding', topic='Exact chemical equivalence at supported stereo resolution',
                       outcome='supported', target_ids=[target_id], evidence_ids=['owner', 'table', 'consumer', 'chemistry', 'history'],
                       summary='Withholding both links removes the confirmed overstatement without guessing an authority or filling unknown stereocenters.'),
                  dict(assessment_id='scope', area='provenance', topic='Maintained inputs and bounded generated changes',
                       outcome='supported', target_ids=[target_id], evidence_ids=['scope', 'validation', 'previous'],
                       summary='Source-row pins, original assertions and historical/current NPAtlas differences remain auditable; unrelated scientific claims, records, components and old reviews are unchanged.'),
                  dict(assessment_id='remaining', area='completeness', topic='Primary experimental and exact-isolate identity support',
                       outcome='unknown', target_ids=[target_id], evidence_ids=['previous', 'history'],
                       summary='Whole-record primary support remains partial. The1993 reassignment, source stereo disagreement and occurrence claims were not newly adjudicated by this xref remediation.')],
              findings=[finding], actions=[],
              limitations=[
                  'A scoped partial successor, not a whole-record or corpus scientific pass. All193 historical source-access limits remain.',
                  'Current owner/source inputs were captured and checked in the working tree; hashes do not claim these changes existed at the base commit.',
                  'The original25 observations remain immutable; this26th observation adds no newly assessed owner and completes no whole scientific review.',
                  'The sibling anhydride identity blocker remains open as GitHub910; no replacement, owner merger, claim transfer or REVIEWED promotion.',
                  'Fresh full QC covers implementation and the historical archive. Final successor contract checks and PR/merge-group CI follow separately.'],
              links=['https://github.com/CultureBotAI/NaturalProductMech/pull/908',
                     'https://github.com/CultureBotAI/NaturalProductMech/issues/911',
                     'https://github.com/CultureBotAI/NaturalProductMech/issues/910'])


class Dumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


with (WORK / 'successor.yaml').open('x') as handle:
    yaml.dump(result, handle, Dumper=Dumper, sort_keys=False, allow_unicode=False, width=100)
print(review_id)
