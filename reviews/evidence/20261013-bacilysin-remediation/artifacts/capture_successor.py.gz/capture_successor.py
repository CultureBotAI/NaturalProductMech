import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from naturalproductmech.graph_components import read_natural_product

WORK = Path(__file__).parent
OWNER = 'data/natural_products/amino_acids_and_peptides/bacilysin-2.yaml'
command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets',
           '/private/tmp/npmech-bacilysin-review-ixdJYA/bacilysin-2-targets.json']
inputs = [
    'curation/mibig_xref_exclusions.tsv', 'src/naturalproductmech/curate/xref_exclusions.py',
    'scripts/seed_from_sources.py', 'docs/CURATION.md', 'docs/HARMONIZATION.md',
    'docs/record-reviews.md', 'docs/record-review-profile.md',
    '.claude/skills/review-yaml-record/SKILL.md',
    'tests/test_xref_exclusions.py', 'tests/test_bacilysin_review_archive.py',
    'reviews/evidence/20261013-bacilysin/manifest.json',
    'reviews/evidence/20261013-bacilysin/artifacts/chemistry.json.gz',
    'reviews/evidence/20261013-bacilysin/artifacts/reassignment-chemistry.json.gz',
    'reviews/structured/20261013T140252Z-bacilysin-2/review.yaml',
    'data/raw/mibig_compounds.tsv', 'data/raw/chebi_structures.tsv',
    'data/raw/lotus_occurrences.tsv', 'data/raw/pubchem_bioassay.tsv',
]
for path in inputs:
    command.extend(['--input', path])
started = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
result = subprocess.run(command, text=True, capture_output=True)
assert result.returncode == 0, result.stderr
doc = json.loads(result.stdout)
with (WORK / 'successor-inspect.json').open('x') as handle:
    handle.write(result.stdout)
with (WORK / 'successor-owner.json').open('x') as handle:
    json.dump(read_natural_product(Path(OWNER)), handle, indent=2)
with (WORK / 'capture.receipt.json').open('x') as handle:
    json.dump(dict(command=command, started_at=started,
                   finished_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
                   exit_code=result.returncode, stderr=result.stderr,
                   sha256=hashlib.sha256(result.stdout.encode()).hexdigest()), handle, indent=2)
print('Captured exact owner and', len(doc['source']['inputs']), 'source inputs')
