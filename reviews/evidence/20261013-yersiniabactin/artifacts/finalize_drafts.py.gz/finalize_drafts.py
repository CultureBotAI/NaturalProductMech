import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml

WORK = Path(__file__).parent
class NoAliases(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True

receipt = json.loads((WORK/'review-validate.receipt.json').read_text())
assert receipt['exit_code'] == 1
assert hashlib.sha256(Path(receipt['log']).read_bytes()).hexdigest() == receipt['log_sha256']
results = []
for row in json.loads((WORK/'prepared.json').read_text()):
    doc = yaml.safe_load(Path(row['draft']).read_text())
    tid = doc['targets'][0]['target_id']
    doc['checks'].append(dict(check_id='initial-draft-validation',name='Initial review-draft format validation',
                             status='failed',required=False,target_ids=[tid],command=shlex.join(receipt['command']),
                             exit_code=1,expected_exit_code=0,summary='Initial generated drafts contained YAML aliases; the canonical validator rejected that format. The assessed content was reserialized without aliases before canonical validation and saving. No scientific inputs or findings changed.',
                             scope_note='Superseded draft-format failure retained; log SHA256 '+receipt['log_sha256']))
    doc['finished_at'] = datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
    destination = WORK/(Path(row['draft']).stem+'-final.yaml')
    with destination.open('x') as handle:
        yaml.dump(doc,handle,Dumper=NoAliases,sort_keys=False,allow_unicode=False,width=100)
    results.append(dict(row,original_draft=row['draft'],draft=str(destination)))
with (WORK/'final-prepared.json').open('x') as handle:
    json.dump(results,handle,indent=2)
print(json.dumps(results,indent=2))
