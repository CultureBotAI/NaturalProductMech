import hashlib
import json
import shlex
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path(__file__).parent
REPO = 'CultureBotAI/NaturalProductMech'
def read(name):
    return json.loads((WORK / name).read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
capture = read('capture.json')
chemistry = read('chemistry.json')
assert read('qc.receipt.json')['exit_code'] == 0
assert read('labels.receipt.json')['exit_code'] == 0

def fetched(eid, filename, kind, locator, summary, support='supports'):
    receipt = read(filename + '.receipt.json')
    assert receipt['status'] == 200
    assert sha(WORK / filename) == receipt['sha256']
    return dict(evidence_id=eid, kind=kind, reference=receipt['url'], locator=locator,
                accessed_at=receipt['finished_at'], support=support, summary=summary,
                snapshot_sha256=receipt['sha256'])

def owner(path, role):
    return dict(repository=REPO, path=path, role=role)

def make(slug):
    inspected = read(slug + '-inspect.json')
    target = inspected['targets'][0]
    tid = target['target_id']
    source = inspected['source']
    for item in source['inputs']:
        assert sha(ROOT / item['path']) == item['sha256'], item['path']
        committed = subprocess.check_output(['git', 'show', source['git_revision'] + ':' + item['path']])
        assert hashlib.sha256(committed).hexdigest() == item['sha256']
    source['state'] = 'git_commit'
    evidence = [
        dict(evidence_id='owner', kind='record_content', reference=target['path'],
             locator='Entire owner, all history, and read_natural_product resolved view',
             accessed_at=capture['finished_at'], support='context_only',
             summary='Full owner read; no inline causal graphs or causal_graph_refs. No protein examples, pathway steps, assays, molecular targets, clinical assertions or sibling links are stored. Existing status is SEEDED; no data or history was changed.',
             snapshot_sha256=sha(ROOT / target['path'])),
        dict(evidence_id='inventories', kind='record_content', reference='data/raw/mibig_compounds.tsv',
             locator='BGC0001055:1 line1206; BGC0000467:1 line651; BGC0002570:1 line3267; LOTUS exact-key rows712-715 and3026; NPClassifier rows257 and1111',
             accessed_at=capture['finished_at'], support='supports',
             summary='Parsed exact-key source rows reproduce the source concepts, database evidence, computed Alkaloids filing and xrefs. Both keys have zero matches in the pinned ChEBI structure/origin and AntibioticMech inventories. This supports minted identity relative to these inventories, not absence from all current databases. Occurrences remain distinct claims from producers; DOI/PMID aliases do not provide independent experiments.',
             search_scope='csv.DictReader read every row in the six explicitly named inventories, including paths independently of gitignore. Complete corpus and component paths were enumerated with Path.rglob. Hidden/ignored-inclusive rg searched curation, data/natural_products and reviews/structured for labels, keys and three accessions. No matching strain/correction decision or earlier review bundle was found in those searched inputs.'),
        dict(evidence_id='chemistry', kind='validation', reference='RDKit:2026.03.5',
             locator='MolFromSmiles; MolToInchi; MolToInchiKey; FindMolChiralCenters(includeUnassigned=True); CalcMolFormula; GetFormalCharge; ExactMolWt; RemoveStereochemistry; TautomerEnumerator.Canonicalize',
             accessed_at=read('chemistry-local-numpy.receipt.json')['finished_at'], support='supports',
             snapshot_sha256=sha(WORK / 'chemistry.json'),
             summary='Both stored SMILES reproduce their stored InChIs and keys; both calculate C21H27N3O4S3, charge0, exact mass481.116369344 Da. yersiniabactin-2 has CIP assignments at zero-based atom indices1:S,9:S,10:R,15:R and unspecified atom13; yersiniabactin has five unspecified centers. Both stereo_complete:false values are honest. Removing stereo then canonicalizing tautomers yields JHYVWAMMAMCUIR-UHFFFAOYSA-N for both. This is computational context, not experimental form assignment or authority to merge owners. The initial isolated environment failed on missing numpy.__config__; the successful rerun used the existing repository NumPy via PYTHONPATH without modifying packages.'),
        fetched('pubchem', 'pubchem-5462519.json', 'database', 'PropertyTable.Properties[0]',
                'CID5462519 denotes CARQCAHMXWHUIE-NRMQOZBLSA-N, with the same SMILES/InChI as yersiniabactin-2 and formulaC21H27N3O4S3. It does not denote the all-stereocenters-unspecified JHYVWAMMAMCUIR-UHFFFAOYSA-N representation.'),
        dict(evidence_id='taxonomy', kind='authority', reference='data/raw/corpus_taxa.obo',
             locator='NCBITaxon:562,630,223283; inspected ENA source features; Wikidata Q25419 and Q135177 organism pages',
             accessed_at=now(), support='supports',
             summary='The pinned taxonomy labels resolve to Escherichia coli, Yersinia enterocolitica and Pseudomonas syringae pv. tomato str. DC3000 respectively. ENA verifies the same taxids on the cited sequence deposits. Wikidata labels match their organism notes; the Q135177 page succeeded after an initial transport timeout. OTHER_BACTERIAL is a broad computed facet, not a new experimental claim.'),
        dict(evidence_id='governance', kind='record_content', reference='docs/CURATION.md',
             locator='Producer strain context, locus-evidence overrides, generated ownership, REVIEWED gate; docs/HARMONIZATION.md identity and producer/occurrence sections; conf/producer_evidence.tsv',
             accessed_at=now(), support='context_only',
             summary='SOURCE_ASSERTION and CLUSTER_UNSTATED honestly preserve ungraded database claims; method absence is not evidence of absent biology. Native knockouts may support both producer and locus. Xrefs assert the same structure. Strain changes use complete-row-pinned curation/mibig_producer_strains.tsv. decisions.tsv is reserved, not a functioning correction path.'),
    ]
    checks = []
    labels = ['strict-' + ('2' if slug.endswith('-2') else '1'),
              'strict-' + ('2' if slug.endswith('-2') else '1') + '-local',
              'chemistry', 'chemistry-local-numpy', 'labels', 'qc', 'review-queue']
    for label in labels:
        receipt = read(label + '.receipt.json')
        checks.append(dict(check_id=label, name=label, status='passed' if receipt['exit_code'] == 0 else 'failed',
                           required=label not in ('strict-1', 'strict-2', 'chemistry', 'review-queue'),
                           command=shlex.join(receipt['command']), exit_code=receipt['exit_code'], expected_exit_code=0,
                           target_ids=[tid], summary={
                               'strict-1':'Initial just wrapper failed on sandbox-denied uv cache; replaced by the documented script in the existing repository environment.',
                               'strict-2':'Initial just wrapper failed on sandbox-denied uv cache; replaced by the documented script in the existing repository environment.',
                               'strict-1-local':'One owner and all referenced components: zero schema errors.',
                               'strict-2-local':'One owner and all referenced components: zero schema errors.',
                               'chemistry':'Initial temporary RDKit environment failed on incomplete NumPy before calculating results; failure retained.',
                               'chemistry-local-numpy':'Exact pinned RDKit calculations succeeded using existing repository NumPy via PYTHONPATH; no package or corpus edits.',
                               'labels':'Full-corpus configured gate exited0: 13434 canonical,646 synonym,35 exception,499 nonblocking mismatch warnings,4649 no-adapter skips. Minted chemical identifiers are skipped; this is not chemical-identity verification.',
                               'qc':'Full documented QC exited0:674 tests passed,3 skipped,2 warnings; strict schema3115 owners with zero errors; lint, vendored synchronization, provenance, site, reproduction and corpus lock passed. Deterministic success is not scientific sign-off.',
                               'review-queue':'Exhaustive native queue generated to the private workspace:8930 diagnostic rows. Multiple diagnostics per record are not distinct owners or completed reviews.',
                           }[label], scope_note='Actual command result retained; log SHA256 ' + receipt['log_sha256']))
    checks.append(dict(check_id='imodulondb', name='Structured source applicability', status='not_applicable', required=False,
                       target_ids=[tid], summary='These owners store BGC/genome accessions but no gene, locus-tag, protein-example, regulator or expression-module claims. MIBiG and INSDC were used first for structured cross-checks. iModulon membership would not establish chemical identity or production. No coverage-absence claim is made.'))
    checks.append(dict(check_id='primary-fulltext', name='Primary experiment and exact isolate-form verification', status='unavailable', required=True,
                       target_ids=[tid], summary='Primary abstracts were inspected but complete experimental and chemical-form verification is access-limited. No source was retrieved through an alternate route after explicit403 or reCAPTCHA. See limitations.'))
    assessments = []
    def assess(aid, area, topic, outcome, summary, ids, dimensions=None):
        value = dict(assessment_id=aid, area=area, topic=topic, outcome=outcome, summary=summary, target_ids=[tid], evidence_ids=ids)
        if dimensions:
            value['dimensions'] = dimensions
        assessments.append(value)
    def dim(name, value, definition, ids):
        return dict(name=name, value=value, definition=definition, evidence_ids=ids)
    def finding(fid, key, category, severity, certainty, title, description, fields, ids, owners):
        return dict(finding_id=fid, issue_key=key, category=category, severity=severity, status='open', certainty=certainty,
                    title=title, description=description, target_ids=[tid], field_paths=fields, evidence_ids=ids, owner_paths=owners,
                    rule_id='review-checklist:Identity; Equivalence; Producer organisms; Occurrences; docs/CURATION.md:Evidence rules',
                    native_severity=severity, normalization_reason='Material unsupported identity/evidence is major; bounded lost strain provenance is minor. Provisional findings require source adjudication before correction.')
    def action(aid, description, findings, owners, acceptance, generator=None):
        value = dict(action_id=aid, description=description, finding_ids=findings, target_ids=[tid], owner_paths=owners, acceptance_checks=acceptance)
        if generator:
            value['generator'] = generator
        return value
    strain_owners = [owner('curation/mibig_producer_strains.tsv', 'Implemented complete-source-row-pinned strain qualification'), owner('scripts/seed_from_sources.py', 'Generated producer claim')]
    limitations = ['This record observation assesses the captured main commit8b5a3ebf, whose input bytes still match the working tree. It does not reassess any other owner or claim all3115 records reviewed.',
                   'Full primary experimental and isolate-form verification is incomplete. Chemical normalization, metadata, database assertions and abstract-level descriptions are not substituted for inspected methods/results.',
                   'All174 inherited access stops were preserved; none was retried. This review records additional source-specific stops. No paid research, contact, GitHub mutation, record edit or native status promotion occurred.']
    if slug.endswith('-2'):
        evidence += [
            fetched('mibig1055', 'BGC0001055.5.json', 'database', 'version5,status,compounds[0],taxonomy,loci[0],legacy_references',
                    'Active BGC0001055v5 names yersiniabactin, exactly supplies the owner chemistry and PubChem xref, assigns taxon562 and AM236324.1, and has no locus method. Its citation is PMID17049458. NRPS/PKS are cluster classes, not the computed filing class.'),
            fetched('hejnova2006', 'epmc-17049458.json', 'primary_source', 'resultList.result[id=17049458].abstractText; DOI metadata',
                    'The abstract identifies E.coli A0 34/86 and reports BAC-array/comparative-sequence identification of yersiniabactin-system genes. PMID17049458 is DOI10.1016/j.ijmm.2006.06.007, also used by the LOTUS occurrence. No metabolite detection is described in the inspected abstract; the subscription full article was not inspected. This does not establish that the complete paper lacks such an experiment.', 'partial'),
            fetched('ena1055', 'AM236324.1.embl', 'authority', 'ID; DE; reference2; source feature1..84189',
                    'AM236324.1 is an 84189bp E.coli sequence; source strainA0 34/86, taxon562. Its reference2 explicitly joins PMID17049458 to DOI10.1016/j.ijmm.2006.06.007. It includes yersiniabactin,cob,pdu clusters, so the entire accession is not automatically a precisely delimited biosynthetic cluster.'),
            fetched('haag1993', 'epmc-other-citations.json', 'primary_source', 'resultList.result[id=8245841].abstractText',
                    'The abstract reports isolation from H1852 spent medium, production under iron limitation by WA-C, and iron-transport assays. It supports a Y.enterocolitica occurrence and strain-specific biological origin at abstract level; it does not establish every encoded stereocenter or tautomer in this record.', 'partial'),
        ]
        assess('identity', 'identity', 'Database identity and internal structure', 'supported',
               'The exact owner matches active MIBiG1055 and PubChem5462519; internal chemistry is consistent. Minted identity is justified against the pinned ChEBI inventory. Natural experimental tautomer/stereo assignment remains unresolved; no claim that the two named owners are unrelated molecules.', ['owner','inventories','chemistry','pubchem','mibig1055'],
               [dim('structure','CARQCAHMXWHUIE-NRMQOZBLSA-N','Exact owner key',['owner','chemistry']),dim('stereochemistry','four specified centers; one unspecified','RDKit zero-based atom-index assignment, not paper numbering',['chemistry'])])
        assess('classification', 'provenance', 'Filing and asserted origin', 'supported',
               'Pinned NPClassifier2026-09-07 supplies Alkaloids; NRPS/PKS come separately from MIBiG. NATURAL_PRODUCT admission rests on source assertions, not this computation. No asserted chemical class or optional assay measurement was fabricated.', ['inventories','mibig1055','governance'])
        assess('producer', 'evidence', 'E.coli producer and locus scope', 'concern',
               'SOURCE_ASSERTION/CLUSTER_UNSTATED match MIBiG. Genomic identification does not establish native metabolite production. A0 34/86 is available in both citation and sequence but absent from the producer. No upgrade to causal evidence is justified by the inspected material.', ['owner','mibig1055','hejnova2006','ena1055'],
               [dim('strain','A0 34/86','Exact source-deposit strain, absent in generated producer',['ena1055']),dim('evidence-tier','SOURCE_ASSERTION;CLUSTER_UNSTATED','Separate producer and locus grades',['owner','mibig1055'])])
        assess('occurrences', 'evidence', 'Four structure-organism-publication claims', 'unknown',
               'All four exact-key LOTUS rows were checked. The1993 Yersinia abstract supports culture isolation; the1995 isolation and2001 stereochemistry articles were inaccessible. The E.coli DOI is the same genomic paper as the producer PMID, and its inspected abstract does not demonstrate chemical detection. Different reference spellings are not independent evidence.', ['inventories','hejnova2006','haag1993'])
        findings = [
            finding('F1','yersiniabactin-BGC0001055-producer-strain','scope','minor','confirmed','Producer assertion drops the available A0 34/86 strain',
                    'The species-level taxon562 producer has neither strain nor a strain qualifier. AM236324.1 and the cited paper identify A0 34/86. Preserve this context without changing the taxon or upgrading the source-assertion evidence.', ['producer_organisms[0].strain'],['owner','ena1055','hejnova2006'],strain_owners),
            finding('F2','yersiniabactin-lotus-ecoli-genomic-citation','evidence','major','provisional','E.coli occurrence needs direct chemical-detection support',
                    'The occurrence claims that this structure was found in E.coli, but its DOI is a comparative-genomics paper whose inspected abstract reports genes rather than metabolite detection. This is a provisional evidence gap, not proof that the complete paper contains no chemical experiment, nor proof of nonproduction.', ['occurrences[3].evidence'], ['owner','inventories','hejnova2006','ena1055'],[owner('data/raw/lotus_occurrences.tsv','Exact imported occurrence row'),owner('scripts/extract_lotus.py','Occurrence extraction'),owner('scripts/seed_from_sources.py','Occurrence emission')]),
        ]
        actions = [action('A1','Add a full-raw-row-pinned A0 34/86 qualification to BGC0001055:1, retaining taxon562 and existing evidence grades.', ['F1'],strain_owners,
                          ['Verify full raw source-row digest and ENA strain citation.','Canary only this record; confirm no chemistry or grade changes.','Strict validation, reproduction and full QC pass.'], 'scripts/seed_from_sources.py'),
                   action('A2','With authorized article access, locate the exact E.coli isolation/detection result or adjudicate the LOTUS occurrence as unsupported. Do not remove it solely from abstract silence. If correction is needed, implement a tested source-row-pinned extraction/overlay path; reserved decisions.tsv cannot do this.', ['F2'],findings[1]['owner_paths'],
                          ['Inspect the complete cited paper or user-supplied source without bypassing access restrictions.','Evidence must identify compound form, A0 34/86 and a chemical detection experiment rather than gene presence.','Any later row exclusion preserves provenance and passes exact-key occurrence, reproduction and full QC regressions.'])]
        limitations += ['Wiley DOI10.1002/jlac.1995199510243 and ScienceDirect DOI10.1016/S0040-4020(01)00012-6 returned403. Search-result snippets were not promoted to inspected primary evidence.',
                        'The1993 publisher abstract was inspected; its full-text endpoint returned403. The2006 DOI transport failed and EuropePMC metadata lists subscription-only full text; its abstract was inspected before that access limit. No alternate full-text retrieval was attempted.']
        summary = 'Exact MIBiG/PubChem chemistry is internally consistent, with one undefined stereocenter honestly flagged. One confirmed minor strain omission and one provisional major occurrence-evidence gap remain. Partial needs_curation; primary isolation/stereochemistry and complete E.coli experiment checks remain access-limited.'
    else:
        evidence += [
            fetched('npatlas','NPA015861.json','database','NPA015861 exact chemistry, original isolation metadata, mol_structures[0]',
                    'NPAtlas2024_09 identifies JHYVWAMMAMCUIR-UHFFFAOYSA-N with the same owner SMILES, cites the1995 structure paper and Y.enterocolitica H1852. This validates the NPAtlas xref as a database identity, not a new source of experimental stereochemistry.'),
            fetched('mibig0467','BGC0000467.5.json','database','version5,status,compounds[0],loci[0],taxonomy,legacy_references',
                    'Active BGC0000467v5 supplies the all-stereo-unspecified phenolic structure, NPAtlas and PubChem xrefs, taxon630, Y12527.1 and PMID9457855. Locus evidence is empty; NRPS is asserted.'),
            fetched('mibig2570','BGC0002570.2.json','database','version2,status,compounds[0],loci[0],taxonomy,legacy_references',
                    'Active BGC0002570v2 supplies the same unspecified structure, NPAtlas xref, taxon223283, AE016853.1 bounds2868541-2897461 and Knock-out studies. PMID17660289 and DOI10.1128/JB.00827-07 alias one publication; NRPS/PKS are asserted.'),
            fetched('pelludat1998','epmc-other-citations.json','primary_source','resultList.result[id=9457855].abstractText and DOI',
                    'The abstract identifies Y.enterocolitica O8 WA-314, a13kb irp1/3/4/5 region, and loss of yersiniabactin synthesis on irp1 or irp2 inactivation. This supports an evidence-upgrade candidate beyond the empty imported method. Complete methods/results and exact isolated form were not inspected.', 'partial'),
            fetched('jones2007','epmc-other-citations.json','primary_source','resultList.result[id=17660289].abstractText and DOI',
                    'The abstract reports DC3000 Ybt synthesis under iron limitation, loss after pchA mutation and rescue by supplied salicylate. This supports the native knockout interpretation. Its negative plant-growth/virulence comparisons prevent turning production into a blanket virulence claim; none is made by this owner.', 'partial'),
            fetched('ena0467','Y12527.1.embl','authority','ID; reference1; source1..13629; irp1 CDS613..10098',
                    'Y12527.1 identifies taxon630, strainWA-314, sub_strainWA-C, serotype08 and PMID9457855. Its13,629bp sequence covers irp1/3/4/5; it is not proof that every biosynthetic function is in this accession.'),
            fetched('ena2570','AE016853.1.embl','authority','source1..6397126 and pchA/PSPTO_2595 complement2868541..2869950',
                    'AE016853.1 source taxon223283 is DC3000. The pchA feature lies within the imported BGC bounds and begins at the low-coordinate bound. This verifies sequence/strain context, not a biochemical assay.'),
        ]
        assess('identity','identity','Internally consistent incomplete-stereo identity','supported',
               'The owner reproduces its key and matches both MIBiG structures and NPAtlas. The five unspecified centers are truthfully flagged. The shared-source discussion remains appropriate; this record is not chemically proven distinct from its named sibling by a different first InChIKey block alone.', ['owner','inventories','chemistry','npatlas','mibig0467','mibig2570'],
               [dim('structure','JHYVWAMMAMCUIR-UHFFFAOYSA-N','Exact owner key',['owner','chemistry']),dim('stereochemistry','five unspecified stereocenters','No stereochemical assignments encoded',['chemistry'])])
        assess('xref','grounding','PubChem exact equivalence','concern',
               'NPAtlas is exact; PubChem5462519 instead carries another tautomer and four specified centers. Computational tautomer normalization only agrees after stereochemistry is removed, so it cannot establish the exact relation asserted by xrefs.', ['owner','pubchem','chemistry','npatlas'])
        assess('classification','provenance','Computed filing versus BGC classes','supported',
               'The pinned2026-09-07 classifier produces Alkaloids/Serine alkaloids/Thiazole alkaloids; NRPS/PKS are separate source assertions. NPAtlas live classifier output is not the pinned filing authority. No silent reclassification or asserted-origin inference was made.', ['inventories','mibig0467','mibig2570','governance'])
        assess('producer','evidence','Native production and cluster grading','supported',
               'DC3000 knockout grading is consistent with the primary abstract and pchA sequence context. The Yersinia SOURCE_ASSERTION/CLUSTER_UNSTATED grades faithfully report missing MIBiG methods, not absent biology; the1998 abstract provides a bounded upgrade lead. Full methods and exact molecular-form attribution remain incomplete.', ['mibig2570','jones2007','ena2570','mibig0467','pelludat1998','ena0467'],
               [dim('strains','DC3000;WA-314/substrainWA-C','Source-specific contexts; Yersinia strain omitted from owner',['ena2570','ena0467']),dim('evidence-tier','DC3000:BGC_CHARACTERIZED/CLUSTER_DEMONSTRATED;Yersinia:SOURCE_ASSERTION/CLUSTER_UNSTATED','Stored grades, not automatic upgrades',['owner','mibig0467','mibig2570'])])
        assess('occurrence','evidence','Yersinia occurrence and publication alias','unknown',
               'The exact-key LOTUS row cites DOI10.1128/JB.180.3.538-546.1998, the same study as producer PMID9457855. Its abstract supports Ybt synthesis, but the experimental isolate-form assignment and detection methods remain unverified without full text.', ['inventories','pelludat1998'])
        xref_owners = [owner('data/raw/mibig_compounds.tsv','BGC0000467:1 imported xref'),owner('scripts/extract_mibig.py','Source-specific extraction and provenance'),owner('scripts/seed_from_sources.py','Exact-identity xref emission')]
        findings = [
            finding('F1','yersiniabactin-JHYVWAMMAMCUIR-pubchem5462519-equivalence','grounding','major','confirmed','PubChem xref asserts an unsupported exact stereochemical identity',
                    'The record denotes JHYVWAMMAMCUIR-UHFFFAOYSA-N with all five centers unspecified. PubChem5462519 is CARQCAHMXWHUIE-NRMQOZBLSA-N with four specified centers and a different tautomer depiction. Exact equivalence is not established by the common name or by removing stereo during tautomer normalization. This is not a claim that the biological compound names are unrelated, and does not authorize changing chemistry or merging the two owners.', ['xrefs[pubchem:5462519]'], ['owner','mibig0467','pubchem','chemistry','npatlas'],xref_owners),
            finding('F2','yersiniabactin-BGC0000467-producer-strain','scope','minor','confirmed','Yersinia producer omits WA-314 and WA-C context',
                    'The taxon630 producer has no strain qualifier, while exact accessionY12527.1 specifies strainWA-314 and sub_strainWA-C. The1998 abstract names WA-314. Preserve both qualified source fields without substituting the isolation strainH1852 or changing taxonomy and evidence grades.', ['producer_organisms[1].strain'], ['owner','ena0467','pelludat1998'],strain_owners),
        ]
        actions = [action('A1','Adjudicate and withhold or qualify the nonexact PubChem xref through a tested source-row-pinned extractor/seeder correction. There is no generic implemented xref override in the inspected tables; add that consumer if needed. Do not use the ChEBI-only structure replacement or reserved decisions.tsv, and do not merge owners merely to eliminate this finding.', ['F1'],xref_owners,
                          ['Retain NPAtlas exact xref and both original structure keys.','Preserve upstream PubChem assertion as attributed provenance without asserting unproven equivalence.','Add regression for BGC0000467:1 only; verify sibling5462519 xref remains valid.','Run source provenance, canary, strict validation, reproduction, full QC and renderer checks.'], 'scripts/seed_from_sources.py'),
                   action('A2','Add a full-source-row-pinned WA-314 (sub_strainWA-C) qualifier for BGC0000467:1.', ['F2'],strain_owners,
                          ['Verify raw row digest and exact ENA source fields.','Do not substituteH1852 or change the taxon or grades.','Canary, strict validation, reproduction and full QC pass.'], 'scripts/seed_from_sources.py'),
                   action('A3','Using authorized full text, verify the1998 native knockout and compound readout, then consider a REPLACE method decision for BGC0000467. Current conservative grades are not evidence that no experiment exists.', [],[owner('curation/mibig_locus_evidence_overrides.tsv','Implemented source-specific method additions'),owner('scripts/seed_from_sources.py','Separate producer and locus grading')],
                          ['Check strain/substrain, irp1 versus irp2 accession coverage and exact product readout.','Only evidence applicable to the represented source locus may alter grading.','Preserve database attribution and add separate curation provenance; full native gates pass.'], 'scripts/seed_from_sources.py')]
        limitations += ['PMC2045226 full text returned403 through EuropePMC; PMC106919 returned a reCAPTCHA challenge through PMC after a EuropePMC transport error. No alternate full-text requests followed these access barriers. Both abstracts had already been inspected through EuropePMC metadata.',
                        'NPAtlas original isolation citation points to the1995 Wiley source that returned403. No all-stereo-unspecified depiction was promoted to a measured absolute configuration. No blanket production, virulence or host-range conclusion was inferred.']
        summary = 'The incomplete-stereo owner matches NPAtlas and both MIBiG structures, and DC3000 knockout evidence is supported at abstract level. One confirmed major nonexact PubChem xref and one confirmed minor missing Yersinia strain qualifier remain. Full experimental/isolate-form verification is access-limited; partial needs_curation, not scientific sign-off.'
    assess('complete','completeness','Optional mechanism and assay scope','unknown',
           'Entire owner and history read, including absence of stored graphs, pathways, proteins, assays and clinical claims. Cited sources provide bounded biosynthesis leads, but no unsupported optional fields were filled and missing optional content was not treated as false. Exact primary chemical-form verification is the remaining sign-off gate.', ['owner','inventories','governance'])
    assess('validation','schema','Native deterministic and provenance gates','supported',
           'Strict owner validation and complete native QC pass; source byte checks and exact corpus enumeration preserve every owner/component. Label gate has known skips and warning-level mismatches. These checks cannot prove literature support.', ['owner','governance','chemistry'])
    finished = now()
    review = dict(schema_version='1.0.0', review_id=finished[:19].replace('-','').replace(':','')+'Z-'+slug,
                  kind='record', repository=REPO, title='Yersiniabactin: '+('partially specified tautomer and E.coli provenance' if slug.endswith('-2') else 'unspecified-stereo identity and native BGC evidence'),
                  started_at=capture['started_at'], finished_at=finished,
                  reviewer=dict(identity='Codex',kind='agent',independence='self_review',independence_basis='Same assistant/thread as preceding corpus curation and publication; this is not independent human sign-off.'),
                  skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial', verdict='needs_curation', scientific_review=True,
                  summary=summary, source=source, targets=[target],
                  scope=dict(description='One exact resolved owner; same-label sibling consulted only as identity context. Full corpus goal remains3115 owners and243 attached components.',
                             selection='Next exact path in the verified exhaustive campaign checkpoint; same-label/different-key candidates prioritized, not a sample.',
                             coverage='partial', population_size=3115, reviewed_target_ids=[tid],
                             exclusions=[dict(target='Other3114 owners',reason='Not scientifically assessed by this single-record observation; retained in the campaign checkpoint.')]),
                  checks=checks, evidence=evidence, assessments=assessments, findings=findings, actions=actions, limitations=limitations,
                  notes=['Only immutable review outputs are authorized. Proposed corrective actions have not been executed.',
                         'Primary summaries above are paraphrases, not quotations. Source access timestamps for retrieved snapshots are preserved from receipts; local/current-page assessments record inspection time.',
                         'Required full-text access remains unavailable, so completed status and a passing whole-record verdict are deliberately not claimed.'])
    with (WORK / (slug + '-review.yaml')).open('x') as handle:
        yaml.safe_dump(review, handle, sort_keys=False, allow_unicode=False, width=100)
    return dict(review_id=review['review_id'], draft=str(WORK / (slug + '-review.yaml')), target_id=tid, findings=len(findings))

results = [make(slug) for slug in ('yersiniabactin-2','yersiniabactin')]
with (WORK / 'prepared.json').open('x') as handle:
    json.dump(results,handle,indent=2)
print(json.dumps(results,indent=2))
