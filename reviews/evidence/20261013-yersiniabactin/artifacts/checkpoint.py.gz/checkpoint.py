import collections
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path(__file__).parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
capture = json.loads((WORK / 'capture.json').read_text())
prior = Path(capture['prior_checkpoint'])
assert sha(prior) == capture['prior_checkpoint_sha256']
checkpoint = json.loads(prior.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == capture['base']
owners = {r['path']:r for r in checkpoint['records']}
components = {c['path']:c for r in owners.values() for c in r['graph_components']}
assert {str(p.relative_to(ROOT)) for d in ('data/natural_products','data/causal_graphs') for p in (ROOT/d).rglob('*.yaml')} == owners.keys() | components.keys()
for path,row in (owners | components).items():
    assert sha(ROOT/path) == row['sha256'], path
for row in checkpoint['all_review_observations']:
    assert sha(ROOT/row['yaml']) == row['yaml_sha256']
    assert sha(ROOT/row['markdown']) == row['markdown_sha256']
for name in ('qc','labels','review-check','review-contract-tests'):
    receipt = json.loads((WORK/(name+'.receipt.json')).read_text())
    assert receipt['exit_code'] == 0
    assert sha(Path(receipt['log'])) == receipt['log_sha256']
additions = []
for row in json.loads((WORK/'scoped-prepared.json').read_text()):
    directory = ROOT/'reviews/structured'/row['review_id']
    saved = directory/'review.yaml'
    markdown = directory/'review.md'
    doc = yaml.safe_load(saved.read_text())
    assert doc['review_id'] == row['review_id']
    target = doc['targets'][0]
    path = target['path']
    assert path in checkpoint['pending_in_priority_order']
    assert doc['completion'] == 'partial'
    for item in doc['source']['inputs']:
        assert sha(ROOT/item['path']) == item['sha256']
    entry = dict(review_id=doc['review_id'],yaml=str(saved.relative_to(ROOT)),yaml_sha256=sha(saved),
                 markdown=str(markdown.relative_to(ROOT)),markdown_sha256=sha(markdown),
                 target_id=target['target_id'],path=path,verdict=doc['verdict'],completion=doc['completion'],
                 scientific_review=doc['scientific_review'],findings=doc['findings'],finished_at=doc['finished_at'])
    additions.append(entry)
    checkpoint['reviews'].append(entry)
    checkpoint['all_review_observations'].append(entry)
    checkpoint['partial_followups'].append(path)
    checkpoint['pending_in_priority_order'].remove(path)
    owners[path]['review_state'] = 'partial'
    for finding in doc['findings']:
        assert not finding.get('previous_occurrences')
        assert finding['issue_key'] not in {f['issue_key'] for f in checkpoint['latest_finding_heads']}
        checkpoint['latest_finding_heads'].append(dict(finding,review_id=doc['review_id'],finished_at=doc['finished_at']))
checkpoint['prior_publication'] = checkpoint['publication']
new_stops = [
    dict(aliases=['DOI:10.1002/jlac.1995199510243'],reason='Wiley publisher403; no primary text inspected'),
    dict(aliases=['DOI:10.1016/S0040-4020(01)00012-6'],reason='ScienceDirect403; indexed search snippet not promoted to primary evidence'),
    dict(aliases=['PMID:17660289','PMC2045226','DOI:10.1128/JB.00827-07'],reason='EuropePMC full text403; abstract inspected before full-text request'),
    dict(aliases=['PMID:9457855','PMC106919','DOI:10.1128/JB.180.3.538-546.1998'],reason='PMC reCAPTCHA after EuropePMC transport error; abstract inspected before challenge'),
    dict(aliases=['PMID:8245841','DOI:10.1099/00221287-139-9-2159'],reason='Publisher full-text endpoint403; publisher and EuropePMC abstracts inspected before barrier'),
    dict(aliases=['PMID:17049458','DOI:10.1016/j.ijmm.2006.06.007'],reason='EuropePMC metadata indicates subscription-only full text; DOI transport unavailable; abstract inspected. No alternate full-text retrieval attempted'),
]
checkpoint['new_access_stops'].extend([dict(s,no_alternate_retrieval=True) for s in new_stops])
for name in ('finalize_scope.py','checkpoint.py'):
    if name not in checkpoint['do_not_replay']:
        checkpoint['do_not_replay'].append(name)
checkpoint.update(
    branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
    recorded_at=datetime.now(timezone.utc).isoformat(), prior_checkpoint=str(prior),prior_checkpoint_sha256=sha(prior),
    review_bundle_state='working_tree_new_immutable_bundles', corpus_state='git_commit',
    publication=dict(phase='two new review pairs saved locally; no commit, PR or GitHub mutation in this review-only continuation'),
    scientific_review_bundles=len(checkpoint['all_review_observations']), partial_reviews=len(checkpoint['partial_followups']),
    unassessed_records=len(checkpoint['pending_in_priority_order']),completed_scientific_reviews=0,
    count_note='Fourteen unique partially reviewed owners; nineteen immutable observations; zero complete. Two new owners assessed in this continuation, not two scientific completions.',
    findings=dict(collections.Counter(f['severity'] for f in checkpoint['latest_finding_heads'] if f['status'] in ('open','deferred'))),
    previous_turn_classification=capture['previous_turn_classification'],
    this_turn_classification='progress: two new immutable record reviews with source-linked identity/provenance findings and actual native checks',
    frontier_note='Next unassessed owners are aborycin-2 and aborycin. All14 partial owners remain unfinished; inspect current source hashes and preserve access stops before any successor.',
    required_work_remaining='Finish all14 partial owners and scientifically review all3101 unassessed owners plus all attached components. No denominator reduction or deterministic-only sign-off.',
    live_sessions=0,goal_status='active',
    working_chemistry_command=['env','RDBASE=/private/tmp/npmech-rdkit-2026.03.5/share/RDKit','PYTHONPATH='+str(ROOT/'.venv/lib/python3.13/site-packages'),'/private/tmp/npmech-rdkit-2026.03.5/bin/python'],
    working_chemistry_note='Exact RDKit2026.03.5 chemistry passed using existing repository NumPy via PYTHONPATH; isolated temporary NumPy lacked __config__. Initial failure retained; packages were not edited.',
    verification=dict(ignored_inclusive=True,unchanged_owners=len(owners),unchanged_components=len(components),prior_reviews_unchanged=17,
                      qc=str(WORK/'qc.receipt.json'),label_gate=str(WORK/'labels.receipt.json'),review_check=str(WORK/'review-check.receipt.json'),contract_tests=str(WORK/'review-contract-tests.receipt.json'),
                      supplementary_stereo_retaining_tautomer_check={'yersiniabactin-2':'JHYVWAMMAMCUIR-VQNLDRKJSA-N','yersiniabactin':'JHYVWAMMAMCUIR-UHFFFAOYSA-N',
                          'scope':'Post-save sanity check with the same RDKit environment: Canonicalize without RemoveStereochemistry retains different stereo keys. No saved scientific conclusion changed.'}),
)
assert checkpoint['partial_reviews'] == 14
assert checkpoint['unassessed_records'] == 3101
assert checkpoint['scientific_review_bundles'] == 19
assert len(owners) == 3115 and len(components) == 243
expected_pairs = {str(ROOT/row['yaml']) for row in checkpoint['all_review_observations']}
assert {str(p) for p in (ROOT/'reviews/structured').rglob('review.yaml')} == expected_pairs
output = WORK/'review-campaign-checkpoint.json'
with output.open('x') as handle:
    json.dump(checkpoint,handle,indent=2)
print(json.dumps(dict(checkpoint=str(output),sha256=sha(output),population=3115,components=243,
                      partial_owners=14,complete_owners=0,unassessed=3101,observations=19,
                      findings=checkpoint['findings'],next=checkpoint['pending_in_priority_order'][:2],
                      additions=[{k:r[k] for k in ('review_id','yaml','markdown','verdict','completion')} for r in additions]),indent=2))
