import csv
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml
from naturalproductmech.graph_components import read_natural_product

ROOT = Path.cwd()
WORK = Path(__file__).parent
PRIOR = Path('/private/tmp/npmech-vibriobactin-publish-ZQxmpQoV/post-merge-campaign-checkpoint.json')
BASE = '8b5a3ebf476c27b21d49a89d7e5684cef41a367d'
def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name, value):
    with (WORK / name).open('x') as handle:
        json.dump(value, handle, indent=2)

started = now()
assert sha(PRIOR) == '800feb590e1d67b9322ee4e809d27c700fa83821036dbd753c896b7eeb283218'
old = json.loads(PRIOR.read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE == old['base']
records = {r['path']: r for r in old['records']}
components = {c['path']: c for r in records.values() for c in r['graph_components']}
actual = {str(p.relative_to(ROOT)) for folder in ('data/natural_products', 'data/causal_graphs') for p in (ROOT / folder).rglob('*.yaml')}
assert actual == records.keys() | components.keys()
for name, row in (records | components).items():
    assert sha(ROOT / name) == row['sha256'], name
for row in old['all_review_observations']:
    assert sha(ROOT / row['yaml']) == row['yaml_sha256']
    assert sha(ROOT / row['markdown']) == row['markdown_sha256']
owners = {
    'data/raw/mibig_compounds.tsv': 'Imported chemical, producer and cluster assertions',
    'data/raw/lotus_occurrences.tsv': 'Imported structure-organism-reference triples',
    'data/raw/chebi_structures.tsv': 'Pinned ChEBI grounding inventory',
    'data/raw/chebi_origins.tsv': 'Pinned ChEBI occurrence inventory',
    'data/raw/npclassifier.tsv': 'Pinned computed classification',
    'data/raw/antibioticmech_inchikeys.tsv': 'Pinned sibling exact-structure joins',
    'scripts/seed_from_sources.py': 'Generated harmonization and grading',
    'scripts/extract_mibig.py': 'MIBiG extraction',
    'scripts/extract_lotus.py': 'LOTUS extraction',
    'curation/mibig_structure_corrections.tsv': 'Implemented pinned structure corrections',
    'curation/mibig_locus_evidence_overrides.tsv': 'Implemented exact-context method corrections',
    'curation/mibig_producer_strains.tsv': 'Implemented pinned strain qualifications',
}
inputs = list(owners) + [
    'CLAUDE.md', 'justfile', 'docs/CURATION.md', 'docs/HARMONIZATION.md', 'docs/record-reviews.md',
    'docs/record-review-profile.md', 'conf/record_review.yaml', 'conf/id_label_targets.yaml',
    '.claude/skills/review-yaml-record/SKILL.md', '.claude/skills/curate-yaml-record/references/review-checklist.md',
    'schema/record_review.yaml', 'scripts/record_review.py', 'conf/producer_evidence.tsv',
    'src/naturalproductmech/schema/naturalproductmech.yaml', 'src/naturalproductmech/schema/mech_shared.yaml',
    'src/naturalproductmech/schema/history.yaml', 'src/naturalproductmech/graph_components.py',
    'data/raw/corpus_taxa.obo', 'data/raw/MANIFEST.yaml', 'data/natural_products/PATHS.tsv',
    'curation/decisions.tsv', 'pyproject.toml', 'uv.lock',
    'data/natural_products/alkaloids/yersiniabactin-2.yaml', 'data/natural_products/alkaloids/yersiniabactin.yaml',
]
captures = []
for slug in ('yersiniabactin-2', 'yersiniabactin'):
    name = f'data/natural_products/alkaloids/{slug}.yaml'
    assert name in old['pending_in_priority_order']
    doc = yaml.safe_load((ROOT / name).read_text())
    target = dict(target_id=doc['identifier'], path=name, label=doc['label'], record_class='NaturalProductRecord', kind='generated',
                  owner_paths=[dict(repository='CultureBotAI/NaturalProductMech', path=p, role=r) for p, r in owners.items()])
    save(slug + '-targets.json', dict(targets=[target]))
    command = [sys.executable, 'scripts/record_review.py', 'inspect', '--targets', str(WORK / (slug + '-targets.json'))]
    for p in inputs:
        command += ['--input', p]
    before = now()
    result = subprocess.run(command, text=True, capture_output=True)
    output = WORK / (slug + '-inspect.json')
    with output.open('x') as handle:
        handle.write(result.stdout)
    with (WORK / (slug + '-inspect.stderr')).open('x') as handle:
        handle.write(result.stderr)
    save(slug + '-inspect.receipt.json', dict(command=command, cwd=str(ROOT), started_at=before, finished_at=now(), exit_code=result.returncode, log=str(output), log_sha256=sha(output)))
    assert result.returncode == 0, result.stderr
    resolved = read_natural_product(ROOT / name)
    assert not resolved.get('causal_graphs') and not doc.get('causal_graph_refs')
    save(slug + '-resolved.json', resolved)
    captures.append(dict(slug=slug, path=name, target_id=doc['identifier'], sha256=sha(ROOT / name), key=doc['chemical_structure']['standard_inchi_key'], graphs=0, components=[]))
keys = {r['key'] for r in captures}
source_rows = {}
for basename in ('mibig_compounds', 'lotus_occurrences', 'chebi_structures', 'chebi_origins', 'npclassifier', 'antibioticmech_inchikeys'):
    with (ROOT / ('data/raw/' + basename + '.tsv')).open() as handle:
        source_rows[basename] = [dict(line=i, **row) for i, row in enumerate(csv.DictReader(handle, delimiter='\t'), 2) if row.get('standard_inchi_key') in keys]
save('source-rows.json', source_rows)
stop_info = old['inherited_scientific_access_stops']
stop_path = Path(stop_info['checkpoint'])
assert sha(stop_path) == stop_info['sha256']
stops = json.loads(stop_path.read_text())['access_stops_no_alternate_retrieval'] + old['new_access_stops']
save('inherited-access-stops.json', stops)
terms = ['yersin', '17049458', '17660289', '9457855', 'jlac', '2006.06.007', '00012-6', '139-9-2159', '538-546.1998']
save('access-stop-matches.json', dict(terms=terms, matches=[s for s in stops if any(t in json.dumps(s).lower() for t in terms)], inherited_count=len(stops), no_global_absence_claim=True))
capture = dict(base=BASE, started_at=started, finished_at=now(), captures=captures, prior_checkpoint=str(PRIOR), prior_checkpoint_sha256=sha(PRIOR), owners_verified=len(records), components_verified=len(components), prior_observations_verified=len(old['all_review_observations']), ignored_inclusive=True, previous_turn_classification='progress: PR894 merged; seven issues closed; tree and review hashes verified; local and remote feature branches deleted')
save('capture.json', capture)
print(json.dumps(capture, indent=2))
