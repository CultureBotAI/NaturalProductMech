import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml

WORK = Path(__file__).parent
class NoAliases(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True

receipt = json.loads((WORK/'review-validate-ready.receipt.json').read_text())
assert receipt['exit_code'] == 1
assert hashlib.sha256(Path(receipt['log']).read_bytes()).hexdigest() == receipt['log_sha256']
results = []
for row in json.loads((WORK/'ready-prepared.json').read_text()):
    doc = yaml.safe_load(Path(row['draft']).read_text())
    tid = doc['targets'][0]['target_id']
    doc['checks'].append(dict(check_id='draft-scope-validation',name='Single-record scope validation',
                             status='failed',required=False,target_ids=[tid],command=shlex.join(receipt['command']),
                             exit_code=1,expected_exit_code=0,summary='The draft incorrectly placed the campaign denominator3115 in a kind:record artifact. Its schema denominator is now1, with the full3115-owner/243-component campaign explicitly retained in scope prose and the checkpoint. No population was removed from the goal.',
                             scope_note='Superseded metadata failure retained; log SHA256 '+receipt['log_sha256']))
    doc['scope']['population_size'] = 1
    doc['notes'].append('The single-record artifact denominator is1. The exhaustive campaign remains3115 owners and243 components; partial observations are not scientific completions.')
    finished = datetime.now(timezone.utc)
    slug = Path(row['original_draft']).name.removesuffix('-review.yaml')
    doc['finished_at'] = finished.isoformat().replace('+00:00','Z')
    doc['review_id'] = finished.strftime('%Y%m%dT%H%M%SZ')+'-'+slug
    destination = WORK/(slug+'-review-scoped.yaml')
    with destination.open('x') as handle:
        yaml.dump(doc,handle,Dumper=NoAliases,sort_keys=False,allow_unicode=False,width=100)
    results.append(dict(row,review_id=doc['review_id'],draft=str(destination)))
with (WORK/'scoped-prepared.json').open('x') as handle:
    json.dump(results,handle,indent=2)
print(json.dumps(results,indent=2))
