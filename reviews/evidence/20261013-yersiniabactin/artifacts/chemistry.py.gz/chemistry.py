import json
from pathlib import Path
from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, rdMolDescriptors
from rdkit.Chem.MolStandardize import rdMolStandardize

work = Path(__file__).parent
assert rdBase.rdkitVersion == '2026.03.5'
pubchem = json.loads((work / 'pubchem-5462519.json').read_text())['PropertyTable']['Properties'][0]
rows = []
for slug in ('yersiniabactin-2', 'yersiniabactin'):
    doc = json.loads((work / (slug + '-resolved.json')).read_text())
    structure = doc['chemical_structure']
    mol = Chem.MolFromSmiles(structure['smiles'])
    assert mol is not None
    inchi = Chem.MolToInchi(mol)
    key = Chem.MolToInchiKey(mol)
    assert inchi == structure['standard_inchi']
    assert key == structure['standard_inchi_key']
    centers = Chem.FindMolChiralCenters(mol, includeUnassigned=True)
    assert structure['stereo_complete'] == (not any(tag == '?' for _, tag in centers))
    no_stereo = Chem.Mol(mol)
    Chem.RemoveStereochemistry(no_stereo)
    canonical = rdMolStandardize.TautomerEnumerator().Canonicalize(no_stereo)
    rows.append(dict(slug=slug, identifier=doc['identifier'], inchi=inchi, inchikey=key,
                     formula=rdMolDescriptors.CalcMolFormula(mol), net_charge=Chem.GetFormalCharge(mol),
                     exact_mass=Descriptors.ExactMolWt(mol), atom_index_CIP=centers,
                     pubchem_exact_match=key == pubchem['InChIKey'],
                     stereo_free_key=Chem.MolToInchiKey(no_stereo),
                     stereo_free_canonical_tautomer=Chem.MolToSmiles(canonical),
                     stereo_free_canonical_tautomer_key=Chem.MolToInchiKey(canonical)))
result = dict(rdkit=rdBase.rdkitVersion, records=rows,
              same_stereo_free_canonical_tautomer=rows[0]['stereo_free_canonical_tautomer'] == rows[1]['stereo_free_canonical_tautomer'],
              limitation='Computational tautomer normalization does not establish experimentally determined form or authorize owner merging.')
with (work / 'chemistry.json').open('x') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result, indent=2))
