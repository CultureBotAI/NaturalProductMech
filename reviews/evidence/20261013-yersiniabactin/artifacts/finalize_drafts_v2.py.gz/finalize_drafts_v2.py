import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml

WORK = Path(__file__).parent
class NoAliases(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True

receipt = json.loads((WORK/'review-validate-final.receipt.json').read_text())
assert receipt['exit_code'] == 1
assert hashlib.sha256(Path(receipt['log']).read_bytes()).hexdigest() == receipt['log_sha256']
results = []
for row in json.loads((WORK/'final-prepared.json').read_text()):
    doc = yaml.safe_load(Path(row['draft']).read_text())
    tid = doc['targets'][0]['target_id']
    doc['checks'].append(dict(check_id='draft-timestamp-validation',name='Draft review ID timestamp validation',
                             status='failed',required=False,target_ids=[tid],command=shlex.join(receipt['command']),
                             exit_code=1,expected_exit_code=0,summary='Alias-free draft validation exposed a review_id prefix that no longer matched finished_at after the format repair. Both timestamp fields were synchronized before final validation. Scientific evidence access timestamps, input hashes and assessments were retained.',
                             scope_note='Superseded draft-format failure retained; log SHA256 '+receipt['log_sha256']))
    finished = datetime.now(timezone.utc)
    slug = Path(row['original_draft']).name.removesuffix('-review.yaml')
    doc['finished_at'] = finished.isoformat().replace('+00:00','Z')
    doc['review_id'] = finished.strftime('%Y%m%dT%H%M%SZ')+'-'+slug
    destination = WORK/(slug+'-review-ready.yaml')
    with destination.open('x') as handle:
        yaml.dump(doc,handle,Dumper=NoAliases,sort_keys=False,allow_unicode=False,width=100)
    results.append(dict(row,review_id=doc['review_id'],draft=str(destination)))
with (WORK/'ready-prepared.json').open('x') as handle:
    json.dump(results,handle,indent=2)
print(json.dumps(results,indent=2))
