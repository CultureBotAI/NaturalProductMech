import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

from naturalproductmech.graph_components import read_natural_product

work = Path(__file__).parent
prior = Path('reviews/structured/20261013T152822Z-compound-3/review.yaml')
doc = yaml.safe_load(prior.read_text())
owner = doc['targets'][0]['path']
with (work / 'targets.json').open('x') as handle:
    json.dump({'targets': doc['targets']}, handle, indent=2)
inputs = [
    str(prior), 'curation/mibig_producer_strains.tsv',
    'src/naturalproductmech/curate/producer_strains.py', 'scripts/seed_from_sources.py',
    'src/naturalproductmech/validation/write_validated.py',
    'src/naturalproductmech/curate/curation_event.py',
    'docs/CURATION.md', 'docs/HARMONIZATION.md', 'docs/record-reviews.md',
    'docs/record-review-profile.md', '.claude/skills/review-yaml-record/SKILL.md',
    '.claude/skills/curate-yaml-record/references/review-checklist.md',
    'tests/test_compound3_curation.py', 'tests/test_compound3_review_archive.py',
    'reviews/evidence/20261013-compound3/manifest.json',
    'reviews/evidence/20261013-compound3/artifacts/chemistry.json.gz',
    'reviews/evidence/20261013-compound3/artifacts/CP034458.1-region.xml.gz',
    'pages/amino_acids_and_peptides/compound-3.html',
    'data/raw/mibig_compounds.tsv', 'data/raw/npclassifier.tsv',
    'src/naturalproductmech/schema/naturalproductmech.yaml',
    'src/naturalproductmech/schema/mech_shared.yaml',
]
command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect',
           '--targets', str(work / 'targets.json')]
for path in inputs:
    command.extend(['--input', path])
started = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
result = subprocess.run(command, text=True, capture_output=True)
assert result.returncode == 0, result.stderr
capture = json.loads(result.stdout)
for item in capture['source']['inputs']:
    raw = subprocess.check_output(['git', 'show', f"{capture['source']['git_revision']}:{item['path']}"])
    assert hashlib.sha256(raw).hexdigest() == item['sha256']
with (work / 'successor-inspect.json').open('x') as handle:
    handle.write(result.stdout)
with (work / 'successor-owner.json').open('x') as handle:
    json.dump(read_natural_product(Path(owner)), handle, indent=2)
with (work / 'capture.receipt.json').open('x') as handle:
    json.dump(dict(command=command, started_at=started,
                   finished_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
                   exit_code=result.returncode, stderr=result.stderr,
                   sha256=hashlib.sha256(result.stdout.encode()).hexdigest()), handle, indent=2)
print('Captured exact owner and', len(capture['source']['inputs']), 'inputs equal to committed bytes')
