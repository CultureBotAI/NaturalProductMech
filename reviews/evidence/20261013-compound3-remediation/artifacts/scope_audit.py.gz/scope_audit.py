import hashlib
import json
import subprocess
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

import yaml

work = Path(__file__).parent
prior = Path('/private/tmp/npmech-compound3-review-2EX0Ug/review-campaign-checkpoint.json')
checkpoint = json.loads(prior.read_text())
target = 'data/natural_products/amino_acids_and_peptides/compound-3.yaml'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


rows = {r['path']: r for r in checkpoint['records']}
actual = {str(p) for p in Path('data/natural_products').rglob('*.yaml')}
assert actual == rows.keys() and len(actual) == 3115
changed = [p for p, r in rows.items() if digest(p) != r['sha256']]
assert changed == [target], changed
components = {c['path']: c for r in rows.values() for c in r['graph_components']}
assert {str(p) for p in Path('data/causal_graphs').rglob('*.yaml')} == components.keys()
assert len(components) == 243
assert all(digest(p) == r['sha256'] for p, r in components.items())
for r in checkpoint['all_review_observations']:
    assert digest(r['yaml']) == r['yaml_sha256']
    assert digest(r['markdown']) == r['markdown_sha256']
before = yaml.safe_load(subprocess.check_output(['git', 'show', f"{checkpoint['base']}:{target}"]))
after = yaml.safe_load(Path(target).read_text())
comparable = deepcopy(after)
producer, = comparable['producer_organisms']
assert producer.pop('strain') == 'APC1.2 (CCOS978)'
assert producer['evidence'].pop()['evidence_type'] == 'CURATOR_INFERENCE'
assert comparable['discussions'].pop()['discussion_id'] == 'curator-compound3-proposed-structure'
assert len(comparable['curation_history']) == len(before['curation_history']) + 2
comparable['curation_history'] = comparable['curation_history'][:-2]
assert comparable == before
proof = dict(
    recorded_at=datetime.now(timezone.utc).isoformat(), base=checkpoint['base'],
    owners=3115, components=243, changed_owners=changed, unchanged_owners=3114,
    unchanged_components=243, immutable_prior_observations=29,
    complete_filesystem_search='Path.rglob includes ignored and hidden paths; full owner/component set equality.',
    original_checkpoint_sha256=digest(prior),
    old_owner_sha256=rows[target]['sha256'], new_owner_sha256=digest(target),
    retained='Exact identity, chemistry, taxon, BGC, classification, evidence grades and SEEDED status.',
    changed='One strain qualifier with separate evidence, one curator discussion, two audit events.',
)
with (work / 'scope-audit.json').open('x') as handle:
    json.dump(proof, handle, indent=2)
print(json.dumps(proof, indent=2))
