import gzip
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import yaml

work = Path(__file__).parent
destination = Path('reviews/evidence/20261013-compound3-remediation')
labels = ['seed-dry', 'seed-canary', 'qualify', 'qualify-fixed', 'focused', 'focused-fixed',
          'render', 'render-final', 'archive-tests', 'scope-audit', 'strict', 'reseed', 'qc', 'labels',
          'governance-network']
names = ['scope-audit.json', 'scope_audit.py', 'capture.receipt.json', 'successor-inspect.json',
         'successor-owner.json', 'targets.json', 'strict.tsv', 'qualify_structure.py',
         'capture_successor.py', 'prepare_successor.py', 'run_check.py', 'archive_remediation.py']
for label in labels:
    names.extend([label + '.log', label + '.receipt.json'])
for label in ['qc', 'labels']:
    assert json.loads((work / (label + '.receipt.json')).read_text())['exit_code'] == 0
(destination / 'artifacts').mkdir(parents=True, exist_ok=False)
artifacts = []
for name in names:
    path = work / name
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    target = destination / 'artifacts' / (name + '.gz')
    with target.open('xb') as handle:
        handle.write(stored)
    artifacts.append(dict(original_path=str(path), path=str(target.relative_to(destination)),
                          sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw),
                          stored_sha256=hashlib.sha256(stored).hexdigest(), stored_bytes=len(stored)))
manifest = dict(format_version=1, recorded_at=datetime.now(timezone.utc).isoformat(),
                review_id=yaml.safe_load((work / 'successor.yaml').read_text())['review_id'],
                source_revision=json.loads((work / 'successor-inspect.json').read_text())['source']['git_revision'],
                source_tag='review-base/compound3-remediation-20261013',
                artifacts=artifacts, prior_archive='reviews/evidence/20261013-compound3/manifest.json',
                note='Successful and superseded failed checks retained. Canonical save/check and final CI happen after this snapshot.')
with (destination / 'manifest.json').open('x') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')
print(f'Retained {len(artifacts)} remediation artifacts')
