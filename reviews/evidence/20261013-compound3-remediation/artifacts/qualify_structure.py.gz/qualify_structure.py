from copy import deepcopy
from pathlib import Path

import yaml

from naturalproductmech.curate.curation_event import record_curation_event
from naturalproductmech.validation.write_validated import write_validated_natural_product

path = Path('data/natural_products/amino_acids_and_peptides/compound-3.yaml')
doc = yaml.safe_load(path.read_text())
assert doc['identifier'] == 'naturalproductmech:mibig-0dd7b68dcd'
assert doc['chemical_structure']['standard_inchi_key'] == 'RHGNLLJMHSJJRX-UHFFFAOYSA-N'
assert doc['curation_status'] == 'SEEDED'
assert doc['producer_organisms'][0]['strain'] == 'APC1.2 (CCOS978)'
assert [d['discussion_id'] for d in doc['discussions']] == ['needs-a-name']
before = deepcopy(doc)
doc['discussions'].append({
    'discussion_id': 'curator-compound3-proposed-structure',
    'kind': 'KNOWLEDGE_GAP',
    'status': 'OPEN',
    'prompt': (
        'The recorded compound 3 structure is proposed, not definitively elucidated. '
        'What direct structural evidence establishes its connectivity and stereochemistry?'
    ),
    'posed_by': 'codex',
    'rationale': (
        'PMID:31081214 Results and Figure 2B propose compound 3 as a di-N-hydroxylated '
        'cyclodileucine intermediate or shunt product. High-resolution mass spectrometry '
        'and isotope feeding support C12H22N2O4 and two leucine-derived carbon backbones '
        '(supplementary Figure S4), not a definitive assignment of all bond positions '
        'or stereochemistry. The imported molecular graph is retained as that proposal; '
        'stereo_complete: false alone does not express the constitutional uncertainty.'
    ),
    'evidence': [{
        'reference': 'PMID:31081214',
        'evidence_source': 'full_text',
        'notes': (
            'Curator interpretation of DOI:10.1111/mmi.14272; compound-analysis Results, Figure 2B and supplementary '
            'Figure S4. This qualification neither establishes a replacement structure '
            'nor assigns the whole-cell antifungal observations to purified compound 3.'
        ),
    }],
    'notes': 'Source qualification added for issue #914. Experimental identity remains unresolved.',
})
record_curation_event(
    doc, curator='codex', action='RECORD_CURATED', llm_assisted=True,
    changes=(
        'Add a cited curator discussion preserving the proposed compound 3 identity '
        'and unresolved connectivity/stereochemistry (PMID:31081214; issue #914). '
        'Chemistry, producer/locus evidence grades and SEEDED status are unchanged.'
    ),
)
assert {k: v for k, v in before.items() if k not in ('discussions', 'curation_history')} == {
    k: v for k, v in doc.items() if k not in ('discussions', 'curation_history')
}
write_validated_natural_product(doc, path)
print(path)
