"""Author a bounded successor only after the real gate receipts exist."""

import gzip
import hashlib
import json
import shlex
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

import yaml

WORK = Path(__file__).parent
ARCHIVE = Path('reviews/evidence/20261013-compound3')
TARGET = 'naturalproductmech:mibig-0dd7b68dcd'
PRIOR = '20261013T152822Z-compound-3'
old = yaml.safe_load(Path(f'reviews/structured/{PRIOR}/review.yaml').read_text())
capture = json.loads((WORK / 'successor-inspect.json').read_text())
capture_receipt = json.loads((WORK / 'capture.receipt.json').read_text())


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


for item in capture['source']['inputs']:
    assert digest(Path(item['path']).read_bytes()) == item['sha256']
scope = json.loads((WORK / 'scope-audit.json').read_text())
assert digest(Path(old['targets'][0]['path']).read_bytes()) == scope['new_owner_sha256']
checks = []
summaries = {
    'focused-fixed': '185 focused tests passed, including strain scoping and same-key discussion carry-forward.',
    'archive-tests': 'Five curation/archive tests passed, including every historical evidence digest and campaign denominator.',
    'strict': 'The changed owner passed strict closed-schema validation with zero errors.',
    'reseed': 'One exact-owner re-seed reported one unchanged record; the captured owner hash remains identical.',
    'scope-audit': 'Only the intended owner changed; all other 3114 owners, 243 components and 29 prior observations are byte-identical.',
    'qc': 'Full native QC passed: 745 tests passed, 4 skipped, 2 dependency warnings; lint, pinned governance, documentation, raw provenance, source queue, all-owner strict validation, site, exact reproduction and path lock passed. The optional governance-network check separately passed on retry.',
    'labels': 'Fresh configured label gate passed. Existing warning mismatches and no-adapter skips are not chemical identity certification.',
    'governance-network': 'The focused optional network snapshot test passed on retry (1 passed); the full suite receipt retains its original skip count.',
}
for label, summary in summaries.items():
    receipt = json.loads((WORK / (label + '.receipt.json')).read_text())
    assert receipt['exit_code'] == 0, (label, receipt)
    assert digest(Path(receipt['log']).read_bytes()) == receipt['log_sha256']
    checks.append(dict(
        check_id=label, name=label, status='passed', required=True,
        command=shlex.join(receipt['command']), exit_code=0, expected_exit_code=0,
        target_ids=[TARGET], summary=summary,
        scope_note=f"Actual run {receipt['started_at']} to {receipt['finished_at']}; log SHA256 {receipt['log_sha256']}",
    ))
for label, summary in [
    ('qualify', 'Initial guarded write was rejected because discussion references do not accept evidence_type; no invalid record was written. Corrected to SupportingReference.evidence_source.'),
    ('focused', 'The initial regression run found the missing discussion after the rejected write. Superseded by focused-fixed after the schema-correct guarded write.'),
]:
    receipt = json.loads((WORK / (label + '.receipt.json')).read_text())
    assert receipt['exit_code'] == 1
    checks.append(dict(check_id=label, name=label, status='failed', required=False,
                       command=shlex.join(receipt['command']), exit_code=1, expected_exit_code=0,
                       target_ids=[TARGET], summary=summary))

evidence = []


def ev(eid, kind, reference, locator, summary, sha=None, support='supports'):
    item = dict(evidence_id=eid, kind=kind, reference=reference, locator=locator,
                accessed_at=now(), support=support, summary=summary)
    if sha:
        item['snapshot_sha256'] = sha
    evidence.append(item)


owner = old['targets'][0]['path']
ev('owner', 'record_content', owner, 'Complete current raw YAML and resolved owner, including all audit events',
   'Exactly one species-rank producer now carries APC1.2 (CCOS978) and separate curator evidence. '
   'The OPEN curator discussion explicitly qualifies the proposed structure. Chemistry, source '
   'concepts, both correlated evidence grades and SEEDED status remain unchanged. No graphs, '
   'occurrences, pure-compound activities or other optional biological claims were added.',
   digest(Path(owner).read_bytes()))
ev('prior', 'record_content', f'reviews/structured/{PRIOR}/review.yaml', 'F1 and F2, exact issue keys and source scope',
   'Original immutable assessment with one major qualification defect and one minor strain omission.',
   digest(Path(f'reviews/structured/{PRIOR}/review.yaml').read_bytes()))
table = 'curation/mibig_producer_strains.tsv'
ev('strain-table', 'record_content', table, 'BGC0002321:4, complete source row SHA256 80d41d4998165dd6b2d6796304411bc824c7fda7c7f11d20a20ead4f36cc7817',
   'Maintained qualification names the WT isolate, retains the taxon and evidence grade, and distinguishes W8/complemented derivatives.',
   digest(Path(table).read_bytes()))
for eid in ['paper', 'figure', 'supplement', 'genome']:
    original = next(e for e in old['evidence'] if e['evidence_id'] == eid)
    item = deepcopy(original)
    item['accessed_at'] = now()
    item['locator'] += '; same retained source capture re-inspected for this scoped disposition, not a new network retrieval'
    evidence.append(item)
ev('scope-proof', 'validation', str(WORK / 'scope-audit.json'), 'Ignored-inclusive complete filesystem hash comparison',
   'The only scientific delta is the strain qualifier/evidence, proposed-identity discussion and two audit events. '
   'All 3115 owners and 243 components remain in scope; all 29 historical review pairs are immutable.',
   digest((WORK / 'scope-audit.json').read_bytes()))
ev('archive', 'validation', str(ARCHIVE / 'manifest.json'), 'All three historical observations and every snapshot mapping',
   '121 compressed artifacts preserve local receipts, computations and full checkpoint. Eleven publisher-derived '
   'artifacts remain explicitly reference-only; no blocked paper was retried. Tests verify bytes and mapping.',
   digest((ARCHIVE / 'manifest.json').read_bytes()))
ev('regressions', 'validation', str(WORK / 'focused-fixed.log'), '185 focused tests',
   'Exact source pin, unchanged imported claims, retained incomplete stereochemistry and grade, cited discussion '
   'and carry-forward limited to the same key all pass.', digest((WORK / 'focused-fixed.log').read_bytes()))

assessments = [
    dict(assessment_id='qualification', area='evidence', topic='Proposed identity is visibly qualified',
         outcome='supported', summary='The discussion states that the molecular graph is proposed, not definitively '
         'elucidated, distinguishes composition/backbone support from full connectivity and stereochemistry, and '
         'cites the exact primary source. F1 is resolved without claiming a replacement structure.',
         target_ids=[TARGET], evidence_ids=['owner', 'paper', 'figure', 'supplement', 'regressions']),
    dict(assessment_id='strain', area='scope', topic='Exact experimental isolate context', outcome='supported',
         summary='APC1.2 (CCOS978) matches the paper and source accession. The qualification is pinned to '
         'BGC0002321:4 and does not upgrade the species taxon, cluster host or correlation grades. F2 is resolved.',
         target_ids=[TARGET], evidence_ids=['owner', 'paper', 'genome', 'strain-table', 'regressions']),
    dict(assessment_id='unresolved-identity', area='identity', topic='Experimental identity remains proposed',
         outcome='unknown', summary='This disposition repairs confidence wording, not experimental elucidation. '
         'The two stereocenters remain unspecified and full connectivity is not experimentally settled. '
         'No native REVIEWED status is warranted by the fixes.', target_ids=[TARGET],
         evidence_ids=['owner', 'paper', 'figure', 'supplement']),
    dict(assessment_id='preserved-scope', area='provenance', topic='Ownership, audit and unchanged scientific scope',
         outcome='supported', summary='Native seeding adds the strain through its maintained consumer; the discussion '
         'uses the guarded writer with a codex-attributed event. All unrelated fields, owners and components remain '
         'unchanged. Current full QC is deterministic verification, not an all-corpus scientific assessment.',
         target_ids=[TARGET], evidence_ids=['owner', 'scope-proof', 'archive', 'regressions']),
]
findings = []
for finding in old['findings']:
    f = deepcopy(finding)
    f['status'] = 'resolved'
    f['previous_occurrences'] = [dict(repository=old['repository'], review_id=PRIOR,
                                     finding_id=f['finding_id'])]
    issue = 914 if f['finding_id'] == 'F1' else 915
    f['external_issues'] = [f'https://github.com/CultureBotAI/NaturalProductMech/issues/{issue}']
    f['evidence_ids'] = (['owner', 'paper', 'figure', 'supplement', 'regressions', 'scope-proof']
                         if issue == 914 else ['owner', 'paper', 'genome', 'strain-table', 'regressions', 'scope-proof'])
    f['disposition_reason'] = (
        'The cited curator-owned discussion now preserves the primary source proposed-identity limitation. '
        'Same-key reseed, strict validation, regression tests, rendered page and full QC pass. '
        'This closes the missing qualification, not the experimental identity question.' if issue == 914 else
        'The complete-row-pinned maintained decision now emits APC1.2 (CCOS978) with separate curator evidence. '
        'Source chemistry, taxon, native grade and all unrelated owners/components are unchanged. '
        'Reproduction and full QC pass; the omission is fixed without inferring species-wide production.'
    )
    findings.append(f)
source = deepcopy(capture['source'])
source['state'] = 'git_commit'
rid = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-compound-3-qualification-resolution'
review = dict(
    schema_version='1.0.0', review_id=rid, kind='record', repository=old['repository'],
    title='Compound 3: scoped proposed-identity and producer-strain resolution',
    started_at=capture_receipt['started_at'], finished_at=now(),
    reviewer=dict(identity='Codex', kind='agent', independence='self_review',
                  independence_basis='Same assistant implemented and separately adversarially checked the changes; not independent human review.'),
    skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial', verdict='pass_with_limitations',
    scientific_review=True,
    summary='Resolve only predecessor F1/F2: preserve proposed-structure confidence and exact APC1.2 isolate context. '
            'Experimental identity remains unresolved, all other owner claims are unchanged, and native status stays SEEDED.',
    source=source, targets=capture['targets'],
    scope=dict(description='One exact owner, bounded disposition of predecessor F1/F2; full campaign remains 3115 owners and 243 components.',
               selection='User-authorized PR remediation of the two confirmed findings.', coverage='partial',
               population_size=1, reviewed_target_ids=[TARGET], exclusions=[
                   dict(target='Other 3114 owners and prior scientific limitations', reason='No new assessment or scope reduction; all previous observations are retained.')]),
    checks=checks, evidence=evidence, assessments=assessments, findings=findings, actions=[],
    limitations=[
        'Scoped partial successor, not a new whole-record scientific pass. The original full assessment remains historical; this observation adds no newly assessed owner.',
        'The proposed connectivity and unresolved stereochemistry remain explicit. No direct PUL-gene experiment or purified-compound antifungal activity is inferred.',
        'The two other paper-local Compound 3 owners remain partial and distinct; their publisher 403 limits and all 195 campaign access limitations are retained.',
        'Source state is git_commit: all 23 captured inputs were checked against the exact tagged implementation commit. The provenance tag is retained across the required squash merge.',
        'The initial failed guarded write and regression run are retained as superseded attempts, not hidden successes. Canonical successor checks and final PR/merge-queue CI follow persistence.',
    ],
    related_reviews=[dict(repository=old['repository'], review_id=PRIOR, relationship='Scoped resolution of F1 and F2 only')],
    links=[f'https://github.com/CultureBotAI/NaturalProductMech/{kind}/{number}' for kind, number in
           [('pull', 913), ('issues', 914), ('issues', 915), ('issues', 916)]],
)


class NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


with (WORK / 'successor.yaml').open('x') as handle:
    yaml.dump(review, handle, Dumper=NoAliasDumper, sort_keys=False, allow_unicode=False, width=94)
print(rid)
