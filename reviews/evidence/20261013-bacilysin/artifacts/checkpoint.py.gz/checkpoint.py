import collections
import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


capture = json.loads((WORK / 'capture.json').read_text())
resume = json.loads((WORK / 'resumption.json').read_text())
prior = Path(capture['prior_checkpoint'])
assert sha(prior) == capture['prior_checkpoint_sha256']
checkpoint = json.loads(prior.read_text())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == resume['head'] == '745da66fbc24191cf6748ef1de89ad9cdfcbd824'
owners = {r['path']: r for r in checkpoint['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
actual = {str(p.relative_to(ROOT)) for folder in ('data/natural_products', 'data/causal_graphs')
          for p in (ROOT / folder).rglob('*.yaml')}
assert actual == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(ROOT / path) == row['sha256'], path
for observation in checkpoint['all_review_observations']:
    for key in ('yaml', 'markdown'):
        assert sha(ROOT / observation[key]) == observation[key + '_sha256']
for name in ('strict', 'labels', 'qc', 'queue-fresh', 'chemistry', 'reassignment-chemistry',
             'validate-drafts', 'validate-final', 'save-bacilysin-2', 'save-bacilysin',
             'review-check', 'review-contract-tests'):
    receipt = json.loads((WORK / (name + '.receipt.json')).read_text())
    assert receipt['exit_code'] == 0
    assert sha(Path(receipt['log'])) == receipt['log_sha256']
additions = []
for row in json.loads((WORK / 'final-index.json').read_text()):
    directory = ROOT / 'reviews/structured' / row['review_id']
    saved, markdown = directory / 'review.yaml', directory / 'review.md'
    doc = yaml.safe_load(saved.read_text())
    assert doc['review_id'] == row['review_id']
    assert doc['completion'] == 'partial'
    target = doc['targets'][0]
    path = target['path']
    assert path in checkpoint['pending_in_priority_order']
    for item in doc['source']['inputs']:
        assert sha(ROOT / item['path']) == item['sha256']
    entry = dict(review_id=doc['review_id'], yaml=str(saved.relative_to(ROOT)), yaml_sha256=sha(saved),
                 markdown=str(markdown.relative_to(ROOT)), markdown_sha256=sha(markdown),
                 target_id=target['target_id'], path=path, verdict=doc['verdict'],
                 completion=doc['completion'], scientific_review=doc['scientific_review'],
                 findings=doc['findings'], finished_at=doc['finished_at'])
    additions.append(entry)
    checkpoint['reviews'].append(entry)
    checkpoint['all_review_observations'].append(entry)
    checkpoint['partial_followups'].append(path)
    checkpoint['pending_in_priority_order'].remove(path)
    owners[path]['review_state'] = 'partial'
    for finding in doc['findings']:
        assert not finding.get('previous_occurrences')
        assert finding['issue_key'] not in {f['issue_key'] for f in checkpoint['latest_finding_heads']}
        checkpoint['latest_finding_heads'].append(dict(finding, review_id=doc['review_id'], finished_at=doc['finished_at']))
access = json.loads((WORK / 'access-limitations-final.json').read_text())
assert len(access['new_access_stops']) == 11
checkpoint['new_access_stops'].extend(access['new_access_stops'])
with (WORK / 'queue-fresh.tsv').open() as handle:
    queue = list(csv.DictReader(handle, delimiter='\t'))
non_owner_paths = {r['path'] for r in queue if r['path'] not in owners}
assert non_owner_paths == {'curation/unresolved_taxa.tsv'}
queued_paths = {r['path'] for r in queue if r['path'] in owners}
expected_pending = {p for p, r in owners.items() if r['status'] not in ('REVIEWED', 'DEPRECATED')}
assert queued_paths == expected_pending
checkpoint['previous_base'] = checkpoint['base']
checkpoint.update(
    base=head, branch=subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip(),
    recorded_at=datetime.now(timezone.utc).isoformat(), prior_checkpoint=str(prior),
    prior_checkpoint_sha256=sha(prior), review_bundle_state='working_tree_new_immutable_bundles',
    corpus_state='git_commit', publication=dict(phase='Two new bacilysin pairs saved locally; no GitHub mutation or scientific record edit in this review continuation.'),
    prior_publication=dict(phase='PR904 merged; local and remote aborycin branches deleted; main verified clean before this review branch',
                          pr='https://github.com/CultureBotAI/NaturalProductMech/pull/904', merge_commit=head,
                          closed_issues=[905], open_scientific_issues=[906, 907]),
    scientific_review_bundles=len(checkpoint['all_review_observations']),
    partial_reviews=len(checkpoint['partial_followups']), unassessed_records=len(checkpoint['pending_in_priority_order']),
    completed_scientific_reviews=0,
    count_note='Eighteen unique partially reviewed owners; twenty-five immutable observations; zero completed scientific reviews. Full denominator3115 remains unchanged.',
    findings=dict(collections.Counter(f['severity'] for f in checkpoint['latest_finding_heads'] if f['status'] in ('open', 'deferred'))),
    previous_turn_classification=resume['previous_turn_classification'],
    this_turn_classification='progress: two new source-linked bacilysin observations; confirmed wrong-connectivity blocker and nonexact-xref major; new1993 revision lead retained; full prior population/reviews verified unchanged',
    frontier_note='Next pending owners are the three compound-3 entries in their pinned priority order. All18 partial owners remain unfinished; preserve193 source-access limits and all finding lineage.',
    required_work_remaining='Finish all18 partial owners and scientifically review all3097 unassessed owners plus attached components. No denominator reduction or deterministic-only completion.',
    live_sessions=0, goal_status='active',
    access_stop_note='Preserve162 inherited plus31 subsequent source limitations,193 total. New timeout/500 failures are not misreported as publisher denials; no alternate retrieval around reCAPTCHA/authorization barriers.',
    durable_prior_mapping='reviews/evidence/20261013-aborycin/manifest.json',
    durable_prior_checkpoint='reviews/evidence/20261013-aborycin/artifacts/review-campaign-checkpoint.json.gz',
    working_chemistry_note='RDKit2026.03.5 with existing repository NumPy via PYTHONPATH; exact connectivity, functional groups and graph-mapped stereochemistry only. Historical/current NPAtlas representations are not primary experimental assignments.',
    verification=dict(ignored_inclusive=True, unchanged_owners=len(owners), unchanged_components=len(components),
                      prior_reviews_unchanged=23, resumption=str(WORK / 'resumption.json'),
                      qc=str(WORK / 'qc.receipt.json'), label_gate=str(WORK / 'labels.receipt.json'),
                      review_check=str(WORK / 'review-check.receipt.json'), contract_tests=str(WORK / 'review-contract-tests.receipt.json'),
                      native_queue=dict(path=str(WORK / 'queue-fresh.tsv'), sha256=sha(WORK / 'queue-fresh.tsv'),
                                        diagnostic_rows=len(queue), unique_pending_owners=len(queued_paths),
                                        non_owner_diagnostic_paths=sorted(non_owner_paths),
                                        non_owner_diagnostic_rows=sum(r['path'] not in owners for r in queue)))
)
for name in ('resume_capture.py', 'prepare_reviews.py', 'reassignment_chemistry.py', 'finalize_reviews.py', 'checkpoint.py'):
    if name not in checkpoint['do_not_replay']:
        checkpoint['do_not_replay'].append(name)
assert checkpoint['partial_reviews'] == 18 and checkpoint['unassessed_records'] == 3097
assert checkpoint['scientific_review_bundles'] == 25
assert checkpoint['findings'] == {'blocker': 6, 'major': 7}
assert len(checkpoint['new_access_stops']) == 31
assert len(owners) == 3115 and len(components) == 243
assert set(checkpoint['partial_followups']) | set(checkpoint['pending_in_priority_order']) == owners.keys()
assert not set(checkpoint['partial_followups']) & set(checkpoint['pending_in_priority_order'])
assert {str(p.relative_to(ROOT)) for p in (ROOT / 'reviews/structured').rglob('review.yaml')} == {r['yaml'] for r in checkpoint['all_review_observations']}
output = WORK / 'review-campaign-checkpoint.json'
with output.open('x') as handle:
    json.dump(checkpoint, handle, indent=2)
print(json.dumps(dict(checkpoint=str(output), sha256=sha(output), population=3115, components=243,
                     partial_owners=18, complete_owners=0, unassessed=3097, observations=25,
                     findings=checkpoint['findings'], next=checkpoint['pending_in_priority_order'][:3],
                     additions=[{k:r[k] for k in ('review_id', 'yaml', 'markdown', 'verdict', 'completion')} for r in additions]), indent=2))
