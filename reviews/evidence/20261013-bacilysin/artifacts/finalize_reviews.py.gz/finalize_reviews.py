import copy
import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml

WORK = Path(__file__).parent


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class NoAliases(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


access = json.loads((WORK / 'access-limitations.json').read_text())
access['recorded_at'] = now()
access['new_access_stops'].append(dict(
    aliases=['DOI:10.1071/ch9931443'],
    url='https://connectsci.au/ch/article/46/9/1443/11502/Concise-Stereocontrolled-Synthesis-of-the-C4',
    reason='Two web opens of the same publisher page timed out (TimeoutError then400 Timeout fetching). No publisher denial/HTTP403 is inferred. No PDF, mirror or alternate-host retrieval attempted.',
    no_alternate_retrieval=True,
    scope='Crossref metadata identifies a C4-configuration-revision paper but its abstract is empty. Neither revision direction nor primary figures/experimental assignments were inspected.'
))
access['note'] += ' Newly discovered1993 DOI and title/author aliases were absent from the complete182 inherited plus10 current-limit entries in an ignored-inclusive search before its first request.'
with (WORK / 'access-limitations-final.json').open('x') as handle:
    json.dump(access, handle, indent=2)
metadata_path = WORK / 'reassignment1993-crossref.json'
metadata = json.loads(metadata_path.read_text())['message']
receipt = json.loads((WORK / 'reassignment1993-crossref.json.receipt.json').read_text())
assert receipt['sha256'] == sha(metadata_path)
assert metadata['DOI'].lower() == '10.1071/ch9931443'
calculation = json.loads((WORK / 'reassignment-chemistry.receipt.json').read_text())
assert calculation['exit_code'] == 0 and sha(Path(calculation['log'])) == calculation['log_sha256']
index = []
for original in json.loads((WORK / 'draft-index.json').read_text()):
    doc = yaml.safe_load(Path(original['path']).read_text())
    tid = doc['targets'][0]['target_id']
    slug = Path(doc['targets'][0]['path']).stem
    for item in doc['evidence']:
        if item['evidence_id'] == 'npatlas':
            item['locator'] += '; mol_structures versions1/2, reassignments and embedded ClassyFire structure'
            item['summary'] += ' The payload marks version1/1970 and embedded ClassyFire as the owner PC PU key, while current version2 cites DOI10.1071/ch9931443 and has NWQN. Historical agreement does not make the unversioned current xref exact; it must be qualified by version/representation.'
            item['summary'] = item['summary'].replace('PC PU key', 'PCPUDTNWSA-N key')
        if item['evidence_id'] == 'access':
            item.update(reference=str(WORK / 'access-limitations-final.json'), snapshot_sha256=sha(WORK / 'access-limitations-final.json'), accessed_at=now())
            item['locator'] = 'Eleven source-specific limits and aliases plus182 inherited restrictions; publisher timeouts distinguished from access barriers'
    doc['evidence'].extend([
        dict(evidence_id='reassignment1993', kind='database', reference='DOI:10.1071/ch9931443',
             locator='Crossref title, authors, year and publisher URL; message.abstract is an empty jats:p element',
             accessed_at=receipt['finished_at'], support='context_only', snapshot_sha256=sha(metadata_path),
             summary='Crossley and Stamford1993, Australian Journal of Chemistry46:1443-1446, is titled as a stereocontrolled synthesis of C4 epimers and revision of anticapsin/bacilysin configurations. NPAtlas points its current structure to this paper. Only bibliographic metadata was obtained; the title does not prove which configuration is correct or validate the NPAtlas graph.'),
        dict(evidence_id='reassignment-chemistry', kind='validation', reference=str(WORK / 'reassignment-chemistry.json'),
             locator='RDKit comparison of NPAtlas mol_structures version1/version2 and embedded ClassyFire SMILES',
             accessed_at=calculation['finished_at'], support='supports', snapshot_sha256=sha(WORK / 'reassignment-chemistry.json'),
             summary='The NPAtlas historical version1 and embedded classifier both recompute to XFOU-PCPU, exactly the owner key. Current version2 recomputes to XFOU-NWQN. Their mapped ring centers are identical in this payload; version2 adds the two previously unspecified centers. This describes database representations, not what the1993 primary figure experimentally revised.')
    ])
    doc['checks'].append(dict(check_id='reassignment-chemistry', name='Historical versus current NPAtlas structure comparison',
        status='passed', required=True, command=shlex.join(calculation['command']), exit_code=0, expected_exit_code=0,
        target_ids=[tid], evidence_ids=['reassignment-chemistry'],
        summary='Historical/current NPAtlas graphs and embedded classification structure mapped explicitly. Current identity was not inferred from an old classifier payload.',
        scope_note='Actual run: ' + calculation['started_at'] + ' to ' + calculation['finished_at'] + '; log SHA256 ' + calculation['log_sha256']))
    for check in doc['checks']:
        if check['check_id'] == 'fulltext':
            check['evidence_ids'].append('reassignment1993')
            check['summary'] += ' The newly identified1993 C4-reassignment paper is also unavailable after two same-page timeouts.'
    for assessment in doc['assessments']:
        if assessment['assessment_id'] in ('identity', 'xref'):
            assessment['evidence_ids'].extend(['reassignment1993', 'reassignment-chemistry'])
            assessment['summary'] += ' NPAtlas explicitly retains a historical exact-owner structure but identifies a different current form with a1993 reassignment citation. Primary revision details must be checked before selecting an authority or altering stereochemistry.'
    if slug == 'bacilysin-2':
        doc['findings'][0]['description'] += ' NPAtlas historical version1 and its embedded ClassyFire payload do match the owner, but the unversioned xref points to a current version2 structure with a different key; retain this historical context in any qualification.'
        doc['findings'][0]['evidence_ids'].append('reassignment-chemistry')
    doc['actions'][0]['acceptance_checks'].insert(0,
        'Inspect the1993 Crossley/Stamford C4-reassignment paper and reconcile its actual figures/assignments with NPAtlas historical/current payloads and ChEBI; infer no correction direction from title alone.')
    doc['limitations'] = [s.replace('the ten listed sources', 'the eleven listed sources').replace('ten new limits', 'eleven new limits') for s in doc['limitations']]
    doc['limitations'].append('The1993 reassignment metadata has no usable abstract. Two same-publisher-page timeouts left full text unavailable; no alternative route was used. This is a retrieval limitation, not an asserted publisher denial.')
    doc['notes'].append('Initial validated drafts were not saved because subsequent complete NPAtlas inspection revealed a1993 reassignment lead. These final observations include that lead and preserve earlier draft/validation evidence without rewriting a saved bundle.')
    doc['finished_at'] = now()
    doc['review_id'] = datetime.fromisoformat(doc['finished_at'].replace('Z', '+00:00')).strftime('%Y%m%dT%H%M%SZ') + '-' + slug
    output = WORK / (slug + '-review-final.yaml')
    with output.open('x') as handle:
        yaml.dump(doc, handle, Dumper=NoAliases, sort_keys=False, allow_unicode=False, width=90)
    index.append(dict(original, path=str(output), review_id=doc['review_id']))
with (WORK / 'final-index.json').open('x') as handle:
    json.dump(index, handle, indent=2)
print(json.dumps(index, indent=2))
