import csv
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

import yaml

from naturalproductmech.graph_components import read_natural_product

ROOT = Path.cwd()
WORK = Path(__file__).parent


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


started = now()
capture = json.loads((WORK / 'capture.json').read_text())
prior_blob = Path(capture['prior_checkpoint']).read_bytes()
assert digest(prior_blob) == capture['prior_checkpoint_sha256']
assert gzip.decompress((ROOT / 'reviews/evidence/20261013-aborycin/artifacts/review-campaign-checkpoint.json.gz').read_bytes()) == prior_blob
prior = json.loads(prior_blob)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
owners = {r['path']: r for r in prior['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
for folder, expected in [('data/natural_products', owners), ('data/causal_graphs', components)]:
    actual = {str(p.relative_to(ROOT)) for p in (ROOT / folder).rglob('*.yaml')}
    assert actual == expected.keys(), folder
    for path, item in expected.items():
        assert digest((ROOT / path).read_bytes()) == item['sha256'], path
for observation in prior['all_review_observations']:
    for key in ('yaml', 'markdown'):
        assert digest((ROOT / observation[key]).read_bytes()) == observation[key + '_sha256']
inputs = {}
for slug in ('bacilysin-2', 'bacilysin'):
    inspection = json.loads((WORK / (slug + '-inspect.json')).read_text())
    for item in inspection['source']['inputs']:
        path, expected = item['path'], item['sha256']
        assert digest((ROOT / path).read_bytes()) == expected
        for revision in (inspection['source']['git_revision'], head):
            assert digest(subprocess.check_output(['git', 'show', revision + ':' + path])) == expected
        inputs[path] = expected
    owner_path = ROOT / inspection['targets'][0]['path']
    resolved = read_natural_product(owner_path)
    assert resolved == json.loads((WORK / (slug + '-resolved.json')).read_text())
    assert not resolved.get('causal_graphs') and not resolved.get('causal_graph_refs')
receipts = []
for path in sorted(WORK.glob('*.receipt.json')):
    receipt = json.loads(path.read_text())
    if 'sha256' in receipt:
        assert digest(path.with_name(path.name.removesuffix('.receipt.json')).read_bytes()) == receipt['sha256']
    elif 'log_sha256' in receipt:
        assert digest(Path(receipt['log']).read_bytes()) == receipt['log_sha256']
    receipts.append(str(path))

sequence_rows = []
for name in ('GQ889493.1.xml', 'CP000560.1-region.xml'):
    for seq in ET.parse(WORK / name).getroot().findall('GBSeq'):
        features = []
        for feature in seq.findall('./GBSeq_feature-table/GBFeature'):
            quals = {}
            for q in feature.findall('./GBFeature_quals/GBQualifier'):
                quals.setdefault(q.findtext('GBQualifier_name'), []).append(q.findtext('GBQualifier_value'))
            if feature.findtext('GBFeature_key') in ('source', 'CDS'):
                features.append(dict(type=feature.findtext('GBFeature_key'),
                                     location=feature.findtext('GBFeature_location'), qualifiers=quals))
        sequence_rows.append(dict(snapshot=name, sha256=digest((WORK / name).read_bytes()),
                                  accession=seq.findtext('GBSeq_accession-version'),
                                  definition=seq.findtext('GBSeq_definition'),
                                  length=int(seq.findtext('GBSeq_length')), features=features))
taxa = [dict(taxon_id=t.findtext('TaxId'), name=t.findtext('ScientificName'),
             rank=t.findtext('Rank'), parent=t.findtext('ParentTaxId'))
        for t in ET.parse(WORK / 'taxonomy.xml').getroot().findall('Taxon')]
with (ROOT / 'data/raw/antibioticmech_inchikeys.tsv').open() as handle:
    sibling_candidates = [r for r in csv.DictReader(handle, delimiter='\t')
                          if 'bacilysin' in json.dumps(r).lower() or 'XFOUAXMJRHNTOP' in json.dumps(r)]
audit = dict(recorded_at=now(), sequences=sequence_rows, taxa=taxa,
             sibling_candidates=sibling_candidates,
             limitations=['CP000560.1 response is only the requested 3593877..3601174 window, with feature coordinates rebased to 1..7298.',
                          'GQ889493.1 is a 4342-bp partial gene-cluster sequence; partial ends are not complete-genome evidence.',
                          'Sequence annotations do not prove biosynthesis or biochemical function.'])
with (WORK / 'sequence-taxonomy-audit.json').open('x') as handle:
    json.dump(audit, handle, indent=2)
report = dict(started_at=started, finished_at=now(), head=head,
              original_capture_base=capture['base'], input_hashes=inputs,
              owners_verified=len(owners), components_verified=len(components),
              prior_review_pairs_verified=len(prior['all_review_observations']),
              receipts_verified=len(receipts), ignored_files_included=True,
              previous_turn_classification='progress: PR904 published23 immutable observations and durable evidence, fixed publication provenance; no new scientific completion',
              scientific_completion_count=0, archived_prior_checkpoint_sha256=digest(prior_blob))
with (WORK / 'resumption.json').open('x') as handle:
    json.dump(report, handle, indent=2)
print(json.dumps({k:v for k,v in report.items() if k != 'input_hashes'}, indent=2))
