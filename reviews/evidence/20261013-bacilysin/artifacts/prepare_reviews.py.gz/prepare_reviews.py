import copy
import hashlib
import json
import re
import shlex
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path(__file__).parent
REPO = 'CultureBotAI/NaturalProductMech'


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def read(name):
    return json.loads((WORK / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class NoAliases(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


capture = read('capture.json')
resume = read('resumption.json')
assert resume['owners_verified'] == 3115 and resume['components_verified'] == 243
assert resume['prior_review_pairs_verified'] == 23
qc = read('qc.receipt.json')
assert qc['exit_code'] == 0 and sha(Path(qc['log'])) == qc['log_sha256']
stats = re.findall(r'\d+ passed, \d+ skipped[^\n]*', Path(qc['log']).read_text())[-1]

# Preserve the interrupted review's actual limits; no alternate full-text route is attempted.
stops = [
    ('4991476', '10.1042/bj1180563', 'PMC1179252', 'https://pmc.ncbi.nlm.nih.gov/articles/PMC1179252/', 'PMC web page returned reCAPTCHA; no alternate full-text retrieval.'),
    ('3121591', '10.1128/jb.170.1.482-484.1988', 'PMC210674', 'https://pmc.ncbi.nlm.nih.gov/articles/PMC210674/', 'PMC web page returned reCAPTCHA; no alternate full-text retrieval.'),
    ('3093430', '10.7164/antibiotics.39.888', None, 'https://doi.org/10.7164/antibiotics.39.888', 'DOI web open unavailable; abstract only. No full-paper absence conclusion.'),
    ('3123448', '10.7164/antibiotics.40.1677', None, 'https://doi.org/10.7164/antibiotics.40.1677', 'DOI web open unavailable; abstract only. No full-paper absence conclusion.'),
    ('26268540', '10.1038/srep12975', 'PMC4534799', 'https://www.nature.com/articles/srep12975', 'Nature request encountered IDP cookie-authorization redirect and nonretryable web-tool error; no alternate full-text retrieval.'),
    ('25261512', '10.1128/aem.02605-14', 'PMC4249228', 'https://europepmc.org/articles/PMC4249228', 'EuropePMC web full-text page unavailable; only abstract inspected.'),
    ('20070370', '10.1111/j.1574-6968.2009.01882.x', None, 'https://doi.org/10.1111/j.1574-6968.2009.01882.x', 'DOI web open unavailable; subscription full text not inspected.'),
    ('19061923', '10.1016/j.jbiotec.2008.10.015', None, 'https://doi.org/10.1016/j.jbiotec.2008.10.015', 'DOI web open unavailable; subscription full text not inspected.'),
    ('1841868', '10.1007/bf02884030', None, 'https://doi.org/10.1007/bf02884030', 'DOI web open unavailable; subscription full text not inspected.'),
    ('14711701', '10.1128/aem.70.1.631-634.2004', 'PMC321241', 'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC321241/fullTextXML', 'Same public fullTextXML endpoint returned HTTP500 twice; the second was a same-endpoint retry after one minute, not a bypass. Error JSON is not article XML.'),
]
access = dict(recorded_at=now(), inherited_count=182, new_access_stops=[
    dict(aliases=['PMID:' + pmid, 'DOI:' + doi] + ([pmc] if pmc else []), url=url,
         reason=reason, no_alternate_retrieval=True,
         scope='Full-text and detailed experimental verification remain unavailable; metadata/abstract inspection is retained.')
    for pmid, doi, pmc, url, reason in stops
], note='These limits occurred during the interrupted bacilysin review before PR904 publication. This continuation re-inspected cached source bytes and Wikidata labels, not blocked full text. Transport failures are not relabelled HTTP403 or a publisher denial.')
for name in ('cs93-original-fulltext.xml', 'cs93-original-fulltext-retry.xml'):
    receipt = read(name + '.receipt.json')
    assert receipt['status'] == 500 and sha(WORK / name) == receipt['sha256']
with (WORK / 'access-limitations.json').open('x') as handle:
    json.dump(access, handle, indent=2)


def owners(*paths):
    roles = {
        'data/raw/mibig_compounds.tsv': 'Pinned original compound, producer and locus assertions',
        'data/raw/lotus_occurrences.tsv': 'Pinned original exact-key organism/citation triples',
        'scripts/extract_mibig.py': 'Source extraction and provenance',
        'scripts/extract_lotus.py': 'Occurrence extraction and provenance',
        'scripts/seed_from_sources.py': 'Maintained source harmonization and generated record emission',
        'curation/mibig_structure_corrections.tsv': 'Narrow REPLACE_WITH_CHEBI path; ambiguous keys and occupied targets rejected',
        'curation/mibig_xref_exclusions.tsv': 'Implemented source-row-pinned literal PubChem exclusion only',
        'src/naturalproductmech/curate/xref_exclusions.py': 'PubChem-only consumer; NPAtlas handling requires tested extension',
    }
    return [dict(repository=REPO, path=p, role=roles[p]) for p in paths]


index = []
for slug in ('bacilysin-2', 'bacilysin'):
    is_dipeptide = slug == 'bacilysin-2'
    inspection = read(slug + '-inspect.json')
    source = copy.deepcopy(inspection['source'])
    for item in source['inputs']:
        expected = item['sha256']
        assert sha(ROOT / item['path']) == expected
        assert hashlib.sha256(subprocess.check_output(['git', 'show', source['git_revision'] + ':' + item['path']])).hexdigest() == expected
    source['state'] = 'git_commit'
    target = inspection['targets'][0]
    tid = target['target_id']
    evidence = []

    def ev(eid, kind, reference, locator, summary, snapshot=None, support='supports', search_scope=None):
        item = dict(evidence_id=eid, kind=kind, reference=reference, locator=locator,
                    accessed_at=now(), support=support, summary=summary)
        if snapshot:
            path = WORK / snapshot
            item['snapshot_sha256'] = sha(path)
            receipt = path.with_name(path.name + '.receipt.json')
            if receipt.exists():
                item['accessed_at'] = json.loads(receipt.read_text())['finished_at']
        if search_scope:
            item['search_scope'] = search_scope
        evidence.append(item)
        return item

    owner = ev('owner', 'record_content', target['path'], 'Complete raw YAML and all history entries; independently resolved via read_natural_product',
               'One exact minted, SEEDED owner. Neither owner has inline graphs or component references; optional mechanism, assay, clinical and target fields are absent. Histories are seeding events, not scientific sign-off.')
    owner['snapshot_sha256'] = sha(ROOT / target['path'])
    ev('resolved-owner', 'record_content', str(WORK / (slug + '-resolved.json')), 'Complete native resolved JSON view; raw-YAML hash is separately attached to owner evidence',
       'The resolved object equals the complete owner content and has no component claims to hide from this inspection.', snapshot=slug + '-resolved.json')
    ev('inventories', 'database', str(WORK / 'source-rows.json'), 'Selected complete parsed rows with TSV line numbers; complete source-file hashes are in source.inputs',
       'MIBiG rows967/1406 preserve two distinct compound keys. LOTUS rows3039..3044 and9544..9545 attach six/two occurrences respectively. NPClassifier2026-09-07 calls both Small peptides/Dipeptides; a computed class does not establish peptide connectivity. Neither exact owner key occurs in pinned3-star ChEBI or AntibioticMech joins.', snapshot='source-rows.json',
       search_scope='Complete structured scans of pinned source TSVs, including ignored files; exact owner keys plus bacilysin name/near-key candidates were inspected. Repository rg --no-ignore --hidden excluded only .git object data and .venv runtime packages. No universal live-database absence claim.')
    ev('chemistry', 'validation', str(WORK / 'chemistry.json'), 'Pinned RDKit2026.03.5 roundtrips, functional-group SMARTS and graph-isomorphism-mapped CIP centers',
       'Every tested SMILES roundtrips its own InChI/key and neutral C12H18N2O5, exact mass270.121571676 Da. XFOU-PCPU has one amide, one acid, one primary amine, one epoxide,3 specified/2 unspecified centers. JJOS has zero amides/acids, one anhydride, two primary amines, one epoxide,4 specified/1 unspecified center. NPAtlas adds two stereo assignments to XFOU-PCPU. ChEBI disagrees at the mapped ring center; NPAtlas and ChEBI also disagree at alanine. These computations locate differences, not the correct experimental stereoisomer.', snapshot='chemistry.json')
    mibig_file = 'BGC0000888.5.json' if is_dipeptide else 'BGC0001184.4.json'
    ev('mibig', 'database', read(mibig_file + '.receipt.json')['url'], 'Exact version/status, compound chemistry/xrefs, taxonomy, locus bounds/methods and legacy references',
       'BGC0000888v5 is active and exactly matches stored XFOU-PCPU chemistry, both xrefs, CS93 taxon679622 and GQ889493.1. Its zero/zero source bounds are honestly omitted; locus methods are empty and PMID20070370 is entry-level provenance.' if is_dipeptide else
       'BGC0001184v4 is active and exactly matches stored JJOS chemistry, PubChem160175, FZB42 taxon326423 and CP000560.1:3593877..3601174. It asserts Knock-out studies and Gene expression correlated with compound production. PMID19061923 is the selected entry citation;25261512 and26268540 are additional legacy references. Source agreement does not validate the wrong graph.', snapshot=mibig_file)
    ev('pubchem', 'database', read('pubchem160175.json.receipt.json')['url'], 'CID160175 SMILES, InChI, InChIKey and formula',
       'PubChem160175 exactly matches JJOSOKMLZZVGKD-INVWQFOESA-N, not the XFOU-PCPU owner. Thus it is a nonexact xref on bacilysin-2 but an exact-to-encoded-graph xref on bacilysin; deleting the latter xref alone would not repair its wrong biological identity.', snapshot='pubchem160175.json')
    ev('npatlas', 'database', read('npatlas15870.json.receipt.json')['url'], 'NPA015870 structure and original isolation metadata',
       'NPA015870 encodes XFOUAXMJRHNTOP-NWQNCHOTSA-N, with all five centers specified. Connectivity matches XFOU-PCPU but it adds alanine R and anticapsin alpha S assignments at mapped atoms1/6. It cites DOI10.1042/bj1180563. This is not exact equivalence to the partially specified owner and is not authority to fill its unknown centers. The source organism string has a spelling defect and a genus-level taxonomy field.', snapshot='npatlas15870.json')
    ev('chebi', 'authority', read('chebi72687.json.receipt.json')['url'], 'Released3-star CHEBI72687 definition and default structure; pinned CHEBI84311 row as protonation context',
       'CHEBI72687 describes L-alanyl and anticapsin joined by a peptide bond and encodes XFOUAXMJRHNTOP-PFQXTLEHSA-N. Its mapped ring center is S versus owner/NPA R; its alanine is S versus NPA R. Pinned CHEBI84311 is a zwitterion sharing the same StandardInChIKey. Neither is an exact owner match, and the current replacement consumer rejects this ambiguous target key. The authority disagreement requires primary stereo adjudication, not an automatic ChEBI choice.', snapshot='chebi72687.json')
    paper_summaries = {
        '20070370': 'The2010 CS93 follow-up acknowledges earlier bacilysin production, sequences bacABCDE, and reports nondetection of bacilysin/chlorotetaine in its later culture-supernatant analysis. This is condition-specific, not proof that CS93 never produces bacilysin. The cited LOTUS genus occurrence needs provenance/condition qualification.',
        '19061923': 'The FZB42 study reports residual antagonism in difficidin or sfp mutants and loss in a Delta-sfp/Delta-bac double mutant. It explicitly calls bacilysin a dipeptide. This supports a native knockout context for biological bacilysin, not the stored anhydride. The antagonism readout alone does not validate exact chemical form or the separate expression/production-correlation method.',
        '3121591': 'B.subtilis168 aro mutants were deficient in bacilysin accumulation but retained synthetase activity; tyrA/pheA mutants produced normal levels. This supports a defined precursor-pathway context, not an experiment on the JJOS anhydride.',
        '1841868': 'The study reports bacilysin-production feedback and pH/temperature effects; maximal production near pH6.8 and25C in the abstract. Detailed strain/culture/identification methods are uninspected. No assay observation is added.',
        '3123448': 'The abstract concerns difficidin/oxydifficidin production in B.subtilis ATCC39320/39374. It does not establish bacilysin detection. Full-paper inspection is needed before accepting or rejecting the LOTUS citation; abstract silence is not whole-paper absence.',
        '3093430': 'The abstract concerns fengycin from B.subtilis F-29-3, with its chemistry/activity. It does not establish bacilysin detection. Full-paper inspection is needed before accepting or rejecting the LOTUS citation; no automatic occurrence deletion follows.',
        '4991476': 'The1970 structure abstract reports mass270, N-terminal alanine, an epoxide-ketone and a C-terminal amino acid. Its stereo assignment used an explicit reversed-Octant-rule assumption. Full chemical figures/spectra were unavailable; abstract-level identity supports a peptide, not JJOS anhydride, but does not resolve the current database stereochemical conflict.',
        '25261512': 'FZB42 bacB disruption abolished anticyanobacterial effect and complementation restored it; GlcNAc antagonized it. Reported expression changes concern target-organism genes and are not automatically correlation of producer bac expression with compound production. Full methods and exact product identification remain unverified.',
        '26268540': 'The abstract reports FZB42 bacilysin/difficidin activity against rice-pathogen Xanthomonas, microscopy and target-organism gene-expression changes. Those expression changes do not by themselves support the stored producer-expression/production-correlation method.',
        '14711701': 'The earlier CS93 study reports HPLC and mass-spectrometric identification of bacilysin, chlorotetaine and iturin. This provides positive production/detection context despite later nondetection. FullTextXML retrieval failed twice with HTTP500, so analytical figures and exact form remain unverified.',
    }
    for pmid, summary in paper_summaries.items():
        filename = ('bgc-additional-metadata.json' if pmid in ('25261512', '26268540') else
                    'cs93-original-discovery.json' if pmid == '14711701' else 'literature-metadata.json')
        record = next(r for r in read(filename)['resultList']['result'] if r['id'] == pmid)
        ev('pmid' + pmid, 'primary_source', 'PMID:' + pmid,
           'EuropePMC core metadata result id=' + pmid + '; DOI:' + record['doi'] + '; complete returned abstract, not full text',
           summary, snapshot=filename, support='partial')
    ev('literature-search', 'search', read('cs93-original-discovery.json.receipt.json')['url'], 'EuropePMC refined query CS93 AND bacilysin AND FIRST_PDATE:[1900-01-01 TO 2010-12-31]',
       'The refined query returned two hits, the2004 identification study and2010 follow-up; both abstracts were inspected. The initial broad CS93 query returned50 hits but only25 rows and was not exhaustive. This search resolves the earlier-study lead, not absence of all other literature.', snapshot='cs93-original-discovery.json', support='context_only',
       search_scope='One provider and explicit date/name query; refined hitCount2/pageSize100. Initial broad query was truncated to25 of50 and is not used for absence.')
    sequence_file = 'GQ889493.1.xml' if is_dipeptide else 'CP000560.1-region.xml'
    ev('sequence', 'authority', read(sequence_file + '.receipt.json')['url'], 'NCBI gbwithparts XML exact accession, source qualifiers and CDS features',
       'GQ889493.1 contains4342bp of partial CS93 bacABCDE, including partial bacA/bacE ends. Taxon679622 and strainCS93 agree with the owner. This is not a complete genome, and gene presence is not proof of product formation.' if is_dipeptide else
       'The requested CP000560.1 window3593877..3601174 is7298bp and contains complement-strand ywfG,bacE,bacD,bacC,bacB,bacA,ywfA annotations. Its feature coordinates are rebased to1..7298, not genomic coordinates. FZB42/taxon326423 source qualifiers agree; the older definition name is not a strain conflict. Sequence context does not repair the wrong chemical form.', snapshot=sequence_file)
    ev('taxonomy', 'authority', read('taxonomy.xml.receipt.json')['url'], 'NCBI TaxIds1386,1423,679622,492670,326423; labels/ranks/parent relationships',
       'Labels agree with pinned records: Bacillus genus1386, B.subtilis species1423, Bacillus sp.CS93 species-rank679622, B.velezensis species492670 and FZB42 strain-rank326423. FZB42 is not the entire species. OTHER_BACTERIAL is consistent with these lineages.', snapshot='taxonomy.xml')
    ev('sequence-taxonomy-audit', 'validation', str(WORK / 'sequence-taxonomy-audit.json'), 'Structured local parsing of both sequence snapshots, taxonomy and bounded pinned sibling candidate scan',
       'Retains sequence-window limitations and exact source features. The sibling bacilysin row is CHEBI72687/XFOU-PFQ at commit74f6cc8362498900f2fe2c13d0b6fdb66dd30976, not either owner key; absence of an automatic related_records join is correct.', snapshot='sequence-taxonomy-audit.json')
    for qid, label in [('Q212032', 'Bacillus'), ('Q131238', 'Bacillus subtilis'), ('Q62873335', 'Bacillus velezensis')]:
        ev('wikidata-' + qid, 'database', 'https://www.wikidata.org/wiki/' + qid,
           'Web page title and taxon label inspected during this resumed review',
           qid + ' resolves to ' + label + '. This verifies the LOTUS organism note, not compound detection or production.')
    ev('bioassay-placeholder', 'database', 'data/raw/pubchem_bioassay.tsv', 'TSV9868, XFOU-PCPU/CID160175 row; complete selected row retained in source-rows.json',
       'The row is a no-assay-data placeholder with no AID, outcome, value or target. Neither owner asserts an assay from it. The CID mismatch is not hidden assay evidence and no activity is inferred.')
    ev('governance', 'record_content', 'docs/CURATION.md', 'Structure correction, source-row-pinned PubChem exclusion, method-withdrawal and generated-file boundaries',
       'The replacement consumer rejects ambiguous ChEBI keys and occupied targets. Xref exclusion supports literal PubChem only, not NPAtlas. Reserved decisions.tsv is not consumed. A primary method gap alone does not authorize WITHDRAW, and no generated record or source assertion was edited.')
    ev('resumption', 'validation', str(WORK / 'resumption.json'), 'Gitignore-independent full population verification; source hashes checked against original captured commit and current745da66f',
       'All3115 owners,243 components,23 prior pairs and22 receipt hashes verified. Every captured input equals both9191a148 and the resumed checkout745da66f. The intervening PR904 was publication-only administrative progress; original pre-judgement capture is retained.', snapshot='resumption.json')
    ev('access', 'validation', str(WORK / 'access-limitations.json'), 'Ten source-specific limits and aliases, plus182 inherited restrictions; exact HTTP500 receipts retained',
       'Full primary experimental/stereo/citation verification remains unavailable. reCAPTCHA/authorization barriers, web retrieval failures and repeated same-endpoint500 failures are distinguished. No blocked full-text source was retried through another host or tool in this continuation.', snapshot='access-limitations.json', support='context_only')

    checks = []
    summaries = {
        'strict': 'Both exact owners passed strict validation with zero errors; no graph refs exist.',
        'labels': 'Configured label gate passed:13434 canonical,646 synonyms,35 exceptions,499 nonblocking warning mismatches and4649 no-adapter skips. Minted compound identity was separately checked, not certified by this gate.',
        'chemistry': 'Pinned RDKit calculations succeeded and located connectivity/stereo differences; no experimental assignment inferred.',
        'ignored-inclusive-search': 'Name, identifiers, keys and selected citations searched with ignored/hidden files included; only .git and .venv excluded. Curation tables/consumers were independently read; no implemented bacilysin-specific correction row was found in that bounded scope.',
        'qc': 'Full native QC passed: ' + stats + '. Strict corpus schema, history/graph tests, provenance, lint, vendored sync, site, reproduction and path lock passed. Run began before PR904 publication; all reviewed inputs remain byte-identical. It did not collect the later archive-only tests, which do not alter the scientific inputs.',
        'review-queue': 'Full native diagnostic queue computed in the original review attempt; diagnostic rows are not scientific review completions.',
        'queue-fresh': 'Full pending-record queue regenerated after this batch assessment; all3115 owners remain included. The extra unresolved_taxa.tsv diagnostics are not owners.',
    }
    for name, summary in summaries.items():
        receipt = read(name + '.receipt.json')
        assert receipt['exit_code'] == 0 and sha(Path(receipt['log'])) == receipt['log_sha256']
        checks.append(dict(check_id=name, name=name, status='passed', required=name in ('strict', 'labels', 'chemistry', 'qc'),
                           command=shlex.join(receipt['command']), exit_code=0, expected_exit_code=0,
                           target_ids=[tid], summary=summary,
                           scope_note='Actual run: ' + receipt['started_at'] + ' to ' + receipt['finished_at'] + '; log SHA256 ' + receipt['log_sha256']))
    checks.extend([
        dict(check_id='fulltext', name='Primary experimental and exact chemical-form verification', status='unavailable', required=True,
             target_ids=[tid], evidence_ids=['access', 'pmid4991476', 'pmid20070370', 'pmid19061923', 'pmid14711701'],
             summary='Full methods, chemical figures/spectra, isolate stereochemistry and exact occurrence citations remain unverified. Abstracts were read without pretending full-text completion.'),
        dict(check_id='imodulondb', name='Structured expression-source applicability', status='not_applicable', required=False,
             target_ids=[tid], summary='Owners contain no named gene/protein/regulator/module claims. MIBiG and sequence/chemical authority APIs were consulted first. Genes in contextual source annotations do not create a transcriptomic assertion; no iModulon dataset-absence claim is made.'),
    ])
    assessments = []

    def assess(aid, area, topic, outcome, summary, eids, dimensions=None):
        row = dict(assessment_id=aid, area=area, topic=topic, outcome=outcome, summary=summary,
                   target_ids=[tid], evidence_ids=eids)
        if dimensions:
            row['dimensions'] = dimensions
        assessments.append(row)

    assess('identity', 'identity', 'Connectivity and supported stereochemical resolution', 'concern',
           'The owner has peptide connectivity, but the specified ring stereochemistry conflicts with ChEBI and the two unspecified centers must not be filled from NPAtlas. Biological exact-form identity remains unresolved; this is distinct from the confirmed nonexact xrefs.' if is_dipeptide else
           'The encoded anhydride has no peptide bond and therefore is not the reported bacilysin dipeptide. Matching MIBiG/PubChem identifiers, mass and formula do not repair identity. F1 blocks exact-structure origin and occurrence attribution.',
           ['owner', 'chemistry', 'chebi', 'npatlas', 'pmid4991476', 'pmid19061923'],
           [dict(name='exact-key', value='XFOUAXMJRHNTOP-PCPUDTNWSA-N' if is_dipeptide else 'JJOSOKMLZZVGKD-INVWQFOESA-N', definition='Current owner key, not a replacement proposal', evidence_ids=['owner', 'chemistry']),
            dict(name='stereo-resolution', value='3 specified/2 unspecified centers' if is_dipeptide else '4 specified/1 unspecified center', definition='Encoded RDKit chiral centers; not independent experimental assignments', evidence_ids=['chemistry'])])
    assess('xref', 'grounding', 'Exact equivalence and grounding candidates', 'concern' if is_dipeptide else 'supported',
           'Neither stored xref denotes this exact structure: PubChem differs in connectivity and NPAtlas specifies two additional centers. No exact pinned ChEBI or sibling link is available; do not conflate partial and fully assigned forms.' if is_dipeptide else
           'The PubChem xref exactly matches the stored graph. That is accurate database equivalence, not correct natural-product identity. ChEBI and the sibling bacilysin key differ; withholding a same-name join is appropriate.',
           ['owner', 'pubchem', 'npatlas', 'chebi', 'chemistry', 'sequence-taxonomy-audit'])
    assess('classification', 'provenance', 'Computed filing versus asserted chemistry and taxonomic facets', 'supported',
           'NPClassifier filing, Small peptides/Dipeptides, tool/version and non-glycoside output match pinned rows. Source BGC OTHER remains a separate assertion, as do OTHER_BACTERIAL taxon facets. A computed dipeptide prediction is not validation of an amide bond.',
           ['inventories', 'mibig', 'taxonomy', 'chemistry'])
    assess('producer', 'evidence', 'Strain, source tier and condition-specific experimental context', 'unknown' if is_dipeptide else 'concern',
           'CS93 SOURCE_ASSERTION correctly represents MIBiG provenance. The2004 abstract reports HPLC/MS identification, whereas the2010 follow-up reports condition-specific nondetection. Preserve both studies; neither a gene annotation nor nondetection alone settles production of this exact partially specified stereoisomer.' if is_dipeptide else
           'Native FZB42 knockout/complementation context supports biological bacilysin at abstract level, consistent with a characterized evidence tier. It does not demonstrate production of the JJOS anhydride. F1 blocks chemical scope despite correct taxon/strain provenance.',
           ['owner', 'mibig', 'taxonomy', 'sequence', 'pmid14711701', 'pmid20070370', 'pmid19061923', 'pmid25261512'],
           [dict(name='strain-context', value='CS93; NCBITaxon679622 (species rank)' if is_dipeptide else 'FZB42; NCBITaxon326423 (strain rank)', definition='Source strain context and live taxonomic rank; not broader species-wide experiments', evidence_ids=['taxonomy', 'sequence']),
            dict(name='stored-evidence-tier', value='SOURCE_ASSERTION; CLUSTER_UNSTATED' if is_dipeptide else 'BGC_CHARACTERIZED; CLUSTER_DEMONSTRATED', definition='Existing source-derived taxon and locus grades, not review upgrades', evidence_ids=['owner', 'mibig'])])
    assess('bgc', 'evidence', 'Versioned entry, genomic interval and exact locus methods', 'supported' if is_dipeptide else 'unknown',
           'Active version5 and partial GQ889493.1 sequence agree with CS93. Empty source bounds/methods remain honestly unstated. This establishes database/sequence context, not complete cluster boundaries or chemical experimental identity.' if is_dipeptide else
           'Active version4 and the7298bp requested FZB42 window agree with bac gene context. Knockout evidence is supported at abstract level, but the separate producer-expression/production-correlation method remains unverified. Target-organism expression changes in later papers cannot substitute for it. No method withdrawal follows from missing full text.',
           ['mibig', 'sequence', 'sequence-taxonomy-audit', 'pmid19061923', 'pmid25261512', 'pmid26268540'])
    assess('occurrences', 'evidence', 'Every LOTUS citation and taxonomic scope', 'unknown' if is_dipeptide else 'concern',
           'Both genus/species notes resolve. The2010 genus occurrence cites a study that recalls earlier bacilysin production but reports nondetection in its own later experiment; the2004 primary identification needs explicit linkage/conditions. The1970 structure study supports B.subtilis context but exact stereo remains unresolved.' if is_dipeptide else
           'All six DOI identities and organism notes resolve at metadata/label level. The1970,1988,1990 andFZB42 studies concern biological bacilysin, not JJOS. Fengycin and difficidin-paper abstracts do not establish bacilysin occurrence, but full-paper silence/false citation is not proven. F1 blocks exact-key attribution; every occurrence needs individual adjudication before any identity correction transfers claims.',
           ['inventories', 'pmid20070370', 'pmid14711701', 'pmid4991476', 'pmid3121591', 'pmid1841868', 'pmid3093430', 'pmid3123448', 'pmid19061923', 'taxonomy', 'wikidata-Q212032', 'wikidata-Q131238', 'wikidata-Q62873335'])
    assess('completeness', 'completeness', 'Optional assays, mechanisms, proteins, clinical assertions and history', 'unknown',
           'Complete resolved owners have no graphs/components, pathway steps, assays, targets, clinical assertions or related_records. These optional omissions are not false claims. The BioAssay placeholder is correctly not used as activity. Literature gives leads for future mechanism curation only after exact identity and full experimental support are established; no evidence/history/status change was made.',
           ['owner', 'resolved-owner', 'bioassay-placeholder', 'sequence-taxonomy-audit', 'pmid25261512', 'pmid3121591', 'governance'])
    assess('validation', 'schema', 'Native deterministic validation and exhaustive scope preservation', 'supported',
           'Native strict, label, full QC and queue checks passed with their real receipts. Captured sources match the original9191a148 tree and current745da66f; all3115 owners/243 components/23 prior pairs remain unchanged. Deterministic validation does not certify scientific correctness or close any prior finding.',
           ['owner', 'resumption', 'governance'])

    if is_dipeptide:
        fix_owners = owners('data/raw/mibig_compounds.tsv', 'scripts/extract_mibig.py', 'scripts/seed_from_sources.py', 'curation/mibig_xref_exclusions.tsv', 'src/naturalproductmech/curate/xref_exclusions.py')
        finding = dict(finding_id='F1', issue_key='bacilysin-BGC0000888-nonexact-pubchem-npatlas-xrefs', category='grounding', severity='major', status='open', certainty='confirmed',
                       title='Both imported xrefs exceed exact chemical equivalence',
                       description='PubChem160175 encodes the different JJOS anhydride connectivity. NPAtlasNPA015870 has XFOU connectivity but keyNWQN with two additional stereo assignments, not owner keyPCPU. Both are asserted as exact xrefs by the generated owner, contrary to the exact-equivalence contract. Neither formula agreement nor a shared compound name is sufficient.',
                       target_ids=[tid], field_paths=['xrefs[0]', 'xrefs[1]'], evidence_ids=['owner', 'mibig', 'pubchem', 'npatlas', 'chemistry'], owner_paths=fix_owners,
                       rule_id='review-checklist:Equivalence; CLAUDE.md:an xref means the same structure', native_severity='major',
                       normalization_reason='Wrong exact-equivalence grounding materially misidentifies the owner through external identifiers without establishing that its entire peptide connectivity is wrong.')
        action = dict(action_id='A1', finding_ids=['F1'], target_ids=[tid], owner_paths=fix_owners,
                      description='Withhold or qualify both nonexact source xrefs through maintained source-row-pinned behavior. The existing PubChem-only exclusion can handle CID160175; NPAtlas requires an explicitly tested consumer extension or upstream correction. Preserve raw assertions and the unresolved stereo conflict; do not fill centers, change identity or merge owners merely to match a database.',
                      generator='scripts/seed_from_sources.py', acceptance_checks=[
                          'Pin the complete BGC0000888:1 row and exact literal xrefs; prove drift/missing/duplicate/conflicting decisions fail.',
                          'Recompute source and candidate SMILES/InChI/keys and compare supported stereochemical resolution, not just connectivity or formula.',
                          'Retain original assertions and curator reasons separately; keep NPAtlas disagreement with ChEBI explicit until primary stereo adjudication.',
                          'Do not alter the BioAssay placeholder or transfer CID assays by name; no scientific status promotion.',
                          'Run canary, strict validation, provenance, reproduction, corpus/path lock, site and full QC; prove unrelated owners/components unchanged.'])
    else:
        fix_owners = owners('data/raw/mibig_compounds.tsv', 'data/raw/lotus_occurrences.tsv', 'scripts/extract_mibig.py', 'scripts/extract_lotus.py', 'scripts/seed_from_sources.py', 'curation/mibig_structure_corrections.tsv')
        finding = dict(finding_id='F1', issue_key='bacilysin-BGC0001184-anhydride-wrong-connectivity', category='identity', severity='blocker', status='open', certainty='confirmed',
                       title='Stored anhydride is not the bacilysin dipeptide',
                       description='JJOSOKMLZZVGKD-INVWQFOESA-N has an acid-anhydride linkage, zero amide bonds and two free primary amines. Biological bacilysin is the alanine/anticapsin dipeptide supported by the inspected primary abstracts and ChEBI definition. MIBiG and PubChem reproduce the same wrong graph; a formula/mass match or exact-to-current-graph xref does not validate it. Producer, origin, cluster-product and occurrence assertions cannot be carried onto this chemically different graph.',
                       target_ids=[tid], field_paths=['label', 'chemical_structure', 'biosynthesis_origin', 'producer_organisms', 'biosynthetic_gene_clusters', 'occurrences'],
                       evidence_ids=['owner', 'chemistry', 'mibig', 'pubchem', 'chebi', 'pmid4991476', 'pmid19061923'], owner_paths=fix_owners,
                       rule_id='review-checklist:Identity; Structure; docs/HARMONIZATION.md:The unit of the corpus is a structure', native_severity='blocker',
                       normalization_reason='Wrong bond connectivity changes the molecule denoted by the record and blocks exact-structure biological attribution.')
        action = dict(action_id='A1', finding_ids=['F1'], target_ids=[tid], owner_paths=fix_owners,
                      description='Adjudicate and repair or quarantine BGC0001184:1 through a tested source-pinned path, with exact stereochemical resolution and chemical-form scope. Do not select ChEBI blindly: the pinned bacilysin/zwitterion pair shares a key that the current replacement consumer rejects as ambiguous. Do not merge into the differently stereospecified sibling or transfer its claims by name. Removing PubChem alone is not an identity repair.',
                      generator='scripts/seed_from_sources.py', acceptance_checks=[
                          'Confirm primary peptide connectivity, supported isolate stereochemistry and intended protonation/form; recompute SMILES/InChI/key without inventing assignments.',
                          'Resolve ChEBI72687/84311 key ambiguity and the relationship to the occupied XFOU-PCPU sibling explicitly; audit identifier/PATHS migration where needed.',
                          'Adjudicate all six LOTUS occurrences individually, especially the fengycin/difficidin citations; preserve full-text gaps and transfer no old-key claims automatically.',
                          'Reassess compound-specific producer/cluster methods and xrefs; preserve original source rows, attribution, history and any unaffected curated content.',
                          'Run guarded canary, strict/source/corpus/reproduction/site/full QC; prove unrelated owners/components and prior reviews unchanged.'])

    finished = now()
    rid = datetime.fromisoformat(finished.replace('Z', '+00:00')).strftime('%Y%m%dT%H%M%SZ') + '-' + slug
    doc = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=REPO,
               title='Bacilysin: partial-stereo identity, nonexact xrefs and CS93 evidence' if is_dipeptide else 'Bacilysin: anhydride identity conflict and FZB42 evidence scope',
               started_at=capture['started_at'], finished_at=finished,
               reviewer=dict(identity='Codex', kind='agent', independence='self_review', independence_basis='Same assistant/thread as earlier corpus and publication work; not independent human sign-off.'),
               skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial', verdict='needs_curation', scientific_review=True,
               summary='One confirmed major finding: neither PubChem nor NPAtlas xref is exact. Peptide connectivity is present, but database stereochemistry conflicts and full experimental/citation checks remain unresolved. CS93 identification and later nondetection are preserved as condition-specific evidence.' if is_dipeptide else
               'One confirmed blocker: the stored anhydride is not the reported bacilysin dipeptide. Source/PubChem agreement does not repair identity. FZB42 experiments and all six occurrences require correct chemical scope; full stereo/method/citation adjudication remains partial.',
               source=source, targets=[target], scope=dict(description='One exact owner; same-name sibling and authority records are context only. The full campaign remains3115 owners and243 components.',
                   selection='Next exact pending owner from the exhaustive campaign checkpoint; all unfinished records remain in scope.', coverage='partial', population_size=1, reviewed_target_ids=[tid],
                   exclusions=[dict(target='Other3114 owners', reason='Not scientifically assessed by this single-record observation; preserved in the full campaign checkpoint.')]),
               checks=checks, evidence=evidence, assessments=assessments, findings=[finding], actions=[action],
               limitations=[
                   'This review assesses exact committed inputs captured before judgement at9191a148. All input bytes were rechecked against current745da66f after publication; no silent hash refresh or scientific mutation occurred.',
                   'Primary full text, chemical figures/spectra, isolate stereochemistry and detailed experimental methods remain unavailable for the ten listed sources. Metadata/abstracts are not claimed as full-paper reading.',
                   'Source stereo conflicts remain unresolved. ChEBI and NPAtlas are not interchangeable exact authorities, and StandardInChIKey can collapse the pinned neutral/zwitterion distinction.',
                   'Abstract silence in fengycin/difficidin papers is not proof of absent bacilysin data; later CS93 nondetection is not proof of universal nonproduction.',
                   'Exact versioned MIBiG JSON status was checked. Latest unversioned alias resolution or absence of a newer version is not independently established.',
                   'Sequence context is limited to a partial CS93 cluster and the requested FZB42 genomic window with rebased feature coordinates; it is not genome-wide absence evidence.',
                   'Native label gate includes documented skips/warnings; these are not exact-structure certification. Both records remain SEEDED.',
                   'Review continuation only: no records, inventories, curation tables, generated pages, old reviews or GitHub objects were changed. Proposed actions are not completed curation.',
                   'Campaign denominator remains3115; partial observations do not count as scientific completions. All prior findings and182 inherited access limits are preserved alongside ten new limits.'
               ], notes=['Canonical validation/save/check results are recorded after authoring, not retroactively claimed as pre-save checks.',
                         'The optional method/citation gaps are explicit unknown assessments rather than confirmed false claims or automatic withdrawals.'])
    path = WORK / (slug + '-review.yaml')
    with path.open('x') as handle:
        yaml.dump(doc, handle, Dumper=NoAliases, sort_keys=False, allow_unicode=False, width=90)
    index.append(dict(path=str(path), review_id=rid, target_id=tid, issue_key=finding['issue_key'], severity=finding['severity']))
with (WORK / 'draft-index.json').open('x') as handle:
    json.dump(index, handle, indent=2)
print(json.dumps(index, indent=2))
