import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, rdMolDescriptors

work=Path(__file__).parent
samples=[]
for slug in ('bacilysin-2','bacilysin'):
    doc=json.loads((work/(slug+'-resolved.json')).read_text())
    s=doc['chemical_structure']
    samples.append((slug,s['smiles'],s['standard_inchi_key'],s['standard_inchi']))
npa=json.loads((work/'npatlas15870.json').read_text())
samples.append(('NPAtlas:NPA015870',npa['smiles'],npa['inchikey'],npa['inchi']))
chebi=json.loads((work/'chebi72687.json').read_text())['default_structure']
samples.append(('CHEBI:72687',chebi['smiles'],chebi['standard_inchi_key'],chebi['standard_inchi']))
pub=json.loads((work/'pubchem160175.json').read_text())['PropertyTable']['Properties'][0]
samples.append(('PubChem:160175',pub['SMILES'],pub['InChIKey'],pub['InChI']))
patterns={'amide':'[CX3](=[OX1])[NX3]','acid':'[CX3](=[OX1])[OX2H1]','anhydride':'[CX3](=[OX1])[OX2][CX3](=[OX1])','free_primary_amines':'[NX3;H2;!$(NC=O)]','epoxide':'[O;r3]1[C;r3][C;r3]1'}
result=[]
molecules={}
for name,smiles,key,inchi in samples:
    mol=Chem.MolFromSmiles(smiles)
    assert mol is not None
    assert Chem.MolToInchi(mol)==inchi and Chem.MolToInchiKey(mol)==key,name
    molecules[name]=mol
    plain=Chem.Mol(mol)
    Chem.RemoveStereochemistry(plain)
    result.append(dict(name=name,smiles=smiles,key=key,inchi_roundtrip=True,formula=rdMolDescriptors.CalcMolFormula(mol),exact_mass_Da=Descriptors.ExactMolWt(mol),charge=Chem.GetFormalCharge(mol),chiral_centers=Chem.FindMolChiralCenters(mol,includeUnassigned=True),stereo_removed_key=Chem.MolToInchiKey(plain),functional_groups={k:dict(smarts=v,matches=mol.GetSubstructMatches(Chem.MolFromSmarts(v))) for k,v in patterns.items()}))
comparisons=[]
reference=molecules['bacilysin-2']
query=Chem.Mol(reference)
Chem.RemoveStereochemistry(query)
for name in ('NPAtlas:NPA015870','CHEBI:72687','bacilysin'):
    m=molecules[name]
    mapping=m.GetSubstructMatch(query,useChirality=False)
    mapped=[]
    if mapping:
        left=dict(Chem.FindMolChiralCenters(reference,includeUnassigned=True))
        right=dict(Chem.FindMolChiralCenters(m,includeUnassigned=True))
        mapped=[dict(owner_atom=i,other_atom=mapping[i],owner_cip=cip,other_cip=right.get(mapping[i])) for i,cip in left.items()]
    comparisons.append(dict(owner='bacilysin-2',other=name,full_connectivity_match=len(mapping)==reference.GetNumAtoms(),mapped_chiral_centers=mapped))
data=dict(rdkit_version=rdBase.rdkitVersion,assessed_at=datetime.now(timezone.utc).isoformat(),samples=result,comparisons=comparisons,limitations=['CIP comparison uses graph isomorphism, not atom-index equality across input SMILES.','Database stereochemistry is not independent experimental validation. No unspecified stereocenter was filled or owner merged.'])
with (work/'chemistry.json').open('x') as h:
    json.dump(data,h,indent=2)
print(json.dumps(data,indent=2))
