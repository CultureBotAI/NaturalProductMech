import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from rdkit import Chem, rdBase

WORK = Path(__file__).parent
npa = json.loads((WORK / 'npatlas15870.json').read_text())
owner = json.loads((WORK / 'bacilysin-2-resolved.json').read_text())['chemical_structure']
reference = Chem.MolFromSmiles(owner['smiles'])
query = Chem.Mol(reference)
Chem.RemoveStereochemistry(query)
left = dict(Chem.FindMolChiralCenters(reference, includeUnassigned=True))
rows = []
variants = npa['mol_structures'] + [dict(current_structure=False,
    reference_doi=None, structure_smiles=npa['classyfire']['smiles'],
    version='embedded-ClassyFire', is_reassignment=False)]
for variant in variants:
    mol = Chem.MolFromSmiles(variant['structure_smiles'])
    assert mol is not None
    mapping = mol.GetSubstructMatch(query, useChirality=False)
    assert len(mapping) == reference.GetNumAtoms()
    right = dict(Chem.FindMolChiralCenters(mol, includeUnassigned=True))
    rows.append(dict(variant, key=Chem.MolToInchiKey(mol), mapped_centers=[
        dict(owner_atom=i, other_atom=mapping[i], owner_cip=cip, other_cip=right.get(mapping[i]))
        for i, cip in left.items()]))
result = dict(assessed_at=datetime.now(timezone.utc).isoformat(), rdkit_version=rdBase.rdkitVersion,
              input_sha256=hashlib.sha256((WORK / 'npatlas15870.json').read_bytes()).hexdigest(),
              variants=rows, limitation='Historical NPAtlas structures and classification payload are not independent experimental assignments; no figure or C4 revision direction inferred from title alone.')
with (WORK / 'reassignment-chemistry.json').open('x') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result, indent=2))
