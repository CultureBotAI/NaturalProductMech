import hashlib
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

work=Path(__file__).parent
name,url=sys.argv[1:]
def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
receipt=dict(url=url,started_at=now())
try:
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'NaturalProductMech-record-review/1.0'}),timeout=90) as r:
        data=r.read()
        receipt.update(status=r.status,final_url=r.url)
except urllib.error.HTTPError as e:
    data=e.read()
    receipt.update(status=e.code,error=str(e))
except (urllib.error.URLError,TimeoutError) as e:
    data=b''
    receipt.update(status=None,error=str(e),transport_failure=True)
receipt.update(finished_at=now(),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with (work/name).open('xb') as h:
    h.write(data)
with (work/(name+'.receipt.json')).open('x') as h:
    json.dump(receipt,h,indent=2)
print(json.dumps(receipt,indent=2))
