import csv
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml
from naturalproductmech.graph_components import read_natural_product

ROOT = Path.cwd()
WORK = Path(__file__).parent
PRIOR = Path('/private/tmp/npmech-aborycin-review-JJKFYR/review-campaign-checkpoint.json')
BASE = '9191a148302dce8d04699b8436a68b84329d20b8'
def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,value):
    with (WORK/name).open('x') as handle:
        json.dump(value,handle,indent=2)

started=now()
assert sha(PRIOR)=='bbd2ce66126e753914315f66e428fd9d1c1847e50a07fe2442449e532e032eaf'
old=json.loads(PRIOR.read_text())
assert old['base']==BASE==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
records={r['path']:r for r in old['records']}
components={c['path']:c for r in records.values() for c in r['graph_components']}
actual={str(p.relative_to(ROOT)) for d in ('data/natural_products','data/causal_graphs') for p in (ROOT/d).rglob('*.yaml')}
assert actual==records.keys()|components.keys()
for p,row in (records|components).items():
    assert sha(ROOT/p)==row['sha256'],p
for row in old['all_review_observations']:
    assert sha(ROOT/row['yaml'])==row['yaml_sha256']
    assert sha(ROOT/row['markdown'])==row['markdown_sha256']
template=yaml.safe_load((ROOT/'reviews/structured/20261013T131439Z-aborycin/review.yaml').read_text())
inputs=[p['path'] for p in template['source']['inputs'] if not p['path'].startswith('data/natural_products/amino_acids_and_peptides/aborycin')]
inputs += ['data/natural_products/amino_acids_and_peptides/'+s+'.yaml' for s in ('bacilysin-2','bacilysin')]
inputs += ['data/raw/pubchem_bioassay.tsv']
captures=[]
for slug in ('bacilysin-2','bacilysin'):
    path='data/natural_products/amino_acids_and_peptides/'+slug+'.yaml'
    assert path in old['pending_in_priority_order']
    doc=yaml.safe_load((ROOT/path).read_text())
    target=dict(target_id=doc['identifier'],path=path,label=doc['label'],record_class='NaturalProductRecord',kind='generated',owner_paths=template['targets'][0]['owner_paths'])
    save(slug+'-targets.json',dict(targets=[target]))
    command=[sys.executable,'scripts/record_review.py','inspect','--targets',str(WORK/(slug+'-targets.json'))]
    for p in inputs:
        command += ['--input',p]
    begin=now()
    result=subprocess.run(command,text=True,capture_output=True)
    out=WORK/(slug+'-inspect.json')
    with out.open('x') as h:
        h.write(result.stdout)
    with (WORK/(slug+'-inspect.stderr')).open('x') as h:
        h.write(result.stderr)
    save(slug+'-inspect.receipt.json',dict(command=command,started_at=begin,finished_at=now(),exit_code=result.returncode,log=str(out),log_sha256=sha(out)))
    assert result.returncode==0,result.stderr
    resolved=read_natural_product(ROOT/path)
    save(slug+'-resolved.json',resolved)
    captures.append(dict(slug=slug,path=path,target_id=doc['identifier'],sha256=sha(ROOT/path),key=doc['chemical_structure']['standard_inchi_key'],graphs=len(resolved.get('causal_graphs',[])),components=doc.get('causal_graph_refs',[])))
keys={r['key'] for r in captures}
rows={}
for name in ('mibig_compounds','lotus_occurrences','chebi_structures','chebi_origins','npclassifier','antibioticmech_inchikeys','pubchem_bioassay'):
    with (ROOT/('data/raw/'+name+'.tsv')).open() as h:
        rows[name]=[dict(line=i,**row) for i,row in enumerate(csv.DictReader(h,delimiter='\t'),2) if row.get('standard_inchi_key') in keys or (name=='chebi_structures' and 'bacilysin' in json.dumps(row).lower())]
save('source-rows.json',rows)
stop_info=old['inherited_scientific_access_stops']
stop_path=Path(stop_info['checkpoint'])
assert sha(stop_path)==stop_info['sha256']
stops=json.loads(stop_path.read_text())['access_stops_no_alternate_retrieval']+old['new_access_stops']
save('inherited-access-stops.json',stops)
terms=['bacilysin','20070370','19061923','01882','bj1180563','bf02884030','482-484.1988','antibiotics.39.888','antibiotics.40.1677','jbiotec.2008.10.015']
save('access-stop-matches.json',dict(terms=terms,matches=[s for s in stops if any(t in json.dumps(s).lower() for t in terms)],inherited_count=len(stops)))
capture=dict(base=BASE,started_at=started,finished_at=now(),captures=captures,prior_checkpoint=str(PRIOR),prior_checkpoint_sha256=sha(PRIOR),owners_verified=len(records),components_verified=len(components),prior_observations_verified=len(old['all_review_observations']),ignored_inclusive=True,previous_turn_classification='progress: two immutable aborycin observations saved and23 bundles validated; full QC passed; scientific corpus unchanged; all3115 owners and unfinished remainder preserved')
save('capture.json',capture)
print(json.dumps(capture,indent=2))
