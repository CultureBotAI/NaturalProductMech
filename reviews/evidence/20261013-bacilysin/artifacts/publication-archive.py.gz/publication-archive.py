"""One-shot archival of historical review inputs; not a replay instruction."""

import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path('/private/tmp/npmech-bacilysin-review-ixdJYA')
DEST = ROOT / 'reviews/evidence/20261013-bacilysin'
REFERENCE_ONLY = {
    'npatlas15870.json': 'NPAtlas response referenced, not redistributed.',
    'literature-metadata.json': 'Primary abstract payload referenced, not redistributed.',
    'bgc-additional-metadata.json': 'Primary abstract payload referenced, not redistributed.',
    'cs93-discovery.json': 'Primary abstract payload referenced, not redistributed.',
    'cs93-original-discovery.json': 'Primary abstract payload referenced, not redistributed.',
    'reassignment1993-crossref.json': 'Publisher metadata payload referenced, not redistributed.',
}


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


checkpoint = json.loads((WORK / 'review-campaign-checkpoint.json').read_text())
assert digest((WORK / 'review-campaign-checkpoint.json').read_bytes()) == (
    '7ac7abc75d1ad8bd83b0a7dc1d50d899b8296d70291a58cfc0cc698a9f9d1390')
artifacts = []
reference_only = []
(DEST / 'artifacts').mkdir(parents=True, exist_ok=False)


def retain(path, name=None, blob=None):
    blob = path.read_bytes() if blob is None else blob
    stored = gzip.compress(blob, mtime=0)
    relative = 'artifacts/' + (name or path.name) + '.gz'
    with (DEST / relative).open('xb') as handle:
        handle.write(stored)
    row = dict(original_path=str(path), path=relative, bytes=len(blob),
               sha256=digest(blob), stored_bytes=len(stored), stored_sha256=digest(stored))
    artifacts.append(row)
    return row


for path in sorted(WORK.iterdir()):
    if not path.is_file():
        continue
    if path.name in REFERENCE_ONLY:
        receipt = json.loads(path.with_name(path.name + '.receipt.json').read_text())
        assert digest(path.read_bytes()) == receipt['sha256']
        reference_only.append(dict(original_path=str(path), sha256=receipt['sha256'],
                                   bytes=path.stat().st_size, source_url=receipt['url'],
                                   accessed_at=receipt['finished_at'], reason=REFERENCE_ONLY[path.name]))
    else:
        retain(path)

for original, name, expected in [
    (checkpoint['prior_checkpoint'], 'prior-checkpoint.json', checkpoint['prior_checkpoint_sha256']),
    (checkpoint['inherited_scientific_access_stops']['checkpoint'], 'inherited-checkpoint.json',
     checkpoint['inherited_scientific_access_stops']['sha256']),
]:
    path = Path(original)
    assert digest(path.read_bytes()) == expected
    retain(path, name)
retain(Path(__file__), 'publication-archive.py')

reviews = []
for slug in ['bacilysin', 'bacilysin-2']:
    review_id = '20261013T140252Z-' + slug
    path = Path('reviews/structured') / review_id / 'review.yaml'
    markdown = path.with_suffix('.md')
    doc = yaml.safe_load((ROOT / path).read_text())
    owner = doc['targets'][0]['path']
    raw = subprocess.check_output(['git', 'show', f"{doc['source']['git_revision']}:{owner}"])
    retain(Path(owner), slug + '-raw.yaml', raw)
    by_hash = {}
    for row in artifacts + reference_only:
        by_hash.setdefault(row['sha256'], []).append(row)
    snapshots = []
    for evidence in doc['evidence']:
        if 'snapshot_sha256' not in evidence:
            continue
        matches = by_hash[evidence['snapshot_sha256']]
        assert len(matches) == 1, (evidence['evidence_id'], matches)
        snapshots.append(dict(evidence_id=evidence['evidence_id'],
                              original_path=matches[0]['original_path'],
                              sha256=evidence['snapshot_sha256']))
    reviews.append(dict(review_id=review_id, path=str(path), sha256=digest((ROOT / path).read_bytes()),
                        markdown=str(markdown), markdown_sha256=digest((ROOT / markdown).read_bytes()),
                        source_base=doc['source']['git_revision'], evidence_snapshots=snapshots))

manifest = dict(
    format_version=1, recorded_at=datetime.now(timezone.utc).isoformat(),
    corpus_base=checkpoint['base'], pr='https://github.com/CultureBotAI/NaturalProductMech/pull/908',
    publication_issue=909, scientific_issues=[910, 911],
    checkpoint=str(WORK / 'review-campaign-checkpoint.json'),
    artifacts=artifacts, reference_only_sources=reference_only, reviews=reviews,
    runtime_directories=['/private/tmp/npmech-rdkit-2026.03.5/share/RDKit',
                         '/private/tmp/npmech-rdkit-2026.03.5/bin/python'],
    snapshot_note='owner hashes raw YAML; resolved-owner hashes JSON; inventories hashes selected rows. '
                  'Historical source bases are retained, not silently advanced to publication HEAD.',
)
with (DEST / 'manifest.json').open('x') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(artifacts=len(artifacts), reference_only=len(reference_only),
                     stored_bytes=sum(row['stored_bytes'] for row in artifacts)), indent=2))
