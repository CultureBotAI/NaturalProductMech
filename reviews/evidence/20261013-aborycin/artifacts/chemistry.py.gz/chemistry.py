import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, rdMolDescriptors

work = Path(__file__).parent
patterns = {
    'amide_carbonyls': '[CX3](=[OX1])[NX3]',
    'carboxylic_acids': '[CX3](=[OX1])[OX2H1]',
    'anhydrides': '[CX3](=[OX1])[OX2][CX3](=[OX1])',
    'free_amino_cysteine': '[NX3;H2;!$(NC=O)]-[CX4H1]-[CX4H2]-[SX2]-[SX2]',
    'disulfides': '[SX2]-[SX2]',
}
rows = []
for slug in ('aborycin-2', 'aborycin'):
    doc = json.loads((work / (slug + '-resolved.json')).read_text())
    s = doc['chemical_structure']
    mol = Chem.MolFromSmiles(s['smiles'])
    assert mol is not None
    inchi = Chem.MolToInchi(mol)
    key = Chem.MolToInchiKey(mol)
    assert inchi == s['standard_inchi'] and key == s['standard_inchi_key']
    plain = Chem.Mol(mol)
    Chem.RemoveStereochemistry(plain)
    row = dict(slug=slug, stored_key=key, inchi_exact=True, formula=rdMolDescriptors.CalcMolFormula(mol), formal_charge=Chem.GetFormalCharge(mol), exact_mass_Da=Descriptors.ExactMolWt(mol), chiral_centers=Chem.FindMolChiralCenters(mol, includeUnassigned=True), stereo_removed_key=Chem.MolToInchiKey(plain))
    row['functional_groups'] = {name: dict(smarts=smarts, atom_matches=mol.GetSubstructMatches(Chem.MolFromSmarts(smarts))) for name, smarts in patterns.items()}
    rows.append(row)

# The sequence is a deposited precursor core, not a new experimental assignment.
core = 'CLGIGSCNDFAGCGYAVVCFW'
linear = Chem.MolFromSequence(core)
atoms = {}
for atom in linear.GetAtoms():
    info = atom.GetPDBResidueInfo()
    atoms[(info.GetResidueNumber(), info.GetName().strip())] = atom.GetIdx()
ed = Chem.RWMol(linear)
nterm = atoms[(1, 'N')]
asp_carbonyl = atoms[(9, 'CG')]
hydroxyl = next(a.GetIdx() for a in ed.GetAtomWithIdx(asp_carbonyl).GetNeighbors() if a.GetAtomicNum() == 8 and ed.GetBondBetweenAtoms(a.GetIdx(), asp_carbonyl).GetBondType() == Chem.BondType.SINGLE)
ed.AddBond(nterm, asp_carbonyl, Chem.BondType.SINGLE)
for a, b in ((1, 13), (7, 19)):
    ed.AddBond(atoms[(a, 'SG')], atoms[(b, 'SG')], Chem.BondType.SINGLE)
ed.RemoveAtom(hydroxyl)
expected = ed.GetMol()
Chem.SanitizeMol(expected)
Chem.RemoveStereochemistry(expected)
expected_key = Chem.MolToInchiKey(expected)
result = dict(rdkit_version=rdBase.rdkitVersion, assessed_at=datetime.now(timezone.utc).isoformat(), input_hashes={s: hashlib.sha256((work / (s + '-resolved.json')).read_bytes()).hexdigest() for s in ('aborycin-2', 'aborycin')}, owners=rows, derived_connectivity=dict(core_sequence=core, source='NZ_MKCP01000039.1 CDS22746..22874, precursor last21 residues; 1994 DOI abstract Cys1-N to Asp9 side-chain closure and Cys1-Cys13/Cys7-Cys19 disulfides', method='RDKit MolFromSequence, RWMol bond edits, sanitize, RemoveStereochemistry', key=expected_key, smiles=Chem.MolToSmiles(expected), formula=rdMolDescriptors.CalcMolFormula(expected), matches_aborycin2=expected_key == rows[0]['stereo_removed_key'], matches_aborycin=expected_key == rows[1]['stereo_removed_key'], limitation='Computational topology check only; does not establish absolute configuration, lasso threading, experimental assignment or replacement authority'))
with (work / 'chemistry.json').open('x') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result, indent=2))
