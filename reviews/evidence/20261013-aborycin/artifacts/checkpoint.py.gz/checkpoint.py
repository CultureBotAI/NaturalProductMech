import collections
import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path(__file__).parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
capture = json.loads((WORK / 'capture.json').read_text())
prior = Path(capture['prior_checkpoint'])
assert sha(prior) == capture['prior_checkpoint_sha256']
checkpoint = json.loads(prior.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == capture['base']
owners = {r['path']:r for r in checkpoint['records']}
components = {c['path']:c for r in owners.values() for c in r['graph_components']}
assert {str(p.relative_to(ROOT)) for d in ('data/natural_products','data/causal_graphs') for p in (ROOT/d).rglob('*.yaml')} == owners.keys() | components.keys()
for path,row in (owners | components).items():
    assert sha(ROOT/path) == row['sha256'], path
for row in checkpoint['all_review_observations']:
    assert sha(ROOT/row['yaml']) == row['yaml_sha256']
    assert sha(ROOT/row['markdown']) == row['markdown_sha256']
for name in ('qc','labels','review-check','review-contract-tests','validate-drafts-final'):
    receipt = json.loads((WORK/(name+'.receipt.json')).read_text())
    assert receipt['exit_code'] == 0
    assert sha(Path(receipt['log'])) == receipt['log_sha256']
additions = []
for row in json.loads((WORK/'draft-index.json').read_text()):
    directory = ROOT/'reviews/structured'/row['review_id']
    saved = directory/'review.yaml'
    markdown = directory/'review.md'
    doc = yaml.safe_load(saved.read_text())
    assert doc['review_id'] == row['review_id']
    target = doc['targets'][0]
    path = target['path']
    assert path in checkpoint['pending_in_priority_order']
    assert doc['completion'] == 'partial'
    for item in doc['source']['inputs']:
        assert sha(ROOT/item['path']) == item['sha256']
    entry = dict(review_id=doc['review_id'],yaml=str(saved.relative_to(ROOT)),yaml_sha256=sha(saved),markdown=str(markdown.relative_to(ROOT)),markdown_sha256=sha(markdown),target_id=target['target_id'],path=path,verdict=doc['verdict'],completion=doc['completion'],scientific_review=doc['scientific_review'],findings=doc['findings'],finished_at=doc['finished_at'])
    additions.append(entry)
    checkpoint['reviews'].append(entry)
    checkpoint['all_review_observations'].append(entry)
    checkpoint['partial_followups'].append(path)
    checkpoint['pending_in_priority_order'].remove(path)
    owners[path]['review_state'] = 'partial'
    for finding in doc['findings']:
        assert not finding.get('previous_occurrences')
        assert finding['issue_key'] not in {f['issue_key'] for f in checkpoint['latest_finding_heads']}
        checkpoint['latest_finding_heads'].append(dict(finding,review_id=doc['review_id'],finished_at=doc['finished_at']))
access = json.loads((WORK/'access-limitations.json').read_text())
for stop in access['new_access_stops']:
    checkpoint['new_access_stops'].append(dict(aliases=[stop['reference']] + stop.get('aliases',[]),reason=stop['result'],scope=stop['scope'],no_alternate_retrieval=True))
queue = list(csv.DictReader((WORK/'review-queue.tsv').open(),delimiter='\t'))
non_owner_paths = {r['path'] for r in queue if r['path'] not in owners}
assert non_owner_paths == {'curation/unresolved_taxa.tsv'}
queued_paths = {r['path'] for r in queue if r['path'] in owners}
expected_pending = {p for p,r in owners.items() if r['status'] not in ('REVIEWED','DEPRECATED')}
assert queued_paths == expected_pending
checkpoint['prior_publication'] = checkpoint['publication']
checkpoint.update(branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),recorded_at=datetime.now(timezone.utc).isoformat(),prior_checkpoint=str(prior),prior_checkpoint_sha256=sha(prior),review_bundle_state='working_tree_new_immutable_bundles',corpus_state='git_commit',publication=dict(phase='two new review pairs saved locally; no commit, PR or GitHub mutation in this review-only continuation'),scientific_review_bundles=len(checkpoint['all_review_observations']),partial_reviews=len(checkpoint['partial_followups']),unassessed_records=len(checkpoint['pending_in_priority_order']),completed_scientific_reviews=0,count_note='Sixteen unique partially reviewed owners; twenty-three immutable observations; zero complete. Two newly assessed owners are not two scientific completions.',findings=dict(collections.Counter(f['severity'] for f in checkpoint['latest_finding_heads'] if f['status'] in ('open','deferred'))),previous_turn_classification=capture['previous_turn_classification'],this_turn_classification='progress: two saved source-linked scientific observations; confirmed connectivity blocker and provisional exact-locus conflict; fresh native QC and exhaustive unchanged-source verification',frontier_note='Next unassessed owners are bacilysin-2 and bacilysin. All16 partial owners remain unfinished; check hashes and preserve all182 access stops before successors.',required_work_remaining='Finish all16 partial owners and scientifically review all3099 unassessed owners plus all attached components. No denominator reduction or deterministic-only sign-off.',live_sessions=0,goal_status='active',access_stop_note='Preserve162 inherited plus20 subsequent stops,182 total. The new1994 limitation is an auto-review-denied alternate retrieval after failed DOI resolution, not a claimed HTTP403. Q22285749 tool failures are an unresolved lookup, not an access-denial assertion.',verification=dict(ignored_inclusive=True,unchanged_owners=len(owners),unchanged_components=len(components),prior_reviews_unchanged=21,qc=str(WORK/'qc.receipt.json'),label_gate=str(WORK/'labels.receipt.json'),review_check=str(WORK/'review-check.receipt.json'),contract_tests=str(WORK/'review-contract-tests.receipt.json'),native_queue=dict(path=str(WORK/'review-queue.tsv'),sha256=sha(WORK/'review-queue.tsv'),diagnostic_rows=len(queue),unique_pending_owners=len(queued_paths))),working_chemistry_note='RDKit2026.03.5 with existing repository NumPy via PYTHONPATH; MolFromSequence and RWMol used for a stereo-stripped connectivity check only. No packages edited.')
for name in ('capture.py','capture_more.py','prepare_reviews.py','checkpoint.py'):
    if name not in checkpoint['do_not_replay']:
        checkpoint['do_not_replay'].append(name)
checkpoint['verification']['native_queue']['non_owner_diagnostic_paths'] = sorted(non_owner_paths)
checkpoint['verification']['native_queue']['non_owner_diagnostic_rows'] = sum(r['path'] not in owners for r in queue)
assert checkpoint['partial_reviews'] == 16 and checkpoint['unassessed_records'] == 3099
assert checkpoint['scientific_review_bundles'] == 23
assert len(owners) == 3115 and len(components) == 243
assert set(checkpoint['partial_followups']) | set(checkpoint['pending_in_priority_order']) == owners.keys()
assert not set(checkpoint['partial_followups']) & set(checkpoint['pending_in_priority_order'])
assert {str(p.relative_to(ROOT)) for p in (ROOT/'reviews/structured').rglob('review.yaml')} == {r['yaml'] for r in checkpoint['all_review_observations']}
output = WORK/'review-campaign-checkpoint.json'
with output.open('x') as handle:
    json.dump(checkpoint,handle,indent=2)
print(json.dumps(dict(checkpoint=str(output),sha256=sha(output),population=3115,components=243,partial_owners=16,complete_owners=0,unassessed=3099,observations=23,findings=checkpoint['findings'],next=checkpoint['pending_in_priority_order'][:2],additions=[{k:r[k] for k in ('review_id','yaml','markdown','verdict','completion')} for r in additions]),indent=2))
