import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

work = Path(__file__).parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
for slug in ('aborycin-2', 'aborycin'):
    before = json.loads((work / (slug + '-inspect.json')).read_text())
    for entry in before['source']['inputs']:
        assert sha(Path(entry['path'])) == entry['sha256']
    command = [sys.executable, 'scripts/record_review.py', 'inspect', '--targets', str(work / (slug + '-targets.json'))]
    for path in [p['path'] for p in before['source']['inputs']] + ['scripts/run_qc.py']:
        command += ['--input', path]
    start = now()
    run = subprocess.run(command, text=True, capture_output=True)
    out = work / (slug + '-inspect-final-context.json')
    with out.open('x') as handle:
        handle.write(run.stdout)
    with (work / (slug + '-inspect-final-context.stderr')).open('x') as handle:
        handle.write(run.stderr)
    with (work / (slug + '-inspect-final-context.receipt.json')).open('x') as handle:
        json.dump(dict(command=command,started_at=start,finished_at=now(),exit_code=run.returncode,log=str(out),log_sha256=sha(out),reason='Add inspected native QC command definition; all original context bytes verified unchanged before extension.'),handle,indent=2)
    assert run.returncode == 0, run.stderr
    after = json.loads(run.stdout)
    assert after['source']['git_revision'] == before['source']['git_revision']
    lookup = {p['path']:p['sha256'] for p in after['source']['inputs']}
    assert all(lookup[p['path']] == p['sha256'] for p in before['source']['inputs'])
    print(slug, 'all prior input hashes unchanged; added scripts/run_qc.py')
