import hashlib
import json
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

work = Path(__file__).parent
root = ET.parse(work / 'sequences-with-parts.xml').getroot()
records = {}
for seq in root.findall('GBSeq'):
    accession = seq.findtext('GBSeq_accession-version')
    features = []
    for f in seq.findall('./GBSeq_feature-table/GBFeature'):
        qualifiers = {}
        for q in f.findall('./GBFeature_quals/GBQualifier'):
            qualifiers.setdefault(q.findtext('GBQualifier_name'), []).append(q.findtext('GBQualifier_value'))
        intervals = []
        for interval in f.findall('./GBFeature_intervals/GBInterval'):
            low, high = interval.findtext('GBInterval_from'), interval.findtext('GBInterval_to')
            if low and high:
                intervals.append([min(int(low), int(high)), max(int(low), int(high))])
        features.append(dict(type=f.findtext('GBFeature_key'), location=f.findtext('GBFeature_location'), intervals=intervals, qualifiers=qualifiers))
    dna = seq.findtext('GBSeq_sequence').upper()
    assert len(dna) == int(seq.findtext('GBSeq_length'))
    records[accession] = dict(accession=accession, definition=seq.findtext('GBSeq_definition'), length=len(dna), dna=dna, features=features)

precursor = next(f for f in records['NZ_MKCP01000039.1']['features'] if f['type'] == 'CDS' and f['location'] == '22746..22874')
precursor_dna = records['NZ_MKCP01000039.1']['dna'][22745:22874]
reverse = precursor_dna.translate(str.maketrans('ACGT', 'TGCA'))[::-1]
summary = []
for accession, record in records.items():
    end = 34000 if accession == 'MKCP01000045.1' else 30566
    selected = [dict(f, qualifiers={k:v for k,v in f['qualifiers'].items() if k in ('locus_tag', 'old_locus_tag', 'gene', 'product', 'protein_id', 'inference', 'note')}) for f in record['features'] if f['type'] == 'CDS' and any(low <= end and high >= 18549 for low, high in f['intervals'])]
    dna = record['dna']
    matches = {strand: [i + 1 for i in range(len(dna)) if dna.startswith(query, i)] for strand, query in (('forward', precursor_dna), ('reverse_complement', reverse))}
    summary.append(dict(accession=accession, definition=record['definition'], length=record['length'], source=[f for f in record['features'] if f['type'] == 'source'], claimed_interval=[18549, end], interval_sha256=hashlib.sha256(dna[18548:end].encode()).hexdigest(), interval_features=selected, exact_precursor_nucleotide_matches=matches))
result = dict(assessed_at=datetime.now(timezone.utc).isoformat(), input_sha256=hashlib.sha256((work/'sequences-with-parts.xml').read_bytes()).hexdigest(), precursor=precursor, precursor_nucleotide_length=len(precursor_dna), records=summary, limitations=['Annotations are computational PGAP assignments, not biochemical evidence.', 'Exact 129-nt query searched across both complete deposited contigs on both strands; absence is bounded to exact sequence, not absence of all divergent lasso genes.', 'No alignment or unannotated gene prediction was performed; no cluster-coordinate replacement is authorized by this audit.'])
with (work / 'sequence-audit.json').open('x') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result, indent=2))
