import csv
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml
from naturalproductmech.graph_components import read_natural_product

ROOT = Path.cwd()
WORK = Path(__file__).parent
PRIOR = Path('/private/tmp/npmech-yersiniabactin-pr-NHM4I6/merged-review-campaign-checkpoint.json')
BASE = '9191a148302dce8d04699b8436a68b84329d20b8'

def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    with (WORK / name).open('x') as handle:
        json.dump(value, handle, indent=2)

started = now()
assert sha(PRIOR) == 'b3c863eb4143915dc9db2490b9db6b134322f07339d39e6e65536b66b4a910a4'
old = json.loads(PRIOR.read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE == old['base']
records = {r['path']: r for r in old['records']}
components = {c['path']: c for r in records.values() for c in r['graph_components']}
actual = {str(p.relative_to(ROOT)) for folder in ('data/natural_products', 'data/causal_graphs') for p in (ROOT / folder).rglob('*.yaml')}
assert actual == records.keys() | components.keys()
for name, row in (records | components).items():
    assert sha(ROOT / name) == row['sha256'], name
for row in old['all_review_observations']:
    assert sha(ROOT / row['yaml']) == row['yaml_sha256']
    assert sha(ROOT / row['markdown']) == row['markdown_sha256']
template = yaml.safe_load((ROOT / 'reviews/structured/20261013T115040Z-yersiniabactin/review.yaml').read_text())
owners = template['targets'][0]['owner_paths'] + [dict(repository='CultureBotAI/NaturalProductMech', path='curation/mibig_xref_exclusions.tsv', role='Implemented exact-row-pinned PubChem xref exclusions')]
inputs = [p['path'] for p in template['source']['inputs'] if not p['path'].startswith('data/natural_products/alkaloids/')]
inputs += ['curation/mibig_xref_exclusions.tsv', 'src/naturalproductmech/curate/structure_corrections.py', 'src/naturalproductmech/curate/xref_exclusions.py', 'src/naturalproductmech/curate/producer_strains.py']
inputs += ['data/natural_products/amino_acids_and_peptides/' + s + '.yaml' for s in ('aborycin-2', 'aborycin')]
captures = []
for slug in ('aborycin-2', 'aborycin'):
    name = 'data/natural_products/amino_acids_and_peptides/' + slug + '.yaml'
    assert name in old['pending_in_priority_order']
    doc = yaml.safe_load((ROOT / name).read_text())
    target = dict(target_id=doc['identifier'], path=name, label=doc['label'], record_class='NaturalProductRecord', kind='generated', owner_paths=owners)
    save(slug + '-targets.json', dict(targets=[target]))
    command = [sys.executable, 'scripts/record_review.py', 'inspect', '--targets', str(WORK / (slug + '-targets.json'))]
    for p in inputs:
        command += ['--input', p]
    before = now()
    result = subprocess.run(command, text=True, capture_output=True)
    output = WORK / (slug + '-inspect.json')
    with output.open('x') as handle:
        handle.write(result.stdout)
    with (WORK / (slug + '-inspect.stderr')).open('x') as handle:
        handle.write(result.stderr)
    save(slug + '-inspect.receipt.json', dict(command=command, cwd=str(ROOT), started_at=before, finished_at=now(), exit_code=result.returncode, log=str(output), log_sha256=sha(output)))
    assert result.returncode == 0, result.stderr
    resolved = read_natural_product(ROOT / name)
    save(slug + '-resolved.json', resolved)
    captures.append(dict(slug=slug, path=name, target_id=doc['identifier'], sha256=sha(ROOT / name), key=doc['chemical_structure']['standard_inchi_key'], graphs=len(resolved.get('causal_graphs', [])), components=doc.get('causal_graph_refs', [])))
keys = {r['key'] for r in captures}
source_rows = {}
for basename in ('mibig_compounds', 'lotus_occurrences', 'chebi_structures', 'chebi_origins', 'npclassifier', 'antibioticmech_inchikeys'):
    with (ROOT / ('data/raw/' + basename + '.tsv')).open() as handle:
        source_rows[basename] = [dict(line=i, **row) for i, row in enumerate(csv.DictReader(handle, delimiter='\t'), 2) if row.get('standard_inchi_key') in keys]
save('source-rows.json', source_rows)
stop_info = old['inherited_scientific_access_stops']
stop_path = Path(stop_info['checkpoint'])
assert sha(stop_path) == stop_info['sha256']
stops = json.loads(stop_path.read_text())['access_stops_no_alternate_retrieval'] + old['new_access_stops']
save('inherited-access-stops.json', stops)
terms = ['aborycin', '30795576', 'md17020127', 'jlac.199419940716']
save('access-stop-matches.json', dict(terms=terms, matches=[s for s in stops if any(t in json.dumps(s).lower() for t in terms)], inherited_count=len(stops), no_global_absence_claim=True))
capture = dict(base=BASE, started_at=started, finished_at=now(), captures=captures, prior_checkpoint=str(PRIOR), prior_checkpoint_sha256=sha(PRIOR), owners_verified=len(records), components_verified=len(components), prior_observations_verified=len(old['all_review_observations']), ignored_inclusive=True, previous_turn_classification='Administrative progress only: verified merged publication and removed empty branch; no new scientific owner coverage. Next safe action is the two unassessed aborycin records.')
save('capture.json', capture)
print(json.dumps(capture, indent=2))
