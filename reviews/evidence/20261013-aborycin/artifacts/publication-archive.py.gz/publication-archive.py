"""One-shot publication archive; historical paths are not replay instructions."""

import gzip
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path.cwd()
WORK = Path('/private/tmp/npmech-aborycin-review-JJKFYR')
DEST = ROOT / 'reviews/evidence/20261013-aborycin'
BASE = '9191a148302dce8d04699b8436a68b84329d20b8'
REFERENCE_ONLY = {
    'npatlas13246.json': 'NPAtlas response is referenced, not redistributed.',
    'original1994-crossref.json': 'Publisher abstract payload is not redistributed.',
    'paper2019-metadata.json': 'Primary abstract payload is not redistributed.',
}


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


checkpoint = json.loads((WORK / 'review-campaign-checkpoint.json').read_text())
assert checkpoint['base'] == BASE
artifacts = []
reference_only = []
(DEST / 'artifacts').mkdir(parents=True, exist_ok=False)


def retain(path, name=None):
    blob = path.read_bytes()
    stored = gzip.compress(blob, mtime=0)
    relative = 'artifacts/' + (name or path.name) + '.gz'
    with (DEST / relative).open('xb') as handle:
        handle.write(stored)
    artifacts.append(dict(original_path=str(path), path=relative, bytes=len(blob),
                          sha256=digest(blob), stored_bytes=len(stored),
                          stored_sha256=digest(stored)))


for path in sorted(WORK.iterdir()):
    if not path.is_file():
        continue
    if path.name in REFERENCE_ONLY:
        receipt = json.loads(path.with_name(path.name + '.receipt.json').read_text())
        assert digest(path.read_bytes()) == receipt['sha256']
        reference_only.append(dict(original_path=str(path), sha256=receipt['sha256'],
                                   bytes=path.stat().st_size, source_url=receipt['url'],
                                   accessed_at=receipt['finished_at'],
                                   reason=REFERENCE_ONLY[path.name]))
    else:
        retain(path)

for key, name, expected in [
    ('prior_checkpoint', 'prior-checkpoint.json', checkpoint['prior_checkpoint_sha256']),
    ('inherited_scientific_access_stops', 'inherited-checkpoint.json',
     checkpoint['inherited_scientific_access_stops']['sha256']),
]:
    original = checkpoint[key]
    path = Path(original if isinstance(original, str) else original['checkpoint'])
    assert digest(path.read_bytes()) == expected
    retain(path, name)
retain(Path(__file__), 'publication-archive.py')

reviews = []
for slug, review_id in [('aborycin-2', '20261013T131436Z-aborycin-2'),
                        ('aborycin', '20261013T131439Z-aborycin')]:
    path = Path('reviews/structured') / review_id / 'review.yaml'
    markdown = path.with_suffix('.md')
    doc = yaml.safe_load((ROOT / path).read_text())
    files = dict(owner=slug + '-resolved.json', inventories='source-rows.json',
                 chemistry='chemistry.json', paper1994='original1994-crossref.json',
                 paper2019='paper2019-metadata.json',
                 **{'sequence-source': 'sequences-with-parts.xml',
                    'sequence-audit': 'sequence-audit.json',
                    'taxonomy': 'taxonomy.xml', 'access': 'access-limitations.json'})
    files['mibig'] = 'BGC0002285.2.json' if slug == 'aborycin-2' else 'BGC0002015.4.json'
    files['xref'] = 'npatlas13246.json' if slug == 'aborycin-2' else 'pubchem136150874.json'
    snapshots = []
    for evidence in doc['evidence']:
        if 'snapshot_sha256' not in evidence:
            continue
        snapshot = WORK / files[evidence['evidence_id']]
        assert digest(snapshot.read_bytes()) == evidence['snapshot_sha256']
        snapshots.append(dict(evidence_id=evidence['evidence_id'], original_path=str(snapshot),
                              sha256=evidence['snapshot_sha256']))
    reviews.append(dict(review_id=review_id, path=str(path), sha256=digest((ROOT / path).read_bytes()),
                        markdown=str(markdown), markdown_sha256=digest((ROOT / markdown).read_bytes()),
                        evidence_snapshots=snapshots))

manifest = dict(
    format_version=1, recorded_at=datetime.now(timezone.utc).isoformat(), corpus_base=BASE,
    pr='https://github.com/CultureBotAI/NaturalProductMech/pull/904',
    publication_issue=905, open_scientific_issues=[906, 907],
    checkpoint=str(WORK / 'review-campaign-checkpoint.json'),
    artifacts=artifacts, reference_only_sources=reference_only, reviews=reviews,
    runtime_directories=['/private/tmp/npmech-rdkit-2026.03.5/share/RDKit',
                         '/private/tmp/npmech-rdkit-2026.03.5/bin/python'],
    snapshot_note='owner evidence hashes resolved JSON; inventories hashes selected TSV rows. '
                  'Raw file hashes remain source.inputs in each immutable review.',
)
with (DEST / 'manifest.json').open('x') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(artifacts=len(artifacts), reference_only=len(reference_only),
                     stored_bytes=sum(row['stored_bytes'] for row in artifacts)), indent=2))
