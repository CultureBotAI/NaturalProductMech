import json
from pathlib import Path

from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, rdMolDescriptors

W = Path(__file__).parent
assert rdBase.rdkitVersion == '2026.03.5'
source = json.loads((W/'source-rows.json').read_text())
acetyl = Chem.MolFromSmarts('[CH3][CX3](=[#8])[#7]~[#8]')
formyl = Chem.MolFromSmarts('[CX3H1](=[#8])[#7]~[#8]')
results = []


def inspect(label, smiles, expected_key=None, expected_inchi=None):
    mol = Chem.MolFromSmiles(smiles)
    assert mol is not None, label
    inchi, key = Chem.MolToInchi(mol), Chem.MolToInchiKey(mol)
    if expected_key:
        assert key == expected_key, (label,key,expected_key)
    if expected_inchi:
        assert inchi == expected_inchi, label
    centers = Chem.FindMolChiralCenters(mol, includeUnassigned=True)
    no_isotope = Chem.Mol(mol)
    for atom in no_isotope.GetAtoms():
        atom.SetIsotope(0)
    no_stereo_or_isotope = Chem.Mol(no_isotope)
    Chem.RemoveStereochemistry(no_stereo_or_isotope)
    row = dict(label=label,smiles=smiles,inchi=inchi,key=key,
               formula=rdMolDescriptors.CalcMolFormula(mol),formal_charge=Chem.GetFormalCharge(mol),
               exact_mass=Descriptors.ExactMolWt(mol),chiral_centers=centers,
               specified_centers=sum(c!='?' for _,c in centers), unspecified_centers=sum(c=='?' for _,c in centers),
               atoms=len(mol.GetAtoms()),fragments=len(Chem.GetMolFrags(mol)),
               iron_atoms=[dict(index=a.GetIdx(),isotope=a.GetIsotope(),charge=a.GetFormalCharge()) for a in mol.GetAtoms() if a.GetAtomicNum()==26],
               isotope_atoms=[dict(element=a.GetSymbol(),index=a.GetIdx(),isotope=a.GetIsotope()) for a in mol.GetAtoms() if a.GetIsotope()],
               n_acetyl_hydroxamate=len(mol.GetSubstructMatches(acetyl)), n_formyl_hydroxamate=len(mol.GetSubstructMatches(formyl)),
               de_isotoped_key=Chem.MolToInchiKey(no_isotope),
               no_stereo_or_isotope_key=Chem.MolToInchiKey(no_stereo_or_isotope))
    results.append(row)
    return row


for slug,bgc in (('ferrichrome-2','BGC0000900.5'),('ferrichrome','BGC0000901.5')):
    d=json.loads((W/(slug+'-resolved.json')).read_text())
    s=d['chemical_structure']
    row=inspect(slug,s['smiles'],s['standard_inchi_key'],s['standard_inchi'])
    assert d['chemical_structure']['stereo_complete'] == (row['unspecified_centers']==0)
    live=json.loads((W/(bgc+'.json')).read_text())['compounds'][0]
    assert Chem.MolToInchiKey(Chem.MolFromSmiles(live['structure']))==row['key']
for row in source['chebi_structures']:
    inspect(row['chebi_id'],row['smiles'],row['standard_inchi_key'])
payload=dict(rdkit_version=rdBase.rdkitVersion,results=results,
             normalization_note='Removing isotopes and/or stereochemistry is a diagnostic computation only, not an authorized correction or equivalence assertion. Standard InChI may disconnect metal coordination bonds; raw SMILES fragment counts are not alone chemical-identity evidence.')
with (W/'chemistry-v2.json').open('x') as f:
    json.dump(payload,f,indent=2)
print(json.dumps(payload,indent=2))
