import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from naturalproductmech.graph_components import read_natural_product
from naturalproductmech.curate.structure_corrections import row_digest

R = Path.cwd()
W = Path(__file__).parent
P = Path('/private/tmp/npmech-compound3-review-2EX0Ug')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


started = now()
prior_path = P / 'review-campaign-checkpoint.json'
assert sha(prior_path) == '574ee60f7aff2a85fd9bb0090989b66d3c1fe2d86fc78e1b0494f7a1bf530f4b'
prior = json.loads(prior_path.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == prior['base']
owners = {r['path']: r for r in prior['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
assert {str(p.relative_to(R)) for folder in ('data/natural_products', 'data/causal_graphs')
        for p in (R / folder).rglob('*.yaml')} == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(R / path) == row['sha256'], path
for row in prior['all_review_observations']:
    assert sha(R / row['yaml']) == row['yaml_sha256']
    assert sha(R / row['markdown']) == row['markdown_sha256']
stops = prior['access_stops_no_alternate_retrieval']
assert len(stops) == 195
with (W / 'inherited-access-stops.json').open('x') as f:
    json.dump(stops, f, indent=2)
tokens = ('25062661','jp2003125779','ja01468a020','bd306272','dj389528','bgc0000900','bgc0000901')
matches = [s for s in stops if any(t in json.dumps(s).lower() for t in tokens)]
with (W / 'access-stop-matches.json').open('x') as f:
    json.dump(dict(checked_at=now(), aliases=tokens, checked_count=len(stops), matches=matches), f, indent=2)
assert not matches, matches
previous = json.loads((P / 'compound-3-inspect-final.json').read_text())
contexts = [r['path'] for r in previous['source']['inputs'] if not r['path'].startswith('data/natural_products/') or r['path'].endswith('PATHS.tsv')]
selected = prior['pending_in_priority_order'][:2]
assert [Path(p).name for p in selected] == ['ferrichrome-2.yaml','ferrichrome.yaml']
captures = []
keys = set()
for path in selected:
    doc = read_natural_product(R / path)
    slug = Path(path).stem
    keys.add(doc['chemical_structure']['standard_inchi_key'])
    target = dict(target_id=doc['identifier'], path=path, label=doc['label'], record_class='NaturalProductRecord',
                  kind='generated', owner_paths=previous['targets'][0]['owner_paths'])
    for owner in target['owner_paths']:
        if owner['path'] == 'curation/mibig_xref_exclusions.tsv':
            owner['role'] = 'Implemented complete-row-pinned PubChem and NPAtlas exclusions'
    with (W / (slug + '-targets.json')).open('x') as f:
        json.dump(dict(targets=[target]), f, indent=2)
    with (W / (slug + '-resolved.json')).open('x') as f:
        json.dump(doc, f, indent=2)
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(W / (slug + '-targets.json'))]
    for context in sorted(set(contexts + selected + [g['path'] for g in owners[path]['graph_components']])):
        command += ['--input', context]
    receipt = dict(command=command, started_at=now())
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    inspection = json.loads(result.stdout)
    for inp in inspection['source']['inputs']:
        assert hashlib.sha256(subprocess.check_output(['git','show',base+':'+inp['path']])).hexdigest() == inp['sha256']
    output = W / (slug + '-inspect.json')
    with output.open('x') as f:
        f.write(result.stdout)
    receipt.update(finished_at=now(),exit_code=0,log=str(output),log_sha256=sha(output))
    with (W / (slug + '-inspect.receipt.json')).open('x') as f:
        json.dump(receipt,f,indent=2)
    captures.append(dict(slug=slug,path=path,target_id=doc['identifier'],key=doc['chemical_structure']['standard_inchi_key'],
                         sha256=sha(R/path),components=owners[path]['graph_components']))
rows = {}
for name in ('mibig_compounds','npclassifier','lotus_occurrences','chebi_structures','chebi_origins','antibioticmech_inchikeys','pubchem_bioassay'):
    with (R/'data/raw'/(name+'.tsv')).open() as f:
        rows[name] = [dict(line=i,source_row_sha256=row_digest(row),**row)
                      for i,row in enumerate(csv.DictReader(f,delimiter='\t'),2)
                      if row.get('standard_inchi_key') in keys or 'ferrichrom' in ' '.join(row.values()).lower()]
with (W/'source-rows.json').open('x') as f:
    json.dump(rows,f,indent=2)
report = dict(started_at=started,finished_at=now(),base=base,captures=captures,owners_verified=3115,
              components_verified=243,prior_observations_verified=29,ignored_inclusive=True,
              previous_turn_classification='progress: three saved reviews, one completed assessment with findings and two partials',
              prior_checkpoint=str(prior_path),prior_checkpoint_sha256=sha(prior_path),
              exact_git_tree_inputs_verified=True,source_row_counts={n:len(r) for n,r in rows.items()})
with (W/'capture.json').open('x') as f:
    json.dump(report,f,indent=2)
print(json.dumps(report,indent=2))
