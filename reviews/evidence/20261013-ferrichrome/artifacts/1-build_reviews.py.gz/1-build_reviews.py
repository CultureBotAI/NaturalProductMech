import hashlib
import json
import shlex
from datetime import datetime, timezone
from pathlib import Path

import yaml


class NoAliasSafeDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


W = Path(__file__).parent
OLD = Path('/private/tmp/npmech-ferrichrome-review-W2MXlZ')
REPO = 'CultureBotAI/NaturalProductMech'
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
capture = json.loads((W / 'capture.json').read_text())
chem = json.loads((W / 'chemistry.json').read_text())


def owned(path, role):
    return dict(repository=REPO, path=path, role=role)


def local(eid, kind, p, locator, summary, support='supports', **extra):
    return dict(evidence_id=eid, kind=kind, reference=str(p), locator=locator,
                accessed_at=now(), support=support, summary=summary,
                snapshot_sha256=sha(p), **extra)


def remote(eid, name, kind, locator, summary, support='supports'):
    p = OLD / name
    r = json.loads((OLD / (name + '.receipt.json')).read_text())
    assert sha(p) == r['sha256']
    return dict(evidence_id=eid, kind=kind, reference=r['url'],
                locator=f"{locator}; HTTP{r['status']} capture {r['started_at']}..{r['finished_at']}; payload {p}; receipt SHA256 {sha(OLD / (name + '.receipt.json'))}",
                accessed_at=now(), support=support, summary=summary, snapshot_sha256=sha(p))


def check(label, target, summary, required=True, expected=0):
    r = json.loads((W / (label + '.receipt.json')).read_text())
    assert sha(Path(r['log'])) == r['log_sha256']
    assert r['exit_code'] == expected, (label, r)
    return dict(check_id=label, name=label, status='passed' if expected == 0 else 'failed',
                required=required, command=shlex.join(r['command']), exit_code=r['exit_code'],
                expected_exit_code=0, target_ids=[target], summary=summary,
                scope_note=f"Actual run {r['started_at']}..{r['finished_at']}; {r['log']}; SHA256 {r['log_sha256']}")


def assessment(aid, area, topic, outcome, text, evs, tid, **extra):
    return dict(assessment_id=aid, area=area, topic=topic, outcome=outcome,
                summary=text, target_ids=[tid], evidence_ids=evs, **extra)


source_owners = [owned('data/raw/mibig_compounds.tsv', 'Untouched versioned source compound, producer and locus row'),
                 owned('scripts/extract_mibig.py', 'MIBiG source extraction'),
                 owned('scripts/seed_from_sources.py', 'Generated identity and source harmonization')]
correction_owners = [owned('curation/mibig_structure_corrections.tsv', 'Guarded complete-row-pinned REPLACE_WITH_CHEBI, only after exact target adjudication'), *source_owners]
xref_owners = [owned('curation/mibig_xref_exclusions.tsv', 'Implemented complete-row-pinned literal xref exclusion'), *source_owners]

for slug, accession, a in [('ferrichrome-2', 'BGC0000900', True), ('ferrichrome', 'BGC0000901', False)]:
    inspect = json.loads((W / (slug + '-inspect.json')).read_text())
    target = inspect['targets'][0]
    tid = target['target_id']
    owner = Path(target['path'])
    d = json.loads((W / (slug + '-resolved.json')).read_text())
    c = next(r for r in chem['results'] if r['label'] == slug)
    key = c['key']
    findings = []
    if a:
        findings.append(dict(finding_id='F1', issue_key='mibig-BGC0000900-compound-1-ferrichrome-constitution',
                             category='identity', severity='blocker', status='open', certainty='confirmed',
                             title='The stored C26 N-formyl structure is not the ferrichrome named by the record',
                             description='The owner and versioned MIBiG source encode C26H43N9O12 with two N-acetyl hydroxamates and one N-formyl hydroxamate, without iron. Authoritative ferrichrome is a C27 iron chelate with three N-acetyl groups; its metal-free ligand is also C27 and triacetylated. This is not merely metal dissociation, isotope choice or unspecified stereochemistry. PubChem90658043 agrees with the imported graph, but agreement among database depictions does not establish the named natural-product identity. The conflict affects exact product attribution; it does not prove this C26 molecule cannot exist or select the patent product/replacement automatically.',
                             target_ids=[tid], field_paths=['label', 'chemical_structure', 'biosynthesis_origin', 'producer_organisms', 'biosynthetic_gene_clusters'],
                             evidence_ids=['owner', 'inventories', 'chemistry', 'mibig', 'chebi-ferrichrome', 'chebi-deferrichrome', 'pubchem'],
                             owner_paths=correction_owners,
                             rule_id='review-checklist:Identity/Structure; docs/HARMONIZATION.md:The unit of the corpus is a structure',
                             native_severity='blocker', normalization_reason='A confirmed constitution/name conflict makes the individual-structure record denote the wrong named molecule.'))
        findings.append(dict(finding_id='F2', issue_key='mibig-BGC0000900-compound-1-pubchem-644246-nonexact',
                             category='grounding', severity='major', status='open', certainty='confirmed',
                             title='PubChem644246 is a nonexact chemical cross-reference',
                             description='The live PubChem response resolves CID644246 to GGUNGDGGXMHBMJ-HCMAANCNSA-N, C27H42FeN9O12 with explicit 55Fe and three undefined centers, not this C26 iron-free key. CID90658043 is exact for the stored graph. The nonexact CID is inherited from the complete BGC0000900:1 row; it needs its own disposition even if the larger identity conflict remains unresolved. No current owner assay is falsely attributed: the pinned assay rows are empty placeholders, not measurements.',
                             target_ids=[tid], field_paths=['xrefs[1]'],
                             evidence_ids=['owner', 'inventories', 'chemistry', 'pubchem'], owner_paths=xref_owners,
                             rule_id='review-checklist:Equivalence; docs/HARMONIZATION.md:an xref means the same structure',
                             native_severity='major', normalization_reason='A false exact-equivalence edge changes downstream structure joins without independently selecting the correct product identity.'))
    else:
        findings.append(dict(finding_id='F1', issue_key='mibig-BGC0000901-compound-1-unqualified-55Fe-origin',
                             category='evidence', severity='major', status='open', certainty='provisional',
                             title='Exact 55Fe product attribution is unqualified and experimentally unresolved',
                             description='The stored graph and exact PubChem644246 match encode iron-55, with three undefined peptide stereocenters. The name, NATURAL_PRODUCT origin, producer and locus assertions do not qualify that isotopic form. The abstract identifies ferrichrome production but does not establish this isotope-specific product; the cited full paper returned403. The available locus patent describes gene cloning and an enzyme assay rather than characterizing this isotope-specific complete product. The isotope encoding is confirmed, but whether it is an erroneous source drawing, an experimental tracer or an intentionally scoped product remains provisional. Do not call the constitution wrong, delete an exact xref, silently remove the isotope, assign missing stereochemistry, or assume the organism cannot incorporate labeled iron.',
                             target_ids=[tid], field_paths=['label', 'chemical_structure.smiles', 'biosynthesis_origin', 'producer_organisms', 'biosynthetic_gene_clusters', 'discussions'],
                             evidence_ids=['owner', 'chemistry', 'mibig', 'pubchem', 'chebi-ferrichrome', 'paper-metadata', 'paper-access', 'locus-patent'],
                             owner_paths=correction_owners + [owned(str(owner), 'Only a curator-owned cited qualification through the validated writer; not direct seeded-field edits')],
                             rule_id='review-checklist:Structure/Producer organisms/Gene clusters; exact chemical form and evidence scope',
                             native_severity='major', normalization_reason='Potentially unsupported isotope-specific natural-product attribution is material, while missing primary evidence precludes a confirmed wrong-product verdict.'))

    checks = [check(slug + '-inspect', tid, 'Canonical pre-assessment inspection captured the exact merged Git revision and input hashes.'),
              check('strict-' + slug + '-native', tid, 'The documented native strict-validator script passed for this owner; no graph components are attached.'),
              check('corpus', tid, 'Full-corpus filesystem and PATHS.tsv audit passed for all3115 owners.'),
              check('qc', tid, 'Full native QC passed: 747 tests passed, 3 skipped and 2 dependency warnings; all-owner strict validation, history/component invariants, provenance, generated site and exact reproduction passed. This run precedes saving these two reviews; their canonical checks are run afterward. Deterministic consistency is not scientific approval.'),
              check('labels', tid, 'Configured ID-label gate passed: 13434 canonical, 646 synonym and 35 exception matches, with 499 nonblocking warning mismatches and 4649 no-adapter skips. Exact chemical identity was assessed separately.'),
              check('chemistry-native', tid, 'RDKit2026.03.5 regenerated owner InChI/key, checked stereo flags, verified source-row digests and matched the live PubChem and ChEBI graphs.'),
              check('local-search', tid, 'Ignored-inclusive identifier/name/slug search covered curation, data/raw, owner/component corpus, reviews, docs, scripts, src, conf and tests.', False),
              check('queue', tid, 'Exhaustive native pending-record diagnostics regenerated to a temporary TSV; no status or tracked queue edit.', False)]
    checks += [check('strict-ferrichrome-2', tid, 'Initial just wrapper failed before validation because sandboxed uv could not access its global cache; the exact native script was then run successfully.', False, 2),
               check('chemistry', tid, 'Initial chemistry helper could not import the local package from the separate pinned runtime; adding repository src to PYTHONPATH enabled the completed run.', False, 1)]
    checks += [dict(check_id='primary-claims', name='Exact compound primary evidence', status='unavailable', required=True, target_ids=[tid],
                    evidence_ids=['occurrence-access', 'wikidata-access'] if a else ['paper-access'],
                    summary='Required occurrence primary text and secondary organism identifier remain unavailable after HTTP403.' if a else 'Required full paper and experimental isotope/strain/product mapping remain unavailable after HTTP403.'),
               dict(check_id='imodulondb', name='Structured expression-source applicability', status='not_applicable', required=False, target_ids=[tid],
                    summary='The owner names no gene/protein/regulator or transcriptomics dataset. MIBiG, taxonomy and GenBank adapters were inspected first. Contextual patent genes are not owner assertions; no iModulonDB coverage or absence claim is made.')]

    evidence = [local('owner', 'record_content', owner, 'Entire raw YAML including both history entries',
                      'One exact MINTED/SEEDED owner, not a label-level compound class. No curator discussion, pathway, activity, target, clinical, dataset, parent/congener, cross-corpus or graph assertion is present.'),
                local('resolved', 'record_content', W / (slug + '-resolved.json'), 'Complete native read_natural_product result',
                      'Resolved full mechanism agrees with the raw owner and has no inline graphs or component references.'),
                local('inventories', 'database', OLD / 'source-rows.json', f'{accession}:1 version5; complete parsed TSV rows with row_digest and line numbers',
                      ('MIBiG line983 and NPClassifier line3113; one LOTUS occurrence line10224 and two no-assay placeholders lines11457-11458. ' if a else 'MIBiG line984 and NPClassifier line677; no exact-key LOTUS occurrence or assay row. ') + 'No exact-key pinned ChEBI default or AntibioticMech join. Fresh chemistry helper reverified all selected rows against unchanged inventories.',
                      search_scope='Full structured scans of mibig_compounds, npclassifier, lotus_occurrences, chebi_structures, chebi_origins, antibioticmech_inchikeys and pubchem_bioassay; exact keys plus ferrichrom label context. Not global registry absence.'),
                local('chemistry', 'validation', W / 'chemistry.json', f'RDKit2026.03.5 result {slug} and authority comparisons',
                      f"Computed {c['formula']}, net charge {c['charge']}, monoisotopic mass {c['exact_mass']} Da; {c['specified']} specified/{c['unspecified']} undefined tetrahedral centers; acetyl/formyl hydroxamates {c['acetyl_hydroxamates']}/{c['formyl_hydroxamates']}; iron isotope list {c['iron_isotopes']}. Exact owner InChI/key roundtrip passed. Calculations are not measurements. Normalization is diagnostic, not authorized identity replacement."),
                remote('mibig', accession + '.5.json', 'database', 'compounds[0], taxonomy, loci, biosynthesis classes and legacy references',
                       'Exact active version5 chemistry, host and references match the raw row. Empty locus methods and 0..0 unspecified bounds are not experiments or real coordinates. OTHER is source asserted; questionable quality and placeholder reviewers are not scientific truth signals. No assertion this is the latest version.'),
                remote('pubchem', 'pubchem-resume.json', 'authority', 'PropertyTable.Properties for CID90658043 and CID644246',
                       'Recovered HTTP200: CID90658043 matches ZZDYFKJSJLUQON-UFYCRDLUSA-N; CID644246 matches GGUNGDGGXMHBMJ-HCMAANCNSA-N. Both formulae and exact InChIs were recomputed. Registry equivalence is not evidence for biosynthesis.', 'refutes' if a else 'supports'),
                remote('chebi-ferrichrome', 'CHEBI5019-resume.json', 'authority', 'CHEBI5019 default_structure, chemical_data, stars and definition',
                       'Live 3-star ferrichrome agrees with the pinned default graph: GGUNGDGGXMHBMJ-OCIDDWSYSA-N, C27H42FeN9O12, three specified peptide centers, no isotope label. Its three N-acetyl groups distinguish it from the C26 record. Representation of coordination is not interpreted as physical negative iron oxidation state.', 'refutes' if a else 'context_only'),
                remote('chebi-deferrichrome', 'CHEBI90132-resume.json', 'authority', 'CHEBI90132 default_structure, chemical_data, stars and definition',
                       'Live 3-star deferrichrome agrees with pinned ZFDAUYPBCXMSBF-ACRUOGEOSA-N, C27H45N9O12, three acetyl hydroxamates and no iron. It is not the C26 form. Occurrences and roles on this nonexact candidate are not transferred.', 'refutes' if a else 'context_only'),
                remote('taxonomy', 'taxonomy.xml', 'authority', 'Direct Taxon nodes5062,5061,562',
                       'NCBI resolves Aspergillus oryzae5062 and Aspergillus niger5061 at species rank with fungal lineage, and Escherichia coli562 at species rank in Bacteria. Taxonomy does not establish production or a strain.'),
                remote('genome', 'sequences.xml', 'authority', 'Exact accession-version, definition, source feature and references',
                       'BD306272.1 is9052nt from A.oryzae5062 and cites JP2003125779-A sequence10; DJ389528.1 is23114nt from A.niger5061 and cites JP2003230381-A sequence2. Neither source feature supplies a strain. Whole-sequence lengths do not specify cluster bounds.'),
                local('scope-proof', 'validation', W / 'capture.json', 'Ignored-inclusive owner/component enumeration and prior-review hashes',
                      'All3115 owners,243 components and30 predecessor review pairs match the prior merged checkpoint. Every new inspected input matches Git504e6b184. Only context change since interrupted research is the unrelated BGC0002321:4 strain row, whose diff was read.'),
                local('search', 'search', W / 'local-search.log', 'rg ignored-inclusive bounded search',
                      'Search found source inventories and exact owners but no applicable existing ferrichrome curation-table decision or prior canonical review. Complete owner parsing supports optional-field absence only within these exact files.',
                      search_scope='rg --no-ignore --hidden -l with both keys, accessions, minted IDs and ferrichrome over curation data/raw data/natural_products data/causal_graphs reviews docs scripts src conf tests. Ignored/hidden files included in those directories; external caches, Git objects and virtual environments not covered.'),
                local('qc-evidence', 'validation', W / 'qc.log', 'Full actual native QC log', 'Read-only consistency gates; results do not promote SEEDED status.'),
                local('labels-evidence', 'validation', W / 'labels.log', 'Configured full-corpus label check', 'Warnings and no-adapter skips retained; NCBITaxon names/ranks independently verified.'),
                local('queue-evidence', 'validation', W / 'queue.tsv', 'Exhaustive pending-record queue', 'All3115 owners remain in the native pending population; scientific review coverage is separately recorded.')]
    if a:
        evidence += [remote('patent', 'patent.html', 'primary_source', 'JP2003125779A description0004,0015-0025,0027-0051; prose, not visual sequence figures',
                            'The patent discusses a ferrichrome family/member rather than proving this C26 structure. It names O-1013 genomic material and a distinct1013-niaD example host; asb3 expression in E.coli tests acetylation, not whole-product biosynthesis. Japanese member spelling is not automatically equated with ferricrocin. Machine translation is imperfect.', 'partial'),
                     remote('occurrence-metadata', 'occurrence-crossref.json', 'database', 'Crossref DOI, title, authors and print date',
                            'DOI10.1021/ja01468a020 resolves to Emery/Neilands, Structure of the Ferrichrome Compounds, JACS83:1626-1628,1961. The2002 online date is not a new experiment. Metadata contains no inspected experimental occurrence evidence.', 'partial')]
        for eid, name in [('occurrence-access', 'occurrence.html'), ('wikidata-access', 'wikidata-Q25419.json')]:
            e = remote(eid, name, 'search', 'Error response only', 'HTTP403; primary content/identifier response not inspected. No alternate route attempted.', 'unknown')
            e['search_scope'] = 'Single preserved exact-URL request and receipt; stopped after403. Does not imply the claim is false or absent from the source.'
            evidence.append(e)
    else:
        evidence += [remote('paper-metadata', 'PMID25062661.json', 'primary_source', 'EuropePMC exact PMID25062661/DOI10.1093/bfgp/elu026 abstract and metadata',
                            'The abstract reports A.niger HPLC ferrichrome production, coprogenB and effects of sreA deletion. It does not establish55Fe-specific product identity, exact strain/locus attribution or a method for DJ389528.1. Full text is subscription-only with no PMCID.', 'partial'),
                     remote('locus-patent', 'patent-DJ389528.html', 'primary_source', 'JP2003230381A prose0017-0027,0031-0045 including table1; cited independently by GenBank, not an alternate copy of the denied paper',
                            'The locus patent identifies IFO4067 genomic DNA for nsb1/nsb2 cloning and tests expressed nsb1 enzyme activity in E.coli. This is useful strain/locus context, not complete55Fe product characterization. General family/member terminology and machine-translation errors require care; sequence figures were not visually audited.', 'partial')]
        e = remote('paper-access', 'paper25062661.html', 'search', 'Error response only', 'Publisher HTTP403; no full-text experimental sections or supporting information inspected and no alternate retrieval.', 'unknown')
        e['search_scope'] = 'Preserved exact DOI request10.1093/bfgp/elu026; stopped after403. Abstract remains a narrower source, not a substitute for the missing experiment.'
        evidence.append(e)

    assessments = []
    def add(aid, area, topic, outcome, text, evs, **extra):
        assessments.append(assessment(aid, area, topic, outcome, text, evs, tid, **extra))
    add('identity', 'identity', 'Exact named chemical form', 'concern',
        'Confirmed C26/N-formyl versus C27/triacetyl identity conflict; neither removing iron nor choosing the other same-label owner solves it. The exact patent product and any replacement remain unselected.' if a else
        'Ferrichrome constitution is compatible after diagnostic removal of isotope/stereo information, but the exact55Fe form and experimental stereochemistry are unverified. This is not a confirmed wrong-constitution finding.',
        ['owner', 'chemistry', 'chebi-ferrichrome', 'chebi-deferrichrome', 'pubchem'],
        dimensions=[dict(name='exact-key', value=key, definition='Stored owner identity, not a proposed replacement', evidence_ids=['owner','chemistry']),
                    dict(name='stereo-resolution', value=f"{c['specified']} specified/{c['unspecified']} undefined centers", definition='Encoded tetrahedral resolution, not experimental assignment', evidence_ids=['chemistry'])])
    add('representation', 'consistency', 'Internal chemistry and pinned source representation', 'supported',
        'Stored SMILES, InChI and key roundtrip and agree with versioned MIBiG. stereo_complete correctly describes the encoded peptide centers. Formal charge and coordination depiction do not independently establish biological chemical form.', ['owner','chemistry','mibig'])
    add('grounding', 'grounding', 'Minted rationale and exact registry links', 'concern' if a else 'supported',
        'Minted status is consistent with the absence of an exact pinned ChEBI default key. CID90658043 is exact; CID644246 is nonexact and needs withholding. No parent/congener assertion is present.' if a else
        'Minted status is consistent with no exact pinned ChEBI key. CID644246 is an exact graph match and should not be excluded merely because the isotope-specific natural-origin attribution is unresolved. CHEBI5019 is not an exact replacement.', ['owner','inventories','pubchem','chemistry'])
    add('classification', 'representation', 'Chemical filing and asserted taxonomy facets', 'supported',
        'NPClassifier@2026-09-07 cyclic-peptide/oligopeptide and nonglycoside output matches the pinned row and AMINO_ACIDS_AND_PEPTIDES filing. OTHER remains the database BGC class rather than a predicted enzyme class. FUNGAL producer grouping matches NCBI.' + (' OTHER_BACTERIAL correctly groups the E.coli occurrence without converting it to a producer.' if a else ''), ['owner','inventories','mibig','taxonomy'])
    add('origin', 'scope', 'Natural versus engineered exact-product origin', 'concern',
        'NATURAL_PRODUCT is database-derived, not classifier-derived, but exact chemical attribution inherits F1. Host engineering and enzyme expression in a patent do not by themselves establish biosynthesis of the stored complete molecule. Do not silently reclassify as engineered either.', ['owner','mibig','chemistry', 'patent' if a else 'locus-patent'])
    add('producer', 'evidence', 'Producer identity, strain and evidence tier', 'unknown',
        'The species taxon is correct and SOURCE_ASSERTION faithfully reflects the database rather than an isolation experiment. Patent source-strain context must be reconciled only after exact product identity; do not infer species-wide experimental production or copy an expression host into native producers. The sequence source alone supplies no strain.',
        ['owner','mibig','taxonomy','genome', 'patent' if a else 'locus-patent'],
        dimensions=[dict(name='taxon-rank',value='species',definition='NCBI rank for the record producer identifier',evidence_ids=['taxonomy']),
                    dict(name='producer-grade',value='SOURCE_ASSERTION',definition='Native imported grade; not upgraded',evidence_ids=['owner','mibig'])])
    add('cluster', 'evidence', 'Exact BGC version, locus and compound-level method', 'unknown',
        'Active version5 and genome accession are confirmed. Unstated source bounds/methods correctly remain omitted/CLUSTER_UNSTATED. Independent genomic and enzyme context does not establish the complete exact product or justify upgrading a whole locus. Gene coordinates in live to_add annotations were not owner-curated claims.',
        ['owner','mibig','genome','patent' if a else 'locus-patent'])
    add('occurrence', 'scope', 'Detection versus biosynthesis', 'unknown' if a else 'not_applicable',
        'The LOTUS triple is faithfully imported as DATABASE_ASSERTION occurrence, not production. NCBITaxon562 is correct, but the1961 experiment and Q25419 linkage remain unavailable. Neither assume the paper proves production nor declare the occurrence false from its title.' if a else
        'No occurrence is asserted by this exact owner. No occurrence from the C26 record or from a nonexact ChEBI candidate is transferred.',
        ['owner','inventories','taxonomy','occurrence-metadata','occurrence-access','wikidata-access'] if a else ['owner','inventories'])
    add('activity', 'scope', 'Pure-compound assays, summaries and molecular targets', 'supported',
        'No activity, molecular target or activity summary is asserted. The uncited MIBiG siderophore annotation was not elevated into an assay. Empty PubChem no-assay placeholders do not mean inactivity; patent enzyme assays are not bioactivity of the complete natural product.', ['owner','inventories','mibig'])
    add('mechanism', 'graph', 'Pathway and complete causal/assembly mechanism', 'not_applicable',
        'No pathway steps, protein examples, inline graphs or external components are attached. Optional absence is not a scientific defect; generic family biosynthesis must not be fabricated as this structure-specific mechanism.', ['owner','resolved'])
    add('optional', 'completeness', 'Clinical, dataset, cross-corpus and relationship claims', 'not_applicable',
        'No clinical status, dataset list, related_records, parent_compounds or congener_of assertions require review. The embedded BGC accession was checked separately. Exact-key sibling scans were bounded to the committed inventory, not a global absence claim.', ['owner','inventories','resolved'])
    add('audit', 'provenance', 'History, sign-off and maintained owners', 'supported',
        'Both events are seeding events and SEEDED is appropriate. No curator discussion resolves the new concerns. Reviews do not mutate native status or history. Future source corrections use implemented pinned tables or a separately tested transform; decisions.tsv is reserved and not consumed.', ['owner','scope-proof','search','qc-evidence'])

    actions = [dict(action_id='A1', description='Adjudicate the exact chemical form before any structure migration. First add a cited curator-owned conflict/qualification through the validated writer. Only use REPLACE_WITH_CHEBI after a unique experimental target, destination ownership, source row and target row are independently established; otherwise retain the explicit unresolved conflict. Never transfer old-key occurrences, assays or graphs automatically.',
                    finding_ids=['F1'], target_ids=[tid], owner_paths=correction_owners + [owned(str(owner), 'Guarded curator-owned discussion and audit event only')],
                    generator='scripts/seed_from_sources.py, only after separately authorized curation and canary; never direct seeded-field edits',
                    acceptance_checks=['Inspect primary exact product/isotope/stereo evidence; distinguish named compound from family and native from engineered context.',
                                       'Recompute InChI/key with pinned RDKit, audit source joins and all old-key claims, and inspect guarded one-record canary.',
                                       'Run just validate-strict, just verify-reproduction, just verify-corpus, just validate-products and just qc; preserve history and component ownership.'])]
    if a:
        actions.append(dict(action_id='A2', description='For the current unchanged structure, withhold literal pubchem:644246 through the implemented complete-row-pinned xref exclusion for BGC0000900:1. Preserve exact pubchem:90658043 and raw provenance. If A1 instead changes structure, adjudicate xrefs with that migration; concurrent structure replacement and xref exclusion are intentionally incompatible.', finding_ids=['F2'], target_ids=[tid], owner_paths=xref_owners,
                            generator='scripts/seed_from_sources.py guarded canary and regeneration',
                            acceptance_checks=['Pin complete source row SHA25678b115cce5a8a133196da68d8dd417a75f5a8f42aa0344a1d3c76d389e58f791 and cite the live PubChem identity evidence.',
                                               'Generated xrefs omit644246 but retain90658043 for the unchanged owner; source-conflict provenance remains visible.',
                                               'Test source-row drift, duplicate decisions and incompatible corrections; run strict validation, reproduction and full QC.']))
    actions.append(dict(action_id='A3', description='Complete unavailable primary checks through authorized access or user-provided source text, and reconcile source-strain context after identity adjudication. Preserve species identifiers and conservative producer/locus grades until exact evidence justifies a change.', finding_ids=[], target_ids=[tid],
                        owner_paths=[owned('curation/mibig_producer_strains.tsv','Implemented source-row-pinned strain qualification when exact context is established'), *source_owners],
                        acceptance_checks=['Inspect the complete cited study and exact product/strain/experimental context; preserve each403 limitation until resolved.',
                                           'Do not reuse family-level claims, isotope tracers, or expression-host enzyme activity as native complete-product proof.']))

    finished = now()
    rid = datetime.fromisoformat(finished.replace('Z','+00:00')).strftime('%Y%m%dT%H%M%SZ') + '-' + slug
    source = inspect['source']
    source['state'] = 'git_commit'
    review = dict(schema_version='1.0.0', review_id=rid, kind='record', repository=REPO,
                  title=f'Ferrichrome ({accession}.5): exact-form scientific review', started_at=capture['started_at'], finished_at=finished,
                  reviewer=dict(identity='Codex',kind='agent',independence='self_review',independence_basis='Same assistant/thread as corpus research and prior curation; not independent human sign-off.'),
                  skill='.claude/skills/review-yaml-record/SKILL.md', completion='partial', verdict='needs_curation', scientific_review=True,
                  summary='One confirmed blocker in named chemical identity and one confirmed major nonexact PubChem link; primary occurrence verification remains unavailable.' if a else
                          'One provisional major concern about unqualified55Fe-specific product attribution. Internal chemistry and PubChem equivalence are correct; missing primary full text prevents final experimental identity/strain/locus assessment.',
                  source=source, targets=[target],
                  scope=dict(description='One exact owner at merged504e6b184; campaign denominator remains3115 owners and243 components.',selection='Next exact pending owner in the exhaustive identity-priority campaign, not a sample.',coverage='partial',population_size=1,reviewed_target_ids=[tid],exclusions=[dict(target='Other3114 owners',reason='Outside this immutable single-record observation; retained in the campaign checkpoint.')]),
                  checks=checks, evidence=evidence, assessments=assessments, findings=findings, actions=actions,
                  limitations=['Required primary material is unavailable; partial coverage is not a whole-record scientific pass or eligibility for REVIEWED.',
                               'Prior research captures are preserved with original retrieval times; fresh merged-state inspection and computation revalidated unchanged inputs. The unrelated strain-table addition was separately read.',
                               'Earlier PubChem503 and ChEBI504 events remain in the historical202-access-limitation ledger. One new-turn retry recovered both PubChem IDs and both ChEBI authorities; these four identities are no longer currently unavailable. No403 endpoint was retried via an alternate path.',
                               'Patent prose and tabular text were inspected; DNA/protein sequence images and original Japanese legal document facsimiles were not visually audited. Machine translation can misname organisms, enzymes and ferrichrome-family members.',
                               'Optional absent fields are not counted as deficiencies. No full-corpus scientific conclusion follows from native consistency tests.',
                               'The initial uv wrapper and isolated-runtime import failures are retained as execution history; their native-script retries passed.',
                               'Temporary evidence paths are session-local; stable source URLs, source-row digests, exact Git inputs and payload hashes are included. No scientific record, status, history, raw inventory, generated page or GitHub object was changed.'],
                  notes=['Full objective remains review of every3115 owner and its attached components; unassessed and partial work is not redefined as complete.',
                         'Original interrupted research began2026-10-13T15:35:47.926332Z. This review uses actual resumed assessment timestamps, not a backdated filename.'])
    for inp in source['inputs']:
        assert sha(Path(inp['path'])) == inp['sha256']
    output = W / (rid + '.yaml')
    with output.open('x') as f:
        yaml.dump(review, f, Dumper=NoAliasSafeDumper, sort_keys=False, allow_unicode=False, width=92)
    print(output)
