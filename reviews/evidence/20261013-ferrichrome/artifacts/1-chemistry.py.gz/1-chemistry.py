import csv
import hashlib
import json
from pathlib import Path

from rdkit import Chem, rdBase
from rdkit.Chem import Descriptors, rdMolDescriptors
from naturalproductmech.curate.structure_corrections import row_digest

W = Path(__file__).parent
OLD = Path('/private/tmp/npmech-ferrichrome-review-W2MXlZ')
assert rdBase.rdkitVersion == '2026.03.5'
keys = {'ZZDYFKJSJLUQON-UFYCRDLUSA-N', 'GGUNGDGGXMHBMJ-HCMAANCNSA-N'}
source = json.loads((OLD / 'source-rows.json').read_text())
for name, expected in source.items():
    with (Path('data/raw') / (name + '.tsv')).open() as f:
        actual = [dict(line=i, source_row_sha256=row_digest(r), **r)
                  for i, r in enumerate(csv.DictReader(f, delimiter='\t'), 2)
                  if r.get('standard_inchi_key') in keys or 'ferrichrom' in ' '.join(r.values()).lower()]
    assert actual == expected, name
results = []
acetyl = Chem.MolFromSmarts('[CH3][CX3](=[#8])[#7]~[#8]')
formyl = Chem.MolFromSmarts('[CX3H1](=[#8])[#7]~[#8]')


def inspect(label, smiles, key, inchi=None):
    m = Chem.MolFromSmiles(smiles)
    assert m is not None
    assert Chem.MolToInchiKey(m) == key, label
    if inchi:
        assert Chem.MolToInchi(m) == inchi, label
    no_isotope = Chem.Mol(m)
    for a in no_isotope.GetAtoms():
        a.SetIsotope(0)
    no_stereo = Chem.Mol(no_isotope)
    Chem.RemoveStereochemistry(no_stereo)
    centers = Chem.FindMolChiralCenters(m, includeUnassigned=True)
    results.append(dict(label=label, key=key, formula=rdMolDescriptors.CalcMolFormula(m),
                        inchi=Chem.MolToInchi(m), charge=Chem.GetFormalCharge(m),
                        exact_mass=Descriptors.ExactMolWt(m), chiral_centers=centers,
                        specified=sum(c != '?' for _, c in centers), unspecified=sum(c == '?' for _, c in centers),
                        iron_isotopes=[a.GetIsotope() for a in m.GetAtoms() if a.GetAtomicNum() == 26],
                        acetyl_hydroxamates=len(m.GetSubstructMatches(acetyl)),
                        formyl_hydroxamates=len(m.GetSubstructMatches(formyl)),
                        no_isotope_key=Chem.MolToInchiKey(no_isotope),
                        no_stereo_or_isotope_key=Chem.MolToInchiKey(no_stereo)))


for slug, bgc in [('ferrichrome-2', 'BGC0000900.5'), ('ferrichrome', 'BGC0000901.5')]:
    d = json.loads((W / (slug + '-resolved.json')).read_text())
    s = d['chemical_structure']
    inspect(slug, s['smiles'], s['standard_inchi_key'], s['standard_inchi'])
    assert s['stereo_complete'] == (results[-1]['unspecified'] == 0)
    live = json.loads((OLD / (bgc + '.json')).read_text())['compounds'][0]
    inspect(bgc, live['structure'], s['standard_inchi_key'])
for r in source['chebi_structures']:
    inspect('pinned-' + r['chebi_id'], r['smiles'], r['standard_inchi_key'])
for cid in (5019, 90132):
    live = json.loads((OLD / ('CHEBI' + str(cid) + '-resume.json')).read_text())
    s = live['default_structure']
    pinned = next(r for r in source['chebi_structures'] if r['chebi_id'] == live['chebi_accession'])
    assert s['smiles'] == pinned['smiles'] and s['standard_inchi_key'] == pinned['standard_inchi_key']
    inspect('live-' + live['chebi_accession'], s['smiles'], s['standard_inchi_key'], s['standard_inchi'])
for r in json.loads((OLD / 'pubchem-resume.json').read_text())['PropertyTable']['Properties']:
    inspect('pubchem:' + str(r['CID']), r['SMILES'], r['InChIKey'], r['InChI'])
payload = dict(rdkit_version=rdBase.rdkitVersion, results=results,
               inventory_rows_reverified=True,
               note='Masses are computed Da, not measurements. Isotope/stereo stripping is diagnostic only. InChI disconnects coordination; raw formal charges are representational, not oxidation-state inference.')
with (W / 'chemistry.json').open('x') as f:
    json.dump(payload, f, indent=2)
print(json.dumps(payload, indent=2))
