import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from naturalproductmech.graph_components import read_natural_product

R = Path.cwd()
W = Path(__file__).parent
OLD = Path('/private/tmp/npmech-ferrichrome-review-W2MXlZ')
CP = Path('/private/tmp/npmech-compound3-pr-4lLMj6/review-campaign-checkpoint.json')
now = lambda: datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

started = now()
prior = json.loads(CP.read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == prior['base'] == '504e6b18472feaa68e45b2f53293330e9a7e13bf'
owners = {r['path']: r for r in prior['records']}
components = {g['path']: g for r in owners.values() for g in r['graph_components']}
assert len(owners) == 3115 and len(components) == 243
assert {str(p.relative_to(R)) for folder in ('data/natural_products', 'data/causal_graphs')
        for p in (R / folder).rglob('*.yaml')} == owners.keys() | components.keys()
for path, row in (owners | components).items():
    assert sha(R / path) == row['sha256'], path
assert len(prior['all_review_observations']) == 30
for row in prior['all_review_observations']:
    assert sha(R / row['yaml']) == row['yaml_sha256']
    assert sha(R / row['markdown']) == row['markdown_sha256']
source_receipts = []
for p in OLD.glob('*.receipt.json'):
    receipt = json.loads(p.read_text())
    body = OLD / p.name.removesuffix('.receipt.json')
    if 'url' in receipt:
        assert sha(body) == receipt['sha256'], body
        source_receipts.append(dict(receipt=str(p), receipt_sha256=sha(p), **receipt))
changed = []
for slug in ('ferrichrome-2', 'ferrichrome'):
    old = json.loads((OLD / (slug + '-inspect.json')).read_text())
    target = old['targets'][0]
    with (W / (slug + '-targets.json')).open('x') as f:
        json.dump(dict(targets=[target]), f, indent=2)
    doc = read_natural_product(R / target['path'])
    assert doc == json.loads((OLD / (slug + '-resolved.json')).read_text())
    with (W / (slug + '-resolved.json')).open('x') as f:
        json.dump(doc, f, indent=2)
    command = ['.venv/bin/python', 'scripts/record_review.py', 'inspect', '--targets', str(W / (slug + '-targets.json'))]
    for inp in old['source']['inputs']:
        command += ['--input', inp['path']]
        if sha(R / inp['path']) != inp['sha256']:
            changed.append(dict(path=inp['path'], old_sha256=inp['sha256'], new_sha256=sha(R / inp['path'])))
    receipt = dict(command=command, started_at=now())
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    for inp in data['source']['inputs']:
        assert hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + inp['path']])).hexdigest() == inp['sha256']
    output = W / (slug + '-inspect.json')
    with output.open('x') as f:
        f.write(result.stdout)
    receipt.update(finished_at=now(), exit_code=0, log=str(output), log_sha256=sha(output))
    with (W / (slug + '-inspect.receipt.json')).open('x') as f:
        json.dump(receipt, f, indent=2)
assert {r['path'] for r in changed} == {'curation/mibig_producer_strains.tsv'}
report = dict(started_at=started, finished_at=now(), base=base, owners_verified=3115,
              components_verified=243, prior_observations_verified=30, ignored_inclusive=True,
              previous_goal_turn_classification='no review-coverage progress: verified previous publication and removed an empty branch; next safe action is to finish ferrichrome reviews',
              prior_checkpoint=str(CP), prior_checkpoint_sha256=sha(CP), changed_context=changed,
              reassessment='Read the new BGC0002321:4 APC1.2 strain row and complete diff; it does not target either ferrichrome source row.',
              reused_research=str(OLD), source_receipts=source_receipts)
with (W / 'capture.json').open('x') as f:
    json.dump(report, f, indent=2)
print(json.dumps({k:v for k,v in report.items() if k != 'source_receipts'}, indent=2))
