import copy
import csv
import hashlib
import json
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import yaml

W = Path(__file__).parent
OLD = Path('/private/tmp/npmech-ferrichrome-review-W2MXlZ')
CP = Path('/private/tmp/npmech-compound3-pr-4lLMj6/review-campaign-checkpoint.json')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prior = json.loads(CP.read_text())
p = copy.deepcopy(prior)
assert sha(CP) == '36ff55529724864d506b920a71d4606036d7a3b2e8af07a2b5682e764468424d'
records = {r['path']: r for r in p['records']}
components = {c['path']: c for r in records.values() for c in r['graph_components']}
assert len(records) == 3115 and len(components) == 243
actual = {str(f) for folder in ('data/natural_products','data/causal_graphs') for f in Path(folder).rglob('*.yaml')}
assert actual == records.keys() | components.keys()
for path, r in (records | components).items():
    assert sha(Path(path)) == r['sha256'], path
for r in p['all_review_observations']:
    assert sha(Path(r['yaml'])) == r['yaml_sha256']
    assert sha(Path(r['markdown'])) == r['markdown_sha256']
new = []
for draft in sorted(W.glob('2026*-ferrichrome*.yaml')):
    d = yaml.safe_load(draft.read_text())
    folder = Path('reviews/structured') / d['review_id']
    yp, mp = folder / 'review.yaml', folder / 'review.md'
    if not yp.exists():
        continue
    assert yaml.safe_load(yp.read_text()) == d
    target = d['targets'][0]
    row = dict(review_id=d['review_id'], yaml=str(yp), yaml_sha256=sha(yp),
               markdown=str(mp), markdown_sha256=sha(mp), target_id=target['target_id'], path=target['path'],
               verdict=d['verdict'], completion=d['completion'], scientific_review=d['scientific_review'],
               findings=d['findings'], finished_at=d['finished_at'])
    assert records[row['path']]['review_state'] == 'unassessed'
    records[row['path']]['review_state'] = 'partial'
    new.append(row)
    p['reviews'].append(row)
    p['all_review_observations'].append(row)
    p['partial_followups'].append(row['path'])
    for finding in d['findings']:
        assert not any(f['issue_key'] == finding['issue_key'] for f in p['latest_finding_heads'])
        p['latest_finding_heads'].append(dict(**finding, review_id=d['review_id'], finished_at=d['finished_at']))
assert len(new) == 2
p['new_bundle_whitespace_checks'] = []
for row in new:
    for field in ('yaml', 'markdown'):
        command = ['git', 'diff', '--no-index', '--check', '/dev/null', row[field]]
        result = subprocess.run(command, capture_output=True, text=True)
        assert result.returncode in (0, 1) and not result.stdout and not result.stderr
        p['new_bundle_whitespace_checks'].append(dict(command=command, exit_code=result.returncode,
                                                     result='No whitespace diagnostics; exit1 denotes added-file difference under --no-index.'))
assert len(p['all_review_observations']) == 32
assert len({r['path'] for r in p['reviews']}) == 23
assert {str(f) for f in Path('reviews/structured').rglob('review.yaml')} == {r['yaml'] for r in p['all_review_observations']}
assert {str(f) for f in Path('reviews/structured').rglob('review.md')} == {r['markdown'] for r in p['all_review_observations']}
queue = list(csv.DictReader((W / 'queue.tsv').open(), delimiter='\t'))
qpaths = {r['path'] for r in queue}
assert records.keys() <= qpaths
base = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert base == p['base']
p.update(branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
         recorded_at=datetime.now(timezone.utc).isoformat(), prior_checkpoint=str(CP), prior_checkpoint_sha256=sha(CP),
         previous_turn_classification='No new review coverage: previous publication verification and empty branch cleanup. Revalidated corpus and resumed the next exact owners.',
         this_turn_classification='Progress: two new immutable exact-owner scientific reviews; source retrieval recovery changed xref adjudication.',
         scientific_review_bundles=32, partial_reviews=22, completed_scientific_reviews=1, unassessed_records=3092,
         count_note='32 observations cover23 owners: one historical completed full assessment and22 partial owners, leaving3092 unassessed. Scoped successor dispositions do not erase historical full assessments. All3115 native owners remain SEEDED.',
         new_reviews=new, review_bundle_state='30 prior committed bundles plus2 new uncommitted immutable bundles',
         scientific_inputs_unchanged=True, live_sessions=0,
         required_work_remaining='Review all3092 unassessed owners and their attached components; finish22 partial owner assessments and retain all unresolved finding heads. No corpus or component scope was removed.',
         frontier_note='Next exact owners: myxochromide-a.yaml and myxochromide-a-2.yaml. Ferrichrome remains partial; do not treat saved review as curation or experimental approval.',
         publication='No commit, push, PR, issue or merge performed in this review-only goal turn.',
         findings=dict(Counter(f['severity'] for f in p['latest_finding_heads'] if f['status'] in ('open','deferred'))),
         queue_verification=dict(rows=len(queue), owner_count=len(qpaths & records.keys()), non_owner_paths=sorted(qpaths-records.keys()),path=str(W/'queue.tsv'),sha256=sha(W/'queue.tsv')))
p['pending_in_priority_order'] = [s for s in p['pending_in_priority_order'] if s not in {r['path'] for r in new}]
assert len(p['pending_in_priority_order']) == 3092
assert p['findings'] == {'blocker':7,'major':8}
assert Counter(r['status'] for r in p['records']) == {'SEEDED':3115}
assert len(p['access_stops_no_alternate_retrieval']) == 202
p['access_stop_note'] = '202 historical access observations retained, not202 current authorization denials. Two PubChem503 and two ChEBI504 limitations recovered on one bounded later-turn official retry. Publisher DOI10.1021/ja01468a020, DOI10.1093/bfgp/elu026 and WikidataQ25419 still403; no alternate retrieval.'
p['access_recovery_observations'] = []
for name in ('pubchem-resume.json','CHEBI5019-resume.json','CHEBI90132-resume.json'):
    receipt = OLD / (name+'.receipt.json')
    r = json.loads(receipt.read_text())
    assert r['status'] == 200 and sha(OLD/name) == r['sha256']
    p['access_recovery_observations'].append(dict(receipt=str(receipt),receipt_sha256=sha(receipt),**r))
p['unpublished_research_handoff'].update(saved_reviews=2,status='Interrupted research completed as two saved partial local reviews; scientific inputs unchanged.',next_step='Use the new review bundles and recovery receipts rather than stale unavailable-PubChem conclusions.')
p['prior_verification'] = prior['verification']
p['verification'] = {}
for receipt in sorted(W.glob('*.receipt.json')):
    r = json.loads(receipt.read_text())
    assert sha(Path(r['log'])) == r['log_sha256']
    p['verification'][receipt.stem] = dict(receipt=str(receipt),receipt_sha256=sha(receipt),**r)
for required in ('qc','labels','canonical','contract','save-ferrichrome','save-ferrichrome-2','validate-reviews-final'):
    assert p['verification'][required+'.receipt']['exit_code'] == 0, required
p['do_not_replay'] = ['All current-turn helper/fetch/check/save commands are terminal and use exclusive output names. Read receipts; use a new workspace/label for any deliberate rerun.']
p['verification_reuse_note'] = 'Fresh full QC and label gates cover all3115 unchanged scientific owners at504e6b184. Later reviews may cite these as prior executed checks only after verifying relevant inputs still match; never present reuse as a fresh run. New review bundles still require fresh canonical validation and immutable-contract checks.'
p['initial_unsaved_draft_failures'] = ['First temporary drafts emitted PyYAML anchors and were rejected before persistence. The temporary builder now suppresses aliases; final drafts validated and were saved normally. Original failed drafts and validation receipt are retained in this workspace.']
with (W / 'review-campaign-checkpoint.json').open('x') as f:
    json.dump(p,f,indent=2)
print(json.dumps({k:p[k] for k in ['base','branch','population','graph_components','scientific_review_bundles','partial_reviews','completed_scientific_reviews','unassessed_records','findings','queue_verification','frontier_note']},indent=2))
print('checkpoint_sha256',sha(W/'review-campaign-checkpoint.json'))
