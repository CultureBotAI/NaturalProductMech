"""Preserve immutable review evidence without republishing publisher payloads."""

import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml

ROOT = Path.cwd()
WORKS = [Path('/private/tmp/npmech-ferrichrome-review-W2MXlZ'),
         Path('/private/tmp/npmech-ferrichrome-resume-mXOYL5')]
DEST = ROOT / 'reviews/evidence/20261013-ferrichrome'
artifacts, references = [], []


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def retain(path, name, raw=None):
    raw = path.read_bytes() if raw is None else raw
    stored = gzip.compress(raw, mtime=0)
    relative = 'artifacts/' + name + '.gz'
    with (DEST / relative).open('xb') as handle:
        handle.write(stored)
    artifacts.append(dict(original_path=str(path), path=relative, bytes=len(raw),
                          sha256=digest(raw), stored_bytes=len(stored), stored_sha256=digest(stored)))


(DEST / 'artifacts').mkdir(parents=True, exist_ok=False)
for index, work in enumerate(WORKS):
    for path in sorted(work.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        receipt_path = path.with_name(path.name + '.receipt.json')
        receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
        if 'url' in receipt and (receipt.get('status') != 200 or path.suffix == '.html'
                                 or path.name in {'PMID25062661.json', 'occurrence-crossref.json'}):
            assert digest(path.read_bytes()) == receipt['sha256']
            references.append(dict(original_path=str(path), sha256=receipt['sha256'],
                                   bytes=path.stat().st_size, source_url=receipt['url'],
                                   accessed_at=receipt['finished_at'],
                                   reason='Publisher/patent text, metadata or error payload; reference-only.'))
        else:
            retain(path, f'{index}-' + path.name)

checkpoint_path = WORKS[1] / 'review-campaign-checkpoint.json'
checkpoint = json.loads(checkpoint_path.read_text())
assert digest(checkpoint_path.read_bytes()) == '0e6f2c5ec7316ff240e7dac81c871325b0c5b7b770c67023a06bb0c0a3ebad9d'
prior = Path(checkpoint['prior_checkpoint'])
assert digest(prior.read_bytes()) == checkpoint['prior_checkpoint_sha256']
retain(prior, 'prior-checkpoint.json')
retain(Path(__file__), 'archive.py')
reviews = []
for rid in ['20261013T170121Z-ferrichrome-2', '20261013T170122Z-ferrichrome']:
    path = Path('reviews/structured') / rid / 'review.yaml'
    markdown = path.with_suffix('.md')
    doc = yaml.safe_load(path.read_text())
    owner = doc['targets'][0]['path']
    raw = subprocess.check_output(['git', 'show', f"{doc['source']['git_revision']}:{owner}"])
    retain(Path(owner), rid + '-raw.yaml', raw)
    snapshots = []
    for evidence in doc['evidence']:
        if 'snapshot_sha256' not in evidence:
            continue
        matches = [row for row in artifacts + references if row['sha256'] == evidence['snapshot_sha256']]
        assert matches, evidence['evidence_id']
        exact = [row for row in matches if row['original_path'] == evidence['reference']]
        match = (exact or matches)[0]
        snapshots.append(dict(evidence_id=evidence['evidence_id'], original_path=match['original_path'],
                              sha256=evidence['snapshot_sha256']))
    reviews.append(dict(review_id=rid, path=str(path), sha256=digest(path.read_bytes()),
                        markdown=str(markdown), markdown_sha256=digest(markdown.read_bytes()),
                        source_base=doc['source']['git_revision'], evidence_snapshots=snapshots))

manifest = dict(format_version=1, recorded_at=datetime.now(timezone.utc).isoformat(),
                corpus_base=checkpoint['base'], pr=917, issues=[918, 919, 920, 921],
                checkpoint=str(checkpoint_path), artifacts=artifacts,
                reference_only_sources=references, reviews=reviews,
                runtime_directories=['/private/tmp/npmech-rdkit-2026.03.5/share/RDKit',
                                     '/private/tmp/npmech-rdkit-2026.03.5/bin/python'],
                snapshot_note='Historical sources, executions and full campaign scope retained unchanged. '
                              'A later disposition does not replace the original scientific assessment.')
with (DEST / 'manifest.json').open('x') as handle:
    json.dump(manifest, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(artifacts=len(artifacts), reference_only=len(references),
                     stored_bytes=sum(r['stored_bytes'] for r in artifacts))))
